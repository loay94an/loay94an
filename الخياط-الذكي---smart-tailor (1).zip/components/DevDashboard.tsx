
import React, { useState } from 'react';
import { Fabric, FabricColor, StyleItem, PricingRule, Order, BrandingSettings, SectionConfig, ActivityLog, Gender, GarmentStyle, User, UserRole, Occasion } from '../types';
import jsPDF from 'jspdf';
import { StatsDashboard } from './StatsDashboard';
import { Firestore, doc, setDoc, deleteDoc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../firebase';

interface Props {
  fabrics: Fabric[];
  setFabrics: (f: Fabric[]) => void;
  styles: StyleItem[];
  setStyles: (s: StyleItem[]) => void;
  colors: FabricColor[];
  setColors: (c: FabricColor[]) => void;
  pricing: PricingRule[];
  setPricing: (p: PricingRule[]) => void;
  orders: Order[];
  setOrders: (o: Order[]) => void;
  branding: BrandingSettings;
  setBranding: (b: BrandingSettings) => void;
  config: SectionConfig;
  setConfig: (c: SectionConfig) => void;
  onClose: () => void;
  activityLogs: ActivityLog[];
  currentUser: User;
  allUsers: User[];
  onAddUser: (username: string, password: string, role: UserRole) => void;
  onUpdateUserRole: (userId: string, newRole: UserRole) => void;
  onDeleteUser: (userId: string) => void;
  onLogout: () => void;
  db: Firestore;
}

type ModalType = 'FABRIC' | 'STYLE' | 'COLOR' | 'PRICING' | 'USER' | null;

export const DevDashboard: React.FC<Props> = ({ 
  fabrics, setFabrics, styles, setStyles, colors, setColors, pricing, setPricing,
  orders, setOrders, branding, setBranding, config, setConfig, onClose, activityLogs,
  currentUser, allUsers, onAddUser, onUpdateUserRole, onDeleteUser, onLogout, db
}) => {
  const [activeTab, setActiveTab] = useState<'BRANDING' | 'LOGS' | 'PRICING' | 'FABRICS' | 'STYLES' | 'COLORS' | 'ORDERS' | 'CONFIG' | 'USER_MANAGEMENT'>('BRANDING');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  
  // CRUD Modal State
  const [modalType, setModalType] = useState<ModalType>(null);
  const [editingItem, setEditingItem] = useState<any>(null); // Generic holder for the item being edited
  const [isUploading, setIsUploading] = useState(false);

  const exportLogs = () => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text("سجل نشاطات النظام", 105, 20, { align: 'center' });
    doc.setFontSize(10);
    activityLogs.forEach((log, i) => {
       doc.text(`${new Date(log.timestamp).toLocaleString()} - ${log.action}: ${log.details}`, 14, 40 + (i * 10));
    });
    doc.save("activity_log.pdf");
  };

  const handleSidebarToggle = () => setIsSidebarOpen(!isSidebarOpen);
  const handleTabClick = (tab: any) => {
    setActiveTab(tab);
    setIsSidebarOpen(false);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>, fieldName: string) => {
    if (!e.target.files?.[0]) return;
    
    const file = e.target.files[0];
    setIsUploading(true);

    // Try Firebase Upload First
    if (storage) {
        const storageRef = ref(storage, `uploads/${modalType?.toLowerCase()}/${Date.now()}_${file.name}`);
        try {
          await uploadBytes(storageRef, file);
          const url = await getDownloadURL(storageRef);
          setEditingItem((prev: any) => ({ ...prev, [fieldName]: url }));
          setIsUploading(false);
          return;
        } catch (error) {
          console.warn("Firebase upload failed, falling back to local Base64:", error);
        }
    }

    // Fallback: Local Base64 (Robust for mobile/offline)
    const reader = new FileReader();
    reader.onloadend = () => {
        setEditingItem((prev: any) => ({ ...prev, [fieldName]: reader.result as string }));
        setIsUploading(false);
    };
    reader.onerror = () => {
        alert("فشل قراءة الملف محلياً.");
        setIsUploading(false);
    };
    reader.readAsDataURL(file);
  };

  // --- CRUD Handlers ---

  const handleDelete = async (type: 'FABRIC' | 'STYLE' | 'COLOR' | 'PRICING', id: string) => {
    if (!window.confirm("هل أنت متأكد من حذف هذا العنصر؟ لا يمكن التراجع عن هذا الإجراء.")) return;

    try {
      if (type === 'FABRIC') {
        if (db) await deleteDoc(doc(db, 'fabrics', id)); // Sync Cloud
        setFabrics(fabrics.filter(i => i.id !== id)); // Sync Local
      }
      if (type === 'STYLE') {
        if (db) await deleteDoc(doc(db, 'styles', id));
        setStyles(styles.filter(i => i.id !== id));
      }
      if (type === 'COLOR') {
        if (db) await deleteDoc(doc(db, 'colors', id));
        setColors(colors.filter(i => i.id !== id));
      }
      if (type === 'PRICING') {
        if (db) await deleteDoc(doc(db, 'pricing', id));
        setPricing(pricing.filter(i => i.styleId !== id));
      }
    } catch (error) {
      console.error("Error deleting item:", error);
      alert("حدث خطأ أثناء الحذف من قاعدة البيانات السحابية، لكن تم الحذف محلياً.");
    }
  };

  const openModal = (type: ModalType, item?: any) => {
    setModalType(type);
    if (item) {
      setEditingItem({ ...item }); // Edit mode (clone)
    } else {
      // Add mode - Initialize default empty objects
      if (type === 'FABRIC') {
        setEditingItem({
          id: `fab-${Date.now()}`,
          name: '', description: '', color: '#ffffff', thickness: 'medium', material: '',
          image: '', properties: { stretch: 'متوسطة', breathability: 'متوسطة', durability: 'عالية' },
          physics: { mass: 1.0, stiffness: 0.5, damping: 0.5 }
        });
      }
      if (type === 'STYLE') {
        setEditingItem({
          id: `style-${Date.now()}`,
          label: '', icon: '👗', description: '', occasion: 'DAILY', season: 'ALL', gender: Gender.FEMALE, image: ''
        });
      }
      if (type === 'COLOR') {
        setEditingItem({
          id: `col-${Date.now()}`, name: '', hex: '#000000', category: 'BASIC'
        });
      }
      if (type === 'PRICING') {
        setEditingItem({
          styleId: '', basePrice: 0, fabricMultipliers: {}
        });
      }
      if (type === 'USER') {
        setEditingItem({
            username: '', password: '', role: UserRole.ASSISTANT
        });
      }
    }
  };

  const handleSaveItem = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!modalType || !editingItem) return;

    // Special handler for User creation which uses the prop function
    if (modalType === 'USER') {
        if (editingItem.username && editingItem.password) {
            onAddUser(editingItem.username, editingItem.password, editingItem.role);
            setModalType(null);
            setEditingItem(null);
        } else {
            alert("الرجاء إدخال اسم المستخدم وكلمة المرور.");
        }
        return;
    }

    try {
      if (modalType === 'FABRIC') {
        // 1. Save to Cloud
        if (db) await setDoc(doc(db, 'fabrics', editingItem.id), editingItem);
        // 2. Save Local (App State -> LocalStorage)
        const exists = fabrics.some(f => f.id === editingItem.id);
        if (exists) setFabrics(fabrics.map(f => f.id === editingItem.id ? editingItem : f));
        else setFabrics([...fabrics, editingItem]);
      }
      
      if (modalType === 'STYLE') {
        if (db) await setDoc(doc(db, 'styles', editingItem.id), editingItem);
        const exists = styles.some(s => s.id === editingItem.id);
        if (exists) setStyles(styles.map(s => s.id === editingItem.id ? editingItem : s));
        else setStyles([...styles, editingItem]);
      }
      
      if (modalType === 'COLOR') {
        if (db) await setDoc(doc(db, 'colors', editingItem.id), editingItem);
        const exists = colors.some(c => c.id === editingItem.id);
        if (exists) setColors(colors.map(c => c.id === editingItem.id ? editingItem : c));
        else setColors([...colors, editingItem]);
      }
      
      if (modalType === 'PRICING') {
        // Use styleId as document ID for pricing
        if (db) await setDoc(doc(db, 'pricing', editingItem.styleId), editingItem);
        const exists = pricing.some(p => p.styleId === editingItem.styleId);
        const others = pricing.filter(p => p.styleId !== editingItem.styleId);
        setPricing([...others, editingItem]);
      }

      setModalType(null);
      setEditingItem(null);
      alert("✅ تم حفظ التغييرات في قاعدة البيانات!");
    } catch (error) {
      console.error("Error saving item:", error);
      // Even if cloud fails, we might want to update local state (Optimistic UI)
      // But let's warn the user.
      alert("⚠️ تم الحفظ محلياً فقط (فشل الاتصال بالسحابة).");
      
      // Still update local state for offline usage
       if (modalType === 'FABRIC') {
         const exists = fabrics.some(f => f.id === editingItem.id);
         if (exists) setFabrics(fabrics.map(f => f.id === editingItem.id ? editingItem : f));
         else setFabrics([...fabrics, editingItem]);
       }
       // ... repeat logic for others if needed, though clean code would combine this.
    }
  };

  return (
    <div className="fixed inset-0 z-[500] bg-dark flex flex-col animate-in fade-in duration-300 overflow-hidden" dir="rtl">
      {/* Overlay for mobile sidebar */}
      {isSidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-[550] lg:hidden" onClick={handleSidebarToggle}></div>
      )}

      {/* EDIT MODAL */}
      {modalType && editingItem && (
        <div className="fixed inset-0 z-[700] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 w-full max-w-2xl max-h-[90vh] overflow-y-auto rounded-[2rem] border border-white/10 shadow-2xl p-6 sm:p-8 animate-in zoom-in-95 duration-200 custom-scrollbar">
            <div className="flex justify-between items-center mb-6 border-b border-white/5 pb-4">
               <h3 className="text-2xl font-black text-white">
                 {modalType === 'FABRIC' ? 'تعديل / إضافة قماش' : 
                  modalType === 'STYLE' ? 'تعديل / إضافة موديل' :
                  modalType === 'COLOR' ? 'تعديل / إضافة لون' :
                  modalType === 'USER' ? 'إضافة مستخدم جديد' : 'تعديل قاعدة تسعير'}
               </h3>
               <button onClick={() => setModalType(null)} className="w-10 h-10 rounded-full bg-slate-800 text-slate-400 hover:text-white flex items-center justify-center transition-colors">✕</button>
            </div>
            
            <form onSubmit={handleSaveItem} className="space-y-6">
              {modalType === 'FABRIC' && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <Input label="اسم القماش" value={editingItem.name} onChange={v => setEditingItem({...editingItem, name: v})} />
                    <Input label="نوع الخامة" value={editingItem.material} onChange={v => setEditingItem({...editingItem, material: v})} />
                  </div>
                  
                  {/* Image Upload for Fabric */}
                  <ImageUploadControl 
                    label="صورة القماش" 
                    value={editingItem.image} 
                    isUploading={isUploading}
                    onTextChange={v => setEditingItem({...editingItem, image: v})}
                    onFileChange={e => handleImageUpload(e, 'image')}
                  />

                  <div className="space-y-2">
                    <label className="text-xs font-bold text-slate-500">الوصف</label>
                    <textarea value={editingItem.description} onChange={e => setEditingItem({...editingItem, description: e.target.value})} className="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white focus:border-primary outline-none" rows={2} />
                  </div>
                  <div className="grid grid-cols-3 gap-4">
                    <Select label="السماكة" value={editingItem.thickness} options={['thin', 'medium', 'thick']} onChange={v => setEditingItem({...editingItem, thickness: v})} />
                    <Input label="المرونة" value={editingItem.properties.stretch} onChange={v => setEditingItem({...editingItem, properties: {...editingItem.properties, stretch: v}})} />
                    <Input label="المسامية" value={editingItem.properties.breathability} onChange={v => setEditingItem({...editingItem, properties: {...editingItem.properties, breathability: v}})} />
                  </div>
                  <div className="bg-slate-800/50 p-4 rounded-xl border border-white/5 space-y-4">
                     <h4 className="text-xs font-black text-primary">الخصائص الفيزيائية (للمحاكاة)</h4>
                     <div className="grid grid-cols-3 gap-4">
                        <Input type="number" label="الكتلة (Mass)" value={editingItem.physics.mass} onChange={v => setEditingItem({...editingItem, physics: {...editingItem.physics, mass: parseFloat(v)}})} />
                        <Input type="number" label="الصلابة (Stiffness)" value={editingItem.physics.stiffness} onChange={v => setEditingItem({...editingItem, physics: {...editingItem.physics, stiffness: parseFloat(v)}})} />
                        <Input type="number" label="التخميد (Damping)" value={editingItem.physics.damping} onChange={v => setEditingItem({...editingItem, physics: {...editingItem.physics, damping: parseFloat(v)}})} />
                     </div>
                  </div>
                </>
              )}

              {modalType === 'STYLE' && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                    <Input label="اسم الموديل" value={editingItem.label} onChange={v => setEditingItem({...editingItem, label: v})} />
                    <Input label="الأيقونة (Emoji)" value={editingItem.icon} onChange={v => setEditingItem({...editingItem, icon: v})} />
                  </div>
                  
                   {/* Image Upload for Style */}
                   <ImageUploadControl 
                    label="صورة الموديل (اختياري)" 
                    value={editingItem.image || ''} 
                    isUploading={isUploading}
                    onTextChange={v => setEditingItem({...editingItem, image: v})}
                    onFileChange={e => handleImageUpload(e, 'image')}
                  />

                  <Input label="الوصف المختصر" value={editingItem.description} onChange={v => setEditingItem({...editingItem, description: v})} />
                  <div className="grid grid-cols-3 gap-4">
                    <Select label="الجنس" value={editingItem.gender} options={Object.values(Gender)} onChange={v => setEditingItem({...editingItem, gender: v})} />
                    <Select label="المناسبة" value={editingItem.occasion} options={['ALL', 'FORMAL', 'DAILY', 'SPORTS', 'EVENING', 'CEREMONY']} onChange={v => setEditingItem({...editingItem, occasion: v})} />
                    <Select label="الموسم" value={editingItem.season} options={['ALL', 'SUMMER', 'WINTER']} onChange={v => setEditingItem({...editingItem, season: v})} />
                  </div>
                  <div className="space-y-2 pt-2">
                     <label className="text-xs font-bold text-slate-500">ملاحظة تقنية</label>
                     <p className="text-[10px] text-slate-400 bg-slate-800 p-2 rounded-lg">إضافة موديل جديد هنا سيظهره في القائمة، ولكن لن يتم إنشاء بترون تلقائي له إلا إذا كان المعرف (ID) مطابقاً لأحد أنواع `GarmentStyle` المدعومة برمجياً في `FullPatternService`.</p>
                  </div>
                </>
              )}

              {modalType === 'COLOR' && (
                <>
                  <Input label="اسم اللون" value={editingItem.name} onChange={v => setEditingItem({...editingItem, name: v})} />
                  <div className="grid grid-cols-2 gap-4">
                     <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500">كود اللون (Hex)</label>
                        <div className="flex gap-2">
                           <input type="color" value={editingItem.hex} onChange={e => setEditingItem({...editingItem, hex: e.target.value})} className="h-10 w-14 bg-transparent cursor-pointer rounded overflow-hidden" />
                           <input type="text" value={editingItem.hex} onChange={e => setEditingItem({...editingItem, hex: e.target.value})} className="flex-1 bg-slate-800 border border-white/10 rounded-xl px-3 text-white text-xs font-mono" />
                        </div>
                     </div>
                     <Select label="التصنيف" value={editingItem.category} options={['BASIC', 'NEUTRAL', 'VIBRANT', 'METALLIC']} onChange={v => setEditingItem({...editingItem, category: v})} />
                  </div>
                </>
              )}

              {modalType === 'PRICING' && (
                <>
                  <div className="grid grid-cols-2 gap-4">
                     <div className="space-y-2">
                        <label className="text-xs font-bold text-slate-500">الموديل</label>
                        <select 
                          value={editingItem.styleId} 
                          onChange={e => setEditingItem({...editingItem, styleId: e.target.value})}
                          className="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white focus:border-primary outline-none text-sm"
                          disabled={pricing.some(p => p.styleId === editingItem.styleId && p !== editingItem)} // Disable if editing existing or to prevent dups logic if strictly enforced
                        >
                           <option value="">اختر موديل...</option>
                           {Object.values(GarmentStyle).map(s => (
                              <option key={s} value={s}>{s.replace(/_/g, ' ')}</option>
                           ))}
                        </select>
                     </div>
                     <Input type="number" label="السعر الأساسي (ر.س)" value={editingItem.basePrice} onChange={v => setEditingItem({...editingItem, basePrice: parseFloat(v)})} />
                  </div>
                  <div className="bg-slate-800/50 p-4 rounded-xl border border-white/5">
                     <h4 className="text-xs font-black text-white mb-4">مضاعفات سعر الأقمشة</h4>
                     <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-40 overflow-y-auto custom-scrollbar">
                        {fabrics.map(f => (
                           <div key={f.id} className="flex items-center justify-between bg-slate-900 p-2 rounded-lg border border-white/5">
                              <span className="text-[10px] text-slate-300">{f.name}</span>
                              <input 
                                type="number" 
                                step="0.1"
                                className="w-16 bg-slate-800 border border-white/10 rounded-lg px-2 py-1 text-xs text-center text-primary font-bold outline-none"
                                value={editingItem.fabricMultipliers?.[f.id] || 1.0}
                                onChange={(e) => {
                                   const newMults = { ...editingItem.fabricMultipliers, [f.id]: parseFloat(e.target.value) };
                                   setEditingItem({...editingItem, fabricMultipliers: newMults});
                                }}
                              />
                           </div>
                        ))}
                     </div>
                  </div>
                </>
              )}

              {modalType === 'USER' && (
                <>
                  <Input 
                    label="اسم المستخدم (البريد الإلكتروني)" 
                    value={editingItem.username} 
                    onChange={v => setEditingItem({...editingItem, username: v})} 
                    placeholder="example@mail.com"
                  />
                  <Input 
                    label="كلمة المرور" 
                    type="password"
                    value={editingItem.password} 
                    onChange={v => setEditingItem({...editingItem, password: v})} 
                  />
                  <Select 
                    label="الدور" 
                    value={editingItem.role} 
                    options={[UserRole.ADMIN, UserRole.ASSISTANT, UserRole.VIEWER]} 
                    onChange={v => setEditingItem({...editingItem, role: v})} 
                  />
                </>
              )}

              <button type="submit" disabled={isUploading} className={`w-full py-4 rounded-2xl font-black text-white text-lg shadow-xl active:scale-95 transition-all ${isUploading ? 'bg-slate-600 cursor-wait' : 'bg-primary hover:bg-blue-600'}`}>
                {isUploading ? 'جاري رفع الصورة...' : (modalType === 'USER' ? 'إضافة المستخدم' : 'حفظ التغييرات ✓')}
              </button>
            </form>
          </div>
        </div>
      )}

      <div className="flex h-full">
        {/* Sidebar */}
        <aside className={`fixed inset-y-0 right-0 w-80 bg-slate-900 border-l border-white/5 p-8 flex flex-col gap-6 
                           lg:static lg:translate-x-0 z-[600] 
                           transform transition-transform duration-300 ease-in-out 
                           ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full'}`}>
           <div className="mb-10 text-center">
              <div className="w-20 h-20 bg-primary rounded-3xl flex items-center justify-center text-4xl mx-auto mb-4 shadow-2xl">⚙️</div>
              <h2 className="text-2xl font-black text-white">إدارة المنشأة</h2>
              <p className="text-slate-500 text-sm">{currentUser.username} ({currentUser.role === UserRole.ADMIN ? 'مدير' : 'مساعد'})</p>
           </div>
           <nav className="flex-1 space-y-2 overflow-y-auto custom-scrollbar">
              <SidebarBtn active={activeTab === 'BRANDING'} onClick={() => handleTabClick('BRANDING')} icon="🏢" label="إعدادات الهوية" />
              <SidebarBtn active={activeTab === 'LOGS'} onClick={() => handleTabClick('LOGS')} icon="📋" label="سجل النشاطات" />
              <SidebarBtn active={activeTab === 'FABRICS'} onClick={() => handleTabClick('FABRICS')} icon="🧵" label="إدارة الأقمشة" />
              <SidebarBtn active={activeTab === 'STYLES'} onClick={() => handleTabClick('STYLES')} icon="👗" label="إدارة الموديلات" />
              <SidebarBtn active={activeTab === 'COLORS'} onClick={() => handleTabClick('COLORS')} icon="🎨" label="إدارة الألوان" />
              <SidebarBtn active={activeTab === 'PRICING'} onClick={() => handleTabClick('PRICING')} icon="💰" label="إدارة الأسعار" />
              <SidebarBtn active={activeTab === 'ORDERS'} onClick={() => handleTabClick('ORDERS')} icon="📦" label="إحصائيات الطلبات" />
              <SidebarBtn active={activeTab === 'CONFIG'} onClick={() => handleTabClick('CONFIG')} icon="⚙️" label="الإعدادات العامة" />
              {currentUser.role === UserRole.ADMIN && (
                <SidebarBtn active={activeTab === 'USER_MANAGEMENT'} onClick={() => handleTabClick('USER_MANAGEMENT')} icon="👥" label="إدارة المستخدمين" />
              )}
           </nav>
           
           <div className="space-y-3 mt-4">
               <button onClick={onClose} className="w-full flex items-center justify-center gap-3 py-4 bg-slate-800 text-slate-300 rounded-3xl font-black text-xs hover:bg-slate-700 hover:text-white transition-all border border-white/5">
                 <span className="text-lg">🏠</span>
                 <span>العودة للرئيسية</span>
               </button>
               <button onClick={onLogout} className="w-full flex items-center justify-center gap-3 py-4 bg-red-500/10 text-red-500 rounded-3xl font-black text-xs hover:bg-red-500 hover:text-white transition-all border border-red-500/10">
                 <span className="text-lg">🚪</span>
                 <span>تسجيل الخروج</span>
               </button>
           </div>

        </aside>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-12 bg-dark/20 backdrop-blur-3xl custom-scrollbar lg:mr-80">
           <button 
             onClick={handleSidebarToggle}
             className="lg:hidden fixed top-6 left-6 z-[601] w-12 h-12 rounded-full bg-slate-800 text-white flex items-center justify-center text-2xl shadow-lg"
           >
             ☰
           </button>

           {activeTab === 'BRANDING' && (
             <section className="max-w-4xl mx-auto space-y-12">
                <div className="bg-slate-900 p-8 sm:p-12 rounded-[4rem] border border-white/5 shadow-2xl space-y-8">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">إعدادات الهوية (Branding)</h3>
                   
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                      <div className="space-y-4">
                         <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">اسم الشركة</label>
                         <input value={branding.companyName} onChange={(e) => setBranding({...branding, companyName: e.target.value})} className="w-full bg-slate-800 border border-white/5 p-6 rounded-3xl text-white font-black" />
                      </div>
                      <div className="space-y-4">
                         <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">الخط الافتراضي</label>
                         <select value={branding.fontFamily} onChange={(e) => setBranding({...branding, fontFamily: e.target.value})} className="w-full bg-slate-800 border border-white/5 p-6 rounded-3xl text-white font-black outline-none">
                            <option value="Tajawal">Tajawal (Default)</option>
                            <option value="Arial">Arial</option>
                            <option value="Cairo">Cairo</option>
                         </select>
                      </div>
                      <div className="space-y-4">
                         <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">اللون الأساسي</label>
                         <div className="flex gap-4 items-center bg-slate-800 p-3 rounded-2xl border border-white/5">
                            <input type="color" value={branding.primaryColor} onChange={(e) => setBranding({...branding, primaryColor: e.target.value})} className="h-14 w-20 bg-transparent border-none cursor-pointer" />
                            <span className="text-white font-mono text-xs">{branding.primaryColor}</span>
                         </div>
                      </div>
                      <div className="space-y-4">
                         <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">اللون الثانوي</label>
                         <div className="flex gap-4 items-center bg-slate-800 p-3 rounded-2xl border border-white/5">
                            <input type="color" value={branding.secondaryColor} onChange={(e) => setBranding({...branding, secondaryColor: e.target.value})} className="h-14 w-20 bg-transparent border-none cursor-pointer" />
                            <span className="text-white font-mono text-xs">{branding.secondaryColor}</span>
                         </div>
                      </div>
                   </div>

                   <div className="space-y-4">
                      <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">رابط الشعار (Logo URL)</label>
                      <input value={branding.logoUrl} onChange={(e) => setBranding({...branding, logoUrl: e.target.value})} placeholder="https://..." className="w-full bg-slate-800 border border-white/5 p-6 rounded-3xl text-white font-black" />
                   </div>

                   <button onClick={() => alert("✅ تم حفظ إعدادات الهوية")} className="w-full bg-primary py-7 rounded-3xl font-black text-white text-xl shadow-2xl active:scale-95 transition-all">حفظ الإعدادات</button>
                </div>
             </section>
           )}

           {activeTab === 'LOGS' && (
             <section className="max-w-5xl mx-auto space-y-8">
                <div className="flex justify-between items-center flex-col sm:flex-row gap-4 sm:gap-0">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">سجل النشاطات الأخير</h3>
                   <button onClick={exportLogs} className="bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 px-8 py-4 rounded-2xl font-black text-xs hover:bg-emerald-500 hover:text-white transition-all w-full sm:w-auto">تصدير PDF سجل</button>
                </div>
                <div className="space-y-4">
                   {activityLogs.map(log => (
                     <div key={log.id} className="p-6 sm:p-8 bg-slate-900 border border-white/5 rounded-[2.5rem] flex flex-col sm:flex-row justify-between sm:items-center group hover:border-primary/30 transition-all gap-4">
                        <div>
                           <h4 className="text-lg sm:text-xl font-black text-white mb-1 sm:mb-2">{log.action}</h4>
                           <p className="text-slate-500 text-sm font-bold">{log.details}</p>
                        </div>
                        <div className="text-right sm:text-left">
                           <span className="text-xs font-black text-slate-600 block mb-1 uppercase tracking-widest">{new Date(log.timestamp).toLocaleDateString()}</span>
                           <span className="text-primary font-black text-lg">{new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                        </div>
                     </div>
                   ))}
                </div>
             </section>
           )}

           {activeTab === 'FABRICS' && (
             <section className="max-w-5xl mx-auto space-y-8">
                <div className="flex justify-between items-center flex-col sm:flex-row gap-4 sm:gap-0">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">إدارة الأقمشة</h3>
                   <button onClick={() => openModal('FABRIC')} className="bg-primary/10 text-primary border border-primary/20 px-8 py-4 rounded-2xl font-black text-xs hover:bg-primary hover:text-white transition-all w-full sm:w-auto">إضافة قماش جديد</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {fabrics.map(fabric => (
                    <div key={fabric.id} className="bg-slate-900 rounded-3xl p-6 border border-white/5 flex flex-col gap-4 group hover:border-primary/30 transition-all">
                      <div className="flex items-center gap-4">
                        <img src={fabric.image} alt={fabric.name} className="w-16 h-16 object-cover rounded-xl" />
                        <div>
                          <h4 className="font-black text-white">{fabric.name}</h4>
                          <p className="text-slate-500 text-xs">{fabric.material}</p>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-auto">
                        <button onClick={() => openModal('FABRIC', fabric)} className="flex-1 bg-indigo-500/10 text-indigo-500 py-3 rounded-xl text-xs hover:bg-indigo-500 hover:text-white transition-all">تعديل</button>
                        <button onClick={() => handleDelete('FABRIC', fabric.id)} className="flex-1 bg-red-500/10 text-red-500 py-3 rounded-xl text-xs hover:bg-red-500 hover:text-white transition-all">حذف</button>
                      </div>
                    </div>
                  ))}
                </div>
             </section>
           )}

           {activeTab === 'STYLES' && (
             <section className="max-w-5xl mx-auto space-y-8">
                <div className="flex justify-between items-center flex-col sm:flex-row gap-4 sm:gap-0">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">إدارة الموديلات</h3>
                   <button onClick={() => openModal('STYLE')} className="bg-primary/10 text-primary border border-primary/20 px-8 py-4 rounded-2xl font-black text-xs hover:bg-primary hover:text-white transition-all w-full sm:w-auto">إضافة موديل جديد</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {styles.map(style => (
                    <div key={style.id} className="bg-slate-900 rounded-3xl p-6 border border-white/5 flex flex-col gap-4 group hover:border-primary/30 transition-all">
                      <div className="flex items-center gap-4">
                        {style.image ? (
                           <img src={style.image} alt={style.label} className="w-16 h-16 object-cover rounded-xl" />
                        ) : (
                           <span className="text-4xl">{style.icon}</span>
                        )}
                        <div>
                          <h4 className="font-black text-white">{style.label}</h4>
                          <p className="text-slate-500 text-xs">{style.gender} - {style.occasion}</p>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-auto">
                        <button onClick={() => openModal('STYLE', style)} className="flex-1 bg-indigo-500/10 text-indigo-500 py-3 rounded-xl text-xs hover:bg-indigo-500 hover:text-white transition-all">تعديل</button>
                        <button onClick={() => handleDelete('STYLE', style.id)} className="flex-1 bg-red-500/10 text-red-500 py-3 rounded-xl text-xs hover:bg-red-500 hover:text-white transition-all">حذف</button>
                      </div>
                    </div>
                  ))}
                </div>
             </section>
           )}

           {activeTab === 'COLORS' && (
             <section className="max-w-5xl mx-auto space-y-8">
                <div className="flex justify-between items-center flex-col sm:flex-row gap-4 sm:gap-0">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">إدارة الألوان</h3>
                   <button onClick={() => openModal('COLOR')} className="bg-primary/10 text-primary border border-primary/20 px-8 py-4 rounded-2xl font-black text-xs hover:bg-primary hover:text-white transition-all w-full sm:w-auto">إضافة لون جديد</button>
                </div>
                <div className="grid grid-cols-5 md:grid-cols-6 lg:grid-cols-8 gap-4">
                  {colors.map(color => (
                    <div key={color.id} className="bg-slate-900 rounded-3xl p-4 border border-white/5 flex flex-col items-center gap-2 group hover:border-primary/30 transition-all">
                      <div className="w-12 h-12 rounded-full border border-white/20 shadow-lg" style={{ backgroundColor: color.hex }}></div>
                      <h4 className="font-black text-white text-xs">{color.name}</h4>
                      <div className="flex gap-1 mt-auto w-full">
                        <button onClick={() => openModal('COLOR', color)} className="flex-1 h-8 bg-indigo-500/10 text-indigo-500 rounded-lg text-xs flex items-center justify-center hover:bg-indigo-500 hover:text-white transition-all">✏️</button>
                        <button onClick={() => handleDelete('COLOR', color.id)} className="flex-1 h-8 bg-red-500/10 text-red-500 rounded-lg text-xs flex items-center justify-center hover:bg-red-500 hover:text-white transition-all">🗑️</button>
                      </div>
                    </div>
                  ))}
                </div>
             </section>
           )}

           {activeTab === 'PRICING' && (
             <section className="max-w-5xl mx-auto space-y-8">
                <div className="flex justify-between items-center flex-col sm:flex-row gap-4 sm:gap-0">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">إدارة الأسعار</h3>
                   <button onClick={() => openModal('PRICING')} className="bg-primary/10 text-primary border border-primary/20 px-8 py-4 rounded-2xl font-black text-xs hover:bg-primary hover:text-white transition-all w-full sm:w-auto">إضافة قاعدة تسعير</button>
                </div>
                <div className="space-y-4">
                  {pricing.map(rule => (
                    <div key={rule.styleId} className="bg-slate-900 rounded-3xl p-6 border border-white/5 flex flex-col sm:flex-row justify-between items-center gap-4 group hover:border-primary/30 transition-all">
                      <div>
                        <h4 className="font-black text-white text-lg">{rule.styleId ? rule.styleId.replace(/_/g, ' ') : 'Unknown'}</h4>
                        <p className="text-slate-500 text-sm font-bold">السعر الأساسي: <span className="text-emerald-400">{rule.basePrice} ر.س</span></p>
                        <p className="text-xs text-slate-600 mt-1">{Object.keys(rule.fabricMultipliers).length} معامل قماش مخصص</p>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => openModal('PRICING', rule)} className="flex-1 bg-indigo-500/10 text-indigo-500 py-3 px-6 rounded-xl text-xs hover:bg-indigo-500 hover:text-white transition-all">تعديل</button>
                        <button onClick={() => handleDelete('PRICING', rule.styleId)} className="flex-1 bg-red-500/10 text-red-500 py-3 px-6 rounded-xl text-xs hover:bg-red-500 hover:text-white transition-all">حذف</button>
                      </div>
                    </div>
                  ))}
                </div>
             </section>
           )}
           
           {activeTab === 'ORDERS' && (
             <section className="max-w-5xl mx-auto space-y-8">
                <h3 className="text-2xl sm:text-3xl font-black text-white mb-6">إحصائيات الطلبات</h3>
                <StatsDashboard orders={orders} branding={branding} /> 
             </section>
           )}

           {activeTab === 'CONFIG' && (
             <section className="max-w-4xl mx-auto space-y-8">
                <div className="bg-slate-900 p-8 sm:p-12 rounded-[4rem] border border-white/5 shadow-2xl space-y-8">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">الإعدادات العامة للتطبيق</h3>
                   
                   <div className="space-y-6">
                      <div className="space-y-2">
                         <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">تعليمات لوحة المطور</label>
                         <textarea 
                            value={config.instructions} 
                            onChange={(e) => setConfig({...config, instructions: e.target.value})} 
                            className="w-full bg-slate-800 border border-white/5 p-6 rounded-3xl text-white font-black h-32" 
                            placeholder="اكتب هنا التعليمات الخاصة بلوحة تحكم المطور..."
                         />
                      </div>

                      <h4 className="text-lg font-black text-white mt-8">تفعيل/تعطيل أقسام لوحة المطور</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                         {currentUser.role === UserRole.ADMIN && (
                            <>
                               <ToggleSwitch label="إدارة الأقمشة" checked={config.fabrics} onChange={(val) => setConfig({...config, fabrics: val})} />
                               <ToggleSwitch label="إدارة الأسعار" checked={config.prices} onChange={(val) => setConfig({...config, prices: val})} />
                               <ToggleSwitch label="إحصائيات الطلبات" checked={config.orders} onChange={(val) => setConfig({...config, orders: val})} />
                            </>
                         )}
                         <ToggleSwitch label="إدارة الموديلات" checked={config.models} onChange={(val) => setConfig({...config, models: val})} />
                         <ToggleSwitch label="إدارة الألوان" checked={config.colors} onChange={(val) => setConfig({...config, colors: val})} />
                      </div>
                   </div>

                   <button onClick={() => alert("✅ تم حفظ الإعدادات العامة")} className="w-full bg-primary py-7 rounded-3xl font-black text-white text-xl shadow-2xl active:scale-95 transition-all">حفظ الإعدادات العامة</button>
                </div>
             </section>
           )}

           {currentUser.role === UserRole.ADMIN && activeTab === 'USER_MANAGEMENT' && (
             <section className="max-w-4xl mx-auto space-y-8">
                <div className="bg-slate-900 p-8 sm:p-12 rounded-[4rem] border border-white/5 shadow-2xl space-y-8">
                   <div className="flex justify-between items-center flex-col sm:flex-row gap-4 sm:gap-0 border-b border-white/5 pb-6">
                       <h3 className="text-2xl sm:text-3xl font-black text-white">إدارة المستخدمين</h3>
                       <button onClick={() => openModal('USER')} className="bg-primary/10 text-primary border border-primary/20 px-8 py-4 rounded-2xl font-black text-xs hover:bg-primary hover:text-white transition-all w-full sm:w-auto">
                           + إضافة مستخدم جديد
                       </button>
                   </div>
                   
                   <div className="space-y-6">
                      <h4 className="text-lg font-black text-white">المستخدمون الحاليون</h4>
                      <div className="space-y-4">
                         {allUsers.map((user) => (
                            <div key={user.id} className="flex justify-between items-center bg-slate-800 p-4 rounded-2xl border border-white/5">
                               <span className="text-white font-bold text-sm">{user.username}</span>
                               <span className={`px-3 py-1 rounded-full text-xs font-black ${
                                 user.role === UserRole.ADMIN ? 'bg-red-500/20 text-red-500' : 
                                 user.role === UserRole.ASSISTANT ? 'bg-green-500/20 text-green-500' :
                                 'bg-blue-500/20 text-blue-500'
                               }`}>
                                  {user.role === UserRole.ADMIN ? 'مدير' : user.role === UserRole.ASSISTANT ? 'مساعد' : 'مشاهد'}
                               </span>
                               <div className="flex gap-2">
                                  {user.id !== currentUser.id && ( 
                                    <>
                                       <select 
                                         value={user.role} 
                                         onChange={(e) => onUpdateUserRole(user.id, e.target.value as UserRole)} 
                                         className="w-fit bg-slate-700 border border-white/5 p-2 rounded-xl outline-none text-white font-bold text-xs"
                                       >
                                          <option value={UserRole.ADMIN}>مدير</option>
                                          <option value={UserRole.ASSISTANT}>مساعد</option>
                                          <option value={UserRole.VIEWER}>مشاهد</option>
                                       </select>
                                       <button onClick={() => onDeleteUser(user.id)} className="w-8 h-8 rounded-full bg-red-500/10 text-red-500 text-xs flex items-center justify-center hover:bg-red-500 hover:text-white transition-all">🗑️</button>
                                    </>
                                  )}
                               </div>
                            </div>
                         ))}
                      </div>
                   </div>
                </div>
             </section>
           )}
        </main>
      </div>
    </div>
  );
};

// UI Helpers
const SidebarBtn = ({ active, onClick, icon, label, disabled = false }: any) => (
  <button 
    onClick={onClick} 
    className={`w-full flex items-center gap-4 p-5 rounded-3xl transition-all font-black text-sm 
               ${active ? 'bg-primary text-white shadow-2xl scale-[1.05]' : 'text-slate-500 hover:bg-white/5'}
               ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    disabled={disabled}
  >
    <span className="text-2xl">{icon}</span>
    <span className="tracking-tight">{label}</span>
  </button>
);

const ToggleSwitch = ({ label, checked, onChange }: { label: string; checked: boolean; onChange: (checked: boolean) => void }) => (
  <div className="flex items-center justify-between bg-slate-800 p-5 rounded-2xl border border-white/5">
    <span className="text-white font-bold text-sm">{label}</span>
    <label className="relative inline-flex items-center cursor-pointer">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="sr-only peer" />
      <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/40 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
    </label>
  </div>
);

const Input = ({ label, value, onChange, type = "text", placeholder }: any) => (
  <div className="space-y-2">
    <label className="text-xs font-bold text-slate-500">{label}</label>
    <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} className="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white focus:border-primary outline-none" />
  </div>
);

const Select = ({ label, value, options, onChange }: any) => (
  <div className="space-y-2">
    <label className="text-xs font-bold text-slate-500">{label}</label>
    <select value={value} onChange={e => onChange(e.target.value)} className="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white focus:border-primary outline-none text-sm">
      {options.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
    </select>
  </div>
);

const ImageUploadControl = ({ label, value, isUploading, onTextChange, onFileChange }: { label: string, value: string, isUploading: boolean, onTextChange: (v: string) => void, onFileChange: (e: React.ChangeEvent<HTMLInputElement>, fieldName: string) => void }) => (
  <div className="space-y-4">
    <label className="text-xs font-bold text-slate-500">{label}</label>
    
    <div className="flex gap-4 items-center">
      <div className="flex-1 space-y-2">
        {/* Text Input for URL */}
        <input 
          type="text" 
          value={value} 
          onChange={e => onTextChange(e.target.value)} 
          className="w-full bg-slate-800 border border-white/10 rounded-xl p-3 text-white focus:border-primary outline-none text-xs"
          placeholder="رابط الصورة (URL)..." 
        />
        
        {/* File Input */}
        <label className={`w-full flex items-center justify-center gap-2 p-3 rounded-xl border border-dashed border-white/20 cursor-pointer hover:bg-white/5 transition-all ${isUploading ? 'opacity-50' : ''}`}>
           <span className="text-xl">📤</span>
           <span className="text-xs font-bold text-slate-400">{isUploading ? 'جاري الرفع...' : 'رفع من الجهاز'}</span>
           <input type="file" hidden accept="image/*" onChange={(e) => onFileChange(e, 'image')} disabled={isUploading} />
        </label>
      </div>

      {/* Preview */}
      <div className="w-24 h-24 bg-slate-800 rounded-2xl border border-white/10 overflow-hidden flex-shrink-0">
        {value ? (
          <img src={value} alt="Preview" className="w-full h-full object-cover" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-slate-600 text-xs">لا توجد صورة</div>
        )}
      </div>
    </div>
  </div>
);
