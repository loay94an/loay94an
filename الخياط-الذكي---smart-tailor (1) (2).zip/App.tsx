
import React, { useState, useEffect, useRef } from 'react';
import { AppStep, Gender, Measurements, Fabric, GarmentStyle, FabricColor, PatternDesign, BrandingSettings, ActivityLog, Order, StyleItem, PricingRule, SectionConfig, User, UserRole, SleeveType, CollarType } from './types';
import { StepProgressBar } from './components/StepProgressBar';
import { GenderSelection } from './components/GenderSelection';
import { StyleSelection } from './components/StyleSelection';
import { SizeInput } from './components/SizeInput';
import { FabricSelection } from './components/FabricSelection';
import { ColorSelection } from './components/ColorSelection';
import { PatternEditor } from './components/PatternEditor';
import { Checkout } from './components/Checkout'; 
import { PaymentStep } from './components/PaymentStep'; 
import { DevDashboard } from './components/DevDashboard';
import { LoginScreen } from './components/LoginScreen'; 
import { STANDARD_SIZES, INITIAL_COLORS, PATTERNS, INITIAL_FABRICS, INITIAL_STYLES, INITIAL_PRICING, INITIAL_USERS, INITIAL_ORDERS, TRANSLATIONS } from './constants';
import { db, storage } from './firebase'; 
import { doc, getDoc, setDoc, collection, getDocs, deleteDoc, writeBatch, addDoc } from 'firebase/firestore';

const App: React.FC = () => {
  const [step, setStep] = useState<AppStep | 'HUB'>('HUB');
  const [language, setLanguage] = useState<'ar' | 'en'>('ar');
  const [gender, setGender] = useState<Gender | null>(null);
  const [style, setStyle] = useState<GarmentStyle | null>(null);
  const [measurements, setMeasurements] = useState<Measurements>(STANDARD_SIZES['M']);
  const [fabric, setFabric] = useState<Fabric | null>(INITIAL_FABRICS[0]);
  const [selectedColor, setSelectedColor] = useState<FabricColor | null>(INITIAL_COLORS[0]);
  const [selectedPattern, setSelectedPattern] = useState<PatternDesign | null>(PATTERNS[0]);
  const [clientPhotoUrl, setClientPhotoUrl] = useState<string | null>(null);
  const [referralManager, setReferralManager] = useState<string | null>(null);
  
  // Define translation helper and navigation helper
  const txt = TRANSLATIONS[language];
  const onBackToHub = () => setStep('HUB');
  
  // To prevent infinite loops or overwrites during initial load
  const isInitialLoad = useRef(true);

  // --- REFERRAL SYSTEM LOGIC (ROUTING) ---
  useEffect(() => {
    let refUsername = null;
    let shouldAutoStart = false;

    // 1. Check for Path-based Routing: /manager/username
    // This assumes the server (Netlify) redirects all 404s to index.html (SPA fallback)
    const path = window.location.pathname;
    const match = path.match(/^\/manager\/([^/]+)/); // Regex to capture username after /manager/
    
    if (match && match[1]) {
        refUsername = match[1]; // Extracted username
        shouldAutoStart = true; // Auto-start flow for direct links
    } 
    // 2. Fallback: Check for standard query param ?ref=username
    else {
        const params = new URLSearchParams(window.location.search);
        if (params.get('ref')) {
            refUsername = params.get('ref');
        }
    }

    if (refUsername) {
      console.log(`🔗 Manager Referral detected: ${refUsername}`);
      localStorage.setItem('smart_tailor_manager_ref', refUsername);
      setReferralManager(refUsername);
      
      // Auto-start journey if accessed via direct manager link
      if (shouldAutoStart) {
        // Optional: Reset other states if needed
        setStep(AppStep.GENDER_SELECTION);
      }
    } else {
        // Retrieve existing session ref
        const stored = localStorage.getItem('smart_tailor_manager_ref');
        if (stored) setReferralManager(stored);
    }
  }, []);

  // --- LOCAL DATABASE PERSISTENCE LAYER ---
  
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>(() => {
    const saved = localStorage.getItem('smart_tailor_logs');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [orders, setOrders] = useState<Order[]>(() => {
    const saved = localStorage.getItem('smart_tailor_orders');
    return saved ? JSON.parse(saved) : INITIAL_ORDERS;
  });

  const [fabrics, setFabrics] = useState<Fabric[]>(() => {
    const saved = localStorage.getItem('smart_tailor_fabrics');
    return saved ? JSON.parse(saved) : INITIAL_FABRICS;
  });

  const [styles, setStyles] = useState<StyleItem[]>(() => {
    const saved = localStorage.getItem('smart_tailor_styles');
    return saved ? JSON.parse(saved) : INITIAL_STYLES;
  });

  const [colors, setColors] = useState<FabricColor[]>(() => {
    const saved = localStorage.getItem('smart_tailor_colors');
    return saved ? JSON.parse(saved) : INITIAL_COLORS;
  });

  const [pricing, setPricing] = useState<PricingRule[]>(() => {
    const saved = localStorage.getItem('smart_tailor_pricing');
    return saved ? JSON.parse(saved) : INITIAL_PRICING;
  });

  const [savedProfiles, setSavedProfiles] = useState<any[]>(() => {
    const saved = localStorage.getItem('smart_tailor_profiles');
    return saved ? JSON.parse(saved) : [];
  });

  const [userId] = useState<string>("guest_" + Math.random().toString(36).substr(2, 9));

  // Authentication state
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('smart_tailor_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });
  
  const [allUsers, setAllUsers] = useState<User[]>(() => {
    const saved = localStorage.getItem('smart_tailor_all_users');
    return saved ? JSON.parse(saved) : INITIAL_USERS;
  });

  const [config, setConfig] = useState<SectionConfig>(() => {
    const savedConfig = localStorage.getItem('smart_tailor_config');
    return savedConfig ? JSON.parse(savedConfig) : {
      fabrics: true,
      models: true,
      colors: true,
      prices: true,
      orders: true,
      instructions: "مرحباً بك في لوحة تحكم المطور. هنا يمكنك إدارة جميع جوانب تطبيقك."
    };
  });

  const [branding, setBranding] = useState<BrandingSettings>(() => {
    const saved = localStorage.getItem('smart_tailor_branding');
    return saved ? JSON.parse(saved) : {
      companyName: "الخياط الذكي برو",
      logoUrl: "",
      primaryColor: "#2563eb",
      secondaryColor: "#f50057",
      fontFamily: "Tajawal",
      logoPosition: "top-right"
    };
  });

  // --- LOCAL STORAGE SYNC ---
  useEffect(() => { if(fabrics.length > 0) localStorage.setItem('smart_tailor_fabrics', JSON.stringify(fabrics)); }, [fabrics]);
  useEffect(() => { if(styles.length > 0) localStorage.setItem('smart_tailor_styles', JSON.stringify(styles)); }, [styles]);
  useEffect(() => { if(colors.length > 0) localStorage.setItem('smart_tailor_colors', JSON.stringify(colors)); }, [colors]);
  useEffect(() => { if(pricing.length > 0) localStorage.setItem('smart_tailor_pricing', JSON.stringify(pricing)); }, [pricing]);
  useEffect(() => { localStorage.setItem('smart_tailor_orders', JSON.stringify(orders)); }, [orders]);
  useEffect(() => { localStorage.setItem('smart_tailor_logs', JSON.stringify(activityLogs)); }, [activityLogs]);
  useEffect(() => { localStorage.setItem('smart_tailor_profiles', JSON.stringify(savedProfiles)); }, [savedProfiles]);
  useEffect(() => { if(allUsers.length > 0) localStorage.setItem('smart_tailor_all_users', JSON.stringify(allUsers)); }, [allUsers]);
  useEffect(() => { localStorage.setItem('smart_tailor_config', JSON.stringify(config)); }, [config]);
  useEffect(() => { localStorage.setItem('smart_tailor_branding', JSON.stringify(branding)); }, [branding]);

  // Effect to update document direction based on language
  useEffect(() => {
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = language;
  }, [language]);


  // --- CLOUD SYNC FUNCTIONS (USER DATA) ---
  useEffect(() => {
    const loadUserData = async () => {
      if (!currentUser || !db) return;

      try {
        console.log(`📡 Fetching data for user: ${currentUser.username} (${currentUser.id})`);
        const userDocRef = doc(db, 'users', currentUser.id);
        const userDocSnap = await getDoc(userDocRef);

        if (userDocSnap.exists()) {
          const userData = userDocSnap.data();
          if (userData.savedProfiles) setSavedProfiles(userData.savedProfiles);
          if (userData.activityLogs) setActivityLogs(userData.activityLogs);
          // Note: We don't overwrite local orders with user-doc orders anymore 
          // because orders are now stored in a global collection for manager access.
          
          if (currentUser.role === UserRole.ADMIN) {
             if (userData.branding) setBranding(userData.branding);
             if (userData.config) setConfig(userData.config);
          }
          addLog("مزامنة سحابية", "تم استرجاع البيانات بنجاح من حسابك");
        } else {
          console.log("🆕 Creating new user document on cloud...");
          await setDoc(userDocRef, {
             username: currentUser.username,
             role: currentUser.role,
             createdAt: Date.now(),
             savedProfiles: savedProfiles,
             activityLogs: activityLogs
          }, { merge: true });
        }
      } catch (error) {
        console.error("❌ Cloud Load Error:", error);
      }
    };
    if (currentUser) loadUserData();
  }, [currentUser?.id]);

  const saveUserDataToCloud = async (key: string, data: any) => {
    if (!currentUser || !db) return;
    try {
        const userDocRef = doc(db, 'users', currentUser.id);
        await setDoc(userDocRef, { [key]: data }, { merge: true });
    } catch (e) {
        console.error(`Failed to save ${key}`, e);
    }
  };

  useEffect(() => { if (currentUser) saveUserDataToCloud('savedProfiles', savedProfiles); }, [savedProfiles, currentUser]);
  useEffect(() => { if (currentUser) saveUserDataToCloud('activityLogs', activityLogs); }, [activityLogs, currentUser]);
  useEffect(() => { if (currentUser?.role === UserRole.ADMIN) saveUserDataToCloud('branding', branding); }, [branding, currentUser]);
  useEffect(() => { if (currentUser?.role === UserRole.ADMIN) saveUserDataToCloud('config', config); }, [config, currentUser]);


  const addLog = (action: string, details: string) => {
    const newLog = { id: Date.now().toString(), action, details, timestamp: Date.now() };
    const updated = [newLog, ...activityLogs].slice(0, 50);
    setActivityLogs(updated);
  };
  
  const handleSaveProfile = (name: string, m: Measurements) => {
      const newProfile = { id: Date.now().toString(), name, measurements: m, createdAt: Date.now() };
      const updated = [...savedProfiles, newProfile];
      setSavedProfiles(updated);
      addLog("حفظ مقاسات", name);
  };

  const handleDeleteProfile = (id: string) => {
      const updated = savedProfiles.filter(p => p.id !== id);
      setSavedProfiles(updated);
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('smart_tailor_user', JSON.stringify(user));
    setStep('HUB'); 
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('smart_tailor_user');
    setStep('HUB');
  };

  const handleUpdateUser = async (updatedUser: User) => {
    try {
        const newUsers = allUsers.map(u => u.id === updatedUser.id ? updatedUser : u);
        setAllUsers(newUsers);
        localStorage.setItem('smart_tailor_all_users', JSON.stringify(newUsers));
        
        if (currentUser && currentUser.id === updatedUser.id) {
            setCurrentUser(updatedUser);
            localStorage.setItem('smart_tailor_user', JSON.stringify(updatedUser));
        }

        if (db) {
            await setDoc(doc(db, "users", updatedUser.id), updatedUser, { merge: true });
            const globalUsersRef = doc(db, 'system', 'users_list');
            await setDoc(globalUsersRef, { list: newUsers }, { merge: true });
        }
        return true;
    } catch (e) {
        console.error("Failed to update user", e);
        return false;
    }
  };

  const handleAddUser = async (username: string, password: string, role: UserRole) => {
    try {
      const newUserId = username.replace(/[^a-zA-Z0-9]/g, '_') + '_' + Date.now();
      const newUser: User = { id: newUserId, username, password, role };
      
      const updatedUsers = [...allUsers, newUser];
      setAllUsers(updatedUsers);
      localStorage.setItem('smart_tailor_all_users', JSON.stringify(updatedUsers));

      if (db) {
        try {
          const userAuthRef = doc(collection(db, "users"), newUserId);
          await setDoc(userAuthRef, { ...newUser, createdAt: Date.now(), savedProfiles: [], activityLogs: [] }); 
          const globalUsersRef = doc(db, 'system', 'users_list');
          await setDoc(globalUsersRef, { list: updatedUsers }, { merge: true });
        } catch (e) { console.warn("Cloud save failed, but saved locally.", e); }
      }
      addLog("إضافة مستخدم", `المستخدم ${username} بالدور ${role}`);
      return true;
    } catch (error) {
      console.error("Error adding user:", error);
      alert("❌ فشل إضافة المستخدم.");
      return false;
    }
  };

  const handleUpdateUserRole = async (userId: string, newRole: UserRole) => {
    try {
      const updatedUsers = allUsers.map(user => user.id === userId ? { ...user, role: newRole } : user);
      setAllUsers(updatedUsers);
      localStorage.setItem('smart_tailor_all_users', JSON.stringify(updatedUsers));
      if (db) {
        const userRef = doc(db, "users", userId);
        await setDoc(userRef, { role: newRole }, { merge: true });
        const globalUsersRef = doc(db, 'system', 'users_list');
        await setDoc(globalUsersRef, { list: updatedUsers }, { merge: true });
      }
      addLog("تحديث دور المستخدم", `تم تحديث دور المستخدم ${userId} إلى ${newRole}`);
      alert("✅ تم تحديث الدور بنجاح!");
    } catch (error) {
      alert("❌ فشل تحديث دور المستخدم.");
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (window.confirm("هل أنت متأكد أنك تريد حذف هذا المستخدم؟")) {
      try {
        const updatedUsers = allUsers.filter(user => user.id !== userId);
        setAllUsers(updatedUsers);
        localStorage.setItem('smart_tailor_all_users', JSON.stringify(updatedUsers));
        if (db) {
          const userRef = doc(db, "users", userId);
          await deleteDoc(userRef);
          const globalUsersRef = doc(db, 'system', 'users_list');
          await setDoc(globalUsersRef, { list: updatedUsers }, { merge: true });
        }
        addLog("حذف مستخدم", `تم حذف المستخدم ${userId}`);
        alert("✅ تم حذف المستخدم بنجاح!");
      } catch (error) {
        alert("❌ فشل حذف المستخدم.");
      }
    }
  };

  const handleCompleteOrder = async (newOrder: Order) => {
    // 1. Update Local State
    setOrders(prev => [...prev, newOrder]);
    
    // 2. Add Log
    addLog("طلب جديد", `تم استلام طلب جديد من العميل ${newOrder.customerName} (${newOrder.managerId ? `إحالة المدير: ${newOrder.managerId}` : 'مباشر'})`);
    
    // 3. Save to GLOBAL Firestore collection "orders" for Manager Dashboard access
    if (db) {
        try {
            await addDoc(collection(db, 'orders'), newOrder);
            console.log("✅ Order saved to global 'orders' collection");
        } catch (e) {
            console.error("❌ Failed to save order to global collection", e);
        }
    }

    // 4. Send Notification (Simulated)
    const targetEmail = currentUser?.username || "admin@smarttailor.com";
    const subject = `طلب جديد #${newOrder.id} - ${newOrder.customerName}`;
    const body = `مرحباً، تم استلام طلب جديد. ${newOrder.managerId ? `(مدير الإحالة: ${newOrder.managerId})` : ''}`;
    // window.location.href = `mailto:${targetEmail}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

    setStep(AppStep.SUCCESS);
  };

  const calculatePrice = () => {
      const basePriceRule = pricing.find(p => p.styleId === style);
      let price = basePriceRule ? basePriceRule.basePrice : 350; 
      if (basePriceRule && fabric) {
          const multiplier = basePriceRule.fabricMultipliers[fabric.id] || 1.0;
          price = price * multiplier;
      }
      return Math.round(price);
  };

  const renderHub = () => (
    <div className="w-full max-w-6xl mx-auto py-8 sm:py-12 px-4 sm:px-6 animate-in fade-in duration-1000">
      
      {/* REFERRAL BANNER */}
      {referralManager && (
        <div className="w-full bg-emerald-600/20 border border-emerald-500/30 text-emerald-400 p-4 rounded-2xl text-center font-black mb-8 animate-in slide-in-from-top-4 flex items-center justify-center gap-3 shadow-lg backdrop-blur-md">
            <span>🛍️</span>
            <span>{language === 'ar' ? `أنت تتسوق الآن مع: ${referralManager}` : `You are shopping with: ${referralManager}`}</span>
        </div>
      )}

      <header className="flex flex-col md:flex-row justify-between items-center mb-10 sm:mb-16 gap-6 sm:gap-8">
         <div className="flex items-center gap-4 sm:gap-6">
            <div className="w-16 h-16 sm:w-20 sm:h-20 bg-primary rounded-3xl flex items-center justify-center text-4xl sm:text-5xl shadow-2xl rotate-3" style={{ backgroundColor: branding.primaryColor }}>🧵</div>
            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tighter" style={{ color: branding.primaryColor, fontFamily: branding.fontFamily }}>{branding.companyName}</h1>
         </div>
         <button 
           onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
           className="px-6 sm:px-8 py-3 sm:py-4 bg-slate-800 rounded-2xl border border-white/5 font-black text-xs hover:bg-slate-700 transition-all flex items-center gap-3 w-full md:w-auto justify-center"
         >
           🌐 {txt.switchLang}
         </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
         <HubCard 
           title={txt.journeyTitle} 
           desc={txt.journeyDesc}
           icon="✂️" 
           onClick={() => setStep(AppStep.GENDER_SELECTION)} 
           primary 
           color={branding.primaryColor}
         />
         <HubCard 
           title={txt.measurementsTitle} 
           desc={txt.measurementsDesc}
           icon="📏" 
           onClick={() => setStep(AppStep.SIZE_INPUT)} 
         />
         <HubCard 
           title={currentUser ? (currentUser.role === UserRole.ADMIN ? txt.devDashboard : 'لوحة المدير') : txt.devDashboard} 
           desc={currentUser ? 'إدارة الطلبات والحساب' : txt.devDesc}
           icon="⚙️" 
           onClick={() => {
             if (currentUser) {
               setStep(AppStep.DEV_DASHBOARD);
             } else {
               setStep(AppStep.LOGIN);
             }
           }} 
           color={branding.secondaryColor}
         />
      </div>
    </div>
  );

  const renderContent = () => {
    if (step === AppStep.LOGIN) {
      return (
        <LoginScreen 
            onLogin={handleLogin} 
            onRegister={handleAddUser}
            allUsers={allUsers} 
            branding={branding} 
            onBackToHub={onBackToHub} 
        />
      );
    }

    if (step === AppStep.DEV_DASHBOARD && !currentUser) {
        return (
            <LoginScreen 
                onLogin={handleLogin} 
                onRegister={handleAddUser}
                allUsers={allUsers} 
                branding={branding} 
                onBackToHub={onBackToHub} 
            />
        );
    }

    if (step === 'HUB') return renderHub();

    switch (step) {
      case AppStep.GENDER_SELECTION:
        return <GenderSelection selected={gender} onSelect={(g) => { setGender(g); addLog("اختيار الجنس", g); setStep(AppStep.SIZE_INPUT); }} branding={branding} onBackToHub={onBackToHub} language={language} />;
      case AppStep.SIZE_INPUT:
        return <SizeInput 
            userId={userId}
            value={measurements} 
            onChange={setMeasurements} 
            savedProfiles={savedProfiles} 
            onSaveProfile={handleSaveProfile} 
            onDeleteProfile={handleDeleteProfile} 
            onSelectProfile={setMeasurements} 
            branding={branding}
            onBackToHub={onBackToHub}
            language={language}
            gender={gender}
            onImageChange={setClientPhotoUrl}
        />;
      case AppStep.FABRIC_SELECTION:
        return <FabricSelection selected={fabric} onSelect={(f) => { setFabric(f); addLog("اختيار القماش", f.name); setStep(AppStep.COLOR_SELECTION); }} fabrics={fabrics} branding={branding} onBackToHub={onBackToHub} language={language} />;
      case AppStep.COLOR_SELECTION:
        return <ColorSelection 
            selectedColor={selectedColor} 
            selectedPattern={selectedPattern} 
            onSelectColor={(c) => { setSelectedColor(c); addLog("اختيار اللون", c.name); }}
            onSelectPattern={(p) => { setSelectedPattern(p); addLog("اختيار النقشة", p.name); setStep(AppStep.STYLE_SELECTION); }} 
            customColors={colors}
            branding={branding} 
            onBackToHub={onBackToHub}
            language={language}
        />;
      case AppStep.STYLE_SELECTION:
        return <StyleSelection gender={gender!} selected={style} onSelect={(s) => { setStyle(s); addLog("اختيار الموديل", s); setStep(AppStep.PATTERN_EDITOR); }} availableStyles={styles.filter(s => s.gender === gender)} branding={branding} onBackToHub={onBackToHub} language={language} />;
      case AppStep.PATTERN_EDITOR:
        return <PatternEditor gender={gender!} style={style!} measurements={measurements} onUpdate={(m) => { setMeasurements(m); addLog("تعديل يدوي", "تغيير قياسات البترون"); }} branding={branding} onBackToHub={onBackToHub} language={language} />;
      case AppStep.EXPORT: 
        return (
          <Checkout 
            orderDetails={{ 
              gender: gender!, 
              style: style!, 
              measurements: measurements, 
              fabric: fabric!, 
              color: selectedColor!, 
              pattern: selectedPattern!,
              sleeveType: SleeveType.BASIC, 
              collarType: CollarType.NONE, 
              totalPrice: calculatePrice(), 
              clientPhotoUrl: clientPhotoUrl || undefined
            } as any} 
            onConfirm={() => {}} 
            onNext={() => setStep(AppStep.PAYMENT)}
            branding={branding}
            onBackToHub={onBackToHub}
            language={language}
          />
        );
      case AppStep.PAYMENT:
        return (
            <PaymentStep 
                orderDetails={{ 
                    gender: gender!, 
                    style: style!, 
                    measurements: measurements, 
                    fabric: fabric!, 
                    color: selectedColor!, 
                    pattern: selectedPattern!,
                    sleeveType: SleeveType.BASIC, 
                    collarType: CollarType.NONE, 
                    totalPrice: calculatePrice(), 
                    clientPhotoUrl: clientPhotoUrl || undefined
                }}
                onConfirm={handleCompleteOrder}
                onBack={() => setStep(AppStep.EXPORT)}
                branding={branding}
                language={language}
            />
        );
      case AppStep.DEV_DASHBOARD:
        return (
          <DevDashboard 
            fabrics={fabrics} 
            setFabrics={setFabrics} 
            styles={styles} 
            setStyles={setStyles} 
            colors={colors} 
            setColors={setColors} 
            pricing={pricing} 
            setPricing={setPricing} 
            orders={orders} 
            setOrders={setOrders} 
            branding={branding} 
            setBranding={setBranding} 
            config={config} 
            setConfig={setConfig} 
            onClose={() => setStep('HUB')} 
            activityLogs={activityLogs} 
            currentUser={currentUser!} 
            allUsers={allUsers}
            onAddUser={handleAddUser}
            onUpdateUser={handleUpdateUser} 
            onUpdateUserRole={handleUpdateUserRole} 
            onDeleteUser={handleDeleteUser} 
            onLogout={handleLogout}
            db={db} 
          />
        );
      case AppStep.SUCCESS:
        return (
          <div className="text-center py-20 sm:py-32 animate-in zoom-in duration-700">
             <div className="text-7xl sm:text-9xl mb-8 sm:mb-12">🎉</div>
             <h2 className="text-3xl sm:text-5xl font-black text-white mb-6">{language === 'ar' ? 'تم حفظ البيانات بنجاح' : 'Order Placed Successfully'}</h2>
             <button onClick={() => setStep('HUB')} className="bg-primary px-8 sm:px-12 py-4 sm:py-6 rounded-3xl font-black text-white text-lg sm:text-xl shadow-2xl" style={{ backgroundColor: branding.primaryColor }}>{txt.backToHome}</button>
          </div>
        );
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-dark text-slate-200 selection:bg-primary/30" style={{ fontFamily: branding.fontFamily }}>
      {step !== 'HUB' && step !== AppStep.DEV_DASHBOARD && step !== AppStep.SUCCESS && step !== AppStep.LOGIN && (
        <header className="sticky top-0 z-[100] glass px-4 sm:px-8 h-20 sm:h-24 flex items-center justify-between border-b border-white/5">
           <div className="flex items-center gap-2 sm:gap-4 cursor-pointer" onClick={() => setStep('HUB')}>
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-primary rounded-2xl flex items-center justify-center text-xl sm:text-2xl shadow-xl" style={{ backgroundColor: branding.primaryColor }}>🧵</div>
              <h1 className="text-lg sm:text-2xl font-black text-white hidden sm:block">{branding.companyName}</h1>
           </div>
           <StepProgressBar currentStep={step as AppStep} />
           {currentUser && (
             <button onClick={handleLogout} className="w-fit px-4 sm:px-6 py-2 sm:py-3 rounded-2xl bg-red-500/10 text-red-500 flex items-center justify-center hover:bg-red-500/20 transition-all border border-red-500/20 text-xs font-black">{txt.logout}</button>
           )}
           {!currentUser && (
             <button onClick={() => setStep('HUB')} className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center hover:bg-red-500/10 hover:text-red-500 transition-all border border-white/5">✕</button>
           )}
        </header>
      )}
      <main className="container mx-auto py-4 sm:py-10 px-4 sm:px-0">
         {renderContent()}
      </main>
      
      {typeof step === 'number' && step < AppStep.EXPORT && step !== AppStep.LOGIN && (
        <nav className="fixed bottom-0 left-0 right-0 z-[200] glass px-4 sm:px-8 py-4 sm:py-6 pb-8 sm:pb-12 flex items-center justify-center border-t border-white/5">
           <button 
             onClick={() => setStep(step + 1)} 
             className="w-full sm:w-auto bg-primary text-white px-8 sm:px-24 py-4 sm:py-6 rounded-3xl font-black text-xl sm:text-2xl shadow-2xl active:scale-95 transition-all flex items-center justify-center gap-4 sm:gap-6" 
             style={{ backgroundColor: branding.primaryColor }}
           >
              <span>{txt.nextStep}</span>
              <span className="text-2xl sm:text-3xl">{language === 'ar' ? '←' : '→'}</span>
           </button>
        </nav>
      )}
    </div>
  );
};

const HubCard = ({ title, desc, icon, onClick, primary, color }: any) => (
  <button 
    onClick={onClick}
    className={`p-6 sm:p-10 rounded-[2.5rem] sm:rounded-[3.5rem] text-right transition-all transform hover:scale-[1.03] active:scale-95 flex flex-col gap-4 sm:gap-6 relative overflow-hidden group border h-full ${
      primary ? 'text-white shadow-2xl' : 'bg-slate-900 border-white/5 hover:border-primary/30'
    }`}
    style={primary ? { backgroundColor: color || '#2563eb' } : {}}
  >
     <div className="text-5xl sm:text-7xl group-hover:rotate-12 transition-transform self-start">{icon}</div>
     <div className="mt-auto w-full">
        <h3 className="text-2xl sm:text-3xl font-black mb-2 sm:mb-3">{title}</h3>
        <p className={`${primary ? 'text-white/80' : 'text-slate-500'} font-bold text-xs sm:text-sm leading-relaxed`}>{desc}</p>
     </div>
     {!primary && (
       <div className="absolute top-0 right-0 w-20 h-20 sm:w-24 sm:h-24 bg-primary/5 rounded-bl-full"></div>
     )}
  </button>
);

export default App;
