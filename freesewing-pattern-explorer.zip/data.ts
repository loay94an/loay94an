
import { PatternData, Software, SoftwareType } from './types';

export const repoStatus = {
  lastSync: new Date().toISOString(),
  version: "3.5.2",
  stars: "1.2k",
  forks: "450",
  link: "https://github.com/freesewing/freesewing"
};

const newsletterHtml = `<!DOCTYPE html>
<html
  lang="ar"
  dir="rtl"
  xmlns="http://www.w3.org/1999/xhtml"
  xmlns:v="urn:schemas-microsoft-com:vml"
  xmlns:o="urn:schemas-microsoft-com:office:office"
>
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="x-apple-disable-message-reformatting" />
    <meta name="format-detection" content="telephone=no,address=no,email=no,date=no,url=no" />
    <meta name="color-scheme" content="light" />
    <meta name="supported-color-schemes" content="light" />
    <title>{{ title }}</title>
    <style>
      :root { color-scheme: light; supported-color-schemes: light; }
      html, body { margin: 0 auto !important; padding: 0 !important; height: 100% !important; width: 100% !important; }
      * { -ms-text-size-adjust: 100%; -webkit-text-size-adjust: 100%; }
      div[style*='margin: 16px 0'] { margin: 0 !important; }
      #MessageViewBody, #MessageWebViewDiv { width: 100% !important; }
      table, td { mso-table-lspace: 0pt !important; mso-table-rspace: 0pt !important; }
      table { border-spacing: 0 !important; border-collapse: collapse !important; table-layout: fixed !important; margin: 0 auto !important; }
      img { -ms-interpolation-mode: bicubic; }
      a { text-decoration: none; }
      .a6S { display: none !important; opacity: 0.01 !important; }
      .im { color: inherit !important; }
      h1 { line-height: 36px; text-align: right; }
      h2 { line-height: 28px; text-align: right; }
      p { text-align: right; }
      @media only screen and (min-device-width: 320px) and (max-device-width: 374px) {
        u ~ div .email-container { min-width: 320px !important; }
      }
      @media only screen and (min-device-width: 375px) and (max-device-width: 413px) {
        u ~ div .email-container { min-width: 375px !important; }
      }
      @media only screen and (min-device-width: 414px) {
        u ~ div .email-container { min-width: 414px !important; }
      }
      .button-td, .button-a { transition: all 100ms ease-in; }
      .button-td-primary:hover, .button-a-primary:hover { background: #212529 !important; border-color: #212529 !important; }
      @media screen and (max-width: 600px) {
        .email-container p { font-size: 17px !important; }
      }
    </style>
  </head>
  <body width="100%" style="margin: 0; padding: 0 !important; mso-line-height-rule: exactly; background-color: #ffffff;">
    <center role="article" aria-roledescription="email" lang="ar" style="width: 100%; background-color: #ffffff">
      <div style="max-height: 0; overflow: hidden; mso-hide: all" aria-hidden="true">
        إصدار هذا الموسم من نشرة FreeSewing الإخبارية.
      </div>
      <div style="display: none; font-size: 1px; line-height: 1px; max-height: 0px; max-width: 0px; opacity: 0; overflow: hidden; mso-hide: all; font-family: sans-serif;">
        &zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;&zwnj;&nbsp;
      </div>
      <div style="max-width: 600px; margin: 0 auto" class="email-container">
        <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto">
          <tr>
            <td style="background-color: #ffffff">
              <table role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%">
                <tr>
                  <td style="padding: 20px; font-family: sans-serif; font-size: 16px; line-height: 22px; color: #212529; text-align: right;">
                    {{{ content }}}
                  </td>
                </tr>
              </table>
            </td>
          </tr>
          <tr><td aria-hidden="true" height="40" style="font-size: 0px; line-height: 0px">&nbsp;</td></tr>
        </table>
        <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto">
          <tr>
            <td style="padding: 20px; font-family: sans-serif; font-size: 12px; line-height: 15px; text-align: center; color: #495057; border-top: 1px solid #cccccc;">
              <a href="https://freesewing.org/patrons/join"><b>{{ support }}</b></a>
            </td>
          </tr>
        </table>
        <table align="center" role="presentation" cellspacing="0" cellpadding="0" border="0" width="100%" style="margin: auto">
          <tr>
            <td style="padding: 10px; font-family: sans-serif; font-size: 12px; line-height: 15px; text-align: center; color: #495057;">
              FreeSewing<br /><span class="unstyle-auto-detected-links">67 Plantin en Moretuslei<br />Antwerp / Belgium<br />info@freesewing.org</span>
              <br /><br />
              <a href="{{{ unsubscribe }}}">{{ unsub1 }}</a><br />{{ unsub2 }}
            </td>
          </tr>
        </table>
      </div>
    </center>
  </body>
</html>`;

const rawDesigns: PatternData = {
  "aaron": { "code": "Joost De Cock", "description": "نمط FreeSewing لقميص داخلي (A-shirt) أو تانك توب", "design": "Joost De Cock", "difficulty": 2, "tags": ["tops", "underwear"], "techniques": ["hem", "stretch", "knit-binding", "curved-seam"] },
  "albert": { "code": "Wouter Van Wageningen", "description": "نمط FreeSewing لمئزر (مريلة مطبخ)", "design": "Wouter Van Wageningen", "difficulty": 2, "tags": ["accessories"], "techniques": ["hem", "knit-binding", "curved-seam", "pocket"] },
  "bee": { "code": "bobgeorgethe3rd", "description": "نمط FreeSewing لقطعة بيكيني علوية", "design": "PrudenceRabbit", "difficulty": 3, "tags": ["tops", "swimwear"], "techniques": ["hem", "stretch", "curved-seam", "precision"] },
  "bella": { "code": "Joost De Cock", "description": "نمط FreeSewing لقالب أساسي (Bodice Block) للملابس النسائية", "design": ["Bella Incognito", "Joost De Cock"], "difficulty": 3, "tags": ["blocks", "tops"], "techniques": ["dart", "block"] },
  "benjamin": { "code": "Wouter Van Wageningen", "description": "نمط FreeSewing لربطة عنق (Bow tie)", "design": "Wouter Van Wageningen", "difficulty": 3, "tags": ["accessories"], "techniques": ["precision", "interfacing"] },
  "bent": { "code": "Joost De Cock", "description": "نمط FreeSewing لقالب جسم للملابس الرجالية مع أكمام من قطعتين", "design": "Joost De Cock", "difficulty": 3, "tags": ["blocks", "tops"], "techniques": ["hem", "curved-seam", "set-sleeve"] },
  "bibi": { "code": "Jonathan Haas", "description": "نمط FreeSewing لقالب جسم توب محبوك", "design": "Jonathan Haas", "difficulty": 2, "tags": ["blocks", "tops"], "techniques": ["curved-seam", "hem", "flat-sleeve"] },
  "bob": { "code": "Joost De Cock", "description": "نمط FreeSewing لمريلة أطفال (Bib)", "design": "Joost De Cock", "difficulty": 3, "tags": ["accessories", "infants"], "techniques": ["bias-tape", "curved-seam", "snap"] },
  "bonny": { "code": "Jonathan Haas", "description": "نمط FreeSewing يحول القياسات إلى مخطط للجسم", "design": "Jonathan Haas", "difficulty": 1, "tags": [], "techniques": [] },
  "box": { 
    "code": "Joost De Cock", 
    "description": "نمط FreeSewing لصندوق بسيط، يستخدم للتوثيق والاختبار", 
    "design": "Joost De Cock", 
    "difficulty": 1, 
    "tags": ["blocks", "examples"], 
    "techniques": ["precision"],
    "codeSnippet": `function draftBox({ options, Point, Path, points, paths, Snippet, snippets, sa, macro, part }) { ... }`
  },
  "breanna": { "code": "Joost De Cock", "description": "نمط FreeSewing لقالب جسم أساسي للملابس النسائية", "design": "Joost De Cock", "difficulty": 3, "tags": ["blocks", "tops"], "techniques": ["block", "dart"] },
  "brian": { "code": "Joost De Cock", "description": "نمط FreeSewing لقالب جسم أساسي للملابس الرجالية", "design": "Joost De Cock", "difficulty": 3, "tags": ["blocks", "tops"], "techniques": ["block", "flat-sleeve"] },
  "bruce": { "code": "Joost De Cock", "description": "نمط FreeSewing لسراويل داخلية بوكسر", "design": "Joost De Cock", "difficulty": 3, "tags": ["bottoms", "underwear"], "techniques": ["stretch", "hem", "curved-seam", "elastic"] },
  "carlita": { "code": "Joost De Cock", "description": "معطف طويل كلاسيكي مستوحى من زي شرلوك هولمز", "design": ["Anneke Caramin", "Joost De Cock"], "difficulty": 5, "tags": ["tops", "coats"], "techniques": ["hem", "pocket", "curved-seam", "precision", "set-sleeve", "welt-pocket", "lining", "princess-seam", "interfacing", "button"] },
  "carlton": { "code": "Joost De Cock", "description": "معطف رجالي طويل بتصميم كلاسيكي", "design": ["Anneke Caramin", "Joost De Cock"], "difficulty": 5, "tags": ["tops", "coats"], "techniques": ["hem", "pocket", "curved-seam", "precision", "set-sleeve", "welt-pocket", "lining", "interfacing", "button"] },
  "cathrin": { "code": "Joost De Cock", "description": "مشد تحت الصدر مصمم لتشكيل الخصر", "design": ["Cathrin Åhlén", "Joost De Cock"], "difficulty": 4, "tags": ["tops", "underwear"], "techniques": ["boning", "precision", "curved-seam", "interfacing"] },
  "charlie": { "code": "Joost De Cock", "description": "سراويل تشينو كلاسيكية مع جيوب مائلة", "design": "Joost De Cock", "difficulty": 3, "tags": ["bottoms", "trousers"], "techniques": ["welt-pocket", "curved-seam", "interfacing", "fly", "zipper", "button", "dart", "hem", "seam-pocket"] },
  "cornelius": { "code": "Wouter Van Wageningen", "description": "سراويل ركوب دراجات تاريخية", "design": "Wouter Van Wageningen", "difficulty": 3, "tags": ["bottoms", "trousers"], "techniques": ["curved-seam", "fly", "zipper", "button", "pocket"] },
  "diana": { "code": "Erica Alcusa Sáez", "description": "توب نسائي بياقة درابيه أنيقة", "design": "Erica Alcusa Sáez", "difficulty": 2, "tags": ["tops"], "techniques": ["curved-seam", "flat-sleeve", "hem"] },
  "florence": { "code": "Joost De Cock", "description": "كمامة وجه قماشية بسيطة", "design": "Joost De Cock", "difficulty": 1, "tags": ["accessories"], "techniques": ["curved-seam"] },
  "florent": { "code": ["Quentin Felix", "Joost De Cock"], "description": "قبعة مسطحة كلاسيكية", "design": "Quentin Felix", "difficulty": 3, "tags": ["accessories", "hats"], "techniques": ["curved-seam"] },
  "gozer": { "code": "Wouter Van Wageningen", "description": "زي شبح بسيط للحفلات", "design": "Wouter Van Wageningen", "difficulty": 1, "tags": ["costumes"], "techniques": ["hem"] },
  "hi": { "code": "Wouter Van Wageningen", "description": "لعبة قرش محشوة", "design": "Wouter Van Wageningen", "difficulty": 4, "tags": ["accessories", "toys"], "techniques": ["curved-seam", "dart"] },
  "holmes": { "code": ["Erica Alcusa Sáez", "bobgeorgethe3rd"], "description": "قبعة التحري شرلوك هولمز", "design": "Erica Alcusa Sáez", "difficulty": 3, "tags": ["accessories", "hats"], "techniques": ["curved-seam", "lining"] },
  "hortensia": { "code": "Wouter Van Wageningen", "description": "حقيبة يد واسعة", "design": ["Stoffsuchti", "Wouter Van Wageningen"], "difficulty": 3, "tags": ["accessories", "bags"], "techniques": ["curved-seam", "precision", "lining", "zipper"] },
  "huey": { "code": "Joost De Cock", "description": "سترة هودي عصرية بسحاب", "design": "Joost De Cock", "difficulty": 3, "tags": ["tops"], "techniques": ["curved-seam", "pocket", "zipper", "ribbing", "flat-sleeve"] },
  "hugo": { "code": "Joost De Cock", "description": "كنزة هودي مريحة بأكمام راجلان", "design": "Joost De Cock", "difficulty": 3, "tags": ["tops"], "techniques": ["curved-seam", "pocket", "ribbing", "raglan-sleeve"] },
  "jaeger": { "code": "Joost De Cock", "description": "سترة كلاسيكية بقصة جاكيت سبورت", "design": "Joost De Cock", "difficulty": 5, "tags": ["tops", "coats"], "techniques": ["hem", "pocket", "curved-seam", "precision", "set-sleeve", "welt-pocket", "lining", "interfacing", "button"] },
  "jane": { "code": "SeaZeeZee", "description": "ثوب داخلي تاريخي رقيق", "design": "SeaZeeZee", "difficulty": 2, "tags": ["tops", "historical", "underwear"], "techniques": ["hem"] },
  "legend": { "code": "Joost De Cock", "description": "دليل رموز FreeSewing التقني", "design": "Joost De Cock", "difficulty": 1, "tags": ["blocks", "internal"], "techniques": [] },
  "lucy": { "code": "SeaZeeZee", "description": "جيب تاريخي خارجي", "design": "SeaZeeZee", "difficulty": 2, "tags": ["accessories", "historical", "bags"], "techniques": ["curved-seam"] },
  "lumina": { "code": "Wouter Van Wageningen", "description": "ليقنز نسائي مريح", "design": "Wouter Van Wageningen", "difficulty": 3, "tags": ["bottoms", "trousers"], "techniques": ["stretch", "curved-seam", "elastic"] },
  "lumira": { "code": "Wouter Van Wageningen", "description": "ليقنز رياضي مرن", "design": "Wouter Van Wageningen", "difficulty": 3, "tags": ["bottoms", "trousers"], "techniques": ["stretch", "curved-seam", "elastic"] },
  "lunetius": { "code": "Rika Tamaike", "description": "رداء روماني تاريخي", "design": "Rika Tamaike", "difficulty": 1, "tags": ["tops", "coats", "historical"], "techniques": ["hem"] },
  "magde": { "code": "clegganator259", "description": "حقيبة مراسلات عملية", "design": "clegganator259", "difficulty": 3, "tags": ["accessories", "bags"], "techniques": [] },
  "noble": { "code": "Wouter Van Wageningen", "description": "قالب صدرية بقصات برنسيس", "design": "Wouter Van Wageningen", "difficulty": 3, "tags": ["blocks", "tops"], "techniques": ["block", "curved-seam", "precision", "princess-seam"] },
  "octoplushy": { "code": "Wouter Van Wageningen", "description": "لعبة أخطبوط محشوة", "design": "Wouter Van Wageningen", "difficulty": 4, "tags": ["accessories", "toys"], "techniques": ["curved-seam", "precision"] },
  "onyx": { "code": "Thrunic", "description": "ملابس نوم قطعة واحدة", "design": "Thrunic", "difficulty": 4, "tags": ["swimwear", "pajamas", "onePiece"], "techniques": ["hem", "curved-seam", "stretch", "lining", "zipper", "ribbing"] },
  "opal": { "code": "Thrunic", "description": "أوفرول عمل متين", "design": "Thrunic", "difficulty": 3, "tags": ["overalls", "onePiece"], "techniques": ["flat-felled-seam", "hem", "curved-seam", "button", "pocket"] },
  "otis": { "code": "Wouter Van Wageningen", "description": "ملابس أطفال قطعة واحدة", "design": "Wouter Van Wageningen", "difficulty": 2, "tags": ["infants"], "techniques": [] },
  "paco": { "code": "Joost De Cock", "description": "سراويل صيفية مريحة", "design": "Joost De Cock", "difficulty": 3, "tags": ["bottoms", "trousers"], "techniques": ["elastic", "curved-seam", "pocket", "welt-pocket", "hem"] },
  "penelope": { "code": "Wouter Van Wageningen", "description": "تنورة قلم الرصاص الكلاسيكية", "design": "Wouter Van Wageningen", "difficulty": 3, "tags": ["bottoms", "skirts"], "techniques": ["hem", "curved-seam", "precision", "zipper"] },
  "sandy": { "code": ["Erica Alcusa Sáez", "Joost De Cock"], "description": "تنورة دائرية كاملة", "design": "Erica Alcusa Sáez", "difficulty": 3, "tags": ["bottoms", "skirts"], "techniques": ["curved-seam", "button", "hem"] },
  "shelly": { "code": "Thrunic", "description": "توب رياضي بأكمام راجلان", "design": "Thrunic", "difficulty": 2, "tags": ["tops", "swimwear"], "techniques": ["hem", "stretch", "curved-seam", "raglan-sleeve"] },
  "shin": { "code": "Joost De Cock", "description": "شورت سباحة رجالي", "design": "Joost De Cock", "difficulty": 2, "tags": ["bottoms", "swimwear"], "techniques": ["hem", "stretch", "curved-seam", "elastic"] },
  "simon": { "code": "Joost De Cock", "description": "قميص رسمي كلاسيكي", "design": "Joost De Cock", "difficulty": 4, "tags": ["tops"], "techniques": ["hem", "button", "interfacing", "curved-seam", "flat-felled-seam", "flat-sleeve"] },
  "simone": { "code": "Joost De Cock", "description": "قميص نسائي رسمي بأزرار", "design": "Joost De Cock", "difficulty": 4, "tags": ["tops"], "techniques": ["hem", "button", "interfacing", "curved-seam", "flat-felled-seam", "flat-sleeve"] },
  "skully": { "code": "Wouter Van Wageningen", "description": "لعبة جمجمة محشوة (شعارنا)", "design": "Wouter Van Wageningen", "difficulty": 4, "tags": ["accessories", "toys"], "techniques": ["curved-seam", "precision"] },
  "sven": { "code": "Joost De Cock", "description": "سترة بلوفر بسيطة", "design": "Joost De Cock", "difficulty": 3, "tags": ["tops"], "techniques": ["curved-seam", "flat-sleeve", "ribbing"] },
  "tamiko": { "code": "Joost De Cock", "description": "توب ياباني مستوحى من الكيمونو", "design": "Joost De Cock", "difficulty": 1, "tags": ["tops"], "techniques": ["curved-seam"] },
  "teagan": { "code": "Joost De Cock", "description": "تي شيرت كاجوال مريح", "design": "Joost De Cock", "difficulty": 2, "tags": ["tops"], "techniques": ["curved-seam", "hem", "flat-sleeve", "knit-band"] },
  "tiberius": { "code": "Rika Tamaike", "description": "توب تونية تاريخية", "design": "Rika Tamaike", "difficulty": 1, "tags": ["tops", "historical"], "techniques": [] },
  "titan": { "code": "Joost De Cock", "description": "قالب سراويل للجنسين", "design": ["Debra Bean", "Joost De Cock"], "difficulty": 3, "tags": ["blocks", "bottoms"], "techniques": [] },
  "trayvon": { "code": "Joost De Cock", "description": "ربطة عنق تقليدية", "design": "Joost De Cock", "difficulty": 2, "tags": ["accessories"], "techniques": ["precision", "lining"] },
  "tristan": { "code": "Wouter van Wageningen", "description": "توب ضيق بقصات عصرية", "design": "Natalia Sayang", "difficulty": 3, "tags": ["tops"], "techniques": ["curved-seam", "precision"] },
  "uma": { "code": "Joost De Cock", "description": "سراويل تحتية نسائية", "design": "Joost De Cock", "difficulty": 2, "tags": ["bottoms", "underwear"], "techniques": ["elastic", "curved-seam"] },
  "umbra": { "code": ["Joost De Cock", "Jonathan Haas"], "description": "سراويل تحتية مرنة", "design": ["Joost De Cock", "Jonathan Haas"], "difficulty": 2, "tags": ["bottoms", "underwear"], "techniques": ["elastic", "curved-seam"] },
  "wahid": { "code": "Joost De Cock", "description": "فيست (صديرية) رجالي كلاسيكي", "design": "Joost De Cock", "difficulty": 4, "tags": ["tops"], "techniques": ["curved-seam", "hem", "interfacing", "lining", "welt-pocket", "button"] },
  "walburga": { "code": "Rika Tamaike", "description": "ثوب فرسان تاريخي", "design": "Rika Tamaike", "difficulty": 1, "tags": ["bottoms", "historical"], "techniques": ["hem"] },
  "waralee": { "code": "Wouter Van Wageningen", "description": "سراويل لف تايلاندية", "design": "Wouter Van Wageningen", "difficulty": 2, "tags": ["bottoms", "trousers"], "techniques": ["curved-seam", "hem", "welt-pocket"] },
  "yuri": { "code": "Hellgy", "description": "سترة هودي مبتكرة بدون سحاب", "design": "Biou", "difficulty": 3, "tags": ["tops"], "techniques": ["curved-seam", "flat-sleeve", "hem", "button"] },
  "lily": { "code": ["Anna Puk", "Joost De Cock"], "description": "ليقنز أساسي للبنات", "design": "Anna Puk", "difficulty": 2, "tags": ["bottoms"], "techniques": ["elastic", "curved-seam", "hem"] }
};

const rawPackages: Record<string, string> = {
  "collection": "الحزمة الرئيسية التي تضم كافة التصاميم",
  "config": "إعدادات تكوين النظام والأنماط",
  "core": "محرك FreeSewing الأساسي للرسم والقياسات",
  "i18n": "نظام الترجمة وتدويل المشروع",
  "models": "نماذج بيانات قياسات الجسم الافتراضية",
  "studio": "بيئة تطوير الأنماط التفاعلية",
  "prettier-config": "إعدادات تنسيق الكود الموحدة",
  "react": "مكتبة مكونات React المخصصة",
  "snapseries": "مولد سلاسل المقاسات التلقائي",
  "utils": "أدوات برمجية عامة للمشروع"
};

const rawPlugins: Record<string, string> = {
  "core-plugins": "الإضافات الأساسية المدمجة في النواة",
  "plugin-annotations": "إضافة للتعليقات التوضيحية والقياسات على البترون",
  "plugin-bin-pack": "خوارزمية رص الأجزاء لتقليل فاقد القماش",
  "plugin-bust": "تعديلات منطقة الصدر المتقدمة",
  "plugin-flip": "أدوات قلب وتدوير أجزاء البترون",
  "plugin-gore": "توليد قطع القبة والكرات",
  "plugin-i18n": "دعم اللغات المتعددة في SVG",
  "plugin-measurements": "حساب القياسات المشتقة تلقائياً",
  "plugin-mirror": "أدوات الانعكاس والتماثل",
  "plugin-ringsector": "رسم الأجزاء الدائرية والمقوسة",
  "plugin-round": "تدوير الحواف والزوايا برمجياً",
  "plugin-sprinkle": "توزيع الرموز (Snippets) على البترون",
  "plugin-svgattr": "التحكم في سمات ملفات SVG",
  "plugin-theme": "نظام السمات البصرية للبترونات",
  "plugin-timing": "قياس أداء رسم أجزاء البترون",
  "plugin-versionfree-svg": "إزالة معلومات الإصدار لتسهيل مقارنة الكود"
};

const rawTasks: Software[] = [
  { name: 'symlink', type: 'task', folder: 'scripts', description: 'إنشاء روابط رمزية للتطوير المحلي.', command: 'mkdir -p ./node_modules/@freesewing && cd ./node_modules/@freesewing && ln -s -f ../../../* . && cd -', tags: ['automation', 'setup'] },
  { name: 'global-test', type: 'task', folder: 'scripts', description: 'تشغيل الاختبارات الشاملة.', command: 'npm test', tags: ['testing'] },
  { name: 'tips', type: 'task', folder: 'scripts', description: 'عرض نصائح التطوير.', command: 'node scripts/help.mjs', tags: ['documentation'] },
  { name: 'global-lint', type: 'task', folder: 'scripts', description: 'فحص جودة الكود.', command: "npx eslint 'src/**'", tags: ['linting'] },
  { name: 'core-report', type: 'task', folder: 'core', description: 'تقرير تغطية اختبارات النواة.', command: 'c8 report', tags: ['testing', 'coverage'] },
  { name: 'backend-dev', type: 'task', folder: 'backend', description: 'تشغيل الخلفية في وضع التطوير.', command: 'nodemon src/index.mjs', tags: ['development', 'backend'] },
  { name: 'docusaurus-dev', type: 'task', folder: 'sites', description: 'تشغيل خادم التوثيق المحلي.', command: 'docusaurus start', tags: ['documentation', 'sites'] }
];

const rawMeasurements: Record<string, string> = {
  "ankle": "محيط الكاحل",
  "biceps": "محيط العضلة ذات الرأسين",
  "bustFront": "الصدر من الأمام",
  "bustPointToUnderbust": "من نقطة الصدر للأسفل",
  "chest": "محيط الصدر",
  "head": "محيط الرأس",
  "hips": "محيط الورك",
  "inseam": "طول الرجل الداخلي",
  "neck": "محيط الرقبة",
  "shoulderToWrist": "طول الذراع",
  "waist": "محيط الخصر"
};

const rawOptions: Record<string, string> = {
  "advanced": "خيارات متقدمة",
  "armhole": "فتحة الإبط",
  "collar": "الياقة",
  "darts": "البنسات",
  "fit": "الملاءمة",
  "pockets": "الجيوب",
  "style": "النمط الجمالي"
};

const rawTemplates: Record<string, string> = {
  "newsletter": newsletterHtml
};

const unpack = (obj: Record<string, string>, folder: string, type: SoftwareType): Software[] =>
  Object.keys(obj).map((name) => ({
    name,
    folder,
    type,
    description: obj[name],
  }));

export const allSoftware: Software[] = [
  ...Object.entries(rawDesigns).map(([name, data]) => ({
    name,
    type: 'design' as SoftwareType,
    folder: 'designs',
    ...data
  })),
  ...unpack(rawPackages, 'packages', 'package'),
  ...unpack(rawPlugins, 'plugins', 'plugin'),
  ...rawTasks,
  ...unpack(rawMeasurements, 'measurements', 'measurement'),
  ...unpack(rawOptions, 'options', 'option'),
  ...Object.entries(rawTemplates).map(([name, html]) => ({
    name,
    type: 'template' as SoftwareType,
    folder: 'templates',
    description: "قالب HTML الرسمي للنشرة الإخبارية.",
    codeSnippet: html,
    design: "Joost De Cock",
    code: "Joost De Cock",
    tags: ["newsletter", "email", "marketing"]
  }))
];

export const patterns = allSoftware.filter(s => s.type === 'design');
const tagsSet = new Set<string>();
const techSet = new Set<string>();
allSoftware.forEach(s => {
  s.tags?.forEach(t => tagsSet.add(t));
  s.techniques?.forEach(t => techSet.add(t));
});
export const allTags = Array.from(tagsSet).sort();
export const allTechniques = Array.from(techSet).sort();
