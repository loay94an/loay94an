
import { GoogleGenAI, Type, GenerateContentResponse } from "@google/genai";
import { allSoftware } from "./data";
import { ExtractedPattern } from "./types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getSewingAdviceStream = async (
  userPrompt: string, 
  onChunk: (text: string) => void,
  onGrounding: (sources: { title: string; uri: string }[]) => void
) => {
  const softwareListStr = allSoftware
    .map(s => `- [${s.type}] ${s.name}: ${s.description}`)
    .join('\n');

  const responseStream = await ai.models.generateContentStream({
    model: 'gemini-3-pro-preview',
    contents: `أنت مساعد خبير خياطة محترف لموقع FreeSewing.org.
    إليك قائمة بالبرامج المتاحة:
    ${softwareListStr}
    
    بناءً على طلب المستخدم: "${userPrompt}"، اقترح أفضل العناصر.
    يجب أن تكون إجابتك باللغة العربية حصراً وبصيغة Markdown.`,
    config: {
      tools: [{ googleSearch: {} }],
      temperature: 0.7,
    }
  });

  let fullText = "";
  for await (const chunk of responseStream) {
    const text = chunk.text;
    if (text) {
      fullText += text;
      onChunk(fullText);
    }
    const groundingChunks = (chunk as GenerateContentResponse).candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (groundingChunks) {
      const sources = groundingChunks
        .filter(c => c.web)
        .map(c => ({ title: c.web!.title || 'مصدر خارجي', uri: c.web!.uri }));
      if (sources.length > 0) onGrounding(sources);
    }
  }
};

export const getRepoSyncReport = async (onChunk: (text: string) => void) => {
  const responseStream = await ai.models.generateContentStream({
    model: 'gemini-3-flash-preview',
    contents: `ابحث في مستودع GitHub الخاص بـ FreeSewing (https://github.com/freesewing/freesewing) وقدم تقريرًا موجزًا بالعربية عن آخر التحديثات.`,
    config: { tools: [{ googleSearch: {} }], temperature: 0.5 }
  });

  let fullText = "";
  for await (const chunk of responseStream) {
    const text = chunk.text;
    if (text) { fullText += text; onChunk(fullText); }
  }
};

/**
 * Automatically handles design analysis and pattern extraction.
 * Supports both text descriptions and image references.
 */
export const extractPatternDesign = async (
  prompt: string,
  imageContent: { data: string, mimeType: string } | null,
  onProgress: (status: string) => void
): Promise<{ imageUrl: string; pattern: ExtractedPattern }> => {
  onProgress("جاري تحليل التصميم واستخراج الأنماط...");

  const blocks = allSoftware.filter(s => s.type === 'design' && s.tags?.includes('blocks')).map(s => s.name);

  // 1. Structured Data Extraction
  const extractionResponse = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: imageContent 
      ? { parts: [ { text: `Extract detailed sewing pattern specifications for the garment in this image. Context: ${prompt}` }, { inlineData: imageContent } ] }
      : `Extract detailed sewing pattern specifications based on this description: "${prompt}"`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          garmentType: { type: Type.STRING, description: "Type of garment (e.g., Hoodie, Dress)" },
          recommendedBaseBlock: { type: Type.STRING, description: `The most suitable FreeSewing base block from: ${blocks.join(', ')}` },
          requiredMeasurements: { type: Type.ARRAY, items: { type: Type.STRING }, description: "List of body measurements needed" },
          suggestedPlugins: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Recommended FreeSewing plugins" },
          technicalSteps: { type: Type.ARRAY, items: { type: Type.STRING }, description: "Drafting steps in Arabic" },
          complexity: { type: Type.NUMBER, description: "1-5 scale" },
          fabricRecommendations: { type: Type.STRING, description: "Fabric advice in Arabic" },
          starterCode: { type: Type.STRING, description: "Minimal FreeSewing JS drafting starter snippet" }
        },
        required: ["garmentType", "recommendedBaseBlock", "requiredMeasurements", "technicalSteps", "complexity", "starterCode"]
      }
    }
  });

  const extractedData = JSON.parse(extractionResponse.text || "{}") as ExtractedPattern;

  onProgress("جاري توليد المخطط البصري (Blueprint)...");

  // 2. Generate Visual Concept
  const visualResponse = await ai.models.generateContent({
    model: 'gemini-2.5-flash-image',
    contents: {
      parts: [
        { text: `A professional technical blueprint and a clean fashion illustration of a ${extractedData.garmentType}. Styled like a sewing pattern document. White background, high contrast, detailed stitching lines. Prompt context: ${prompt}` }
      ]
    },
    config: { imageConfig: { aspectRatio: "1:1" } }
  });

  let imageUrl = "";
  for (const part of visualResponse.candidates[0].content.parts) {
    if (part.inlineData) imageUrl = `data:image/png;base64,${part.inlineData.data}`;
  }

  return { imageUrl, pattern: extractedData };
};
