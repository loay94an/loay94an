
export type SoftwareType = 'design' | 'package' | 'plugin' | 'template' | 'task' | 'measurement' | 'option';

export interface Software {
  name: string;
  type: SoftwareType;
  folder: string;
  description: string;
  // Specific to designs
  code?: string | string[];
  design?: string | string[];
  difficulty?: number;
  tags?: string[];
  techniques?: string[];
  codeSnippet?: string;
  command?: string; // Shell command for tasks
}

export interface ExtractedPattern {
  garmentType: string;
  recommendedBaseBlock: string;
  requiredMeasurements: string[];
  suggestedPlugins: string[];
  technicalSteps: string[];
  complexity: number;
  fabricRecommendations: string;
  starterCode: string;
}

export interface PatternData {
  [key: string]: {
    code: string | string[];
    description: string;
    design: string | string[];
    difficulty?: number;
    tags?: string[];
    techniques?: string[];
    codeSnippet?: string;
  };
}

export type SortOption = 'difficulty-asc' | 'difficulty-desc' | 'name-asc' | 'name-desc';
