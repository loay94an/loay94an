
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { allSoftware, allTags, allTechniques, repoStatus } from './data';
import { Software, SortOption, SoftwareType } from './types';
import SoftwareCard from './components/SoftwareCard';
import SoftwareDetail from './components/SoftwareDetail';
import { getSewingAdviceStream, getRepoSyncReport } from './geminiService';
import { LiveMentor } from './components/LiveMentor';
import { DesignLab } from './components/DesignLab';

const translations = {
  design: 'تصاميم',
  package: 'حزم برمجية',
  plugin: 'إضافات',
  template: 'قوالب',
  task: 'مهام آلية',
  measurement: 'قياسات',
  option: 'خيارات الضبط',
  designLab: 'مختبر التصميم',
  explorer: 'المستكشف',
  search: 'بحث متقدم: الاسم، المصمم، الوسوم...',
  filters: 'تصفية النتائج',
  clearAll: 'إعادة تعيين',
  difficulty: 'مستوى الصعوبة',
  categories: 'التصنيفات',
  techniques: 'تقنيات الخياطة',
  scopes: 'مجالات العمل',
  aiMentor: 'المرشد الذكي',
  aiDescription: 'نصائح خبيرة في نظام FreeSewing. اسأل عن أي شيء أو ابدأ محادثة صوتية.',
  voiceChat: 'محادثة صوتية مباشرة',
  thinking: 'جاري التفكير والاستقصاء...',
  getAdvice: 'استشر الذكاء الاصطناعي',
  expertInsights: 'رؤى الخبراء',
  aiPowered: 'مدعوم بتقنية Gemini والبحث المتقدم',
  found: 'تم العثور على',
  items: 'عناصر',
  sortBy: 'ترتيب حسب:',
  nameAsc: 'الاسم (أ - ي)',
  nameDesc: 'الاسم (ي - أ)',
  diffAsc: 'الصعوبة (مبتدئ أولاً)',
  diffDesc: 'الصعوبة (خبير أولاً)',
  noResults: 'لم يتم العثور على نتائج تطابق اختياراتك',
  tryClearing: 'حاول تغيير الفلاتر أو البحث عن مصطلح آخر مثل اسم المصمم أو وسم معين.',
  resetFilters: 'إعادة ضبط الفلاتر',
  groundingSources: 'المصادر والمراجع',
  githubSync: 'مزامنة GitHub',
  syncing: 'جاري جلب البيانات من GitHub...',
  lastSynced: 'آخر مزامنة:',
  repoStats: 'إحصائيات المستودع',
  version: 'الإصدار:',
  stars: 'النجوم:',
  forks: 'النسخ:'
};

const App: React.FC = () => {
  const [activeType, setActiveType] = useState<SoftwareType | 'designLab'>('design');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [selectedTechniques, setSelectedTechniques] = useState<string[]>([]);
  const [selectedDifficulty, setSelectedDifficulty] = useState<number | null>(null);
  const [showInternal, setShowInternal] = useState(false);
  const [sortOption, setSortOption] = useState<SortOption>('name-asc');
  const [selectedItem, setSelectedItem] = useState<Software | null>(null);
  const [isLiveActive, setIsLiveActive] = useState(false);
  const [isSyncing, setIsSyncing] = useState(false);
  
  // AI Advice State
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiAdvice, setAiAdvice] = useState<string | null>(null);
  const [aiSources, setAiSources] = useState<{title: string, uri: string}[]>([]);
  const [isAiLoading, setIsAiLoading] = useState(false);
  const adviceEndRef = useRef<HTMLDivElement>(null);

  const softwareTypes: SoftwareType[] = ['design', 'package', 'plugin', 'template', 'task', 'measurement', 'option'];

  const handleSync = async () => {
    setIsSyncing(true);
    setAiAdvice(null);
    setAiSources([]);
    try {
      await getRepoSyncReport((text) => setAiAdvice(text));
    } catch (e) {
      console.error(e);
    } finally {
      setTimeout(() => setIsSyncing(false), 2000);
    }
  };

  const filteredItems = useMemo(() => {
    const term = searchTerm.toLowerCase().trim();
    
    return allSoftware
      .filter(p => {
        if (p.type !== activeType) return false;
        
        const isInternal = p.tags?.includes('internal');
        if (!showInternal && isInternal) return false;

        // Advanced Search Logic
        let matchesSearch = true;
        if (term) {
          const nameMatch = p.name.toLowerCase().includes(term);
          const descMatch = p.description.toLowerCase().includes(term);
          
          let designerMatch = false;
          if (p.design) {
            if (Array.isArray(p.design)) {
              designerMatch = p.design.some(d => d.toLowerCase().includes(term));
            } else {
              designerMatch = p.design.toLowerCase().includes(term);
            }
          }
          const tagsMatch = p.tags?.some(tag => tag.toLowerCase().includes(term)) || false;
          const techMatch = p.techniques?.some(tech => tech.toLowerCase().includes(term)) || false;
          const extraMatch = (p.command?.toLowerCase().includes(term)) || (p.folder?.toLowerCase().includes(term)) || false;
          matchesSearch = nameMatch || descMatch || designerMatch || tagsMatch || techMatch || extraMatch;
        }
        
        const matchesTags = selectedTags.length === 0 || selectedTags.every(t => p.tags?.includes(t));
        const matchesDifficulty = selectedDifficulty === null || p.difficulty === selectedDifficulty;
        const matchesTechniques = selectedTechniques.length === 0 || selectedTechniques.every(tech => p.techniques?.includes(tech));
        
        return matchesSearch && matchesTags && matchesDifficulty && matchesTechniques;
      })
      .sort((a, b) => {
        switch (sortOption) {
          case 'difficulty-asc': return (a.difficulty || 0) - (b.difficulty || 0);
          case 'difficulty-desc': return (b.difficulty || 0) - (a.difficulty || 0);
          case 'name-asc': return a.name.localeCompare(b.name);
          case 'name-desc': return b.name.localeCompare(a.name);
          default: return 0;
        }
      });
  }, [activeType, searchTerm, selectedTags, selectedTechniques, selectedDifficulty, sortOption, showInternal]);

  const toggleTag = (tag: string) => {
    setSelectedTags(prev => prev.includes(tag) ? prev.filter(t => t !== tag) : [...prev, tag]);
  };

  const toggleTechnique = (tech: string) => {
    setSelectedTechniques(prev => prev.includes(tech) ? prev.filter(t => t !== tech) : [...prev, tech]);
  };

  const resetFilters = () => {
    setSearchTerm('');
    setSelectedTags([]);
    setSelectedTechniques([]);
    setSelectedDifficulty(null);
    setShowInternal(false);
  };

  const handleAiAdvice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiPrompt.trim()) return;
    setIsAiLoading(true);
    setAiAdvice('');
    setAiSources([]);
    try {
      await getSewingAdviceStream(
        aiPrompt, 
        (text) => setAiAdvice(text),
        (sources) => setAiSources(prev => {
          const existingUris = new Set(prev.map(s => s.uri));
          const newSources = sources.filter(s => !existingUris.has(s.uri));
          return [...prev, ...newSources];
        })
      );
    } catch (error) {
      console.error(error);
      setAiAdvice("حدث خطأ تقني أثناء محاولة جلب النصيحة. يرجى المحاولة لاحقاً.");
    } finally {
      setIsAiLoading(false);
    }
  };

  useEffect(() => {
    adviceEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [aiAdvice]);

  return (
    <div className="min-h-screen bg-slate-50 text-slate-900 font-sans pb-20" dir="rtl">
      {isSyncing && (
        <div className="fixed inset-0 z-[100] bg-slate-950/90 backdrop-blur-md flex flex-col items-center justify-center p-8 text-white">
           <div className="w-24 h-24 mb-8 relative">
              <div className="absolute inset-0 border-4 border-indigo-500/20 rounded-full" />
              <div className="absolute inset-0 border-4 border-indigo-500 rounded-full border-t-transparent animate-spin" />
              <div className="absolute inset-0 flex items-center justify-center">
                 <svg className="w-10 h-10 text-indigo-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                   <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                 </svg>
              </div>
           </div>
           <h2 className="text-2xl font-black mb-4 tracking-tighter">{translations.syncing}</h2>
           <div className="w-64 h-1 bg-slate-800 rounded-full overflow-hidden mb-8">
              <div className="h-full bg-indigo-500 animate-[progress_2s_ease-in-out_infinite]" style={{ width: '40%' }} />
           </div>
        </div>
      )}

      <header className="sticky top-0 z-40 w-full bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-2 space-x-reverse">
              <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center text-white font-black text-xl shadow-lg shadow-indigo-200">FS</div>
              <h1 className="text-xl font-black tracking-tight hidden sm:block">
                FreeSewing <span className="text-indigo-600">{translations.explorer}</span>
              </h1>
            </div>
            
            <nav className="hidden xl:flex items-center space-x-1 space-x-reverse bg-slate-100 p-1 rounded-xl">
               <button
                 onClick={() => { setActiveType('designLab'); resetFilters(); }}
                 className={`px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all flex items-center gap-2 ${
                   activeType === 'designLab' ? 'bg-indigo-600 text-white shadow-sm' : 'text-slate-500 hover:text-indigo-600'
                 }`}
               >
                 <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path d="M7 3a1 1 0 000 2h6a1 1 0 100-2H7zM4 7a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zM2 11a2 2 0 012-2h12a2 2 0 012 2v4a2 2 0 01-2 2H4a2 2 0 01-2-2v-4z"/></svg>
                 {translations.designLab}
               </button>
               <div className="w-px h-4 bg-slate-300 mx-1"></div>
               {softwareTypes.map(t => (
                 <button
                   key={t}
                   onClick={() => { setActiveType(t); resetFilters(); }}
                   className={`px-4 py-2 rounded-lg text-xs font-black uppercase tracking-widest transition-all ${
                     activeType === t ? 'bg-white text-indigo-600 shadow-sm' : 'text-slate-500 hover:text-slate-800'
                   }`}
                 >
                   {translations[t as keyof typeof translations]}
                 </button>
               ))}
            </nav>

            <div className="flex items-center space-x-4 space-x-reverse">
              <button 
                onClick={handleSync}
                className="hidden md:flex items-center space-x-2 space-x-reverse px-4 py-2 bg-slate-900 text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition-all shadow-lg shadow-slate-200"
              >
                <svg className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
                </svg>
                <span>{translations.githubSync}</span>
              </button>
              <div className="relative group">
                <input 
                  type="text" 
                  placeholder={translations.search}
                  className="pr-10 pl-4 py-2 bg-slate-100 border-none rounded-full text-sm focus:ring-2 focus:ring-indigo-500 w-48 sm:w-80 transition-all shadow-inner"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
                <svg className="w-4 h-4 absolute right-3 top-2.5 text-slate-400 group-focus-within:text-indigo-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="xl:hidden bg-white border-b border-slate-100 flex p-2 overflow-x-auto no-scrollbar">
          <button
              onClick={() => { setActiveType('designLab'); resetFilters(); }}
              className={`flex-1 min-w-[120px] px-4 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap flex items-center justify-center gap-2 ${
                activeType === 'designLab' ? 'bg-indigo-600 text-white' : 'text-indigo-400'
              }`}
          >
             <svg className="w-3 h-3" fill="currentColor" viewBox="0 0 20 20"><path d="M7 3a1 1 0 000 2h6a1 1 0 100-2H7zM4 7a1 1 0 011-1h10a1 1 0 110 2H5a1 1 0 01-1-1zM2 11a2 2 0 012-2h12a2 2 0 012 2v4a2 2 0 01-2 2H4a2 2 0 01-2-2v-4z"/></svg>
             {translations.designLab}
          </button>
          {softwareTypes.map(t => (
            <button
              key={t}
              onClick={() => { setActiveType(t); resetFilters(); }}
              className={`flex-1 min-w-[100px] px-4 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${
                activeType === t ? 'bg-indigo-50 text-indigo-600' : 'text-slate-400'
              }`}
            >
              {translations[t as keyof typeof translations]}
            </button>
          ))}
      </div>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {activeType === 'designLab' ? (
          <DesignLab />
        ) : (
          <div className="flex flex-col lg:flex-row gap-8">
            <aside className="lg:w-64 flex-shrink-0 space-y-8 no-scrollbar lg:max-h-[calc(100vh-120px)] lg:overflow-y-auto lg:sticky lg:top-24">
              <section className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm">
                 <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4">{translations.repoStats}</h3>
                 <div className="space-y-3">
                    <div className="flex justify-between items-center text-xs">
                       <span className="text-slate-500">{translations.version}</span>
                       <span className="font-mono font-bold text-indigo-600">{repoStatus.version}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                       <span className="text-slate-500">{translations.stars}</span>
                       <span className="font-bold text-slate-800">{repoStatus.stars}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs">
                       <span className="text-slate-500">{translations.forks}</span>
                       <span className="font-bold text-slate-800">{repoStatus.forks}</span>
                    </div>
                    <div className="pt-2 mt-2 border-t border-slate-50">
                       <p className="text-[9px] text-slate-400">{translations.lastSynced} {new Date(repoStatus.lastSync).toLocaleDateString('ar-EG')}</p>
                    </div>
                 </div>
              </section>

              <div className="flex items-center justify-between mb-2">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest">{translations.filters}</h3>
                <button 
                  onClick={resetFilters}
                  className="text-[10px] text-indigo-500 font-bold hover:text-indigo-700 uppercase tracking-tighter"
                >
                  {translations.clearAll}
                </button>
              </div>

              {activeType === 'design' && (
                <>
                  <section>
                    <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">{translations.difficulty}</h3>
                    <div className="flex flex-wrap gap-2">
                      {[1, 2, 3, 4, 5].map(lvl => (
                        <button
                          key={lvl}
                          onClick={() => setSelectedDifficulty(selectedDifficulty === lvl ? null : lvl)}
                          className={`w-9 h-9 rounded-lg font-bold transition-all border ${
                            selectedDifficulty === lvl 
                            ? 'bg-indigo-600 text-white border-indigo-600 shadow-lg shadow-indigo-100' 
                            : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300'
                          }`}
                        >
                          {lvl}
                        </button>
                      ))}
                    </div>
                  </section>

                  <section>
                    <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">{translations.categories}</h3>
                    <div className="flex flex-wrap gap-1.5">
                      {allTags.map(tag => (
                        <button
                          key={tag}
                          onClick={() => toggleTag(tag)}
                          className={`px-3 py-1 rounded-full text-[11px] font-medium transition-all border ${
                            selectedTags.includes(tag)
                            ? 'bg-indigo-600 text-white border-indigo-600'
                            : 'bg-white text-slate-600 border-slate-200 hover:border-indigo-300'
                          }`}
                        >
                          {tag}
                        </button>
                      ))}
                    </div>
                  </section>
                </>
              )}

              <section className="bg-gradient-to-br from-indigo-900 to-indigo-800 rounded-2xl p-6 text-white shadow-xl relative overflow-hidden group">
                <div className="absolute top-0 left-0 p-2 opacity-20 group-hover:opacity-100 transition-opacity">
                   <button 
                     onClick={() => setIsLiveActive(true)}
                     className="w-8 h-8 rounded-full bg-white text-indigo-600 flex items-center justify-center shadow-lg hover:scale-110 transition-transform"
                   >
                     <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 005.93 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd" /></svg>
                   </button>
                </div>
                <h3 className="text-lg font-bold mb-2 flex items-center">
                  <svg className="w-5 h-5 ml-2 text-indigo-400" fill="currentColor" viewBox="0 0 20 20"><path d="M10 2a1 1 0 011 1v1a1 1 0 11-2 0V3a1 1 0 011-1zm4 8a4 4 0 11-8 0 4 4 0 018 0zm-.464 4.95l.707.707a1 1 0 001.414-1.414l-.707-.707a1 1 0 00-1.414 1.414zm2.12-10.607a1 1 0 010 1.414l-.706.707a1 1 0 11-1.414-1.414l.707-.707a1 1 0 011.414 0zM17 11a1 1 0 100-2h-1a1 1 0 100 2h1zm-7 4a1 1 0 011 1v1a1 1 0 11-2 0v-1a1 1 0 011-1zM5.05 6.464A1 1 0 106.464 5.05l-.707-.707a1 1 0 00-1.414 1.414l.707.707zm1.414 8.486l-.707.707a1 1 0 01-1.414-1.414l.707-.707a1 1 0 011.414 1.414zM4 11a1 1 0 100-2H3a1 1 0 000 2h1z" /></svg>
                  {translations.aiMentor}
                </h3>
                <p className="text-indigo-200 text-xs mb-4 leading-relaxed">
                  {translations.aiDescription} <button onClick={() => setIsLiveActive(true)} className="underline decoration-indigo-400 hover:text-white transition-colors">{translations.voiceChat}</button>.
                </p>
                <form onSubmit={handleAiAdvice} className="space-y-3">
                  <textarea 
                    rows={3}
                    className="w-full bg-indigo-950/40 border border-indigo-700/50 rounded-xl text-[11px] p-3 placeholder:text-indigo-400 focus:ring-1 focus:ring-indigo-400 transition-all outline-none resize-none"
                    placeholder={`أخبرني ما الذي تود معرفته عن ${translations[activeType as keyof typeof translations] || 'هذا القسم'}...`}
                    value={aiPrompt}
                    onChange={(e) => setAiPrompt(e.target.value)}
                  />
                  <button 
                    type="submit"
                    disabled={isAiLoading}
                    className="w-full py-2.5 bg-indigo-500 hover:bg-indigo-400 disabled:bg-indigo-800/50 disabled:text-indigo-400 font-bold rounded-xl text-xs transition-all flex items-center justify-center shadow-lg shadow-indigo-950/20"
                  >
                    {isAiLoading ? translations.thinking : translations.getAdvice}
                  </button>
                </form>
              </section>
            </aside>

            <div className="flex-1">
              {(aiAdvice || isAiLoading) && (
                <div className="mb-10 bg-white rounded-2xl p-6 sm:p-8 border-r-4 border-indigo-500 shadow-xl relative overflow-hidden animate-in slide-in-from-top duration-700">
                  <button 
                    onClick={() => {setAiAdvice(null); setAiSources([]);}}
                    className="absolute top-4 left-4 p-1.5 rounded-full hover:bg-slate-100 text-slate-300 hover:text-slate-600 transition-colors"
                  >
                    <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                  </button>
                  <div className="flex items-center space-x-3 space-x-reverse mb-6">
                    <div className="w-10 h-10 bg-indigo-50 text-indigo-600 rounded-xl flex items-center justify-center shadow-sm">
                      <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" /></svg>
                    </div>
                    <div>
                      <h2 className="text-xl font-black text-slate-800">{translations.expertInsights}</h2>
                      <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">{translations.aiPowered}</p>
                    </div>
                  </div>
                  <div className="prose prose-indigo prose-sm sm:prose-base max-w-none text-slate-600 leading-relaxed whitespace-pre-wrap">
                    {aiAdvice || (isAiLoading && <div className="animate-pulse space-y-2"><div className="h-4 bg-slate-100 rounded w-3/4"></div><div className="h-4 bg-slate-100 rounded w-1/2"></div></div>)}
                    <div ref={adviceEndRef} />
                  </div>
                  {aiSources.length > 0 && (
                    <div className="mt-8 pt-6 border-t border-slate-100">
                      <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3">{translations.groundingSources}</h4>
                      <div className="flex flex-wrap gap-2">
                        {aiSources.map((source, i) => (
                          <a key={i} href={source.uri} target="_blank" rel="noopener noreferrer" className="px-3 py-1 bg-slate-50 border border-slate-200 hover:border-indigo-300 hover:bg-indigo-50 rounded-full text-xs text-indigo-600 font-medium transition-all">{source.title}</a>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              )}

              <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-8 gap-4">
                <div className="text-slate-500 text-sm">
                  {translations.found} <span className="font-bold text-slate-900">{filteredItems.length}</span> من {translations[activeType as keyof typeof translations]}
                </div>
                <div className="flex items-center space-x-2 space-x-reverse">
                  <span className="text-sm text-slate-400">{translations.sortBy}</span>
                  <select 
                    className="bg-transparent border-none text-sm font-bold focus:ring-0 cursor-pointer text-indigo-600 pl-8 pr-0"
                    value={sortOption}
                    onChange={(e) => setSortOption(e.target.value as SortOption)}
                  >
                    <option value="name-asc">{translations.nameAsc}</option>
                    <option value="name-desc">{translations.nameDesc}</option>
                    {activeType === 'design' && (
                      <>
                        <option value="difficulty-asc">{translations.diffAsc}</option>
                        <option value="difficulty-desc">{translations.diffDesc}</option>
                      </>
                    )}
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 animate-in fade-in duration-700">
                {filteredItems.map(item => (
                  <SoftwareCard key={`${item.name}-${item.type}`} item={item} onClick={setSelectedItem} />
                ))}
              </div>
              
              {filteredItems.length === 0 && (
                <div className="flex flex-col items-center justify-center py-24 text-center bg-white rounded-3xl border border-dashed border-slate-200">
                  <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-6">
                    <svg className="w-10 h-10 text-slate-200" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" /></svg>
                  </div>
                  <h3 className="text-xl font-black text-slate-800 mb-2">{translations.noResults}</h3>
                  <p className="text-slate-400 text-sm max-w-xs mx-auto">{translations.tryClearing}</p>
                  <button onClick={resetFilters} className="mt-8 px-6 py-2 bg-indigo-50 text-indigo-600 font-bold rounded-xl hover:bg-indigo-100 transition-colors">{translations.resetFilters}</button>
                </div>
              )}
            </div>
          </div>
        )}
      </main>

      {selectedItem && <SoftwareDetail item={selectedItem} onClose={() => setSelectedItem(null)} />}
      {isLiveActive && <LiveMentor onClose={() => setIsLiveActive(false)} />}

      <footer className="mt-12 py-12 border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center space-x-2 space-x-reverse">
              <div className="w-8 h-8 bg-slate-800 rounded flex items-center justify-center text-white font-black text-sm">FS</div>
              <span className="font-black text-slate-800 tracking-tighter">FS {translations.explorer}</span>
            </div>
            <div className="flex space-x-6 space-x-reverse text-[11px] font-bold text-slate-400 uppercase tracking-widest">
              <a href="https://freesewing.org" target="_blank" className="hover:text-indigo-600 transition-colors">الموقع الرسمي</a>
              <a href="https://github.com/freesewing/freesewing" target="_blank" className="hover:text-indigo-600 transition-colors">مستودع GitHub</a>
              <a href="https://discord.freesewing.org" target="_blank" className="hover:text-indigo-600 transition-colors">مجتمع Discord</a>
            </div>
            <div className="text-[10px] text-slate-400 font-medium">صُنع بحب 💖 لمجتمع الخياطة العالمي FreeSewing.</div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
