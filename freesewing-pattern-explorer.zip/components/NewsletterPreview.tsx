
import React, { useState, useMemo } from 'react';

interface NewsletterPreviewProps {
  template: string;
}

const NewsletterPreview: React.FC<NewsletterPreviewProps> = ({ template }) => {
  const [title, setTitle] = useState("تحديث FreeSewing الأسبوعي: أنماط جديدة بانتظارك!");
  const [content, setContent] = useState(`<h1>أهلاً بك في عالم الخياطة المبدع!</h1><p>يسعدنا أن نشاركك آخر التحديثات من FreeSewing. لقد أضفنا مؤخراً خيارات جديدة لنمط <b>Box</b> لتسهيل عمليات الاختبار والتوثيق.</p><p>لا تنسَ تجربة ميزة "المرشد الذكي" الجديدة في مستكشفنا!</p>`);
  const [isMobile, setIsMobile] = useState(false);

  const renderedHtml = useMemo(() => {
    return template
      .replace(/{{ title }}/g, title)
      .replace(/{{{ content }}}/g, content)
      .replace(/{{ support }}/g, "ادعم FreeSewing عبر Patreon")
      .replace(/{{{ unsubscribe }}}/g, "#")
      .replace(/{{ unsub1 }}/g, "إلغاء الاشتراك")
      .replace(/{{ unsub2 }}/g, "من هذه القائمة البريدية");
  }, [template, title, content]);

  return (
    <div className="flex flex-col h-full bg-slate-50 text-right" dir="rtl">
      <div className="p-6 border-b border-slate-200 bg-white space-y-4">
        <div className="flex justify-between items-center">
          <h3 className="text-xs font-black uppercase tracking-widest text-slate-400">محرر معاينة النشرة الإخبارية</h3>
          <button 
            onClick={() => setIsMobile(!isMobile)}
            className="flex items-center space-x-2 space-x-reverse px-4 py-1.5 bg-indigo-50 text-indigo-600 rounded-lg text-[10px] font-black uppercase tracking-tighter hover:bg-indigo-100 transition-colors shadow-sm"
          >
            {isMobile ? (
              <>
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.75 17L9 20l-1 1h8l-1-1-.75-3M3 13h18M5 17h14a2 2 0 002-2V5a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                </svg>
                <span>عرض سطح المكتب</span>
              </>
            ) : (
              <>
                <svg className="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 18h.01M8 21h8a2 2 0 002-2V5a2 2 0 00-2-2H8a2 2 0 00-2 2v14a2 2 0 002 2z" />
                </svg>
                <span>عرض الجوال</span>
              </>
            )}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-3">
            <div>
              <label className="block text-[10px] font-black uppercase tracking-tighter text-slate-400 mb-1">عنوان البريد (Subject)</label>
              <input 
                type="text" 
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-lg text-sm focus:ring-1 focus:ring-indigo-500 outline-none text-right shadow-inner"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
              />
            </div>
            <div>
              <label className="block text-[10px] font-black uppercase tracking-tighter text-slate-400 mb-1">المحتوى الأساسي (HTML مدعوم)</label>
              <textarea 
                rows={6}
                className="w-full px-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-sans focus:ring-1 focus:ring-indigo-500 outline-none resize-none text-right shadow-inner"
                value={content}
                onChange={(e) => setContent(e.target.value)}
              />
            </div>
          </div>
          <div className="hidden md:flex flex-col justify-center items-center bg-slate-50 border border-dashed border-slate-200 rounded-xl p-4 text-center">
             <div className="w-12 h-12 bg-indigo-100 rounded-full flex items-center justify-center text-indigo-600 mb-2">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
             </div>
             <p className="text-[10px] text-slate-400 font-bold max-w-[200px]">
               قم بتعديل المحتوى على اليمين لرؤية النتيجة في المعاينة أدناه مباشرةً.
             </p>
          </div>
        </div>
      </div>

      <div className="flex-1 bg-slate-200 p-4 md:p-8 flex justify-center overflow-y-auto no-scrollbar">
        <div className={`bg-white shadow-2xl transition-all duration-500 rounded-lg overflow-hidden border border-slate-300 ${isMobile ? 'w-[375px]' : 'w-full max-w-[650px]'}`}>
           <iframe 
             title="Newsletter Preview"
             srcDoc={renderedHtml}
             className="w-full h-[800px] border-none"
           />
        </div>
      </div>
    </div>
  );
};

export default NewsletterPreview;
