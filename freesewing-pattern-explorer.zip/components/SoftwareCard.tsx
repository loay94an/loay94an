
import React from 'react';
import { Software } from '../types';

interface SoftwareCardProps {
  item: Software;
  onClick: (item: Software) => void;
}

const SoftwareCard: React.FC<SoftwareCardProps> = ({ item, onClick }) => {
  const difficultyColor = (diff: number) => {
    if (diff <= 1) return 'bg-emerald-50 text-emerald-700 border-emerald-100';
    if (diff <= 2) return 'bg-sky-50 text-sky-700 border-sky-100';
    if (diff <= 3) return 'bg-amber-50 text-amber-700 border-amber-100';
    if (diff <= 4) return 'bg-orange-50 text-orange-700 border-orange-100';
    return 'bg-rose-50 text-rose-700 border-rose-100';
  };

  const typeColors = {
    design: 'border-indigo-100 bg-indigo-50/50',
    package: 'border-teal-100 bg-teal-50/50',
    plugin: 'border-violet-100 bg-violet-50/50',
    template: 'border-rose-100 bg-rose-50/50',
    task: 'border-amber-200 bg-amber-50/50',
    measurement: 'border-blue-100 bg-blue-50/50',
    option: 'border-fuchsia-100 bg-fuchsia-50/50'
  };

  const typeLabels = {
    design: 'تصميم',
    package: 'حزمة',
    plugin: 'إضافة',
    template: 'قالب',
    task: 'مهمة',
    measurement: 'قياس',
    option: 'خيار'
  };

  return (
    <div 
      onClick={() => onClick(item)}
      className={`group cursor-pointer bg-white rounded-2xl shadow-sm hover:shadow-xl border overflow-hidden transition-all duration-500 hover:-translate-y-2 flex flex-col h-full ${typeColors[item.type]}`}
    >
      <div className="relative h-48 bg-slate-50 flex items-center justify-center border-b border-slate-100 overflow-hidden">
        {item.type === 'task' ? (
          <div className="w-full h-full bg-slate-900 flex flex-col p-6 font-mono text-[10px] text-emerald-400 overflow-hidden group-hover:bg-slate-800 transition-colors">
            <div className="flex space-x-1 space-x-reverse mb-4">
              <div className="w-2 h-2 rounded-full bg-rose-500" />
              <div className="w-2 h-2 rounded-full bg-amber-500" />
              <div className="w-2 h-2 rounded-full bg-emerald-500" />
            </div>
            <div className="flex items-start">
              <span className="text-indigo-400 ml-2">$</span>
              <span className="break-all">{item.command?.slice(0, 100)}{item.command && item.command.length > 100 ? '...' : ''}</span>
            </div>
            <div className="mt-auto opacity-40">_</div>
          </div>
        ) : item.type === 'measurement' ? (
           <div className="w-full h-full bg-slate-100 flex flex-col items-center justify-center relative p-8 group-hover:bg-blue-50 transition-colors">
              <div className="absolute inset-0 border-[0.5px] border-slate-200/50" style={{ backgroundImage: 'linear-gradient(to right, #e2e8f0 1px, transparent 1px), linear-gradient(to bottom, #e2e8f0 1px, transparent 1px)', backgroundSize: '20px 20px' }} />
              <svg className="w-16 h-16 text-blue-400 opacity-60 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121m0 5.758L5 19m0-14l4.121 4.121" />
              </svg>
              <div className="mt-4 text-[10px] font-mono text-slate-400 z-10 uppercase tracking-widest">مرجع القياس</div>
           </div>
        ) : item.type === 'option' ? (
           <div className="w-full h-full bg-fuchsia-50 flex flex-col items-center justify-center relative p-8 group-hover:bg-fuchsia-100 transition-colors">
              <div className="absolute inset-0 border-[0.5px] border-fuchsia-200/30" style={{ backgroundImage: 'radial-gradient(#d946ef 0.5px, transparent 0.5px)', backgroundSize: '15px 15px' }} />
              <svg className="w-16 h-16 text-fuchsia-500 opacity-60 relative z-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
              </svg>
              <div className="mt-4 text-[10px] font-mono text-fuchsia-700 z-10 uppercase font-black tracking-widest">خيار الضبط</div>
           </div>
        ) : (
          <img 
            src={`https://picsum.photos/seed/fs-${item.name}-${item.type}/600/400`} 
            alt={item.name}
            loading="lazy"
            className="w-full h-full object-cover grayscale-[20%] group-hover:grayscale-0 group-hover:scale-105 transition-all duration-1000 ease-out"
          />
        )}
        
        {item.type === 'design' && item.difficulty && (
          <div className="absolute top-4 left-4 shadow-xl">
            <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${difficultyColor(item.difficulty)}`}>
              مستوى {item.difficulty}
            </span>
          </div>
        )}

        <div className="absolute bottom-4 right-4">
          <span className={`px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-widest border border-white/20 bg-black/30 text-white backdrop-blur`}>
            {typeLabels[item.type]}
          </span>
        </div>
        
        {/* Overlay on hover */}
        <div className="absolute inset-0 bg-indigo-900/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center">
          <span className="bg-white/90 backdrop-blur px-4 py-2 rounded-full text-xs font-bold text-indigo-900 shadow-2xl transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
            {item.type === 'task' ? 'عرض الأمر' : 'عرض التفاصيل'}
          </span>
        </div>
      </div>
      
      <div className="p-6 flex flex-col flex-1">
        <div className="mb-3">
          <h3 className="text-xl font-black text-slate-800 capitalize mb-1 group-hover:text-indigo-600 transition-colors tracking-tight">
            {item.name.replace('global-', '')}
          </h3>
          {item.design ? (
            <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
              {Array.isArray(item.design) ? item.design[0] : item.design}
            </p>
          ) : (
             <p className={`text-[10px] font-bold uppercase tracking-widest ${item.type === 'option' ? 'text-fuchsia-600' : 'text-indigo-400'}`}>
                {item.type === 'measurement' ? 'صُنع حسب القياس' : (item.type === 'option' ? 'قابل للتخصيص' : `المجال: ${item.folder}`)}
             </p>
          )}
        </div>
        
        <p className="text-slate-500 text-sm line-clamp-2 mb-6 leading-relaxed font-medium">
          {item.description}
        </p>
        
        {item.tags && (
          <div className="flex flex-wrap gap-1.5 mt-auto">
            {item.tags.slice(0, 3).map(tag => (
              <span key={tag} className="text-[9px] px-2 py-0.5 bg-slate-50 text-slate-500 rounded border border-slate-100 uppercase font-black tracking-tighter">
                {tag}
              </span>
            ))}
            {item.tags.length > 3 && (
              <span className="text-[9px] px-2 py-0.5 text-slate-400 italic font-bold">
                +{item.tags.length - 3}
              </span>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default SoftwareCard;
