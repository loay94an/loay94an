
import React from 'react';
/* Use 'Software' type as 'Pattern' is not defined in types.ts */
import { Software } from '../types';

interface PatternDetailProps {
  pattern: Software;
  onClose: () => void;
}

const PatternDetail: React.FC<PatternDetailProps> = ({ pattern, onClose }) => {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl relative animate-in zoom-in-95 duration-300">
        <button 
          onClick={onClose}
          className="absolute top-4 right-4 p-2 rounded-full hover:bg-slate-100 transition-colors z-10"
        >
          <svg className="w-6 h-6 text-slate-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="h-64 sm:h-80 w-full overflow-hidden">
          <img 
            src={`https://picsum.photos/seed/${pattern.name}/800/600`} 
            alt={pattern.name}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="p-8">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
            <div>
              <h2 className="text-4xl font-extrabold text-slate-900 capitalize mb-1">{pattern.name}</h2>
              <p className="text-indigo-600 font-medium italic">
                Designed by: {Array.isArray(pattern.design) ? pattern.design.join(', ') : pattern.design}
              </p>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-slate-400 font-semibold uppercase">Difficulty</span>
              <div className="flex space-x-1">
                {[1, 2, 3, 4, 5].map(star => (
                  <div 
                    key={star} 
                    className={`h-2 w-8 rounded-full ${star <= (pattern.difficulty || 1) ? 'bg-indigo-500' : 'bg-slate-200'}`}
                  />
                ))}
              </div>
            </div>
          </div>

          <p className="text-slate-600 text-lg leading-relaxed mb-8">
            {pattern.description}
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-8">
            <div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 11h.01M7 15h.01M13 7h.01M13 11h.01M13 15h.01M17 7h.01M17 11h.01M17 15h.01" />
                </svg>
                Tags
              </h4>
              <div className="flex flex-wrap gap-2">
                {pattern.tags?.map(tag => (
                  <span key={tag} className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-full text-sm font-medium">
                    {tag}
                  </span>
                ))}
              </div>
            </div>

            <div>
              <h4 className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center">
                <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
                Techniques
              </h4>
              <div className="flex flex-wrap gap-2">
                {pattern.techniques?.map(tech => (
                  <span key={tech} className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-sm font-medium">
                    {tech.replace(/-/g, ' ')}
                  </span>
                ))}
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-100 flex justify-between items-center">
             <div className="text-xs text-slate-400">
               Maintainer: {Array.isArray(pattern.code) ? pattern.code.join(', ') : pattern.code}
             </div>
             <a 
               href={`https://freesewing.org/designs/${pattern.name}`}
               target="_blank"
               rel="noopener noreferrer"
               className="inline-flex items-center px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-xl transition-all shadow-lg shadow-indigo-200"
             >
               View on FreeSewing
               <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                 <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
               </svg>
             </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PatternDetail;
