
import React, { useState } from 'react';
import { Software } from '../types';
import NewsletterPreview from './NewsletterPreview';

interface SoftwareDetailProps {
  item: Software;
  onClose: () => void;
}

const softwareTranslations = {
  design: 'تصميم',
  package: 'حزمة',
  plugin: 'إضافة',
  template: 'قالب',
  task: 'مهمة',
  measurement: 'قياس',
  option: 'خيار',
  preview: 'معاينة',
  source: 'المصدر',
  by: 'بواسطة:',
  folder: 'المجلد:',
  difficulty: 'الصعوبة',
  status: 'الحالة',
  readyToRun: 'جاهز للتنفيذ',
  tags: 'الوسوم',
  techniques: 'التقنيات',
  fullCommand: 'الأمر الكامل',
  templateSource: 'مصدر القالب',
  draftingLogic: 'منطق الرسم',
  boilerplate: 'قالب المطور',
  showCode: 'عرض الكود',
  hideCode: 'إخفاء الكود',
  maintainer: 'المسؤول:',
  monorepoScript: 'سكربت أتمتة Monorepo',
  exploreOnGitHub: 'استكشف على GitHub',
  viewOnFS: 'عرض في FreeSewing'
};

const SoftwareDetail: React.FC<SoftwareDetailProps> = ({ item, onClose }) => {
  const [showCode, setShowCode] = useState(false);
  const [viewMode, setViewMode] = useState<'details' | 'preview'>(item.type === 'template' ? 'preview' : 'details');

  const getBoilerplate = () => {
    const capitalizedName = item.name.charAt(0).toUpperCase() + item.name.slice(1);
    if (item.type === 'design') {
      return `import { Design } from '@freesewing/core'
import { i18n } from '../i18n/index.mjs'
import { data } from '../data.mjs'
import { ${item.name} } from './${item.name}.mjs'

// Create new design
const ${capitalizedName} = new Design({
  data,
  parts: [${item.name}],
})

// Named exports
export { ${item.name}, i18n, ${capitalizedName} }`;
    } else if (item.type === 'plugin') {
      return `export const plugin = {
  name: "${item.name}",
  version: "1.0.0",
  macros: {
    ${item.name}: function (so, {points, paths, Path}) {
      const defaults = {
        scale: 1,
        rotation: 0,
      }
      so = { ...defaults, ...so }
      // Write your plugin logic here
    },
  },
}

export const ${item.name}Plugin = plugin;`;
    }
    return null;
  };

  const boilerplate = getBoilerplate();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-sm animate-in fade-in duration-300">
      <div className={`bg-white rounded-3xl w-full max-w-4xl max-h-[95vh] overflow-hidden shadow-2xl relative animate-in zoom-in-95 duration-300 flex flex-col`}>
        {/* Modal Header */}
        <div className="absolute top-4 left-4 z-50 flex items-center space-x-2 space-x-reverse">
          {item.type === 'template' && (
             <div className="flex bg-black/10 backdrop-blur rounded-xl p-1">
                <button 
                  onClick={() => setViewMode('preview')}
                  className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter transition-all ${viewMode === 'preview' ? 'bg-white text-indigo-600 shadow-sm' : 'text-white hover:bg-white/10'}`}
                >
                  {softwareTranslations.preview}
                </button>
                <button 
                  onClick={() => setViewMode('details')}
                  className={`px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-tighter transition-all ${viewMode === 'details' ? 'bg-white text-indigo-600 shadow-sm' : 'text-white hover:bg-white/10'}`}
                >
                  {softwareTranslations.source}
                </button>
             </div>
          )}
          <button 
            onClick={onClose}
            className="p-2 rounded-full bg-black/10 hover:bg-black/20 text-white backdrop-blur transition-colors"
          >
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {viewMode === 'preview' && item.type === 'template' && item.codeSnippet ? (
          <NewsletterPreview template={item.codeSnippet} />
        ) : (
          <div className="overflow-y-auto no-scrollbar flex-1">
            <div className="h-64 sm:h-80 w-full overflow-hidden relative">
              {item.type === 'task' ? (
                <div className="w-full h-full bg-slate-950 flex flex-col p-8 sm:p-12 font-mono">
                   <div className="flex space-x-2 space-x-reverse mb-6">
                      <div className="w-3 h-3 rounded-full bg-rose-500 shadow-lg shadow-rose-900/20" />
                      <div className="w-3 h-3 rounded-full bg-amber-500 shadow-lg shadow-amber-900/20" />
                      <div className="w-3 h-3 rounded-full bg-emerald-500 shadow-lg shadow-emerald-900/20" />
                   </div>
                   <div className="flex items-start text-emerald-400 text-lg sm:text-2xl leading-relaxed" dir="ltr">
                      <span className="text-indigo-500 mr-4 font-black">$</span>
                      <code className="break-all">{item.command}</code>
                   </div>
                   <div className="mt-auto flex items-center space-x-2 space-x-reverse text-slate-600 text-[10px] uppercase font-bold tracking-widest">
                      <span className="animate-pulse">●</span>
                      <span>جلسة الطرفية نشطة</span>
                   </div>
                </div>
              ) : (
                <img 
                  src={`https://picsum.photos/seed/fs-${item.name}-${item.type}/800/600`} 
                  alt={item.name}
                  className="w-full h-full object-cover"
                />
              )}
              <div className="absolute bottom-0 right-0 w-full p-8 bg-gradient-to-t from-black/80 to-transparent">
                 <div className="flex items-center space-x-2 space-x-reverse mb-2">
                    <span className="px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-widest bg-indigo-500 text-white shadow-lg">
                      {softwareTranslations[item.type]}
                    </span>
                 </div>
                 <h2 className="text-4xl font-black text-white capitalize tracking-tighter">{item.name}</h2>
              </div>
            </div>

            <div className="p-8">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
                <div className="text-right">
                  {item.design ? (
                    <p className="text-indigo-600 font-bold tracking-tight">
                      {softwareTranslations.by} {Array.isArray(item.design) ? item.design.join(', ') : item.design}
                    </p>
                  ) : (
                    <p className="text-amber-600 font-bold tracking-tight">
                       {softwareTranslations.folder} {item.folder}
                    </p>
                  )}
                  <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">
                    المجلد: {item.folder}
                  </p>
                </div>
                {item.type === 'design' && item.difficulty !== undefined && (
                  <div className="flex flex-col items-start sm:items-end">
                    <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-1">{softwareTranslations.difficulty}</span>
                    <div className="flex space-x-1 space-x-reverse">
                      {[1, 2, 3, 4, 5].map(star => (
                        <div 
                          key={star} 
                          className={`h-1.5 w-6 rounded-full ${star <= (item.difficulty || 1) ? 'bg-indigo-500' : 'bg-slate-200'}`}
                        />
                      ))}
                    </div>
                  </div>
                )}
                {item.type === 'task' && (
                   <div className="flex flex-col items-start sm:items-end">
                      <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mb-1">{softwareTranslations.status}</span>
                      <span className="text-xs font-black text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100 uppercase tracking-tighter">{softwareTranslations.readyToRun}</span>
                   </div>
                )}
              </div>

              <p className="text-slate-600 text-lg leading-relaxed mb-10 font-medium text-right">
                {item.description}
              </p>

              {(item.tags?.length || item.techniques?.length) ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 mb-10">
                  {item.tags && item.tags.length > 0 && (
                    <div className="text-right">
                      <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center justify-start">
                        <svg className="w-3 h-3 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 7h.01M7 11h.01M7 15h.01M13 7h.01M13 11h.01M13 15h.01M17 7h.01M17 11h.01M17 15h.01" />
                        </svg>
                        {softwareTranslations.tags}
                      </h4>
                      <div className="flex flex-wrap gap-2 justify-start">
                        {item.tags.map(tag => (
                          <span key={tag} className="px-3 py-1 bg-indigo-50 text-indigo-700 rounded-lg text-xs font-bold border border-indigo-100 uppercase tracking-tighter">
                            {tag}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {item.techniques && item.techniques.length > 0 && (
                    <div className="text-right">
                      <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-4 flex items-center justify-start">
                        <svg className="w-3 h-3 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                        </svg>
                        {softwareTranslations.techniques}
                      </h4>
                      <div className="flex flex-wrap gap-2 justify-start">
                        {item.techniques.map(tech => (
                          <span key={tech} className="px-3 py-1 bg-slate-100 text-slate-700 rounded-lg text-xs font-bold border border-slate-200 uppercase tracking-tighter">
                            {tech.replace(/-/g, ' ')}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : null}

              {(item.codeSnippet || boilerplate || item.command) && (
                <div className="mb-10 text-right">
                   <div className="flex items-center justify-between mb-4">
                     <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest flex items-center">
                       <svg className="w-3 h-3 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                         <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 20l4-16m4 4l4 4-4 4M6 16l-4-4 4-4" />
                       </svg>
                       {item.type === 'task' ? softwareTranslations.fullCommand : (item.type === 'template' ? softwareTranslations.templateSource : (item.codeSnippet ? softwareTranslations.draftingLogic : softwareTranslations.boilerplate))}
                     </h4>
                     <button 
                       onClick={() => setShowCode(!showCode)}
                       className="text-[10px] font-black uppercase text-indigo-600 hover:text-indigo-800 transition-colors"
                     >
                       {showCode ? softwareTranslations.hideCode : softwareTranslations.showCode}
                     </button>
                   </div>
                   {showCode && (
                     <div className="bg-slate-900 rounded-2xl p-6 overflow-x-auto shadow-inner animate-in slide-in-from-top-2 duration-300" dir="ltr">
                       <pre className="text-[11px] text-indigo-200 font-mono leading-relaxed text-left">
                         <code>{item.command || item.codeSnippet || boilerplate}</code>
                       </pre>
                     </div>
                   )}
                </div>
              )}

              <div className="pt-8 border-t border-slate-100 flex flex-col sm:flex-row justify-between items-center gap-4">
                 <div className="text-[10px] text-slate-400 font-bold uppercase tracking-widest text-center sm:text-right">
                   {item.code ? `${softwareTranslations.maintainer} ${Array.isArray(item.code) ? item.code.join(', ') : item.code}` : softwareTranslations.monorepoScript}
                 </div>
                 <a 
                   href={item.type === 'design' ? `https://freesewing.org/designs/${item.name}` : `https://github.com/freesewing/freesewing/blob/main/${item.folder}/package.json`}
                   target="_blank"
                   rel="noopener noreferrer"
                   className="w-full sm:w-auto inline-flex items-center justify-center px-8 py-3 bg-indigo-600 hover:bg-indigo-700 text-white text-sm font-black rounded-2xl transition-all shadow-xl shadow-indigo-200 uppercase tracking-widest"
                 >
                   {item.type === 'design' ? softwareTranslations.viewOnFS : softwareTranslations.exploreOnGitHub}
                   <svg className="w-4 h-4 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                     <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                   </svg>
                 </a>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default SoftwareDetail;
