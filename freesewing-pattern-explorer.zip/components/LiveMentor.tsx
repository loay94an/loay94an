
import React, { useEffect, useRef, useState } from 'react';
import { GoogleGenAI, LiveServerMessage, Modality } from '@google/genai';
import { allSoftware } from '../data';

interface LiveMentorProps {
  onClose: () => void;
}

export const LiveMentor: React.FC<LiveMentorProps> = ({ onClose }) => {
  const [isActive, setIsActive] = useState(false);
  const [transcript, setTranscript] = useState<{ type: 'user' | 'ai', text: string }[]>([]);
  const [isConnecting, setIsConnecting] = useState(false);
  
  const audioContextInRef = useRef<AudioContext | null>(null);
  const audioContextOutRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  const sessionRef = useRef<any>(null);
  const streamRef = useRef<MediaStream | null>(null);

  const currentInputText = useRef('');
  const currentOutputText = useRef('');

  // Manual encode implementation as required by guidelines for base64
  const encode = (bytes: Uint8Array) => {
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  };

  // Manual decode implementation as required by guidelines for base64
  const decode = (base64: string) => {
    const binaryString = atob(base64);
    const bytes = new Uint8Array(binaryString.length);
    for (let i = 0; i < binaryString.length; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    return bytes;
  };

  // Raw PCM audio decoding for Live API stream
  const decodeAudioData = async (
    data: Uint8Array,
    ctx: AudioContext,
    sampleRate: number,
    numChannels: number,
  ): Promise<AudioBuffer> => {
    const dataInt16 = new Int16Array(data.buffer);
    const frameCount = dataInt16.length / numChannels;
    const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

    for (let channel = 0; channel < numChannels; channel++) {
      const channelData = buffer.getChannelData(channel);
      for (let i = 0; i < frameCount; i++) {
        channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
      }
    }
    return buffer;
  };

  const startSession = async () => {
    setIsConnecting(true);
    try {
      // Create fresh instance of GoogleGenAI for session
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const softwareContext = allSoftware
        .map(s => `${s.name} (${s.type}): ${s.description}`)
        .join(', ');

      audioContextInRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      audioContextOutRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      streamRef.current = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } },
          },
          systemInstruction: `أنت مرشد خياطة خبير وودود ومساعد مطور من FreeSewing.org.
          أنت تساعد المستخدمين في العثور على الأنماط، وتقدم نصائح حول الخياطة، وتجيب على الأسئلة التقنية حول أدوات المطور الخاصة بنا.
          البرامج المتاحة (الأنماط، الحزم، الإضافات): ${softwareContext}.
          يجب أن تتحدث باللغة العربية حصراً. اجعل إجاباتك حوارية ومفيدة وموجزة.`,
          inputAudioTranscription: {},
          outputAudioTranscription: {}
        },
        callbacks: {
          onopen: () => {
            setIsActive(true);
            setIsConnecting(false);
            
            const source = audioContextInRef.current!.createMediaStreamSource(streamRef.current!);
            const scriptProcessor = audioContextInRef.current!.createScriptProcessor(4096, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                int16[i] = inputData[i] * 32768;
              }
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              
              // Handle race condition with promise resolve
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };

            source.connect(scriptProcessor);
            scriptProcessor.connect(audioContextInRef.current!.destination);
          },
          onmessage: async (message: LiveServerMessage) => {
            // Processing audio output bytes from model
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && audioContextOutRef.current) {
              const ctx = audioContextOutRef.current;
              // Schedule playback for gapless audio
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(ctx.destination);
              source.addEventListener('ended', () => sourcesRef.current.delete(source));
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
            }

            // Handling transcriptions of conversation turns
            if (message.serverContent?.inputTranscription) {
              currentInputText.current += message.serverContent.inputTranscription.text;
            }
            if (message.serverContent?.outputTranscription) {
              currentOutputText.current += message.serverContent.outputTranscription.text;
            }

            if (message.serverContent?.turnComplete) {
              setTranscript(prev => [
                ...prev,
                { type: 'user', text: currentInputText.current },
                { type: 'ai', text: currentOutputText.current }
              ].filter(item => item.text.trim().length > 0));
              currentInputText.current = '';
              currentOutputText.current = '';
            }

            // Handle interruption signal from the server
            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => s.stop());
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: (e) => console.error('Live API Error:', e),
          onclose: () => {
            setIsActive(false);
            onClose();
          }
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error('Failed to start Live session:', err);
      setIsConnecting(false);
    }
  };

  const stopSession = () => {
    if (sessionRef.current) sessionRef.current.close();
    if (streamRef.current) streamRef.current.getTracks().forEach(t => t.stop());
    setIsActive(false);
  };

  useEffect(() => {
    startSession();
    return () => stopSession();
  }, []);

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-indigo-950/90 backdrop-blur-xl animate-in fade-in duration-500 text-right">
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[80vh]">
        <div className="p-6 bg-indigo-600 text-white flex justify-between items-center">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className={`w-3 h-3 rounded-full ${isActive ? 'bg-green-400 animate-pulse' : 'bg-slate-400'}`} />
            <h2 className="font-black tracking-tight text-lg">مرشد الخياطة المباشر</h2>
          </div>
          <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-4 no-scrollbar">
          {isConnecting && (
            <div className="flex flex-col items-center justify-center py-20 space-y-4">
              <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin" />
              <p className="text-slate-500 font-bold animate-pulse">جاري الاتصال بخبير الخياطة...</p>
            </div>
          )}

          {transcript.map((msg, i) => (
            <div key={i} className={`flex ${msg.type === 'user' ? 'justify-start' : 'justify-end'}`}>
              <div className={`max-w-[85%] px-4 py-2 rounded-2xl text-sm ${
                msg.type === 'user' ? 'bg-indigo-100 text-indigo-900 rounded-tl-none' : 'bg-slate-100 text-slate-800 rounded-tr-none'
              }`}>
                {msg.text}
              </div>
            </div>
          ))}
          
          {isActive && transcript.length === 0 && (
            <div className="text-center py-20">
              <p className="text-slate-400 font-medium">جاري الاستماع... جرب قول "ما هو النمط السهل للمبتدئين؟" أو اسأل عن الإضافات.</p>
            </div>
          )}
        </div>

        <div className="p-8 border-t border-slate-100 bg-slate-50 flex flex-col items-center">
          <div className="relative mb-6">
            <div className={`absolute inset-0 bg-indigo-500 rounded-full animate-ping opacity-20 ${isActive ? 'block' : 'hidden'}`} />
            <div className={`w-20 h-20 rounded-full flex items-center justify-center transition-all ${
              isActive ? 'bg-indigo-600 text-white shadow-xl shadow-indigo-200' : 'bg-slate-200 text-slate-400'
            }`}>
              <svg className="w-10 h-10" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 11-6 0v6a3 3 0 01-3 3z" />
              </svg>
            </div>
          </div>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">
            {isActive ? 'تحدث الآن' : 'جاري الاتصال...'}
          </p>
          <button 
            onClick={stopSession}
            className="mt-2 px-6 py-2 bg-rose-50 text-rose-600 font-bold rounded-xl hover:bg-rose-100 transition-colors"
          >
            إنهاء المكالمة
          </button>
        </div>
      </div>
    </div>
  );
};
