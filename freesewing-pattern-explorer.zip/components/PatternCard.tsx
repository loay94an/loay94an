
import React from 'react';
/* Use 'Software' type as 'Pattern' is not defined in types.ts */
import { Software } from '../types';

interface PatternCardProps {
  pattern: Software;
  onClick: (pattern: Software) => void;
}

const PatternCard: React.FC<PatternCardProps> = ({ pattern, onClick }) => {
  const difficultyColor = (diff: number) => {
    if (diff <= 1) return 'bg-emerald-50 text-emerald-700 border-emerald-100';
    if (diff <= 2) return 'bg-sky-50 text-sky-700 border-sky-100';
    if (diff <= 3) return 'bg-amber-50 text-amber-700 border-amber-100';
    if (diff <= 4) return 'bg-orange-50 text-orange-700 border-orange-100';
    return 'bg-rose-50 text-rose-700 border-rose-100';
  };

  return (
    <div 
      onClick={() => onClick(pattern)}
      className="group cursor-pointer bg-white rounded-2xl shadow-sm hover:shadow-xl border border-slate-200 overflow-hidden transition-all duration-500 hover:-translate-y-2 flex flex-col h-full"
    >
      <div className="relative h-56 bg-slate-50 flex items-center justify-center border-b border-slate-100 overflow-hidden">
        <img 
          src={`https://picsum.photos/seed/fs-${pattern.name}/600/400`} 
          alt={pattern.name}
          loading="lazy"
          className="w-full h-full object-cover grayscale-[20%] group-hover:grayscale-0 group-hover:scale-105 transition-all duration-1000 ease-out"
        />
        <div className="absolute top-4 right-4 shadow-xl">
          <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${difficultyColor(pattern.difficulty || 1)}`}>
            Lvl {pattern.difficulty || 1}
          </span>
        </div>
        
        {/* Overlay on hover */}
        <div className="absolute inset-0 bg-indigo-900/10 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center">
          <span className="bg-white/90 backdrop-blur px-4 py-2 rounded-full text-xs font-bold text-indigo-900 shadow-2xl transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
            View Details
          </span>
        </div>
      </div>
      
      <div className="p-6 flex flex-col flex-1">
        <div className="mb-3">
          <h3 className="text-xl font-black text-slate-800 capitalize mb-1 group-hover:text-indigo-600 transition-colors tracking-tight">
            {pattern.name}
          </h3>
          <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">
            {Array.isArray(pattern.design) ? pattern.design[0] : pattern.design}
          </p>
        </div>
        
        <p className="text-slate-500 text-sm line-clamp-2 mb-6 leading-relaxed font-medium">
          {pattern.description}
        </p>
        
        <div className="flex flex-wrap gap-1.5 mt-auto">
          {pattern.tags?.slice(0, 3).map(tag => (
            <span key={tag} className="text-[9px] px-2 py-0.5 bg-slate-50 text-slate-500 rounded border border-slate-100 uppercase font-black tracking-tighter">
              {tag}
            </span>
          ))}
          {pattern.tags && pattern.tags.length > 3 && (
            <span className="text-[9px] px-2 py-0.5 text-slate-400 italic font-bold">
              +{pattern.tags.length - 3}
            </span>
          )}
        </div>
      </div>
    </div>
  );
};

export default PatternCard;
