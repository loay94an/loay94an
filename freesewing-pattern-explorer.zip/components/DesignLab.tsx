
import React, { useState, useRef } from 'react';
import { extractPatternDesign } from '../geminiService';
import { ExtractedPattern } from '../types';

export const DesignLab: React.FC = () => {
  const [prompt, setPrompt] = useState('');
  const [image, setImage] = useState<{ data: string, mimeType: string } | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [status, setStatus] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [result, setResult] = useState<{ imageUrl: string; pattern: ExtractedPattern } | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64Data = (reader.result as string).split(',')[1];
        setImage({ data: base64Data, mimeType: file.type });
        setImagePreview(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    if ((!prompt.trim() && !image) || isGenerating) return;

    setIsGenerating(true);
    setResult(null);
    try {
      const data = await extractPatternDesign(prompt, image, setStatus);
      setResult(data);
    } catch (error) {
      console.error(error);
      setStatus("حدث خطأ أثناء استخراج النمط. يرجى المحاولة مرة أخرى.");
    } finally {
      setIsGenerating(false);
      setStatus("");
    }
  };

  const resetDesign = () => {
    setPrompt('');
    setImage(null);
    setImagePreview(null);
    setResult(null);
  };

  return (
    <div className="max-w-6xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-700 pb-12">
      <div className="bg-white rounded-[2rem] shadow-2xl overflow-hidden border border-slate-200">
        <div className="p-8 sm:p-12 bg-slate-900 text-white relative">
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-600/20 blur-[100px] -z-0" />
          
          <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-8 mb-10">
             <div className="flex items-center gap-6">
                <div className="w-20 h-20 bg-indigo-600 rounded-3xl flex items-center justify-center text-4xl shadow-2xl shadow-indigo-900/40">📐</div>
                <div>
                   <h2 className="text-4xl font-black tracking-tighter mb-1">استخراج وتصميم الأنماط</h2>
                   <p className="text-slate-400 font-medium">حول أي فكرة أو صورة إلى بترون تقني جاهز للتنفيذ</p>
                </div>
             </div>
             {result && (
               <button onClick={resetDesign} className="px-6 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-xs font-bold transition-all border border-white/10 uppercase tracking-widest">تصميم جديد</button>
             )}
          </div>
          
          <form onSubmit={handleGenerate} className="relative z-10 space-y-6">
             <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <div className="lg:col-span-2">
                   <label className="block text-[10px] font-black uppercase tracking-widest text-indigo-400 mb-3">وصف التصميم</label>
                   <textarea
                     className="w-full bg-white/5 border border-white/10 rounded-2xl p-6 text-lg placeholder:text-white/20 focus:bg-white/10 focus:ring-2 focus:ring-indigo-500/50 transition-all outline-none resize-none h-40"
                     placeholder="مثال: سترة جلدية بياقة عريضة وسحابات معدنية على الأكمام..."
                     value={prompt}
                     onChange={(e) => setPrompt(e.target.value)}
                     disabled={isGenerating}
                   />
                </div>
                <div className="lg:col-span-1">
                   <label className="block text-[10px] font-black uppercase tracking-widest text-indigo-400 mb-3">صورة مرجعية (اختياري)</label>
                   <div 
                     onClick={() => !isGenerating && fileInputRef.current?.click()}
                     className={`h-40 border-2 border-dashed rounded-2xl flex flex-col items-center justify-center cursor-pointer transition-all overflow-hidden relative ${imagePreview ? 'border-indigo-500' : 'border-white/10 hover:border-indigo-500/50 bg-white/5'}`}
                   >
                      {imagePreview ? (
                        <>
                          <img src={imagePreview} alt="Preview" className="w-full h-full object-cover opacity-60" />
                          <div className="absolute inset-0 flex items-center justify-center bg-black/40">
                             <span className="text-[10px] font-black uppercase tracking-widest bg-white text-black px-4 py-1.5 rounded-full">تغيير الصورة</span>
                          </div>
                        </>
                      ) : (
                        <>
                          <svg className="w-8 h-8 text-white/20 mb-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z"/></svg>
                          <span className="text-[10px] font-bold text-white/30 uppercase tracking-widest text-center px-4">اسحب صورة هنا أو اضغط للرفع</span>
                        </>
                      )}
                   </div>
                   <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" accept="image/*" />
                </div>
             </div>
             <div className="flex justify-end pt-2">
                <button
                  type="submit"
                  disabled={isGenerating || (!prompt.trim() && !image)}
                  className="w-full lg:w-auto px-12 py-4 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-600 text-white font-black rounded-2xl transition-all shadow-2xl flex items-center justify-center gap-4 group"
                >
                  {isGenerating ? (
                    <>
                      <div className="w-5 h-5 border-3 border-white border-t-transparent rounded-full animate-spin" />
                      <span className="tracking-widest uppercase text-sm">{status || 'جاري المعالجة...'}</span>
                    </>
                  ) : (
                    <>
                      <span className="tracking-widest uppercase text-sm">بدء الاستخراج الآلي</span>
                      <svg className="w-5 h-5 group-hover:translate-x-1 transition-transform" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M13 5l7 7-7 7M5 5l7 7-7 7"/></svg>
                    </>
                  )}
                </button>
             </div>
          </form>
        </div>

        <div className="p-8 sm:p-12 min-h-[400px] bg-white">
          {result ? (
            <div className="grid grid-cols-1 xl:grid-cols-12 gap-12 animate-in zoom-in-95 duration-500">
               {/* Left: Blueprint & Sketch */}
               <div className="xl:col-span-5 space-y-8">
                  <div className="bg-slate-50 rounded-[2.5rem] p-4 shadow-inner border border-slate-100">
                     <div className="flex items-center justify-between mb-4 px-4 pt-2">
                        <h3 className="text-xs font-black text-slate-400 uppercase tracking-widest flex items-center gap-2">
                           <span className="w-2 h-2 rounded-full bg-indigo-500" />
                           المخطط البصري للهيكل
                        </h3>
                        <span className="text-[10px] font-mono text-slate-300">REF-DESIGN-ALPHA</span>
                     </div>
                     <div className="rounded-[2rem] overflow-hidden shadow-2xl border border-white relative group">
                        <img src={result.imageUrl} alt="Blueprint" className="w-full h-auto" />
                        <div className="absolute top-4 right-4 bg-black/80 backdrop-blur-md px-3 py-1.5 rounded-full border border-white/20">
                           <span className="text-[10px] font-black text-white uppercase tracking-tighter">AI GENERATED BLUEPRINT</span>
                        </div>
                     </div>
                  </div>

                  <div className="bg-indigo-900 rounded-[2rem] p-8 text-white shadow-xl relative overflow-hidden">
                     <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-full -mr-16 -mt-16" />
                     <h4 className="text-[10px] font-black uppercase tracking-widest text-indigo-400 mb-4">كود البداية (Starter Code)</h4>
                     <pre className="text-[10px] font-mono bg-black/30 p-4 rounded-xl overflow-x-auto text-indigo-100 border border-white/5 leading-relaxed" dir="ltr">
                        {result.pattern.starterCode}
                     </pre>
                  </div>
               </div>

               {/* Right: Extracted Specs */}
               <div className="xl:col-span-7 space-y-10">
                  <div className="flex flex-wrap items-center gap-4 border-b border-slate-100 pb-6">
                     <div className="flex flex-col">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">نوع القطعة</span>
                        <span className="text-2xl font-black text-slate-900">{result.pattern.garmentType}</span>
                     </div>
                     <div className="h-10 w-px bg-slate-200 mx-4" />
                     <div className="flex flex-col">
                        <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">الصعوبة التقنية</span>
                        <div className="flex gap-1 mt-1">
                           {[1, 2, 3, 4, 5].map(s => (
                             <div key={s} className={`h-1.5 w-6 rounded-full ${s <= result.pattern.complexity ? 'bg-indigo-600' : 'bg-slate-200'}`} />
                           ))}
                        </div>
                     </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                     <section>
                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                           <svg className="w-4 h-4 text-indigo-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2"/></svg>
                           القياسات المطلوبة
                        </h4>
                        <div className="flex flex-wrap gap-2">
                           {result.pattern.requiredMeasurements.map(m => (
                             <span key={m} className="px-3 py-1.5 bg-slate-50 text-slate-700 rounded-xl text-xs font-bold border border-slate-200">{m}</span>
                           ))}
                        </div>
                     </section>
                     <section>
                        <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                           <svg className="w-4 h-4 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10"/></svg>
                           القالب الأساسي المقترح
                        </h4>
                        <span className="inline-block px-4 py-2 bg-emerald-50 text-emerald-700 rounded-2xl text-sm font-black border border-emerald-100 uppercase tracking-widest">
                           {result.pattern.recommendedBaseBlock}
                        </span>
                     </section>
                  </div>

                  <section>
                     <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-4 flex items-center gap-2">
                        <svg className="w-4 h-4 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z"/></svg>
                        خطوات الرسم التقنية
                     </h4>
                     <ol className="space-y-3">
                        {result.pattern.technicalSteps.map((step, i) => (
                          <li key={i} className="flex items-start gap-4 group">
                             <span className="w-6 h-6 rounded-full bg-slate-100 flex items-center justify-center text-[10px] font-black text-slate-400 group-hover:bg-indigo-600 group-hover:text-white transition-colors">{i+1}</span>
                             <p className="text-sm font-medium text-slate-600 pt-0.5">{step}</p>
                          </li>
                        ))}
                     </ol>
                  </section>

                  <section className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100">
                     <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">توصيات القماش</h4>
                     <p className="text-sm text-slate-600 leading-relaxed font-medium">{result.pattern.fabricRecommendations}</p>
                  </section>
               </div>
            </div>
          ) : !isGenerating && (
            <div className="flex flex-col items-center justify-center py-20 text-center">
               <div className="w-32 h-32 bg-slate-50 rounded-[3rem] flex items-center justify-center mb-8 relative">
                  <div className="absolute inset-0 border-2 border-dashed border-slate-200 rounded-[3rem] animate-[spin_20s_linear_infinite]" />
                  <span className="text-5xl grayscale opacity-20">✂️</span>
               </div>
               <h3 className="text-2xl font-black text-slate-800 mb-3">جاهز للاستخراج التلقائي</h3>
               <p className="text-slate-400 text-sm max-w-sm mx-auto leading-relaxed">
                  بمجرد إدخال وصفك أو رفع صورة، سيقوم نظامنا بتحليل كل التفاصيل واستخراج مواصفات البترون المناسبة لبيئة FreeSewing.
               </p>
            </div>
          )}

          {isGenerating && (
             <div className="flex flex-col items-center justify-center py-32 space-y-10">
                <div className="relative">
                   <div className="w-40 h-40 border-[8px] border-slate-50 rounded-full" />
                   <div className="absolute top-0 w-40 h-40 border-[8px] border-indigo-600 rounded-full border-t-transparent animate-spin" />
                   <div className="absolute inset-0 flex items-center justify-center text-6xl animate-bounce">🧵</div>
                </div>
                <div className="space-y-3 text-center">
                   <p className="text-2xl font-black text-slate-800 animate-pulse">{status}</p>
                   <p className="text-slate-400 text-xs font-mono uppercase tracking-widest">Drafting Engine Powering Up...</p>
                </div>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};
