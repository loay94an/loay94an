
import { Measurements, Point, DrawResult, PatternPath, StyleConfig, PatternLabel } from '../types';

export const SCALE = 6.0; 

/**
 * Creates professional dimension lines with architectural ticks.
 */
const createDimension = (
  id: string, x1: number, y1: number, x2: number, y2: number,
  label: string, offset: number = 20, vertical: boolean = false
): { paths: PatternPath[], labels: PatternLabel[] } => {
  const paths: PatternPath[] = [];
  const labels: PatternLabel[] = [];
  const ox1 = vertical ? x1 - offset : x1;
  const oy1 = vertical ? y1 : y1 - offset;
  const ox2 = vertical ? x2 - offset : x2;
  const oy2 = vertical ? y2 : y2 - offset;

  paths.push({
    id: `${id}-line`,
    d: `M ${ox1} ${oy1} L ${ox2} ${oy2}`,
    type: 'dimension',
    strokeWidth: 0.8,
    dashArray: '3,3'
  });

  const tick = 4;
  paths.push({ id: `${id}-t1`, d: `M ${ox1-tick} ${oy1+tick} L ${ox1+tick} ${oy1-tick}`, type: 'dimension', strokeWidth: 1.2 });
  paths.push({ id: `${id}-t2`, d: `M ${ox2-tick} ${oy2+tick} L ${ox2+tick} ${oy2-tick}`, type: 'dimension', strokeWidth: 1.2 });

  labels.push({ x: (ox1+ox2)/2, y: (oy1+oy2)/2 - (vertical ? 0 : 8), text: label, fontSize: 9, color: '#3b82f6', angle: vertical ? -90 : 0 });
  return { paths, labels };
};

export const draftPattern = (config: StyleConfig, m: Measurements): DrawResult => {
  const paths: PatternPath[] = [];
  const labels: PatternLabel[] = [];
  const summary: { key: string, value: string }[] = [];
  const originX = 180;
  const originY = 80;

  // Measurement Extraction
  const bust = m["محيط_الصدر"] || 96;
  const waist = m["محيط_الوسط"] || 76;
  const hip = m["محيط_الهنش"] || 104;
  const backLen = m["طول_الظهر"] || 42;
  const neck = m["محيط_الرقبة"] || 36;
  const shoulder = m["عرض_الكتف"] || 13;
  const sleeveLen = m["طول_الكم"] || 60;
  const garmentLen = m["طول_الجولنة"] || config.garmentLength || 75;

  const modelId = config.model;

  // --- MODEL ROUTING & DRAFTING ---

  // 1. SKIRTS CHAPTER
  if (config.chapter === 'skirts') {
    if (modelId === 'skirt_circular') {
      const radius = (waist / 6.28) * SCALE;
      const totalR = radius + (garmentLen * SCALE);
      paths.push({ id: 'c-w', d: `M ${originX} ${originY+radius} A ${radius} ${radius} 0 0 1 ${originX+radius} ${originY}`, type: 'outline' });
      paths.push({ id: 'c-h', d: `M ${originX} ${originY+totalR} A ${totalR} ${totalR} 0 0 1 ${originX+totalR} ${originY}`, type: 'outline', strokeWidth: 3 });
      paths.push({ id: 'c-s1', d: `M ${originX} ${originY+radius} V ${originY+totalR}`, type: 'outline' });
      paths.push({ id: 'c-s2', d: `M ${originX+radius} ${originY} H ${originX+totalR}`, type: 'outline' });
      summary.push({ key: 'النمط', value: 'كلوش كامل' });
    } else if (modelId === 'skirt_pleats' || modelId === 'skirt_plisse') {
      const qH = (hip / 4 + 2) * SCALE;
      const gL = garmentLen * SCALE;
      paths.push({ id: 'p-box', d: `M ${originX} ${originY} H ${originX+qH} V ${originY+gL} H ${originX} Z`, type: 'outline' });
      for(let i=1; i<4; i++) {
        const x = originX + (qH/4)*i;
        paths.push({ id: `pl-${i}`, d: `M ${x} ${originY} V ${originY+gL}`, type: 'pleat', dashArray: '5,5', stroke: '#94a3b8' });
      }
      summary.push({ key: 'النمط', value: 'جولنة بكسرات' });
    } else {
      const qH = (hip / 4 + 1.5) * SCALE;
      const qW = (waist / 4 + 2.5) * SCALE;
      const gL = garmentLen * SCALE;
      const sL = (m["طول_الجنب"] || 20) * SCALE;
      paths.push({ id: 's-c', d: `M ${originX} ${originY} V ${originY+gL}`, type: 'outline' });
      paths.push({ id: 's-h', d: `M ${originX} ${originY+gL} H ${originX+qH}`, type: 'outline', strokeWidth: 3 });
      paths.push({ id: 's-side', d: `M ${originX+qH} ${originY+gL} V ${originY+sL} Q ${originX+qH+8} ${originY+sL/2} ${originX+qW} ${originY}`, type: 'outline' });
      paths.push({ id: 's-w', d: `M ${originX} ${originY} L ${originX+qW} ${originY}`, type: 'outline' });
      summary.push({ key: 'النمط', value: 'جولنة أساسية' });
    }
  }

  // 2. BODICE & DRESSES & OUTERWEAR
  else if (['bodice', 'blouses', 'dresses', 'outerwear', 'islamic'].includes(config.chapter)) {
    const qB = (bust / 4 + (config.chapter === 'outerwear' ? 4 : 2)) * SCALE;
    const bl = backLen * SCALE;
    const nw = (neck / 5) * SCALE;
    const nh = (neck / 5 + 1) * SCALE;
    const sd = (bust / 4) * SCALE;
    const sh = shoulder * SCALE;

    // Standard Bodice Block
    paths.push({ id: 'b-n', d: `M ${originX} ${originY+nh} Q ${originX} ${originY} ${originX+nw} ${originY}`, type: 'outline', strokeWidth: 2 });
    paths.push({ id: 'b-sh', d: `M ${originX+nw} ${originY} L ${originX+nw+sh} ${originY+30}`, type: 'outline', strokeWidth: 2 });
    paths.push({ id: 'b-arm', d: `M ${originX+nw+sh} ${originY+30} C ${originX+nw+sh} ${originY+sd} ${originX+qB-10} ${originY+sd} ${originX+qB} ${originY+sd}`, type: 'outline', strokeWidth: 3 });
    
    // Extensions for dresses/coats
    const totalH = (config.chapter === 'dresses' || config.chapter === 'outerwear') ? bl + 40 * SCALE : bl;
    paths.push({ id: 'b-s', d: `M ${originX+qB} ${originY+sd} V ${originY+totalH}`, type: 'outline' });
    paths.push({ id: 'b-w', d: `M ${originX} ${originY+totalH} H ${originX+qB}`, type: 'outline' });
    paths.push({ id: 'b-cf', d: `M ${originX} ${originY+nh} V ${originY+totalH}`, type: 'outline', dashArray: '10,5' });

    // Princess cut specific
    if (modelId === 'dress_princess') {
      const px = originX + (qB * 0.4);
      paths.push({ id: 'p-cut', d: `M ${px} ${originY+totalH} V ${originY+sd+20} Q ${px} ${originY+sd-10} ${originX+nw+sh/2} ${originY+15}`, type: 'technical', stroke: '#3b82f6', dashArray: '4,2' });
      summary.push({ key: 'القصة', value: 'برنسيس' });
    }
    
    summary.push({ key: 'النمط', value: 'كورساج/فستان' });
  }

  // 3. SLEEVES
  else if (config.chapter === 'sleeves') {
    const sw = (bust / 4) * SCALE;
    const sl = sleeveLen * SCALE;
    const capH = (bust / 8 + 3) * SCALE;
    paths.push({ id: 'sl-c', d: `M ${originX} ${originY+capH} C ${originX+sw/4} ${originY-15} ${originX+sw*0.75} ${originY-15} ${originX+sw} ${originY+capH}`, type: 'outline', strokeWidth: 3 });
    paths.push({ id: 'sl-s1', d: `M ${originX} ${originY+capH} L ${originX+15} ${originY+sl}`, type: 'outline' });
    paths.push({ id: 'sl-s2', d: `M ${originX+sw} ${originY+capH} L ${originX+sw-15} ${originY+sl}`, type: 'outline' });
    paths.push({ id: 'sl-w', d: `M ${originX+15} ${originY+sl} H ${originX+sw-15}`, type: 'outline', strokeWidth: 2 });
    summary.push({ key: 'النمط', value: 'كم أساسي' });
  }

  // 4. TROUSERS
  else if (config.chapter === 'trousers' || modelId.includes('pants')) {
    const qH = (hip / 4 + 1.5) * SCALE;
    const totalL = (m["الطول_الكلي"] || 105) * SCALE;
    const innerL = (m["الطول_الداخلي"] || 80) * SCALE;
    const rise = totalL - innerL;
    const cExt = (hip / 16) * SCALE;
    paths.push({ id: 't-w', d: `M ${originX} ${originY} H ${originX+qH}`, type: 'outline' });
    paths.push({ id: 't-c', d: `M ${originX+qH} ${originY} V ${originY+rise-40} Q ${originX+qH} ${originY+rise} ${originX+qH+cExt} ${originY+rise}`, type: 'outline', strokeWidth: 2.5 });
    paths.push({ id: 't-i', d: `M ${originX+qH+cExt} ${originY+rise} L ${originX+qH-10} ${originY+totalL}`, type: 'outline' });
    paths.push({ id: 't-o', d: `M ${originX} ${originY} V ${originY+totalL}`, type: 'outline' });
    paths.push({ id: 't-h', d: `M ${originX} ${originY+totalL} H ${originX+qH-10}`, type: 'outline', strokeWidth: 3 });
    summary.push({ key: 'النمط', value: 'بنطلون' });
  }

  // CATCH-ALL BLOCK
  else {
    const w = (bust / 4) * SCALE;
    const h = (m["طول_الظهر"] || 42) * SCALE;
    paths.push({ id: 'gen-box', d: `M ${originX} ${originY} H ${originX+w} V ${originY+h} H ${originX} Z`, type: 'outline', dashArray: '5,5' });
    labels.push({ x: originX+w/2, y: originY+h/2, text: 'قالب افتراضي', fontSize: 10 });
    summary.push({ key: 'النمط', value: 'افتراضي' });
  }

  // Dimensions for all
  const dimW = createDimension('dim-w', originX, originY-30, originX + (bust/4)*SCALE, originY-30, `العرض: ${(bust/4).toFixed(1)}`);
  paths.push(...dimW.paths);
  labels.push(...dimW.labels);

  return { points: [], paths, labels, summary };
};
