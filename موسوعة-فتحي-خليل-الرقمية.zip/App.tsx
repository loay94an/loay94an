import React, { useState, useMemo, useEffect, useRef, useCallback } from 'react';
import { 
  Download, Eye, Info,
  Maximize2, Minimize2,
  ZoomIn, ZoomOut,
  LayoutTemplate, 
  X, Menu, Crosshair, Book,
  ChevronDown,
  Layers,
  Ruler
} from 'lucide-react';
import { Category, ChapterType, ModelType, Measurements, DrawResult, StyleConfig, PatternPath } from './types.ts';
import { DB, CATEGORY_STRUCTURE } from './constants.ts';
import { draftPattern } from './services/patternEngine.ts';
import MeasurementTable from './MeasurementTable.tsx';

interface VisualConfig {
  outline: { width: number; color: string };
  dart: { width: number; color: string };
  technical: { width: number; color: string };
  dimension: { width: number; color: string };
  curve: { width: number; color: string };
}

const INITIAL_VISUAL_CONFIG: VisualConfig = {
  outline: { width: 3.2, color: '#0f172a' },
  dart: { width: 1.8, color: '#475569' },
  technical: { width: 1.2, color: '#94a3b8' },
  dimension: { width: 1.0, color: '#3b82f6' },
  curve: { width: 2.8, color: '#0f172a' }
};

const App: React.FC = () => {
  const [category, setCategory] = useState<Category>('women');
  const [size, setSize] = useState<string>('42');
  const [activeChapterIdx, setActiveChapterIdx] = useState(0);
  const [activeModelIdx, setActiveModelIdx] = useState(0);
  const [measurements, setMeasurements] = useState<Measurements>({});
  const [visualConfig] = useState<VisualConfig>(INITIAL_VISUAL_CONFIG);
  
  const [zoom, setZoom] = useState(0.9);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [sidebarOpen, setSidebarOpen] = useState(window.innerWidth > 1024);
  const [viewMode, setViewMode] = useState<'paper' | 'blueprint'>('paper');
  const [showSummary, setShowSummary] = useState(false);
  const [focusMode, setFocusMode] = useState(false);
  const [isPatternAnimating, setIsPatternAnimating] = useState(false);
  
  const [visibleLayers] = useState<Record<string, boolean>>({
    outline: true,
    dart: true,
    technical: true,
    dimension: true,
    labels: true,
    curve: true,
    pleat: true
  });

  const [hoveredPath, setHoveredPath] = useState<PatternPath | null>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const dragStart = useRef({ x: 0, y: 0 });
  
  const svgRef = useRef<SVGSVGElement>(null);

  const currentChapters = useMemo(() => CATEGORY_STRUCTURE[category] || [], [category]);
  const currentChapter = currentChapters[activeChapterIdx] || currentChapters[0];
  const currentModel = currentChapter.models[activeModelIdx] || currentChapter.models[0];
  const availableSizes = useMemo(() => Object.keys(DB[category] || {}), [category]);

  const changeCategory = (newCat: Category) => {
    setCategory(newCat);
    const newSizes = Object.keys(DB[newCat]);
    setSize(newSizes.includes(size) ? size : newSizes[0]);
    setActiveChapterIdx(0);
    setActiveModelIdx(0);
  };

  useEffect(() => {
    setPan({ x: 0, y: 0 });
    setZoom(0.9);
    setIsPatternAnimating(true);
    const timer = setTimeout(() => setIsPatternAnimating(false), 400);
    return () => clearTimeout(timer);
  }, [activeModelIdx, activeChapterIdx, category, size]);

  useEffect(() => {
    if (size && DB[category][size]) {
      setMeasurements({ ...DB[category][size] });
    }
  }, [size, category]);

  const styleConfig: StyleConfig = useMemo(() => ({
    chapter: currentChapter.id as ChapterType,
    model: currentModel.id as ModelType,
    category: category,
    garmentLength: measurements["طول_الجولنة"] || 75,
    ease: 2.0
  }), [currentChapter, currentModel, category, measurements]);

  const patternData = useMemo<DrawResult>(() => draftPattern(styleConfig, measurements), [styleConfig, measurements]);

  const handleMouseDown = (e: React.MouseEvent) => {
    if (e.button !== 0) return;
    setIsDragging(true);
    dragStart.current = { x: e.clientX - pan.x, y: e.clientY - pan.y };
  };

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    setMousePos({ x: e.clientX, y: e.clientY });
    if (isDragging) {
      setPan({ x: e.clientX - dragStart.current.x, y: e.clientY - dragStart.current.y });
    }
  }, [isDragging]);

  const handleMouseUp = () => setIsDragging(false);

  const handleWheel = (e: React.WheelEvent) => {
    if (e.ctrlKey) {
      e.preventDefault();
      const delta = e.deltaY > 0 ? -0.05 : 0.05;
      setZoom(z => Math.max(0.1, Math.min(5, z + delta)));
    } else {
      setPan(p => ({ x: p.x - e.deltaX, y: p.y - e.deltaY }));
    }
  };

  const handleExport = () => {
    if (!svgRef.current) return;
    const serializer = new XMLSerializer();
    const svgString = serializer.serializeToString(svgRef.current);
    const blob = new Blob([svgString], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `FathiKhalil_${currentModel.id}_Size${size}.svg`;
    link.click();
  };

  const getPathColor = (p: PatternPath) => {
    const isHovered = hoveredPath?.id === p.id;
    if (viewMode === 'blueprint') return isHovered ? '#fff' : (p.type === 'dimension' ? '#60a5fa' : '#3b82f6');
    const color = (visualConfig as any)[p.type]?.color || p.stroke || '#1e293b';
    return isHovered ? '#2563eb' : color;
  };

  const getPathWidth = (p: PatternPath) => {
    const width = (visualConfig as any)[p.type]?.width || p.strokeWidth || 1.5;
    return hoveredPath?.id === p.id ? width + 2.5 : width;
  };

  return (
    <div className="flex h-screen w-screen bg-slate-50 text-slate-900 overflow-hidden font-tajawal rtl">
      <aside className={`
        bg-white border-l border-slate-200 shadow-2xl z-50 fixed lg:relative h-full transition-all duration-300 flex flex-col
        ${sidebarOpen ? 'w-[380px] translate-x-0' : 'w-0 translate-x-full lg:w-0 overflow-hidden'}
        ${focusMode ? 'lg:hidden translate-x-full' : ''}
      `}>
        {/* Sidebar Header (Fixed) */}
        <div className="p-6 border-b border-slate-100 flex items-center justify-between sticky top-0 bg-white z-30">
          <div className="flex items-center gap-3">
             <div className="w-12 h-12 bg-slate-900 rounded-2xl flex items-center justify-center text-white shadow-xl rotate-3">
                <LayoutTemplate size={24} />
             </div>
             <div>
                <h2 className="font-black text-base tracking-tight text-slate-900 leading-tight">الاستوديو الرقمي</h2>
                <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest mt-1">منهج البروفيسور فتحي خليل</p>
             </div>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-2 bg-slate-50 rounded-xl text-slate-400 hover:text-slate-900 transition-all">
            <X size={20} />
          </button>
        </div>

        {/* SECTION 1: CATEGORY & SIZE (Fixed Top) */}
        <div className="px-6 py-5 space-y-5 bg-slate-50 border-b border-slate-100 shadow-sm z-20">
           <div className="space-y-3">
              <div className="flex items-center gap-2">
                 <Layers size={14} className="text-blue-600" />
                 <h3 className="text-[11px] font-black text-slate-500 uppercase tracking-wider">اختيار الفئة</h3>
              </div>
              <div className="flex gap-1.5 bg-white p-1.5 rounded-2xl shadow-sm border border-slate-100/50">
                {(['women', 'men', 'children'] as Category[]).map(c => (
                  <button
                    key={c}
                    onClick={() => changeCategory(c)}
                    className={`flex-1 py-2 rounded-xl text-[11px] font-black transition-all duration-300 ${category === c ? 'bg-slate-900 text-white shadow-lg' : 'text-slate-400 hover:bg-slate-50'}`}
                  >
                    {c === 'women' ? 'نسائي' : c === 'men' ? 'رجالي' : 'أطفال'}
                  </button>
                ))}
              </div>
           </div>

           <div className="space-y-3">
              <div className="flex items-center justify-between">
                 <div className="flex items-center gap-2">
                    <Ruler size={14} className="text-emerald-600" />
                    <h3 className="text-[11px] font-black text-slate-500 uppercase tracking-wider">المقاس القياسي</h3>
                 </div>
                 <span className="px-2 py-0.5 bg-emerald-100 text-emerald-700 rounded-full text-[9px] font-black">{size}</span>
              </div>
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none scroll-smooth touch-pan-x">
                 {availableSizes.map((s) => (
                    <button
                      key={s}
                      onClick={() => setSize(s)}
                      className={`flex-shrink-0 min-w-[50px] h-10 flex items-center justify-center rounded-xl text-[12px] font-black border transition-all duration-200 ${size === s ? 'bg-emerald-600 border-emerald-500 text-white shadow-lg scale-105' : 'bg-white border-slate-200 text-slate-400 hover:border-slate-300'}`}
                    >
                      {s.replace('سنة ', '')}
                    </button>
                 ))}
              </div>
           </div>
        </div>

        {/* Scrollable Library and Measurements */}
        <nav className="flex-1 overflow-y-auto custom-scroll p-6 space-y-8">
          <div className="space-y-4">
             <div className="flex items-center gap-2 mb-2 px-1">
                <Book size={16} className="text-purple-600" />
                <h3 className="text-[12px] font-black text-slate-800 uppercase tracking-tight">مكتبة التصميم</h3>
             </div>

             <div className="space-y-2">
                {currentChapters.map((ch, idx) => (
                  <div key={idx} className={`rounded-2xl transition-all border ${activeChapterIdx === idx ? 'bg-slate-50 border-slate-200' : 'border-transparent hover:bg-slate-50/30'}`}>
                    <button
                      onClick={() => { setActiveChapterIdx(idx); setActiveModelIdx(0); }}
                      className={`w-full text-right px-4 py-3.5 rounded-2xl text-[13px] font-black flex items-center justify-between transition-all ${activeChapterIdx === idx ? 'text-slate-900' : 'text-slate-400 hover:text-slate-600'}`}
                    >
                      <span className="flex items-center gap-3">
                        <span className={`w-2 h-2 rounded-full ${activeChapterIdx === idx ? 'bg-blue-600 scale-125' : 'bg-slate-200'}`} />
                        {ch.name}
                      </span>
                      <ChevronDown size={16} className={`transition-transform duration-300 ${activeChapterIdx === idx ? 'rotate-180 text-blue-500' : 'text-slate-300'}`} />
                    </button>
                    {activeChapterIdx === idx && (
                      <div className="px-3 pb-3 space-y-1 animate-fade-in">
                        {ch.models.map((m, mIdx) => (
                          <button
                            key={m.id}
                            onClick={() => { 
                              setActiveModelIdx(mIdx);
                              if (window.innerWidth < 1024) setSidebarOpen(false);
                            }}
                            className={`w-full text-right px-4 py-3 rounded-xl text-[12px] transition-all border ${activeModelIdx === mIdx ? 'text-blue-700 font-bold bg-white border-blue-200 shadow-md ring-2 ring-blue-50' : 'text-slate-400 border-transparent hover:bg-white'}`}
                          >
                            {m.name}
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                ))}
             </div>
          </div>

          <div className="h-px bg-slate-100" />

          <div className="space-y-4 pb-12">
             <div className="flex items-center gap-2 mb-2 px-1">
                <Crosshair size={16} className="text-orange-600" />
                <h3 className="text-[12px] font-black text-slate-800 uppercase tracking-tight">القياسات الفنية (سم)</h3>
             </div>
             <MeasurementTable 
               measurements={measurements} 
               onChange={(k, v) => setMeasurements(p => ({...p, [k]: v}))} 
             />
          </div>
        </nav>
      </aside>

      <main className="flex-1 flex flex-col relative min-w-0">
        <header className="h-20 bg-white border-b border-slate-100 flex items-center justify-between px-8 z-40 shadow-sm">
          <div className="flex items-center gap-6">
            {!sidebarOpen && (
              <button onClick={() => setSidebarOpen(true)} className="p-3 bg-slate-900 rounded-2xl text-white shadow-2xl shadow-slate-400 hover:bg-slate-800 transition-all active:scale-90">
                <Menu size={20} />
              </button>
            )}
            <div className="flex flex-col">
              <div className="flex items-center gap-2 mb-1">
                 <span className="text-[9px] text-white bg-blue-600 px-2 py-0.5 rounded-full font-black uppercase tracking-widest">{currentChapter.name}</span>
                 <span className="text-[9px] text-slate-400 font-black uppercase tracking-widest">المقاس: {size}</span>
              </div>
              <h1 className="text-lg font-black text-slate-900 truncate max-w-[300px] leading-tight">{currentModel.name}</h1>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button onClick={handleExport} className="flex items-center gap-2 px-6 py-3 bg-slate-900 text-white rounded-2xl text-[12px] font-black shadow-xl shadow-slate-200 hover:bg-slate-800 transition-all active:scale-95 group">
              <Download size={16} className="group-hover:translate-y-0.5 transition-transform" />
              <span className="hidden md:inline">تصدير الباترون النهائي</span>
            </button>
          </div>
        </header>

        <section 
          className="flex-1 relative overflow-hidden bg-slate-100 cursor-grab active:cursor-grabbing"
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
          onWheel={handleWheel}
        >
          <div className={`
            absolute inset-0 transition-all duration-700
            ${viewMode === 'blueprint' ? 'bg-[#050811]' : 'bg-[#fcfaf5] paper-texture'}
          `} style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transformOrigin: 'center' }}>
            <div className={`absolute inset-0 pointer-events-none transition-opacity duration-700 ${viewMode === 'blueprint' ? 'blueprint-grid opacity-30' : 'pattern-grid opacity-50'}`} />
            <div className="flex items-center justify-center w-full h-full">
              <svg 
                ref={svgRef} 
                viewBox="0 0 800 1000" 
                className={`w-full h-full max-w-[800px] pointer-events-auto transition-all ${viewMode === 'blueprint' ? 'drop-shadow-[0_0_40px_rgba(59,130,246,0.3)]' : 'drop-shadow-2xl'} ${isPatternAnimating ? 'scale-[1.02] opacity-0 blur-xl' : 'scale-100 opacity-100 blur-0'} duration-500 ease-out`}
              >
                {patternData.paths.map(p => (
                  (visibleLayers[p.type] || p.type === 'outline') && (
                    <path 
                      key={p.id} 
                      d={p.d} 
                      fill="none" 
                      stroke={getPathColor(p)} 
                      strokeWidth={getPathWidth(p)} 
                      strokeDasharray={p.dashArray} 
                      strokeLinecap="round" 
                      onMouseEnter={() => setHoveredPath(p)}
                      onMouseLeave={() => setHoveredPath(null)}
                      className="cursor-crosshair transition-all duration-300"
                    />
                  )
                ))}
                {visibleLayers.labels && patternData.labels.map((lbl, idx) => (
                  <text 
                    key={idx} x={lbl.x} y={lbl.y} 
                    fill={viewMode === 'blueprint' ? '#93c5fd' : (lbl.color || "#334155")} 
                    fontSize={lbl.fontSize || 12} 
                    fontWeight="900" 
                    textAnchor="middle" 
                    transform={lbl.angle ? `rotate(${lbl.angle}, ${lbl.x}, ${lbl.y})` : undefined}
                    className="select-none pointer-events-none opacity-100 drop-shadow-sm filter contrast-125"
                  >
                    {lbl.text}
                  </text>
                ))}
              </svg>
            </div>
          </div>

          <div className="absolute top-8 right-8 flex flex-col gap-3 z-40">
             <button onClick={() => setViewMode(v => v === 'paper' ? 'blueprint' : 'paper')} className={`p-4 rounded-[1.5rem] shadow-2xl transition-all active:scale-90 ring-1 ring-white/20 ${viewMode === 'blueprint' ? 'bg-blue-600 text-white' : 'bg-white text-slate-400 hover:text-slate-900'}`}>
                <Eye size={20}/>
             </button>
             <button onClick={() => setShowSummary(!showSummary)} className={`p-4 rounded-[1.5rem] shadow-2xl transition-all active:scale-90 ring-1 ring-white/20 ${showSummary ? 'bg-emerald-600 text-white' : 'bg-white text-slate-400 hover:text-slate-900'}`}>
                <Info size={20}/>
             </button>
          </div>

          <div className="absolute bottom-10 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-white/95 backdrop-blur-2xl border border-white p-2 rounded-[2.5rem] shadow-2xl z-40 ring-1 ring-slate-200/50">
                <button onClick={() => setZoom(z => Math.max(0.1, z - 0.1))} className="p-3 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-all active:scale-90"><ZoomOut size={18}/></button>
                <div className="w-px h-6 bg-slate-100 mx-2" />
                <button onClick={() => { setZoom(0.9); setPan({x:0, y:0}); }} className="px-5 text-[12px] font-black text-slate-900 tracking-tight whitespace-nowrap min-w-[80px] text-center hover:bg-slate-50 py-2 rounded-full transition-all">{Math.round(zoom * 100)}%</button>
                <div className="w-px h-6 bg-slate-100 mx-2" />
                <button onClick={() => setZoom(z => Math.min(4, z + 0.1))} className="p-3 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-all active:scale-90"><ZoomIn size={18}/></button>
                <div className="w-px h-6 bg-slate-100 mx-2" />
                <button onClick={() => setFocusMode(!focusMode)} className="p-3 text-slate-400 hover:text-slate-900 hover:bg-slate-100 rounded-full transition-all active:scale-90">
                    {focusMode ? <Minimize2 size={18}/> : <Maximize2 size={18}/>}
                </button>
          </div>

          {showSummary && (
             <div className="absolute top-28 right-8 w-72 bg-white/98 backdrop-blur-2xl shadow-[0_20px_50px_rgba(0,0,0,0.1)] rounded-[2rem] border border-white overflow-hidden animate-scale-in z-30 ring-1 ring-slate-200/50">
                <div className="p-5 bg-slate-50/80 border-b border-slate-100 flex justify-between items-center">
                   <h3 className="text-[11px] font-black uppercase text-slate-600 tracking-widest flex items-center gap-3">
                     <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse shadow-sm shadow-emerald-200" />
                     الملخص الهندسي
                   </h3>
                   <button onClick={() => setShowSummary(false)} className="text-slate-300 hover:text-slate-900 p-1.5 hover:bg-slate-100 rounded-full transition-all"><X size={16} /></button>
                </div>
                <div className="p-6 space-y-4">
                   {patternData.summary.map(s => (
                      <div key={s.key} className="flex justify-between items-center group">
                         <span className="text-[12px] text-slate-400 font-bold transition-colors group-hover:text-slate-600">{s.key}</span>
                         <span className="text-[12px] font-black text-slate-900 bg-slate-50 px-3 py-1 rounded-lg">{s.value}</span>
                      </div>
                   ))}
                </div>
                <div className="p-4 bg-blue-600 text-[10px] text-center text-white font-black tracking-widest">
                  أبعاد البترون: {size}
                </div>
             </div>
          )}

          {hoveredPath && (
             <div 
               className="fixed pointer-events-none z-50 bg-slate-900/98 backdrop-blur-xl text-white px-5 py-3 rounded-2xl text-[12px] font-black shadow-2xl flex items-center gap-3 ring-1 ring-white/20 animate-fade-in"
               style={{ left: mousePos.x + 28, top: mousePos.y + 28 }}
             >
               <div className="p-2 bg-blue-500/30 rounded-xl">
                 <Crosshair size={14} className="text-blue-400" />
               </div>
               {hoveredPath.description || 'جزء من الباترون الهندسي'}
             </div>
          )}
        </section>
      </main>
    </div>
  );
};

export default App;