
import React from 'react';
import { Measurements } from '../types.js';

interface MeasurementTableProps {
  measurements: Measurements;
  onChange: (key: string, value: number) => void;
}

const MeasurementTable: React.FC<MeasurementTableProps> = ({ measurements, onChange }) => {
  return (
    <div className="overflow-x-auto rounded-xl border border-slate-200 bg-white shadow-sm scrollbar-thin">
      <table className="w-full text-right text-xs">
        <thead className="bg-slate-50 text-slate-500 border-b border-slate-100">
          <tr>
            <th className="px-3 py-2 font-bold uppercase tracking-tighter">القياس</th>
            <th className="px-3 py-2 text-center font-bold uppercase tracking-tighter">سم</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-slate-50">
          {Object.entries(measurements).map(([key, val]) => (
            <tr key={key} className="hover:bg-slate-50 transition-colors">
              <td className="px-3 py-2 text-slate-700 font-medium whitespace-nowrap">{key.replace(/_/g, ' ')}</td>
              <td className="px-3 py-2 text-center">
                <input
                  type="number"
                  step="0.1"
                  value={val}
                  onChange={(e) => onChange(key, parseFloat(e.target.value) || 0)}
                  className="w-14 sm:w-16 rounded border border-slate-200 bg-slate-50 px-1 py-1 text-center text-secondary font-bold focus:outline-none focus:ring-1 focus:ring-secondary focus:bg-white transition-all shadow-inner"
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MeasurementTable;
