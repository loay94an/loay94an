
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  BookOpen, Scissors, Download, Plus, Minus, RotateCcw, 
  LayoutGrid, Ruler, Menu, X, Image as ImageIcon, Eye, MousePointer2
} from 'lucide-react';
import { Category, ChapterType, ModelType, Measurements, DrawResult, StyleConfig, Point } from './types.js';
import { DB, CATEGORY_STRUCTURE } from './constants.js';
import { draftPattern, SCALE } from './services/patternEngine.js';
import Button from './components/Button.js';
import MeasurementTable from './components/MeasurementTable.js';

const App: React.FC = () => {
  const [category, setCategory] = useState<Category>('women');
  const [size, setSize] = useState<string>('42');
  const [activeChapterIdx, setActiveChapterIdx] = useState(0);
  const [activeModelIdx, setActiveModelIdx] = useState(0);
  const [measurements, setMeasurements] = useState<Measurements>({});
  const [zoom, setZoom] = useState(0.65);
  const [sidebarOpen, setSidebarOpen] = useState(window.innerWidth > 1024);
  const [showReference, setShowReference] = useState(false);
  
  // حالات التفاعل مع النقاط
  const [hoveredPointIdx, setHoveredPointIdx] = useState<number | null>(null);
  const [selectedPointIdx, setSelectedPointIdx] = useState<number | null>(null);

  const svgRef = useRef<SVGSVGElement>(null);

  const currentChapters = useMemo(() => CATEGORY_STRUCTURE[category] || [], [category]);
  const currentChapter = currentChapters[activeChapterIdx] || currentChapters[0] || { id: 'skirts', name: '', models: [] };
  const currentModel = currentChapter.models[activeModelIdx] || currentChapter.models[0] || { id: 'basic_skirt', name: '', pageNumber: 0 };

  const availableSizes = useMemo(() => Object.keys(DB[category] || {}), [category]);

  useEffect(() => {
    const defaultSize = availableSizes.includes('42') ? '42' : availableSizes[0] || '';
    setSize(defaultSize);
    setActiveChapterIdx(0);
    setActiveModelIdx(0);
    setHoveredPointIdx(null);
    setSelectedPointIdx(null);
    if (defaultSize && DB[category][defaultSize]) {
      setMeasurements({ ...DB[category][defaultSize] });
    }
  }, [category, availableSizes]);

  useEffect(() => {
    if (size && DB[category][size]) {
      setMeasurements({ ...DB[category][size] });
    }
  }, [size, category]);

  const styleConfig: StyleConfig = useMemo(() => ({
    chapter: currentChapter.id as ChapterType,
    model: currentModel.id as ModelType,
    category: category,
    garmentLength: measurements["طول_الجولنة"] || measurements["طول_الظهر"] || 60,
    ease: 1.5
  }), [currentChapter, currentModel, category, measurements]);

  const patternData = useMemo<DrawResult>(() => {
    return draftPattern(styleConfig, measurements);
  }, [styleConfig, measurements]);

  const handleExport = () => {
    if (!svgRef.current) return;
    const serializer = new XMLSerializer();
    const svgString = serializer.serializeToString(svgRef.current);
    const blob = new Blob([svgString], { type: 'image/svg+xml' });
    const link = document.body.appendChild(document.createElement('a'));
    link.href = URL.createObjectURL(blob);
    link.download = `FathyKhalil_${category}_${currentModel.id}.svg`;
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="flex h-screen w-screen bg-[#f1f5f9] text-slate-900 overflow-hidden font-tajawal">
      {/* Mobile Sidebar Overlay */}
      {sidebarOpen && window.innerWidth <= 1024 && (
        <div className="fixed inset-0 bg-black/40 z-40 backdrop-blur-sm transition-opacity" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar Index */}
      <aside className={`bg-white border-l border-slate-200 transition-all duration-300 flex flex-col shadow-2xl z-50 fixed lg:relative h-full ${sidebarOpen ? 'w-80 translate-x-0' : 'w-0 -translate-x-full lg:translate-x-0 lg:w-0 overflow-hidden'}`}>
        <div className="p-6 border-b border-slate-100 bg-primary text-white flex-shrink-0">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <BookOpen className="w-6 h-6 text-secondary" />
              <h1 className="font-bold text-lg">موسوعة فتحي خليل</h1>
            </div>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-1 hover:bg-white/10 rounded transition-colors"><X className="w-5 h-5" /></button>
          </div>
          
          <div className="flex gap-1 bg-black/20 p-1 rounded-xl mb-4">
            {(['women', 'men', 'children'] as Category[]).map(c => (
              <button 
                key={c}
                onClick={() => setCategory(c)}
                className={`flex-1 py-2 rounded-lg text-[10px] sm:text-xs transition-all ${category === c ? 'bg-white text-primary font-bold shadow-md' : 'text-white/60 hover:text-white hover:bg-white/5'}`}
              >
                {c === 'women' ? 'حريمي' : c === 'men' ? 'رجالي' : 'أطفال'}
              </button>
            ))}
          </div>

          <div className="flex flex-col gap-2">
            <span className="text-[10px] font-bold text-white/50 uppercase tracking-widest flex items-center gap-1">
              <Ruler className="w-3 h-3" /> مقاس {category === 'children' ? 'العمر' : 'الجسم'}
            </span>
            <div className="flex gap-1.5 overflow-x-auto pb-1 scrollbar-none snap-x">
              {availableSizes.map(s => (
                <button
                  key={s}
                  onClick={() => setSize(s)}
                  className={`flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center text-xs font-bold transition-all snap-start ${size === s ? 'bg-secondary text-white ring-2 ring-white/20 shadow-lg' : 'bg-white/10 text-white/70 hover:bg-white/20'}`}
                >
                  {s.replace('سنة ', '')}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-6 bg-slate-50 scrollbar-thin">
          <section>
            <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
              <LayoutGrid className="w-3 h-3" /> أبواب الموسوعة
            </h3>
            <div className="grid gap-1.5">
              {currentChapters.map((chapter, idx) => (
                <button
                  key={idx}
                  onClick={() => {
                    setActiveChapterIdx(idx);
                    setActiveModelIdx(0);
                    setHoveredPointIdx(null);
                    setSelectedPointIdx(null);
                  }}
                  className={`text-right px-4 py-3 rounded-xl text-sm transition-all border ${activeChapterIdx === idx ? 'bg-secondary text-white border-secondary shadow-lg shadow-secondary/20 font-bold scale-[1.02]' : 'bg-white border-slate-200 text-slate-600 hover:border-secondary'}`}
                >
                  {chapter.name}
                </button>
              ))}
            </div>
          </section>

          <section>
            <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
              <Scissors className="w-3 h-3" /> الموديل
            </h3>
            <div className="grid grid-cols-1 gap-1.5">
              {currentChapter.models.map((m, idx) => (
                <button
                  key={m.id}
                  onClick={() => {
                    setActiveModelIdx(idx);
                    setHoveredPointIdx(null);
                    setSelectedPointIdx(null);
                    if (window.innerWidth <= 768) setSidebarOpen(false);
                  }}
                  className={`text-right px-4 py-2.5 rounded-lg text-xs transition-all border ${activeModelIdx === idx ? 'bg-primary/5 border-primary text-primary font-bold' : 'bg-white border-slate-100 text-slate-500 hover:border-slate-300'}`}
                >
                  <div className="flex items-center justify-between">
                    <span>{m.name}</span>
                    <span className="text-[9px] opacity-60">ص {m.pageNumber}</span>
                  </div>
                </button>
              ))}
            </div>
          </section>

          <section>
            <h3 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-3 flex items-center gap-2">
              <Ruler className="w-3 h-3" /> القياسات المخصصة (مقاس {size})
            </h3>
            <MeasurementTable measurements={measurements} onChange={(k, v) => setMeasurements(p => ({...p, [k]: v}))} />
          </section>
        </div>
      </aside>

      <main className="flex-1 flex flex-col relative bg-slate-100 min-w-0">
        <header className="h-16 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-6 z-20 shadow-sm">
          <div className="flex items-center gap-2 sm:gap-4 overflow-hidden">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:bg-slate-100 rounded-xl text-slate-500 transition-colors flex-shrink-0">
              <Menu className="w-6 h-6" />
            </button>
            <div className="flex flex-col overflow-hidden">
              <span className="text-[8px] sm:text-[10px] text-secondary font-bold uppercase tracking-widest truncate">منهجية فتحي خليل الأصلية</span>
              <h2 className="text-xs sm:text-base font-bold text-slate-700 truncate">{currentModel.name}</h2>
            </div>
          </div>
          
          <div className="flex items-center gap-2">
            <button 
              onClick={() => setShowReference(!showReference)}
              className={`flex items-center gap-2 px-3 py-2 rounded-xl text-xs font-bold transition-all border ${showReference ? 'bg-secondary text-white border-secondary' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}
            >
              <ImageIcon className="w-4 h-4" />
              <span className="hidden md:inline">صورة الكتاب</span>
            </button>
            <div className="w-px h-6 bg-slate-200 mx-1 hidden sm:block"></div>
            <button onClick={handleExport} className="p-2 sm:px-4 sm:py-2 bg-primary text-white rounded-xl text-xs font-bold hover:bg-slate-800 transition-all shadow-md flex items-center gap-2">
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">تصدير SVG</span>
            </button>
          </div>
        </header>

        <section className="flex-1 relative flex flex-col md:flex-row overflow-hidden p-4 sm:p-6 gap-6">
          {/* Reference Page View */}
          <div className={`${showReference ? 'flex' : 'hidden'} flex-1 bg-white rounded-2xl shadow-inner border border-slate-200 overflow-hidden relative group transition-all duration-300`}>
            <div className="absolute top-4 left-4 z-10 bg-black/60 text-white px-3 py-1 rounded-full text-[10px] font-bold backdrop-blur-md">
              الرسم التوضيحي الأصلي (ص {currentModel.pageNumber})
            </div>
            <div className="w-full h-full flex flex-col items-center justify-center p-8 bg-slate-50">
               <div className="text-center">
                  <ImageIcon size={64} className="mx-auto text-slate-200 mb-4" />
                  <h4 className="text-slate-500 font-bold mb-1">مرجع: {currentModel.name}</h4>
                  <p className="text-xs text-slate-400">الصفحة رقم {currentModel.pageNumber} من الموسوعة</p>
                  <div className="mt-8 p-4 bg-white rounded-xl border border-slate-200 shadow-sm text-[10px] text-slate-400 text-right leading-relaxed">
                    يتم رسم هذا الباترون آلياً بناءً على القواعد الرياضية المذكورة في الصفحة {currentModel.pageNumber}. تأكد من مراجعة قيم القياسات في الجدول الجانبي للحصول على نتيجة مطابقة لجسم العميل.
                  </div>
               </div>
            </div>
          </div>

          {/* Canvas View */}
          <div className="flex-[1.5] relative bg-white rounded-2xl shadow-xl border border-slate-200 overflow-hidden flex items-center justify-center">
            <div className="absolute inset-0 opacity-20 pointer-events-none" style={{ 
              backgroundImage: `linear-gradient(to right, #94a3b8 1px, transparent 1px), linear-gradient(to bottom, #94a3b8 1px, transparent 1px)`,
              backgroundSize: `${10 * SCALE}px ${10 * SCALE}px` 
            }}></div>

            <div className="relative overflow-visible transition-transform duration-500 ease-out" style={{ 
              width: '800px', 
              height: '1000px',
              transform: `scale(${zoom})`
            }}>
              <svg 
                ref={svgRef} 
                viewBox="0 0 800 1000" 
                className="w-full h-full drop-shadow-sm"
                onClick={() => setSelectedPointIdx(null)}
              >
                <g className="drafting-layer">
                  {patternData.paths.map(p => (
                    <path 
                      key={p.id} 
                      d={p.d} 
                      // تم تحديث السطر لدعم خاصية fill من PatternPath
                      fill={p.fill || "none"} 
                      stroke={p.stroke || "#334155"} 
                      strokeWidth={p.type === 'outline' ? 2.5 : 1.2}
                      strokeDasharray={p.dashArray}
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    />
                  ))}
                  {patternData.points.map((pt, i) => {
                    const isHovered = hoveredPointIdx === i;
                    const isSelected = selectedPointIdx === i;
                    const showLabel = isHovered || isSelected || pt.label;

                    return (
                      <g 
                        key={i} 
                        className="cursor-pointer group"
                        onMouseEnter={() => setHoveredPointIdx(i)}
                        onMouseLeave={() => setHoveredPointIdx(null)}
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedPointIdx(i);
                        }}
                      >
                        {/* Circle Ring on Selection */}
                        {(isSelected || isHovered) && (
                          <circle 
                            cx={pt.x} 
                            cy={pt.y} 
                            r={isSelected ? "12" : "10"} 
                            fill="transparent" 
                            stroke={isSelected ? "#e11d48" : "#3498db"} 
                            strokeWidth="2" 
                            strokeDasharray="2,2"
                            className={isHovered ? "animate-spin-slow" : ""}
                          />
                        )}
                        
                        {/* Main Point */}
                        <circle 
                          cx={pt.x} 
                          cy={pt.y} 
                          r={isSelected ? "6" : "4"} 
                          fill={isSelected ? "#e11d48" : isHovered ? "#3498db" : "#334155"} 
                          className="transition-all duration-200"
                        />

                        {/* Point Label - Professional Tooltip Style */}
                        {showLabel && pt.label && (
                          <g transform={`translate(${pt.x + 12}, ${pt.y - 12})`}>
                            {/* Label Background */}
                            <rect 
                              x="-5" 
                              y="-25" 
                              width={pt.label.length * 15 + 10} 
                              height="30" 
                              rx="6" 
                              fill={isSelected ? "#e11d48" : "#1e293b"} 
                              className="shadow-lg transition-colors duration-200"
                            />
                            {/* Label Pointer */}
                            <path 
                              d="M -5 -10 L -12 0 L 0 -5 Z" 
                              fill={isSelected ? "#e11d48" : "#1e293b"} 
                            />
                            {/* Label Text */}
                            <text 
                              x="5" 
                              y="-5" 
                              fontSize="18" 
                              fontWeight="bold" 
                              fill="white"
                              className="select-none pointer-events-none font-tajawal"
                            >
                              {pt.label}
                            </text>
                            
                            {/* Optional: Show Coordinates on Selection */}
                            {isSelected && (
                              <text 
                                x="5" 
                                y="15" 
                                fontSize="10" 
                                fill="#64748b" 
                                className="font-mono"
                              >
                                {`${Math.round(pt.x/SCALE)}, ${Math.round(pt.y/SCALE)} cm`}
                              </text>
                            )}
                          </g>
                        )}
                      </g>
                    );
                  })}
                </g>
              </svg>
            </div>

            <div className="absolute bottom-6 left-6 flex items-center gap-1.5 bg-white/90 backdrop-blur-xl p-1.5 rounded-2xl shadow-2xl border border-slate-200">
              <button onClick={() => setZoom(z => Math.min(z + 0.1, 4))} className="p-3 hover:bg-slate-100 rounded-xl text-slate-600 transition-all"><Plus size={20}/></button>
              <div className="w-px h-6 bg-slate-200"></div>
              <button onClick={() => setZoom(0.65)} className="px-4 py-2 text-[11px] font-black text-slate-500 hover:text-secondary uppercase tracking-tighter">إعادة ضبط</button>
              <div className="w-px h-6 bg-slate-200"></div>
              <button onClick={() => setZoom(z => Math.max(z - 0.1, 0.1))} className="p-3 hover:bg-slate-100 rounded-xl text-slate-600 transition-all"><Minus size={20}/></button>
              <button onClick={() => setZoom(1.0)} className="p-3 hover:bg-slate-100 rounded-xl text-secondary transition-all"><RotateCcw size={20}/></button>
            </div>
            
            {/* Interactive Legend */}
            <div className="absolute top-6 right-6 hidden md:block">
              <div className="bg-white/80 backdrop-blur-md p-3 rounded-xl border border-slate-200 shadow-sm flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500">
                  <div className="w-2 h-2 rounded-full bg-[#1e293b]"></div> نقطة أساسية
                </div>
                <div className="w-px h-3 bg-slate-300"></div>
                <div className="flex items-center gap-1.5 text-[10px] font-bold text-slate-500">
                  <MousePointer2 size={12} className="text-secondary" /> انقر للتثبيت
                </div>
              </div>
            </div>
          </div>
        </section>

        <footer className="h-10 bg-white border-t border-slate-200 px-6 flex items-center justify-between text-[10px] text-slate-500 font-bold uppercase tracking-widest flex-shrink-0">
          <div className="flex gap-6">
            <span className="flex items-center gap-1.5"><Eye size={12} className="text-secondary" /> الموديل: {currentModel.name}</span>
            <span className="hidden sm:inline">مقاس: {size}</span>
            {selectedPointIdx !== null && (
              <span className="text-secondary font-black animate-pulse">
                نقطة محددة: {patternData.points[selectedPointIdx]?.label || selectedPointIdx}
              </span>
            )}
          </div>
          <div className="flex items-center gap-2 text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
            <div className="w-1.5 h-1.5 rounded-full bg-current animate-pulse"></div>
            <span>محرك الباترونات نشط</span>
          </div>
        </footer>
      </main>

      <style>{`
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 8s linear infinite;
          transform-origin: center;
        }
      `}</style>
    </div>
  );
};

export default App;
