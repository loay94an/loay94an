
import { Measurements, Point, DrawResult, PatternPath, StyleConfig } from '../types.js';

export const SCALE = 8; // 1سم = 8 بكسل

const checkIsMen = (cat: string) => cat === 'men';

/**
 * محرك رسم الباترونات الرقمي - المنهجية المتقدمة لفتحي خليل
 */
export const draftPattern = (config: StyleConfig, m: Measurements): DrawResult => {
  const points: Point[] = [];
  const paths: PatternPath[] = [];
  const center = { x: 350, y: 120 };

  const addPt = (x: number, y: number, label?: string) => {
    const pt = { x, y, label };
    points.push(pt);
    return pt;
  };

  // استخراج القياسات الأساسية مع قيم افتراضية ذكية
  const bust = m["محيط_الصدر"] || 96;
  const waist = m["محيط_الوسط"] || 76;
  const hip = m["محيط_الهنش"] || 104;
  const backLen = m["طول_الظهر"] || 42;
  const sideLen = m["طول_الجنب"] || 20;
  const shoulderW = m["عرض_الكتف"] || 13;
  const neckCirc = m["محيط_الرقبة"] || 36;
  const sleeveLen = m["طول_الكم"] || 60;
  const totalLen = m["الطول_الكلى"] || 105;
  const jacketLen = m["طول_الجاكيت"] || 75;

  // --- 1. خوارزمية الجولنة (Skirts) ---
  if (config.chapter === 'skirts') {
    const h = (config.garmentLength || 75) * SCALE;
    const s = sideLen * SCALE;
    const isCircular = config.model.includes('circular');
    
    if (isCircular) {
      // الجولنة الكلوش (صفحة 97)
      const isFull = config.model.includes('wedding');
      const radius = waist / (isFull ? (2 * Math.PI) : Math.PI);
      const r = radius * SCALE;
      const totalR = r + h;
      
      paths.push({ 
        id: 'waist-arc', 
        d: `M ${center.x - r} ${center.y} A ${r} ${r} 0 0 1 ${center.x + r} ${center.y}`, 
        type: 'outline', stroke: '#2c3e50', strokeWidth: 3 
      });
      paths.push({ 
        id: 'hem-arc', 
        d: `M ${center.x - totalR} ${center.y} A ${totalR} ${totalR} 0 0 1 ${center.x + totalR} ${center.y}`, 
        type: 'outline', stroke: '#1e293b', strokeWidth: 4 
      });
      paths.push({ id: 'side-l', d: `M ${center.x - r} ${center.y} L ${center.x - totalR} ${center.y}`, type: 'outline' });
      paths.push({ id: 'side-r', d: `M ${center.x + r} ${center.y} L ${center.x + totalR} ${center.y}`, type: 'outline' });
      addPt(center.x, center.y, 'م');
    } else {
      // الجولنة الكلاسيكية (صفحة 2)
      const w = ((hip / 4) + 1) * SCALE;
      const waistW = ((waist / 4) + 2.5) * SCALE;
      
      // خطوط البناء
      paths.push({ id: 'frame', d: `M ${center.x} ${center.y} H ${center.x + w} V ${center.y + h} H ${center.x} Z`, type: 'technical', stroke: '#cbd5e1', dashArray: '4,4' });
      
      // خطوط القص
      paths.push({ id: 'waist', d: `M ${center.x} ${center.y} L ${center.x + waistW} ${center.y}`, type: 'outline', strokeWidth: 2 });
      paths.push({ id: 'hip-curve', d: `M ${center.x + waistW} ${center.y} Q ${center.x + w + 12} ${center.y + s/2} ${center.x + w} ${center.y + s}`, type: 'curve', stroke: '#2563eb', strokeWidth: 3 });
      paths.push({ id: 'side', d: `M ${center.x + w} ${center.y + s} V ${center.y + h}`, type: 'outline', strokeWidth: 3 });
      paths.push({ id: 'hem', d: `M ${center.x} ${center.y + h} H ${center.x + w}`, type: 'outline', strokeWidth: 4 });
      paths.push({ id: 'center', d: `M ${center.x} ${center.y} V ${center.y + h}`, type: 'outline' });

      // البنسات (Darts)
      const dartX = center.x + (waistW * 0.4);
      paths.push({ id: 'dart', d: `M ${dartX - 1.25*SCALE} ${center.y} L ${dartX} ${center.y + 10*SCALE} L ${dartX + 1.25*SCALE} ${center.y}`, type: 'dart', stroke: '#334155' });

      // إضافات الموديلات
      if (config.model.includes('pleats')) {
        const pleatCount = 3;
        for (let i = 1; i <= pleatCount; i++) {
          const px = center.x + (w / (pleatCount + 1)) * i;
          paths.push({ id: `pleat-${i}`, d: `M ${px} ${center.y} V ${center.y + h}`, type: 'pleat', stroke: '#6366f1', dashArray: '10,5' });
        }
      }
      addPt(center.x, center.y, '1');
      addPt(center.x + waistW, center.y, '2');
    }
  }

  // --- 2. خوارزمية الجزء العلوي (Bodice / Blouses / Dresses) ---
  else if (['bodice', 'blouses', 'dresses', 'outerwear', 'home', 'children'].includes(config.chapter)) {
    const isMen = checkIsMen(config.category);
    const isChild = config.category === 'children';
    const ease = isMen ? 6 : (isChild ? 4 : 2);
    
    const w = ((bust / 4) + ease) * SCALE;
    const h = (config.chapter === 'dresses' ? totalLen : (config.chapter === 'outerwear' ? jacketLen : backLen)) * SCALE;
    const armDepth = (backLen / 2 + (isMen ? 4 : 2)) * SCALE;
    const nw = (neckCirc / (isMen ? 6 : 5)) * SCALE;
    const sw = shoulderW * SCALE;
    
    // رسم الإطار الأساسي
    paths.push({ id: 'frame', d: `M ${center.x} ${center.y} H ${center.x + w} V ${center.y + h} H ${center.x} Z`, type: 'technical', stroke: '#e2e8f0', dashArray: '2,2' });
    
    // الرقبة (صفحة 134)
    paths.push({ id: 'neck', d: `M ${center.x} ${center.y + 2*SCALE} Q ${center.x} ${center.y} ${center.x + nw} ${center.y}`, type: 'outline', strokeWidth: 2.5 });
    
    if (config.model.includes('japanese')) {
      // الكم الجابونيز (صفحة 771) - كتف ممتد
      paths.push({ id: 'jap-shoulder', d: `M ${center.x + nw} ${center.y} L ${center.x + nw + sw + 25*SCALE} ${center.y + 10*SCALE} L ${center.x + nw + sw + 23*SCALE} ${center.y + 20*SCALE} Q ${center.x + w} ${center.y + armDepth + 8*SCALE} ${center.x + w} ${center.y + armDepth}`, type: 'outline', stroke: '#1e293b', strokeWidth: 3 });
    } else {
      paths.push({ id: 'shoulder', d: `M ${center.x + nw} ${center.y} L ${center.x + nw + sw} ${center.y + 4.5*SCALE}`, type: 'outline', strokeWidth: 2 });
      paths.push({ id: 'armhole', d: `M ${center.x + nw + sw} ${center.y + 4.5*SCALE} Q ${center.x + w} ${center.y + armDepth/2} ${center.x + w} ${center.y + armDepth}`, type: 'curve', stroke: '#ef4444', strokeWidth: 3 });
    }

    // قصات الصدر الاحترافية
    if (config.model.includes('princess')) {
      // قصة البرنسيس (صفحة 243)
      const bustPtX = center.x + (bust/10 + 1)*SCALE;
      const bustPtY = center.y + armDepth;
      paths.push({ id: 'princess', d: `M ${center.x + nw + sw/2} ${center.y + 2*SCALE} Q ${bustPtX} ${bustPtY} ${bustPtX} ${center.y + h}`, type: 'outline', stroke: '#2563eb', dashArray: '8,4' });
    }

    if (config.model.includes('empire')) {
      // قصة الأمبير (صفحة 304)
      const empY = center.y + armDepth + 6*SCALE;
      paths.push({ id: 'empire', d: `M ${center.x} ${empY} H ${center.x + w}`, type: 'technical', stroke: '#8b5cf6', strokeWidth: 2 });
    }

    if (config.model.includes('jacket') || config.model.includes('coat')) {
      // الياقة وتوسعة المرد (صفحة 481)
      paths.push({ id: 'lapel', d: `M ${center.x} ${center.y + 15*SCALE} L ${center.x - 10*SCALE} ${center.y + 22*SCALE} L ${center.x} ${center.y + 35*SCALE}`, type: 'outline', strokeWidth: 2 });
      paths.push({ id: 'overlap', d: `M ${center.x} ${center.y + 35*SCALE} V ${center.y + h} H ${center.x - 3*SCALE} V ${center.y + 35*SCALE} Z`, type: 'outline', fill: '#f1f5f9' });
    }

    // رسم الجسم
    const expansion = config.model.includes('wide') || config.model.includes('abaya') ? 20*SCALE : 0;
    paths.push({ id: 'side', d: `M ${center.x + w} ${center.y + armDepth} L ${center.x + w + expansion} ${center.y + h}`, type: 'outline', strokeWidth: 2.5 });
    paths.push({ id: 'center', d: `M ${center.x} ${center.y + 2*SCALE} V ${center.y + h}`, type: 'outline', strokeWidth: 2.5 });
    paths.push({ id: 'hem', d: `M ${center.x} ${center.y + h} L ${center.x + w + expansion} ${center.y + h}`, type: 'outline', strokeWidth: 4 });

    addPt(center.x, center.y, 'أ');
    addPt(center.x + nw, center.y, '1');
    addPt(center.x + nw + sw, center.y + 4.5*SCALE, '2');
  }

  // --- 3. خوارزمية البنطلون (Trousers) ---
  else if (config.chapter === 'trousers' || config.model.includes('pants')) {
    const isMen = checkIsMen(config.category);
    const hw = ((hip / 4) + (isMen ? 2.5 : 1.5)) * SCALE;
    const cd = ((hip / 4) + (isMen ? 4 : 2)) * SCALE; 
    const legL = (m["الطول_الكلى"] || totalLen) * SCALE;
    const ext = (hip / (isMen ? 10 : 16)) * SCALE;

    paths.push({ id: 'construction', d: `M ${center.x} ${center.y} H ${center.x + hw} V ${center.y + legL} H ${center.x} Z`, type: 'technical', stroke: '#cbd5e1', dashArray: '2,2' });
    
    // خطوط القص (صفحة 385 و 401)
    paths.push({ id: 'waist', d: `M ${center.x} ${center.y} H ${center.x + hw}`, type: 'outline', strokeWidth: 2.5 });
    paths.push({ id: 'crotch', d: `M ${center.x + hw} ${center.y} Q ${center.x + hw} ${center.y + cd} ${center.x + hw + ext} ${center.y + cd}`, type: 'curve', stroke: '#ef4444', strokeWidth: 3 });
    paths.push({ id: 'inner', d: `M ${center.x + hw + ext} ${center.y + cd} L ${center.x + hw - 5*SCALE} ${center.y + legL}`, type: 'outline', strokeWidth: 2 });
    paths.push({ id: 'outer', d: `M ${center.x} ${center.y} V ${center.y + legL}`, type: 'outline', strokeWidth: 2 });
    paths.push({ id: 'hem', d: `M ${center.x} ${center.y + legL} H ${center.x + hw - 5*SCALE}`, type: 'outline', strokeWidth: 4 });

    if (config.model.includes('salopette')) {
      paths.push({ id: 'bib', d: `M ${center.x + 6*SCALE} ${center.y} V ${center.y - 25*SCALE} H ${center.x + hw - 6*SCALE} V ${center.y}`, type: 'outline', stroke: '#1e293b', strokeWidth: 2 });
    }
    addPt(center.x + hw, center.y + cd, 'ج');
  }

  // --- 4. خوارزمية الأكمام (Sleeves) ---
  else if (config.chapter === 'sleeves' || config.model.includes('sleeve')) {
    const isMen = checkIsMen(config.category);
    const sw = (bust / 3) * SCALE;
    const headH = (bust / 10 + (isMen ? 3.5 : 2.5)) * SCALE;
    const sl = sleeveLen * SCALE;

    // رأس الكم (Sleeve Cap)
    paths.push({ id: 'cap', d: `M ${center.x - sw/2} ${center.y + headH} Q ${center.x} ${center.y - 8*SCALE} ${center.x + sw/2} ${center.y + headH}`, type: 'curve', stroke: '#ef4444', strokeWidth: 3 });
    paths.push({ id: 'side-l', d: `M ${center.x - sw/2} ${center.y + headH} L ${center.x - 9*SCALE} ${center.y + sl}`, type: 'outline', strokeWidth: 2 });
    paths.push({ id: 'side-r', d: `M ${center.x + sw/2} ${center.y + headH} L ${center.x + 9*SCALE} ${center.y + sl}`, type: 'outline', strokeWidth: 2 });
    paths.push({ id: 'cuff', d: `M ${center.x - 9*SCALE} ${center.y + sl} H ${center.x + 9*SCALE}`, type: 'outline', strokeWidth: 4 });

    if (config.model.includes('raglan')) {
      // الكم الرجلان (صفحة 705)
      paths.push({ id: 'raglan-line', d: `M ${center.x} ${center.y} L ${center.x - sw/3} ${center.y + headH/2}`, type: 'technical', stroke: '#2563eb', dashArray: '6,3' });
    }
    addPt(center.x, center.y, 'س');
  }

  // Fallback إذا لم يتم العثور على مسارات محددة
  if (paths.length === 0) {
    paths.push({ id: 'error-placeholder', d: `M ${center.x} ${center.y} L ${center.x + 100} ${center.y + 100}`, type: 'technical', stroke: '#cbd5e1' });
  }

  return { points, paths };
};
