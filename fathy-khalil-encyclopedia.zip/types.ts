
export type Category = 'women' | 'men' | 'children';
// إضافة 'children' كنوع فصل صالح لدعم هيكل تصنيف الأطفال في ملف constants.ts
export type ChapterType = 
  | 'introduction' | 'skirts' | 'bodice' | 'blouses' | 'sleeves' | 'collars' 
  | 'dresses' | 'islamic' | 'trousers' | 'outerwear' | 'home' | 'underwear' 
  | 'men_traditional' | 'men_modern' | 'swimwear' | 'technical' | 'children';

export type ModelType = string; // استخدام string للمرونة مع العدد الضخم من الموديلات

export interface Measurements {
  [key: string]: number;
}

export type Database = Record<Category, Record<string, Measurements>>;

export interface Point {
  x: number;
  y: number;
  label?: string;
}

export interface PatternPath {
  id: string;
  d: string;
  type: 'outline' | 'technical' | 'curve' | 'dart' | 'pleat';
  stroke?: string;
  strokeWidth?: number;
  dashArray?: string;
  // إضافة خاصية fill للسماح بتعبئة المسارات (مثل تداخل الجاكيت)
  fill?: string;
}

export interface DrawResult {
  paths: PatternPath[];
  points: Point[];
  warnings?: string[];
}

export interface StyleConfig {
  chapter: ChapterType;
  model: ModelType;
  category: Category;
  garmentLength: number;
  ease: number;
}

export interface ModelInfo {
  id: ModelType;
  name: string;
  pageNumber?: number;
}

export interface ChapterInfo {
  id: ChapterType;
  name: string;
  models: ModelInfo[];
}
