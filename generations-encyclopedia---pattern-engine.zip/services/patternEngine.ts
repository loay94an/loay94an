
import { Measurements, ModelType, Point } from '../types';

export const calculateJacketPath = (m: Measurements, scale: number, center: Point) => {
  const bust = m["صدر"] || 88;
  const backLen = m["ظهر"] || 39;
  const neckCirc = m["رقبة"] || 36;
  const shoulderW = m["عرض_ظهر"] || 17.5;
  const fullLen = m["طول_كلي"] || 65;

  const armDepth = (backLen / 2) + 4;
  const neckW = (neckCirc / 5) + 1;
  const rectW = (bust / 4) + 2;

  const startX = center.x - (rectW * scale) / 2;
  const startY = center.y - (fullLen * scale) / 2;

  const points = {
    A: { x: startX, y: startY },
    B: { x: startX + rectW * scale, y: startY },
    C: { x: startX + rectW * scale, y: startY + fullLen * scale },
    D: { x: startX, y: startY + fullLen * scale },
    Arm: { x: startX, y: startY + armDepth * scale },
    Waist: { x: startX, y: startY + backLen * scale },
    NeckTop: { x: startX + neckW * scale, y: startY },
    NeckSide: { x: startX, y: startY + 1.5 * scale },
    Shoulder: { x: startX + shoulderW * scale, y: startY + 3 * scale },
  };

  return {
    rect: `M ${points.A.x} ${points.A.y} L ${points.B.x} ${points.B.y} L ${points.C.x} ${points.C.y} L ${points.D.x} ${points.D.y} Z`,
    armLine: `M ${points.Arm.x} ${points.Arm.y} L ${points.B.x} ${points.Arm.y}`,
    waistLine: `M ${points.Waist.x} ${points.Waist.y} L ${points.B.x} ${points.Waist.y}`,
    neckCurve: `M ${points.NeckSide.x} ${points.NeckSide.y} Q ${points.A.x} ${points.A.y} ${points.NeckTop.x} ${points.NeckTop.y}`,
    shoulderLine: `M ${points.NeckTop.x} ${points.NeckTop.y} L ${points.Shoulder.x} ${points.Shoulder.y}`,
    armhole: `M ${points.Shoulder.x} ${points.Shoulder.y} Q ${points.Shoulder.x + 2 * scale} ${points.Arm.y} ${points.B.x} ${points.Arm.y}`,
    points
  };
};

export const calculateSkirtPath = (m: Measurements, scale: number, center: Point) => {
    // Simplified Skirt Logic
    const waist = m["وسط"] || 70;
    const bust = m["صدر"] || 88; // Using bust as proxy for hips if hip not provided
    const hip = bust + 4; 
    const fullLen = 60; // Default skirt length

    const rectW = (hip / 4) + 1;
    const startX = center.x - (rectW * scale) / 2;
    const startY = center.y - (fullLen * scale) / 2;

    const points = {
        A: { x: startX, y: startY },
        B: { x: startX + rectW * scale, y: startY },
        C: { x: startX + rectW * scale, y: startY + fullLen * scale },
        D: { x: startX, y: startY + fullLen * scale },
        HipLine: { x: startX, y: startY + 20 * scale }
    };

    return {
        rect: `M ${points.A.x} ${points.A.y} L ${points.B.x} ${points.B.y} L ${points.C.x} ${points.C.y} L ${points.D.x} ${points.D.y} Z`,
        hipLine: `M ${points.HipLine.x} ${points.HipLine.y} L ${points.B.x} ${points.HipLine.y}`,
        waistShaping: `M ${points.A.x} ${points.A.y} Q ${points.B.x} ${points.A.y - 1 * scale} ${points.B.x} ${points.A.y}`,
        points
    };
};
