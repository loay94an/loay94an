
export type Category = 'women' | 'men';
export type ModelType = 'jacket' | 'skirt' | 'shirt';

export interface Measurements {
  [key: string]: number;
}

export interface SizeData {
  [size: string]: Measurements;
}

export interface Database {
  women: SizeData;
  men: SizeData;
}

export interface Point {
  x: number;
  y: number;
}
