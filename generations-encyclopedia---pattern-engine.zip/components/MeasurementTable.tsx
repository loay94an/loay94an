
import React from 'react';
import { Measurements } from '../types';

interface MeasurementTableProps {
  measurements: Measurements;
  onChange: (key: string, value: number) => void;
}

const MeasurementTable: React.FC<MeasurementTableProps> = ({ measurements, onChange }) => {
  return (
    <div className="overflow-hidden rounded-xl border border-white/10 bg-white/5 backdrop-blur-sm">
      <table className="w-full text-right text-sm">
        <thead className="bg-white/10 text-secondary">
          <tr>
            <th className="px-4 py-2 text-center">القياس</th>
            <th className="px-4 py-2 text-center">القيمة (سم)</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-white/5">
          {Object.entries(measurements).map(([key, val]) => (
            <tr key={key} className="hover:bg-white/5 transition-colors">
              <td className="px-4 py-2 text-gray-300 font-medium">{key}</td>
              <td className="px-4 py-2 text-center">
                <input
                  type="number"
                  step="0.1"
                  value={val}
                  onChange={(e) => onChange(key, parseFloat(e.target.value) || 0)}
                  className="w-20 rounded border border-white/20 bg-dark px-2 py-1 text-center text-secondary focus:outline-none focus:ring-1 focus:ring-secondary"
                />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default MeasurementTable;
