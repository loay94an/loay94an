
import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { 
  Settings, 
  Ruler, 
  Layers, 
  Download, 
  Plus, 
  Minus, 
  RotateCcw, 
  Scissors, 
  User, 
  ChevronRight 
} from 'lucide-react';
// Added Point import to handle measurement point typing
import { Category, ModelType, Measurements, Point } from './types';
import { DB, MODEL_NAMES, MODEL_DESCRIPTIONS } from './constants';
import { calculateJacketPath, calculateSkirtPath } from './services/patternEngine';
import Button from './components/Button';
import MeasurementTable from './components/MeasurementTable';

const App: React.FC = () => {
  const [category, setCategory] = useState<Category>('women');
  const [size, setSize] = useState<string>('38');
  const [model, setModel] = useState<ModelType>('jacket');
  const [measurements, setMeasurements] = useState<Measurements>(DB.women['38']);
  const [zoom, setZoom] = useState(1.0);
  const [showModels, setShowModels] = useState(false);
  const [showSizes, setShowSizes] = useState(false);

  // Sync measurements when category or size changes
  useEffect(() => {
    if (DB[category] && DB[category][size]) {
      setMeasurements({ ...DB[category][size] });
    }
  }, [category, size]);

  const handleMeasurementChange = useCallback((key: string, value: number) => {
    setMeasurements(prev => ({ ...prev, [key]: value }));
  }, []);

  const handleExport = () => {
    const svgElement = document.getElementById('pattern-svg');
    if (!svgElement) return;
    const serializer = new XMLSerializer();
    const svgString = '<?xml version="1.0" encoding="UTF-8"?>' + serializer.serializeToString(svgElement);
    const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `باترون_${MODEL_NAMES[model]}_مقاس_${size}.svg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const patternData = useMemo(() => {
    const center = { x: 400, y: 300 };
    const scale = 8 * zoom;
    if (model === 'jacket') return calculateJacketPath(measurements, scale, center);
    if (model === 'skirt') return calculateSkirtPath(measurements, scale, center);
    return null;
  }, [measurements, model, zoom]);

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-gray-50 font-tajawal">
      {/* Header */}
      <header className="flex items-center justify-between bg-gradient-to-l from-primary to-secondary px-6 py-4 text-white shadow-lg z-10">
        <div className="flex items-center gap-3">
          <div className="rounded-full bg-white/20 p-2">
            <Settings className="h-6 w-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold">موسوعة الأجيال الرقمية</h1>
            <p className="text-xs opacity-80">المحرك الهندسي المتطور - طريقة فتحي خليل</p>
          </div>
        </div>
        <div className="flex gap-2">
          <Button onClick={handleExport} variant="accent" icon={<Download className="h-4 w-4" />}>
            تصدير SVG
          </Button>
        </div>
      </header>

      <main className="flex flex-1 overflow-hidden">
        {/* Sidebar */}
        <aside className="w-80 flex-shrink-0 overflow-y-auto bg-dark p-6 text-white shadow-2xl transition-all">
          <section className="mb-8">
            <h3 className="mb-4 flex items-center gap-2 text-secondary font-bold border-r-4 border-secondary pr-2">
              <User className="h-5 w-5" /> الفئة والمقاس
            </h3>
            <select 
              className="mb-4 w-full rounded-lg bg-white/10 p-2 text-white outline-none focus:ring-2 focus:ring-secondary"
              value={category}
              onChange={(e) => {
                const newCat = e.target.value as Category;
                setCategory(newCat);
                setSize(Object.keys(DB[newCat])[0]);
              }}
            >
              <option value="women" className="bg-dark">حريمي</option>
              <option value="men" className="bg-dark">رجالي</option>
            </select>
            <div className="mb-4 flex items-center justify-between">
              <span className="text-sm font-bold text-secondary">المقاس الحالي: {size}</span>
              <Button onClick={() => setShowSizes(true)} variant="outline" className="px-2 py-1 text-xs border-white/20 text-white">تغيير</Button>
            </div>
          </section>

          <section className="mb-8">
            <h3 className="mb-4 flex items-center gap-2 text-secondary font-bold border-r-4 border-secondary pr-2">
              <Ruler className="h-5 w-5" /> جدول القياسات الحية
            </h3>
            <MeasurementTable measurements={measurements} onChange={handleMeasurementChange} />
          </section>

          <section>
            <h3 className="mb-4 flex items-center gap-2 text-secondary font-bold border-r-4 border-secondary pr-2">
              <Scissors className="h-5 w-5" /> الموديل الهندسي
            </h3>
            <div className="rounded-xl bg-white/5 p-4 border border-white/10">
              <p className="mb-2 font-bold text-secondary">{MODEL_NAMES[model]}</p>
              <p className="text-xs text-gray-400 mb-4 leading-relaxed">{MODEL_DESCRIPTIONS[model]}</p>
              <Button onClick={() => setShowModels(true)} className="w-full bg-emerald-600 hover:bg-emerald-700">تغيير الموديل</Button>
            </div>
          </section>
        </aside>

        {/* Viewport */}
        <section className="relative flex-1 bg-white">
          <div className="absolute inset-0 z-0 bg-[radial-gradient(#e5e7eb_1px,transparent_1px)] [background-size:20px_20px]"></div>
          
          <div className="absolute top-6 left-6 z-20 flex flex-col gap-2">
            <Button onClick={() => setZoom(z => z * 1.2)} variant="secondary" className="p-2 h-10 w-10"><Plus className="h-5 w-5" /></Button>
            <Button onClick={() => setZoom(z => z / 1.2)} variant="secondary" className="p-2 h-10 w-10"><Minus className="h-5 w-5" /></Button>
            <Button onClick={() => setZoom(1.0)} variant="outline" className="p-2 h-10 w-10 bg-white"><RotateCcw className="h-5 w-5" /></Button>
          </div>

          <div className="h-full w-full overflow-hidden flex items-center justify-center p-8">
            <svg 
              id="pattern-svg"
              className="max-h-full max-w-full drop-shadow-xl z-10"
              viewBox="0 0 800 600"
              xmlns="http://www.w3.org/2000/svg"
            >
              {patternData && (
                <g>
                  {/* Base Outlines */}
                  <path d={patternData.rect} fill="none" stroke="#2c3e50" strokeWidth="2" />
                  
                  {/* Technical Lines */}
                  {'armLine' in patternData && <path d={patternData.armLine} fill="none" stroke="#3498db" strokeWidth="1" strokeDasharray="5,5" />}
                  {'waistLine' in patternData && <path d={patternData.waistLine} fill="none" stroke="#3498db" strokeWidth="1" strokeDasharray="5,5" />}
                  {'hipLine' in patternData && <path d={patternData.hipLine} fill="none" stroke="#3498db" strokeWidth="1" strokeDasharray="5,5" />}

                  {/* Anatomical Curves */}
                  {'neckCurve' in patternData && <path d={patternData.neckCurve} fill="none" stroke="#e74c3c" strokeWidth="2" />}
                  {'shoulderLine' in patternData && <path d={patternData.shoulderLine} fill="none" stroke="#2c3e50" strokeWidth="2" />}
                  {'armhole' in patternData && <path d={patternData.armhole} fill="none" stroke="#e74c3c" strokeWidth="2" />}
                  {'waistShaping' in patternData && <path d={patternData.waistShaping} fill="none" stroke="#e74c3c" strokeWidth="2" />}

                  {/* Labels */}
                  {/* Fixed typing for points using explicit cast to Point type to avoid 'unknown' error */}
                  {Object.entries(patternData.points).map(([key, pt]) => {
                    const point = pt as Point;
                    return (
                      <text 
                          key={key} 
                          x={point.x - 15} 
                          y={point.y - 10} 
                          fontSize="12" 
                          fill="#e74c3c" 
                          fontWeight="bold"
                      >
                          {key === 'A' ? 'أ' : key === 'B' ? 'ب' : key === 'C' ? 'ج' : key === 'D' ? 'د' : ''}
                      </text>
                    );
                  })}
                </g>
              )}
              {/* Fallback for undeveloped models */}
              {model === 'shirt' && (
                <text x="300" y="300" fill="#e74c3c" fontSize="24" fontWeight="bold">باترون القميص قيد التطوير</text>
              )}
            </svg>
          </div>
        </section>
      </main>

      {/* Modals */}
      {showModels && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl animate-in fade-in zoom-in duration-300">
            <div className="mb-4 flex items-center justify-between border-b pb-3">
              <h3 className="text-xl font-bold text-primary">اختيار الموديل الهندسي</h3>
              <Button onClick={() => setShowModels(false)} variant="outline" className="p-1 h-8 w-8 text-red-500 border-none">&times;</Button>
            </div>
            <div className="grid grid-cols-2 gap-4">
              {Object.keys(MODEL_NAMES).map((m) => (
                <div 
                  key={m}
                  onClick={() => { setModel(m as ModelType); setShowModels(false); }}
                  className={`cursor-pointer rounded-xl border-2 p-4 text-center transition-all hover:shadow-lg ${model === m ? 'border-secondary bg-blue-50' : 'border-gray-100 hover:border-gray-300'}`}
                >
                  <Layers className={`mx-auto mb-2 h-8 w-8 ${model === m ? 'text-secondary' : 'text-gray-400'}`} />
                  <span className="font-bold">{MODEL_NAMES[m]}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {showSizes && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl animate-in fade-in zoom-in duration-300">
            <div className="mb-4 flex items-center justify-between border-b pb-3">
              <h3 className="text-xl font-bold text-primary">قاعدة بيانات المقاسات القياسية</h3>
              <Button onClick={() => setShowSizes(false)} variant="outline" className="p-1 h-8 w-8 text-red-500 border-none">&times;</Button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-right">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-2 text-center">المقاس</th>
                    <th className="px-4 py-2 text-center">الصدر</th>
                    <th className="px-4 py-2 text-center">الوسط</th>
                    <th className="px-4 py-2 text-center">الظهر</th>
                    <th className="px-4 py-2 text-center">العمل</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {Object.entries(DB[category]).map(([s, row]) => (
                    <tr key={s} className="hover:bg-blue-50">
                      <td className="px-4 py-3 text-center font-bold text-secondary">{s}</td>
                      <td className="px-4 py-3 text-center text-gray-600">{row["صدر"]}</td>
                      <td className="px-4 py-3 text-center text-gray-600">{row["وسط"]}</td>
                      <td className="px-4 py-3 text-center text-gray-600">{row["ظهر"]}</td>
                      <td className="px-4 py-3 text-center">
                        <Button onClick={() => { setSize(s); setShowSizes(false); }} className="px-3 py-1 text-xs">اختيار</Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
