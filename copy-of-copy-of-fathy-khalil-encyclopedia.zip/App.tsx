
import React, { useState, useMemo, useEffect, useRef } from 'react';
import { 
  BookOpen, Scissors, Download, Plus, Minus, RotateCcw, 
  Ruler, Menu, X, Hash, Maximize2, Layers, Settings, Book as BookIcon, 
  ChevronLeft, ChevronRight, FileText, Search, ZoomIn, ZoomOut, Printer,
  Minimize2, ArrowRight, ArrowLeft, Eye, RefreshCcw, Info, BookMarked, GraduationCap, ChevronDown, List,
  BookCopy
} from 'lucide-react';
import { Category, ChapterType, ModelType, Measurements, DrawResult, StyleConfig, ViewMode } from './types';
import { DB, CATEGORY_STRUCTURE, ENCYCLOPEDIA_SUMMARY, TECHNICAL_SHEETS } from './constants';
import { draftPattern } from './services/patternEngine';
import MeasurementTable from './components/MeasurementTable';
import SizeDial from './components/SizeDial';

const App: React.FC = () => {
  const [category, setCategory] = useState<Category>('women');
  const [size, setSize] = useState<string>('42');
  const [activeChapterIdx, setActiveChapterIdx] = useState(0);
  const [activeModelIdx, setActiveModelIdx] = useState(0);
  const [measurements, setMeasurements] = useState<Measurements>({});
  const [zoom, setZoom] = useState(0.7);
  const [sidebarOpen, setSidebarOpen] = useState(window.innerWidth > 1024);
  const [showReader, setShowReader] = useState(false);
  const [readerFullScreen, setReaderFullScreen] = useState(false);
  const [readerPage, setReaderPage] = useState(1);
  const [readerZoom, setReaderZoom] = useState(1);
  const [readerTab, setReaderTab] = useState<'model' | 'handbook'>('model');
  const [viewMode, setViewMode] = useState<ViewMode>('paper');
  const [showSummary, setShowSummary] = useState(false);
  
  const svgRef = useRef<SVGSVGElement>(null);

  const currentChapters = useMemo(() => CATEGORY_STRUCTURE[category] || [], [category]);
  const currentChapter = currentChapters[activeChapterIdx] || currentChapters[0];
  const currentModel = currentChapter.models[activeModelIdx] || currentChapter.models[0];
  const availableSizes = useMemo(() => Object.keys(DB[category] || {}), [category]);

  const TOTAL_PAGES = 1200;

  // Sync reader page with current model
  useEffect(() => {
    if (currentModel.pageNumber) {
      setReaderPage(currentModel.pageNumber);
    }
  }, [currentModel]);

  useEffect(() => {
    const defaultSize = availableSizes.includes('42') ? '42' : availableSizes[0] || '';
    if (!availableSizes.includes(size)) {
      setSize(defaultSize);
    }
  }, [category, availableSizes]);

  useEffect(() => {
    if (size && DB[category][size]) {
      setMeasurements({ ...DB[category][size] });
    }
  }, [size, category]);

  const styleConfig: StyleConfig = useMemo(() => ({
    chapter: currentChapter.id as ChapterType,
    model: currentModel.id as ModelType,
    category: category,
    garmentLength: measurements["طول_الجولنة"] || measurements["طول_الظهر"] || 60,
    ease: 1.5
  }), [currentChapter, currentModel, category, measurements]);

  const patternData = useMemo<DrawResult>(() => {
    return draftPattern(styleConfig, measurements);
  }, [styleConfig, measurements]);

  const handleExport = () => {
    if (!svgRef.current) return;
    const serializer = new XMLSerializer();
    const svgString = serializer.serializeToString(svgRef.current);
    const blob = new Blob([svgString], { type: 'image/svg+xml' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Pattern_${category}_${currentModel.id}_Size${size}.svg`;
    link.click();
    URL.revokeObjectURL(url);
  };

  const handlePrint = () => {
    window.print();
  };

  const resetToDefaults = () => {
    if (DB[category][size]) {
      setMeasurements({ ...DB[category][size] });
    }
  };

  // Internal Reader Navigation: Flip through models in the current chapter
  const goToNextModel = () => {
    if (activeModelIdx < currentChapter.models.length - 1) {
      setActiveModelIdx(activeModelIdx + 1);
    } else if (activeChapterIdx < currentChapters.length - 1) {
      setActiveChapterIdx(activeChapterIdx + 1);
      setActiveModelIdx(0);
    }
  };

  const goToPrevModel = () => {
    if (activeModelIdx > 0) {
      setActiveModelIdx(activeModelIdx - 1);
    } else if (activeChapterIdx > 0) {
      const prevIdx = activeChapterIdx - 1;
      setActiveChapterIdx(prevIdx);
      setActiveModelIdx(currentChapters[prevIdx].models.length - 1);
    }
  };

  const renderRefSketch = () => {
    const stroke = "#2d2d2d";
    return (
      <div className="w-full h-full flex items-center justify-center p-4">
        <svg viewBox="0 0 200 280" className="w-full h-full opacity-80 max-h-[400px]">
           {currentChapter.id === 'skirts' ? (
              <g stroke={stroke} fill="none" strokeWidth="1.5">
                <path d="M60 40 L140 40 L155 240 H45 Z" />
                <path d="M100 40 V240" strokeDasharray="3,3" />
                <text x="100" y="265" textAnchor="middle" fontSize="12" fill={stroke} className="font-serif italic font-bold">نموذج تقني: {currentModel.name}</text>
              </g>
           ) : (
              <g stroke={stroke} fill="none" strokeWidth="1.5">
                <path d="M50 40 H150 V240 H50 Z" strokeDasharray="5,5" stroke="#ccc" />
                <path d="M70 40 L130 40 L150 120 H50 Z" />
                <path d="M50 120 V240 H150" />
                <path d="M100 40 V240" strokeDasharray="3,3" />
                <text x="100" y="265" textAnchor="middle" fontSize="12" fill={stroke} className="font-serif italic font-bold">{currentModel.name} ص {readerPage}</text>
              </g>
           )}
        </svg>
      </div>
    );
  };

  const renderHandbook = () => (
    <div className="w-full max-w-4xl mx-auto space-y-16 pb-24 text-right overflow-x-hidden print:p-0">
      <div className="text-center space-y-6 pt-10 print:pt-0">
        <div className="inline-flex items-center gap-4 px-8 py-3 bg-secondary/10 text-secondary rounded-full border border-secondary/20 shadow-sm print:hidden">
           <GraduationCap size={24} />
           <span className="text-sm font-black uppercase tracking-[0.3em]">المجلد الرقمي الكامل</span>
        </div>
        <h2 className="text-4xl sm:text-7xl font-serif font-bold text-slate-800 leading-tight px-4">
          موسوعة فن التفصيل الهندسي
          <span className="block text-2xl sm:text-4xl text-slate-400 mt-4 font-tajawal font-light">خلاصة منهج المهندس فتحي خليل</span>
        </h2>
        <div className="h-2 w-48 bg-gradient-to-r from-transparent via-secondary/40 to-transparent mx-auto rounded-full print:hidden"></div>
      </div>

      <div className="space-y-14 px-4 sm:px-0">
        {ENCYCLOPEDIA_SUMMARY.map((section, idx) => (
          <div key={section.id} className="bg-white/50 backdrop-blur-sm border border-slate-200 rounded-[3rem] p-8 sm:p-16 shadow-lg hover:shadow-2xl transition-all duration-700 overflow-hidden relative group print:shadow-none print:border-none print:bg-transparent print:p-0 print:mb-12">
            <div className="absolute top-0 left-0 w-40 h-40 bg-slate-900/[0.03] -translate-x-20 -translate-y-20 rounded-full group-hover:scale-150 transition-transform duration-1000 print:hidden"></div>
            
            <div className="relative z-10">
              <div className="flex flex-col sm:flex-row items-center gap-8 mb-14 text-center sm:text-right print:mb-6">
                <div className="flex items-center justify-center w-20 h-20 bg-slate-900 text-white rounded-3xl text-4xl font-serif shadow-2xl flex-shrink-0 group-hover:-rotate-3 transition-transform duration-500 ring-8 ring-slate-100 print:ring-0 print:bg-slate-200 print:text-black">
                  {idx + 1}
                </div>
                <div>
                   <h3 className="text-4xl sm:text-5xl font-serif font-bold text-primary leading-tight mb-4">{section.title}</h3>
                   <div className="h-1.5 w-24 bg-secondary/60 rounded-full print:hidden"></div>
                </div>
              </div>

              {section.description && (
                <div className="mb-12 p-10 bg-slate-900 text-white rounded-[2.5rem] font-serif text-xl leading-relaxed text-justify shadow-2xl border border-white/10 group-hover:translate-x-1 transition-transform print:bg-slate-100 print:text-black print:p-6 print:rounded-xl">
                  <span className="text-secondary font-bold text-3xl ml-4 block mb-2 font-tajawal print:text-black">مبدأ المجلد:</span>
                  {section.description}
                </div>
              )}

              {section.subsections && (
                <div className="grid grid-cols-1 gap-12 print:gap-8">
                  {section.subsections.map((sub, sidx) => (
                    <div key={sidx} className="space-y-6 bg-white/80 p-10 rounded-[2.5rem] border border-slate-100 shadow-sm hover:shadow-md hover:border-secondary/20 transition-all group/sub print:p-0 print:border-none print:bg-transparent">
                      <h4 className="text-2xl sm:text-3xl font-bold text-slate-800 flex items-center gap-5 border-b border-slate-50 pb-6 group-hover/sub:text-secondary transition-colors print:pb-2 print:border-slate-300">
                        <div className="w-4 h-4 rounded-full bg-secondary shadow-[0_0_15px_rgba(59,130,246,0.7)] animate-pulse print:hidden"></div>
                        {sub.subtitle}
                      </h4>
                      <div className="text-[18px] sm:text-[20px] text-slate-600 font-serif leading-relaxed text-justify whitespace-pre-wrap pl-2 pr-6 border-r-2 border-slate-100 print:pr-0 print:border-none">
                        {sub.content}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 pb-20 print:hidden">
           <div className="bg-emerald-50/80 backdrop-blur-sm border border-emerald-100 p-12 rounded-[3rem] space-y-8 shadow-xl group hover:-translate-y-2 transition-all">
              <h4 className="text-emerald-900 font-bold flex items-center gap-4 text-3xl">
                <Scissors size={32} className="text-emerald-600" /> ميثاق التنفيذ
              </h4>
              <ul className="text-xl text-emerald-800 font-serif space-y-6 leading-relaxed">
                <li className="flex gap-6"><span className="text-emerald-400 font-bold text-3xl">٠١</span> تجربة الباترون على قماش تجريبي (Muslin) هي القاعدة الذهبية لتفادي خسارة الأقمشة الفاخرة.</li>
                <li className="flex gap-6"><span className="text-emerald-400 font-bold text-3xl">٠٢</span> احترام اتجاه "نسيج القماش" (Grainline) هو الضمان الوحيد لسقوط القطعة بشكل جمالي منسجم.</li>
                <li className="flex gap-6"><span className="text-emerald-400 font-bold text-3xl">٠٣</span> الدقة الهندسية في رسم المنحنيات تفصل بين التفصيل العشوائي والهندسة الاحترافية.</li>
              </ul>
           </div>
           
           <div className="bg-amber-50/80 backdrop-blur-sm border border-amber-100 p-12 rounded-[3rem] space-y-8 shadow-xl group hover:-translate-y-2 transition-all">
              <h4 className="text-amber-900 font-bold flex items-center gap-4 text-3xl">
                <Info size={32} className="text-amber-600" /> إرث فتحي خليل
              </h4>
              <p className="text-xl text-amber-800 font-serif leading-relaxed text-justify italic">
                "إن فن التفصيل ليس مجرد قص للأقمشة، بل هو علم يجمع بين النسب الذهبية للجسم البشري والقدرة على تطويع الخامات لتشكيل لوحات فنية متحركة. التزم بالأساس، تبرع في الموديلات."
              </p>
              <div className="pt-8 border-t border-amber-200 flex justify-between items-center">
                 <div className="space-y-1">
                    <p className="text-xs text-amber-600 font-bold uppercase tracking-[0.3em]">النسخة الرقمية المعتمدة</p>
                    <p className="text-[10px] text-amber-400 font-bold">مجلد المراجعة التقنية ٢٠٢٥</p>
                 </div>
                 <button onClick={handlePrint} className="p-3 bg-amber-200/50 rounded-xl hover:bg-amber-200 transition-colors">
                    <Printer size={24} className="text-amber-600" />
                 </button>
              </div>
           </div>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen h-[100dvh] w-screen bg-slate-100 text-slate-900 overflow-hidden font-tajawal antialiased">
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-50 transition-opacity duration-300" onClick={() => setSidebarOpen(false)} />
      )}

      <aside className={`bg-white border-l border-slate-200 transition-all duration-300 flex flex-col shadow-2xl z-[60] fixed lg:relative h-full print:hidden ${sidebarOpen ? 'w-[85vw] sm:w-80 translate-x-0' : 'w-0 -translate-x-full lg:translate-x-0 lg:w-0 overflow-hidden'}`}>
        <div className="p-6 bg-primary text-white flex-shrink-0 relative overflow-hidden safe-top">
          <div className="absolute top-0 right-0 w-32 h-32 bg-secondary opacity-10 rounded-full -translate-y-16 translate-x-16"></div>
          <div className="flex items-center justify-between mb-6 relative z-10">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-secondary rounded-xl shadow-lg shadow-blue-500/30">
                <BookOpen className="w-6 h-6" />
              </div>
              <h1 className="font-bold text-lg leading-tight">موسوعة المهندس<br/>فتحي خليل</h1>
            </div>
            <button onClick={() => setSidebarOpen(false)} className="lg:hidden p-2 hover:bg-white/10 rounded-lg"><X size={24}/></button>
          </div>
          
          <div className="flex gap-1 bg-white/10 p-1 rounded-xl mb-6 relative z-10">
            {(['women', 'men', 'children'] as Category[]).map(c => (
              <button key={c} onClick={() => setCategory(c)} className={`flex-1 py-2 rounded-lg text-xs transition-all font-bold ${category === c ? 'bg-white text-primary shadow-lg' : 'text-white/60 hover:text-white'}`}>
                {c === 'women' ? 'حريمي' : c === 'men' ? 'رجالي' : 'أطفال'}
              </button>
            ))}
          </div>

          <div className="space-y-3 relative z-10">
            <label className="text-[10px] font-bold text-white/40 uppercase tracking-widest flex items-center gap-2">
              <Hash className="w-3 h-3" /> اختيار المقاس
            </label>
            <div className="flex overflow-x-auto gap-2 pb-3 scrollbar-hide snap-x snap-mandatory">
              {availableSizes.map(s => (
                <button key={s} onClick={() => setSize(s)} className={`flex-shrink-0 min-w-[56px] py-2.5 rounded-xl text-[11px] font-bold transition-all border snap-center ${size === s ? 'bg-secondary border-secondary text-white shadow-lg' : 'bg-white/5 border-white/10 text-white/70 hover:bg-white/10'}`}>
                  {s.replace('سنة ', '')}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 space-y-8 custom-scroll safe-bottom">
          <section>
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
              <Layers size={12} /> فصول الموسوعة
            </h3>
            <div className="space-y-1">
              {currentChapters.map((chapter, idx) => (
                <button 
                  key={idx} 
                  onClick={() => { setActiveChapterIdx(idx); setActiveModelIdx(0); if(window.innerWidth < 1024) setSidebarOpen(false); }} 
                  className={`w-full text-right px-4 py-3 rounded-xl text-xs transition-all border flex items-center justify-between group ${activeChapterIdx === idx ? 'bg-slate-900 text-white border-slate-900 shadow-xl' : 'bg-white border-slate-100 text-slate-600 hover:border-slate-300'}`}
                >
                  <span>{chapter.name}</span>
                  {activeChapterIdx === idx && <div className="w-1.5 h-1.5 rounded-full bg-secondary animate-pulse" />}
                </button>
              ))}
            </div>
          </section>

          <section>
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4 flex items-center gap-2">
              <Scissors size={12} /> النماذج التقنية
            </h3>
            <div className="grid grid-cols-1 gap-2">
              {currentChapter.models.map((m, idx) => (
                <button 
                  key={m.id} 
                  onClick={() => { setActiveModelIdx(idx); if(window.innerWidth < 1024) setSidebarOpen(false); }} 
                  className={`text-right px-4 py-3 rounded-xl text-[11px] transition-all border flex flex-col gap-0.5 ${activeModelIdx === idx ? 'bg-secondary/5 border-secondary text-secondary font-bold' : 'bg-white border-slate-100 text-slate-500 hover:border-slate-200'}`}
                >
                  <span className="truncate">{m.name}</span>
                  <span className="text-[9px] opacity-60">رقم الصفحة: {m.pageNumber}</span>
                </button>
              ))}
            </div>
          </section>

          <section>
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] flex items-center gap-2">
                <Settings size={12} /> جدول القياسات (سم)
              </h3>
              <button onClick={resetToDefaults} className="text-[9px] font-bold text-secondary hover:underline flex items-center gap-1">
                <RefreshCcw size={10} /> استعادة الافتراضي
              </button>
            </div>
            <MeasurementTable measurements={measurements} onChange={(k, v) => setMeasurements(p => ({...p, [k]: v}))} />
          </section>
        </div>
      </aside>

      <main className="flex-1 flex flex-col relative min-w-0 print:overflow-visible print:block print:bg-white">
        <header className="h-16 lg:h-18 bg-white border-b border-slate-200 flex items-center justify-between px-4 sm:px-6 z-40 shadow-sm safe-top print:hidden">
          <div className="flex items-center gap-3 sm:gap-4">
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-500 transition-colors">
              <Menu size={20}/>
            </button>
            <div className="max-w-[120px] sm:max-w-none">
              <h2 className="text-xs sm:text-sm font-bold text-slate-800 leading-tight truncate">{currentModel.name}</h2>
              <span className="text-[9px] sm:text-[10px] text-slate-400 font-bold uppercase tracking-widest truncate block">{currentChapter.name}</span>
            </div>
          </div>
          <div className="flex items-center gap-1.5 sm:gap-3">
            <div className="hidden sm:flex bg-slate-100 p-1 rounded-xl border border-slate-200 mr-2">
              <button onClick={() => setViewMode('paper')} className={`p-1.5 rounded-lg transition-all ${viewMode === 'paper' ? 'bg-white shadow-sm text-secondary' : 'text-slate-400'}`} title="وضع الورق">
                <FileText size={16} />
              </button>
              <button onClick={() => setViewMode('blueprint')} className={`p-1.5 rounded-lg transition-all ${viewMode === 'blueprint' ? 'bg-slate-800 shadow-sm text-blue-400' : 'text-slate-400'}`} title="وضع المخطط التقني">
                <Eye size={16} />
              </button>
            </div>
            <button onClick={() => setShowReader(!showReader)} className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-xl text-xs font-bold transition-all border ${showReader ? 'bg-primary text-white border-primary shadow-lg ring-4 ring-primary/10' : 'bg-white text-slate-600 border-slate-200 hover:bg-slate-50'}`}>
              <BookIcon size={16} />
              <span className="hidden md:inline">موسوعة التفصيل</span>
            </button>
            <div className="hidden sm:block w-px h-6 bg-slate-200 mx-1"></div>
            <button onClick={handleExport} className="p-2 sm:px-5 sm:py-2 bg-secondary text-white rounded-xl text-xs font-bold hover:bg-blue-600 transition-all shadow-lg flex items-center gap-2">
              <Download size={16} />
              <span className="hidden sm:inline">تصدير SVG</span>
            </button>
          </div>
        </header>

        <div className="bg-white border-b border-slate-100 px-4 sm:px-6 py-2 z-10 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-3 sm:gap-4 flex-1">
             <div className="flex items-center gap-2 text-slate-400 shrink-0">
               <Ruler size={14} />
               <span className="hidden sm:inline text-[10px] font-black uppercase tracking-widest">المقاس النشط:</span>
             </div>
             <div className="flex-1 max-w-[280px]">
               <SizeDial sizes={availableSizes} currentSize={size} onSizeChange={setSize} variant="compact" />
             </div>
          </div>
          <button onClick={() => setShowSummary(!showSummary)} className={`p-2 mr-2 rounded-lg text-slate-400 hover:bg-slate-100 transition-all ${showSummary ? 'text-secondary bg-secondary/5' : ''}`}>
             <Info size={18} />
          </button>
        </div>

        <section className="flex-1 relative flex flex-col lg:flex-row overflow-hidden p-3 sm:p-6 gap-6 print:p-0 print:block">
          {showReader && (
            <div className={`${readerFullScreen ? 'fixed inset-0 z-[100]' : 'flex-1'} flex flex-col bg-[#121212] lg:rounded-[3rem] overflow-hidden shadow-2xl border border-white/5 transition-all duration-500 print:block print:bg-white print:static print:shadow-none print:rounded-none`}>
               <div className="h-16 bg-[#1a1a1a] border-b border-white/10 flex items-center justify-between px-4 sm:px-6 text-white/90 safe-top print:hidden">
                  <div className="flex items-center gap-2 sm:gap-4 h-full">
                     <button onClick={() => setReaderTab('model')} className={`h-full px-5 text-xs font-bold flex items-center gap-3 border-b-2 transition-all ${readerTab === 'model' ? 'border-secondary text-secondary bg-secondary/5' : 'border-transparent text-white/40 hover:text-white/60'}`}>
                        <BookMarked size={18} />
                        <span className="hidden sm:inline">شيت الموديل</span>
                        <span className="sm:hidden">الموديل</span>
                     </button>
                     <button onClick={() => setReaderTab('handbook')} className={`h-full px-5 text-xs font-bold flex items-center gap-3 border-b-2 transition-all ${readerTab === 'handbook' ? 'border-secondary text-secondary bg-secondary/5' : 'border-transparent text-white/40 hover:text-white/60'}`}>
                        <GraduationCap size={18} />
                        <span className="hidden sm:inline">موسوعة القواعد</span>
                        <span className="sm:hidden">الموسوعة</span>
                     </button>
                  </div>
                  <div className="flex items-center gap-1 sm:gap-2">
                     <button onClick={() => setReaderFullScreen(!readerFullScreen)} className="p-2 hover:bg-white/10 rounded-xl">
                        {readerFullScreen ? <Minimize2 size={18}/> : <Maximize2 size={18}/>}
                     </button>
                     <div className="h-6 w-px bg-white/10 mx-1 sm:mx-2"></div>
                     <button onClick={() => setShowReader(false)} className="p-2 bg-accent/20 text-accent hover:bg-accent hover:text-white rounded-xl"><X size={18}/></button>
                  </div>
               </div>
               
               <div className="flex-1 relative overflow-auto flex items-start justify-center p-4 sm:p-12 bg-[#0a0a0a] custom-scroll print:p-0 print:bg-white print:block">
                  {readerTab === 'model' ? (
                    <div className="print:block w-full flex flex-col items-center">
                      <div className="flex items-center gap-4 mb-8 print:hidden">
                         <button 
                           onClick={goToPrevModel} 
                           className="group flex items-center gap-3 p-4 bg-white/5 rounded-2xl text-white hover:bg-secondary transition-all"
                         >
                            <ChevronLeft size={24} className="group-hover:-translate-x-1 transition-transform" />
                            <span className="text-xs font-black uppercase tracking-widest hidden sm:inline">الموديل السابق</span>
                         </button>
                         
                         <div className="px-10 py-3 bg-white/10 rounded-2xl border border-white/5 flex items-center gap-4">
                            <BookCopy size={20} className="text-secondary" />
                            <span className="text-white font-bold font-serif text-xl">ص {readerPage}</span>
                         </div>

                         <button 
                           onClick={goToNextModel} 
                           className="group flex items-center gap-3 p-4 bg-white/5 rounded-2xl text-white hover:bg-secondary transition-all"
                         >
                            <span className="text-xs font-black uppercase tracking-widest hidden sm:inline">الموديل التالي</span>
                            <ChevronRight size={24} className="group-hover:translate-x-1 transition-transform" />
                         </button>
                      </div>
                      
                      <div className="relative paper-texture w-full max-w-[850px] shadow-2xl rounded-sm transition-all duration-300 origin-top flex flex-col print:shadow-none print:w-full print:max-w-none print:bg-white" style={{ transform: readerFullScreen ? 'none' : `scale(${readerZoom})`, minHeight: '1100px' }}>
                        <div className="absolute inset-0 p-6 sm:p-16 flex flex-col overflow-y-auto sm:overflow-visible print:relative print:p-0">
                          <div className="flex justify-between items-center border-b-2 border-slate-900/10 pb-4 sm:pb-6 mb-6 sm:mb-10 print:mb-4">
                            <div className="flex items-center gap-3">
                               <div className="w-8 h-8 sm:w-10 sm:h-10 rounded-full bg-primary flex items-center justify-center text-[10px] sm:text-xs text-white font-serif font-bold">FK</div>
                               <div className="flex flex-col">
                                  <span className="text-[8px] sm:text-[10px] font-black text-slate-400 uppercase tracking-widest">شيت الباترون التقني</span>
                                  <span className="text-[8px] sm:text-[9px] font-serif text-slate-500 italic">موسوعة فتحي خليل</span>
                               </div>
                            </div>
                            <div className="bg-slate-900 text-white px-2 py-0.5 sm:px-3 sm:py-1 rounded text-[10px] sm:text-xs font-serif font-bold italic print:bg-slate-200 print:text-black">ص {readerPage}</div>
                          </div>
                          
                          <div className="flex-1 flex flex-col">
                             <h2 className="text-2xl sm:text-5xl font-serif font-bold text-center mb-6 sm:mb-12 text-slate-800 underline decoration-secondary/30 decoration-4 sm:decoration-8 underline-offset-4 sm:underline-offset-8 print:mb-8">
                                {currentModel.name}
                             </h2>
                             
                             <div className="bg-white/40 border border-slate-200 rounded-2xl p-4 sm:p-8 mb-6 sm:mb-12 flex flex-col items-center justify-center min-h-[300px] sm:min-h-[450px] shadow-inner relative overflow-hidden group print:mb-6 print:border-none print:bg-transparent">
                                <div className="absolute top-2 right-4 text-[8px] sm:text-[10px] font-bold text-slate-300 uppercase print:hidden">تخطيط القالب: {currentModel.id}</div>
                                {renderRefSketch()}
                             </div>

                             <div className="grid grid-cols-1 md:grid-cols-2 gap-6 sm:gap-12 border-t border-slate-100 pt-6 sm:pt-10 print:grid-cols-1 print:gap-4 print:pt-4">
                                <div className="space-y-6">
                                   <div className="flex items-center gap-4 border-b border-slate-50 pb-4">
                                      <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center text-white"><List size={20}/></div>
                                      <h4 className="text-xl font-bold text-primary">خطوات التنفيذ الهندسية</h4>
                                   </div>
                                   <div className="text-[14px] sm:text-[16px] font-serif leading-loose text-slate-700 text-right print:text-lg whitespace-pre-wrap">
                                      {TECHNICAL_SHEETS[currentModel.id] || "يتم البدء برسم الخطوط الأفقية الأساسية بناءً على مقاسات المهندس فتحي خليل الموحدة. يرجى التأكد من أن ميل الكتف يتبع المقاييس المذكورة في المجلد الأول. يتم تصريف البنسات وفقاً لهذا الموديل الموضح بالرسم الهندسي."}
                                   </div>
                                </div>
                                
                                <div className="space-y-6">
                                  <div className="bg-slate-900 text-white p-8 rounded-[2rem] border border-white/10 shadow-2xl flex flex-col justify-center h-fit print:bg-white print:text-black print:border-slate-200 print:shadow-none print:p-4">
                                     <div className="flex items-center justify-between mb-6 print:mb-2 border-b border-white/10 pb-4 print:border-slate-200">
                                        <span className="text-xs font-black uppercase tracking-[0.2em] text-secondary">إرشادات الضبط</span>
                                        <Scissors size={18} className="text-secondary print:hidden"/>
                                     </div>
                                     <ul className="text-sm space-y-4 font-serif leading-relaxed print:text-base">
                                        <li className="flex gap-4">
                                          <div className="w-1.5 h-1.5 rounded-full bg-secondary mt-2 shrink-0" />
                                          <p>دقة الرسم الهندسي في مستطيل الأساس هي الضمان الوحيد لنجاح الموديل النهائي.</p>
                                        </li>
                                        <li className="flex gap-4">
                                          <div className="w-1.5 h-1.5 rounded-full bg-secondary mt-2 shrink-0" />
                                          <p>راعِ دائماً إضافة سماحات الخياطة (١-٢ سم) عند القص على القماش.</p>
                                        </li>
                                        <li className="flex gap-4">
                                          <div className="w-1.5 h-1.5 rounded-full bg-secondary mt-2 shrink-0" />
                                          <p>استخدم قماش تجريبي Muslin لاختبار توازن القالب قبل البدء في الأقمشة الفاخرة.</p>
                                        </li>
                                      </ul>
                                  </div>

                                  <div className="bg-secondary/5 border border-secondary/10 p-6 rounded-[2rem] flex flex-col items-center text-center gap-2 print:hidden">
                                     <span className="text-[10px] font-black uppercase tracking-widest text-slate-400">تحميل الشيت</span>
                                     <button onClick={handleExport} className="flex items-center gap-2 text-secondary font-bold text-sm hover:underline">
                                       <Download size={16}/> حفظ الباترون بصيغة SVG
                                     </button>
                                  </div>
                                </div>
                             </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="paper-texture w-full min-h-full p-6 sm:p-20 rounded-sm shadow-2xl overflow-y-auto custom-scroll print:shadow-none print:p-0 print:bg-white print:block">
                      {renderHandbook()}
                    </div>
                  )}
               </div>
            </div>
          )}

          <div className={`${(showReader && !readerFullScreen) ? 'flex-1 hidden lg:flex' : (showReader ? 'hidden' : 'flex-1')} flex flex-col rounded-2xl sm:rounded-3xl shadow-inner border overflow-hidden relative transition-colors duration-500 print:hidden ${viewMode === 'blueprint' ? 'bg-[#0f172a] border-slate-700' : 'bg-white border-slate-200 paper-texture'}`}>
            {viewMode === 'paper' && <div className="absolute inset-0 pattern-grid pointer-events-none opacity-40"></div>}
            
            <div className="absolute top-3 right-3 sm:top-4 sm:right-4 z-10 flex flex-col gap-2 items-end max-w-[150px] sm:max-w-none">
               <div className={`px-2.5 py-1.5 sm:px-4 sm:py-2 rounded-lg sm:rounded-xl text-[8px] sm:text-[10px] font-bold shadow-2xl border flex items-center gap-2 sm:gap-3 backdrop-blur-md transition-colors ${viewMode === 'blueprint' ? 'bg-blue-500/10 text-blue-400 border-blue-500/30' : 'bg-slate-900/90 text-white border-white/10'}`}>
                  <div className={`w-1.5 h-1.5 sm:w-2 sm:h-2 rounded-full animate-ping ${viewMode === 'blueprint' ? 'bg-blue-400' : 'bg-secondary'}`}></div>
                  <span className="truncate">المقاس: {size} - {category === 'women' ? 'حريمي' : category === 'men' ? 'رجالي' : 'أطفال'}</span>
               </div>
               
               {showSummary && patternData.summary && (
                  <div className={`w-36 sm:w-48 p-3 sm:p-4 rounded-xl sm:rounded-2xl border shadow-xl backdrop-blur-lg animate-in fade-in slide-in-from-top-2 transition-colors ${viewMode === 'blueprint' ? 'bg-slate-800/80 border-slate-700 text-slate-300' : 'bg-white/90 border-slate-200 text-slate-600'}`}>
                     <h4 className="text-[8px] sm:text-[9px] font-black uppercase tracking-widest mb-2 sm:mb-3 flex items-center gap-2 opacity-50"><Settings size={10}/> ملخص القالب</h4>
                     <div className="space-y-1.5 sm:space-y-2">
                        {patternData.summary.map(s => (
                           <div key={s.key} className="flex justify-between items-center text-[9px] sm:text-[10px]">
                              <span className="font-medium">{s.key}</span>
                              <span className={`font-bold ${viewMode === 'blueprint' ? 'text-blue-400' : 'text-secondary'}`}>{s.value}</span>
                           </div>
                        ))}
                     </div>
                  </div>
               )}
            </div>

            <div className="flex-1 flex items-center justify-center transition-all duration-700 touch-none" style={{ transform: `scale(${zoom})` }}>
              <svg ref={svgRef} viewBox="0 0 800 1000" className="w-full h-full max-w-[800px] drop-shadow-2xl">
                <g className="pattern-layer">
                  {patternData.paths.map(p => (
                    <path 
                      key={p.id} 
                      d={p.d} 
                      fill={p.fill || "none"} 
                      stroke={viewMode === 'blueprint' 
                        ? (p.type === 'outline' ? '#3b82f6' : (p.type === 'dimension' ? '#475569' : '#1e293b')) 
                        : (p.stroke || "#1e293b")} 
                      strokeWidth={p.type === 'outline' ? 2.5 : 1.2} 
                      strokeDasharray={p.dashArray} 
                      strokeLinecap="round" 
                      className="transition-colors duration-500"
                    />
                  ))}
                  {patternData.labels.map((lbl, idx) => (
                    <text 
                      key={`lbl-${idx}`} 
                      x={lbl.x} 
                      y={lbl.y} 
                      fill={viewMode === 'blueprint' ? '#94a3b8' : (lbl.color || "#64748b")} 
                      fontSize={lbl.fontSize || 11} 
                      fontWeight="bold" 
                      textAnchor="middle" 
                      transform={lbl.angle ? `rotate(${lbl.angle}, ${lbl.x}, ${lbl.y})` : undefined} 
                      className="select-none font-mono tracking-tighter transition-colors duration-500"
                    >
                      {lbl.text}
                    </text>
                  ))}
                </g>
              </svg>
            </div>
            
            <div className="absolute bottom-4 sm:bottom-6 left-1/2 -translate-x-1/2 flex items-center gap-1 sm:gap-2 bg-white/95 backdrop-blur-md p-1.5 sm:p-2 rounded-xl sm:rounded-2xl shadow-2xl border border-slate-200 z-30">
              <button onClick={() => setZoom(z => Math.min(z + 0.1, 3))} className="p-2 sm:p-3 hover:bg-slate-100 rounded-lg sm:rounded-xl text-slate-600 transition-all active:scale-90"><Plus size={18}/></button>
              <div className="w-px h-5 sm:h-6 bg-slate-200 mx-0.5 sm:mx-1"></div>
              <button onClick={() => setZoom(0.7)} className="px-2 sm:px-4 py-1.5 sm:py-2 text-[8px] sm:text-[10px] font-black text-slate-400 hover:text-secondary uppercase">توسيط</button>
              <div className="w-px h-5 sm:h-6 bg-slate-200 mx-0.5 sm:mx-1"></div>
              <button onClick={() => setZoom(z => Math.max(z - 0.1, 0.1))} className="p-2 sm:p-3 hover:bg-slate-100 rounded-lg sm:rounded-xl text-slate-600 transition-all active:scale-90"><Minus size={18}/></button>
              <button onClick={() => setZoom(1.0)} className="p-2 sm:p-3 hover:bg-blue-50 text-secondary rounded-lg sm:rounded-xl transition-all active:rotate-45"><RotateCcw size={18}/></button>
            </div>
          </div>
        </section>

        <footer className="h-8 sm:h-10 bg-white border-t border-slate-200 px-4 sm:px-6 flex items-center justify-between text-[8px] sm:text-[9px] text-slate-400 font-black uppercase tracking-[0.1em] sm:tracking-[0.2em] safe-bottom print:hidden">
          <div className="flex gap-4 sm:gap-8">
            <span className="flex items-center gap-1.5 sm:gap-2"><Ruler size={10} className="text-secondary"/> 1:5</span>
            <span className="flex items-center gap-1.5 sm:gap-2 uppercase"><BookIcon size={10} className="text-secondary"/> ص: {readerPage}</span>
          </div>
          <div className="flex items-center gap-4">
            <div className="hidden sm:flex items-center gap-2 text-emerald-500">
               <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></div>النظام جاهز
            </div>
            <span className="text-slate-300">V.2.6.0</span>
          </div>
        </footer>
      </main>
    </div>
  );
};

export default App;
