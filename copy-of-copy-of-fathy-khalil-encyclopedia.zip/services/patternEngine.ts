
import { Measurements, Point, DrawResult, PatternPath, StyleConfig, PatternLabel } from '../types.js';

export const SCALE = 8; // 1سم = 8 بكسل

const checkIsMen = (cat: string) => cat === 'men';

export const draftPattern = (config: StyleConfig, m: Measurements): DrawResult => {
  const points: Point[] = [];
  const paths: PatternPath[] = [];
  const labels: PatternLabel[] = [];
  const summary: { key: string, value: string }[] = [];
  const center = { x: 350, y: 120 };

  const addPt = (x: number, y: number, label?: string) => {
    const pt = { x, y, label };
    points.push(pt);
    if (label) {
      labels.push({ x, y: y - 10, text: label, fontSize: 14, color: '#1e293b' });
    }
    return pt;
  };

  const addDim = (x1: number, y1: number, x2: number, y2: number, text: string, offset = 30) => {
    const isVertical = Math.abs(x1 - x2) < 1;
    const midX = (x1 + x2) / 2;
    const midY = (y1 + y2) / 2;
    
    let d = "";
    let lx = midX;
    let ly = midY;
    let angle = 0;

    if (isVertical) {
      const dx = x1 - offset;
      d = `M ${dx} ${y1} V ${y2} M ${dx-5} ${y1} H ${dx+5} M ${dx-5} ${y2} H ${dx+5}`;
      lx = dx - 10;
      ly = midY;
      angle = -90;
    } else {
      const dy = y1 - offset;
      d = `M ${x1} ${dy} H ${x2} M ${x1} ${dy-5} V ${dy+5} M ${x2} ${dy-5} V ${dy+5}`;
      lx = midX;
      ly = dy - 10;
      angle = 0;
    }

    paths.push({
      id: `dim-${text}-${Math.random()}`,
      d,
      type: 'dimension',
      stroke: '#94a3b8',
      strokeWidth: 1,
      dashArray: '2,2'
    });

    labels.push({
      x: lx,
      y: ly,
      text: `${text} سم`,
      angle,
      color: '#64748b',
      fontSize: 10
    });
  };

  const bust = m["محيط_الصدر"] || 96;
  const waist = m["محيط_الوسط"] || 76;
  const hip = m["محيط_الهنش"] || 104;
  const backLen = m["طول_الظهر"] || 42;
  const sideLen = m["طول_الجنب"] || 20;
  const shoulderW = m["عرض_الكتف"] || 13;
  const neckCirc = m["محيط_الرقبة"] || 36;
  const sleeveLen = m["طول_الكم"] || 60;
  const totalLen = m["الطول_الكلى"] || 105;
  const jacketLen = m["طول_الجاكيت"] || 75;

  if (config.chapter === 'skirts') {
    const hVal = config.garmentLength || 75;
    const h = hVal * SCALE;
    const sVal = sideLen;
    const s = sVal * SCALE;
    const isCircular = config.model.includes('circular');
    
    if (isCircular) {
      const isFull = config.model.includes('wedding');
      const radius = waist / (isFull ? (2 * Math.PI) : Math.PI);
      const r = radius * SCALE;
      const totalR = r + h;
      
      paths.push({ 
        id: 'waist-arc', 
        d: `M ${center.x - r} ${center.y} A ${r} ${r} 0 0 1 ${center.x + r} ${center.y}`, 
        type: 'outline', strokeWidth: 3 
      });
      paths.push({ 
        id: 'hem-arc', 
        d: `M ${center.x - totalR} ${center.y} A ${totalR} ${totalR} 0 0 1 ${center.x + totalR} ${center.y}`, 
        type: 'outline', strokeWidth: 4 
      });
      paths.push({ id: 'side-l', d: `M ${center.x - r} ${center.y} L ${center.x - totalR} ${center.y}`, type: 'outline' });
      paths.push({ id: 'side-r', d: `M ${center.x + r} ${center.y} L ${center.x + totalR} ${center.y}`, type: 'outline' });
      
      addDim(center.x, center.y, center.x + r, center.y, `نصف القطر: ${radius.toFixed(1)}`, 40);
      addDim(center.x + r, center.y, center.x + totalR, center.y, `الطول: ${hVal}`, 20);
      addPt(center.x, center.y, 'م');
      
      summary.push({ key: 'نصف قطر الوسط', value: `${radius.toFixed(1)} سم` });
      summary.push({ key: 'إجمالي طول القماش', value: `${hVal} سم` });
    } else {
      const wVal = (hip / 4) + 1;
      const w = wVal * SCALE;
      const waistWVal = (waist / 4) + 2.5;
      const waistW = waistWVal * SCALE;
      
      paths.push({ id: 'frame', d: `M ${center.x} ${center.y} H ${center.x + w} V ${center.y + h} H ${center.x} Z`, type: 'technical', stroke: '#cbd5e1', dashArray: '4,4' });
      paths.push({ id: 'waist', d: `M ${center.x} ${center.y} L ${center.x + waistW} ${center.y}`, type: 'outline', strokeWidth: 2 });
      paths.push({ id: 'hip-curve', d: `M ${center.x + waistW} ${center.y} Q ${center.x + w + 12} ${center.y + s/2} ${center.x + w} ${center.y + s}`, type: 'curve', stroke: '#2563eb', strokeWidth: 3 });
      paths.push({ id: 'side', d: `M ${center.x + w} ${center.y + s} V ${center.y + h}`, type: 'outline', strokeWidth: 3 });
      paths.push({ id: 'hem', d: `M ${center.x} ${center.y + h} H ${center.x + w}`, type: 'outline', strokeWidth: 4 });
      paths.push({ id: 'center', d: `M ${center.x} ${center.y} V ${center.y + h}`, type: 'outline' });

      addDim(center.x, center.y, center.x, center.y + h, `الطول: ${hVal}`);
      addDim(center.x, center.y, center.x + waistW, center.y, `الوسط: ${waistWVal.toFixed(1)}`, 20);
      addDim(center.x, center.y + h + 20, center.x + w, center.y + h + 20, `الهنش: ${wVal.toFixed(1)}`, -10);

      const dartX = center.x + (waistW * 0.4);
      paths.push({ id: 'dart', d: `M ${dartX - 1.25*SCALE} ${center.y} L ${dartX} ${center.y + 10*SCALE} L ${dartX + 1.25*SCALE} ${center.y}`, type: 'dart', stroke: '#334155' });

      addPt(center.x, center.y, '1');
      addPt(center.x + waistW, center.y, '2');

      summary.push({ key: 'عرض الربع', value: `${wVal.toFixed(1)} سم` });
      summary.push({ key: 'مقدار التوسيع', value: `١ سم` });
    }
  } else if (['bodice', 'blouses', 'dresses', 'outerwear', 'home', 'children'].includes(config.chapter)) {
    const isMen = checkIsMen(config.category);
    const isChild = config.category === 'children';
    const ease = isMen ? 6 : (isChild ? 4 : 2);
    
    const wVal = (bust / 4) + ease;
    const w = wVal * SCALE;
    const hVal = (config.chapter === 'dresses' ? totalLen : (config.chapter === 'outerwear' ? jacketLen : backLen));
    const h = hVal * SCALE;
    const armDepthVal = (backLen / 2 + (isMen ? 4 : 2));
    const armDepth = armDepthVal * SCALE;
    const nwVal = (neckCirc / (isMen ? 6 : 5));
    const nw = nwVal * SCALE;
    const sw = shoulderW * SCALE;
    
    paths.push({ id: 'frame', d: `M ${center.x} ${center.y} H ${center.x + w} V ${center.y + h} H ${center.x} Z`, type: 'technical', stroke: '#e2e8f0', dashArray: '2,2' });
    paths.push({ id: 'neck', d: `M ${center.x} ${center.y + 2*SCALE} Q ${center.x} ${center.y} ${center.x + nw} ${center.y}`, type: 'outline', strokeWidth: 2.5 });
    
    if (config.model.includes('japanese')) {
      paths.push({ id: 'jap-shoulder', d: `M ${center.x + nw} ${center.y} L ${center.x + nw + sw + 25*SCALE} ${center.y + 10*SCALE} L ${center.x + nw + sw + 23*SCALE} ${center.y + 20*SCALE} Q ${center.x + w} ${center.y + armDepth + 8*SCALE} ${center.x + w} ${center.y + armDepth}`, type: 'outline', stroke: '#1e293b', strokeWidth: 3 });
    } else {
      paths.push({ id: 'shoulder', d: `M ${center.x + nw} ${center.y} L ${center.x + nw + sw} ${center.y + 4.5*SCALE}`, type: 'outline', strokeWidth: 2 });
      paths.push({ id: 'armhole', d: `M ${center.x + nw + sw} ${center.y + 4.5*SCALE} Q ${center.x + w} ${center.y + armDepth/2} ${center.x + w} ${center.y + armDepth}`, type: 'curve', stroke: '#ef4444', strokeWidth: 3 });
    }

    addDim(center.x, center.y, center.x + w, center.y, `عرض البناء: ${wVal.toFixed(1)}`);
    addDim(center.x, center.y, center.x, center.y + h, `الطول: ${hVal}`);
    addDim(center.x + w, center.y, center.x + w, center.y + armDepth, `حردة الإبط: ${armDepthVal.toFixed(1)}`, -30);

    const expansion = config.model.includes('wide') || config.model.includes('abaya') ? 20*SCALE : 0;
    paths.push({ id: 'side', d: `M ${center.x + w} ${center.y + armDepth} L ${center.x + w + expansion} ${center.y + h}`, type: 'outline', strokeWidth: 2.5 });
    paths.push({ id: 'center', d: `M ${center.x} ${center.y + 2*SCALE} V ${center.y + h}`, type: 'outline', strokeWidth: 2.5 });
    paths.push({ id: 'hem', d: `M ${center.x} ${center.y + h} L ${center.x + w + expansion} ${center.y + h}`, type: 'outline', strokeWidth: 4 });

    addPt(center.x, center.y, 'أ');
    addPt(center.x + nw, center.y, 'ب');
    addPt(center.x + nw + sw, center.y + 4.5*SCALE, 'ج');

    summary.push({ key: 'عمق الإبط', value: `${armDepthVal.toFixed(1)} سم` });
    summary.push({ key: 'براح الجسم', value: `${ease} سم` });
  } else if (config.chapter === 'trousers' || config.model.includes('pants')) {
    const isMen = checkIsMen(config.category);
    const hwVal = (hip / 4) + (isMen ? 2.5 : 1.5);
    const hw = hwVal * SCALE;
    const cdVal = (hip / 4) + (isMen ? 4 : 2);
    const cd = cdVal * SCALE; 
    const legLVal = (m["الطول_الكلى"] || totalLen);
    const legL = legLVal * SCALE;
    const ext = (hip / (isMen ? 10 : 16)) * SCALE;

    paths.push({ id: 'construction', d: `M ${center.x} ${center.y} H ${center.x + hw} V ${center.y + legL} H ${center.x} Z`, type: 'technical', stroke: '#cbd5e1', dashArray: '2,2' });
    paths.push({ id: 'waist', d: `M ${center.x} ${center.y} H ${center.x + hw}`, type: 'outline', strokeWidth: 2.5 });
    paths.push({ id: 'crotch', d: `M ${center.x + hw} ${center.y} Q ${center.x + hw} ${center.y + cd} ${center.x + hw + ext} ${center.y + cd}`, type: 'curve', stroke: '#ef4444', strokeWidth: 3 });
    paths.push({ id: 'inner', d: `M ${center.x + hw + ext} ${center.y + cd} L ${center.x + hw - 5*SCALE} ${center.y + legL}`, type: 'outline', strokeWidth: 2 });
    paths.push({ id: 'outer', d: `M ${center.x} ${center.y} V ${center.y + legL}`, type: 'outline', strokeWidth: 2 });
    paths.push({ id: 'hem', d: `M ${center.x} ${center.y + legL} H ${center.x + hw - 5*SCALE}`, type: 'outline', strokeWidth: 4 });

    addDim(center.x, center.y, center.x + hw, center.y, `عرض الهنش: ${hwVal.toFixed(1)}`);
    addDim(center.x, center.y, center.x, center.y + legL, `الطول: ${legLVal}`);
    addDim(center.x + hw, center.y, center.x + hw, center.y + cd, `طول الحجر: ${cdVal.toFixed(1)}`, -20);

    addPt(center.x + hw, center.y + cd, 'ج');
    summary.push({ key: 'نزول الحجر', value: `${cdVal.toFixed(1)} سم` });
    summary.push({ key: 'بروز الحجر', value: `${(ext/SCALE).toFixed(1)} سم` });
  } else if (config.chapter === 'sleeves' || config.model.includes('sleeve')) {
    const isMen = checkIsMen(config.category);
    const swVal = (bust / 3);
    const sw = swVal * SCALE;
    const headHVal = (bust / 10 + (isMen ? 3.5 : 2.5));
    const headH = headHVal * SCALE;
    const slVal = sleeveLen;
    const sl = slVal * SCALE;

    paths.push({ id: 'cap', d: `M ${center.x - sw/2} ${center.y + headH} Q ${center.x} ${center.y - 8*SCALE} ${center.x + sw/2} ${center.y + headH}`, type: 'curve', stroke: '#ef4444', strokeWidth: 3 });
    paths.push({ id: 'side-l', d: `M ${center.x - sw/2} ${center.y + headH} L ${center.x - 9*SCALE} ${center.y + sl}`, type: 'outline', strokeWidth: 2 });
    paths.push({ id: 'side-r', d: `M ${center.x + sw/2} ${center.y + headH} L ${center.x + 9*SCALE} ${center.y + sl}`, type: 'outline', strokeWidth: 2 });
    paths.push({ id: 'cuff', d: `M ${center.x - 9*SCALE} ${center.y + sl} H ${center.x + 9*SCALE}`, type: 'outline', strokeWidth: 4 });

    addDim(center.x - sw/2, center.y + headH, center.x + sw/2, center.y + headH, `عرض الكم: ${swVal.toFixed(1)}`, 20);
    addDim(center.x, center.y, center.x, center.y + sl, `طول الكم: ${slVal}`, 80);

    addPt(center.x, center.y, 'س');
    summary.push({ key: 'ارتفاع رأس الكم', value: `${headHVal.toFixed(1)} سم` });
  }

  if (paths.length === 0) {
    paths.push({ id: 'error-placeholder', d: `M ${center.x} ${center.y} L ${center.x + 100} ${center.y + 100}`, type: 'technical', stroke: '#cbd5e1' });
  }

  return { points, paths, labels, summary };
};
