import React, { useRef, useEffect, useState } from 'react';

interface SizeDialProps {
  sizes: string[];
  currentSize: string;
  onSizeChange: (size: string) => void;
  variant?: 'full' | 'compact';
}

const SizeDial: React.FC<SizeDialProps> = ({ sizes, currentSize, onSizeChange, variant = 'full' }) => {
  const scrollRef = useRef<HTMLDivElement>(null);
  const isProgrammaticScroll = useRef(false);
  const scrollTimeout = useRef<number | null>(null);

  // When external size changes, scroll to it without triggering onSizeChange
  useEffect(() => {
    if (scrollRef.current) {
      const activeElement = scrollRef.current.querySelector(`[data-size="${currentSize}"]`);
      if (activeElement) {
        isProgrammaticScroll.current = true;
        activeElement.scrollIntoView({ behavior: 'smooth', block: 'nearest', inline: 'center' });
        
        // Reset the flag after animation finishes
        if (scrollTimeout.current) window.clearTimeout(scrollTimeout.current);
        scrollTimeout.current = window.setTimeout(() => {
          isProgrammaticScroll.current = false;
        }, 600); 
      }
    }
  }, [currentSize]);

  const handleScroll = () => {
    // If scrolling was triggered programmatically (by useEffect), ignore it
    if (isProgrammaticScroll.current || !scrollRef.current) return;
    
    const container = scrollRef.current;
    const children = container.querySelectorAll('.dial-item');
    let closestSize = sizes[0];
    let minDistance = Infinity;

    const containerRect = container.getBoundingClientRect();
    const containerCenterX = containerRect.left + containerRect.width / 2;

    children.forEach((child) => {
      const rect = (child as HTMLElement).getBoundingClientRect();
      const childCenter = rect.left + rect.width / 2;
      const distance = Math.abs(childCenter - containerCenterX);
      
      if (distance < minDistance) {
        minDistance = distance;
        closestSize = (child as HTMLElement).dataset.size || sizes[0];
      }
    });

    if (closestSize !== currentSize) {
      onSizeChange(closestSize);
    }
  };

  const isCompact = variant === 'compact';

  return (
    <div className={`relative w-full ${isCompact ? 'h-14 bg-slate-100/50' : 'h-24 bg-primary/20'} rounded-2xl border ${isCompact ? 'border-slate-200' : 'border-white/10'} overflow-hidden shadow-inner group`}>
      {/* Decorative Gradients */}
      <div className={`absolute inset-y-0 left-0 w-16 bg-gradient-to-r ${isCompact ? 'from-white/90' : 'from-primary/50'} to-transparent z-10 pointer-events-none`} />
      <div className={`absolute inset-y-0 right-0 w-16 bg-gradient-to-l ${isCompact ? 'from-white/90' : 'from-primary/50'} to-transparent z-10 pointer-events-none`} />
      
      {/* Selection Needle */}
      <div className={`absolute top-0 left-1/2 -translate-x-1/2 w-0.5 h-full ${isCompact ? 'bg-secondary' : 'bg-secondary shadow-[0_0_15px_rgba(52,152,219,0.5)]'} z-20 pointer-events-none`}>
        <div className={`absolute top-0 left-1/2 -translate-x-1/2 w-2 h-2 bg-secondary rounded-full`} />
        <div className={`absolute bottom-0 left-1/2 -translate-x-1/2 w-2 h-2 bg-secondary rounded-full`} />
      </div>

      {/* Dial Scroll Area */}
      <div 
        ref={scrollRef}
        onScroll={handleScroll}
        className="flex items-center h-full overflow-x-auto scrollbar-none snap-x snap-mandatory px-[48%] touch-pan-x"
        style={{ scrollBehavior: 'smooth' }}
      >
        {sizes.map((s) => {
          const isActive = s === currentSize;
          const label = s.replace('سنة ', '');
          
          return (
            <div 
              key={s}
              data-size={s}
              onClick={() => {
                isProgrammaticScroll.current = false; // Allow manual click to update
                onSizeChange(s);
              }}
              className={`dial-item flex-shrink-0 ${isCompact ? 'w-12' : 'w-16'} flex flex-col items-center justify-center snap-center cursor-pointer transition-all duration-300`}
            >
              <div className={`font-black transition-all duration-300 ${isCompact ? 'text-[11px]' : 'text-sm'} ${isActive ? 'text-secondary scale-150' : (isCompact ? 'text-slate-400' : 'text-white/40')} scale-100`}>
                {label}
              </div>
              
              {/* Tick Marks */}
              <div className={`flex items-end gap-1 mt-1 ${isCompact ? 'h-3' : 'h-6'}`}>
                <div className={`w-0.5 transition-all duration-300 ${isActive ? (isCompact ? 'h-3 bg-secondary' : 'h-6 bg-secondary') : (isCompact ? 'h-1.5 bg-slate-200' : 'h-3 bg-white/20')}`} />
                <div className={`w-0.5 h-1 bg-slate-200 ${isCompact ? 'hidden' : 'block opacity-20'}`} />
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SizeDial;