
import React, { useState, useMemo } from 'react';
import { GarmentSize, Variations, MarkerLayout } from '../types';
import { calculateMarkerLayout, cmToPx, ADULT_SIZES, CHILD_SIZES, computePatternDimensions, getSizeMeasurements } from '../services/patternLogic';

interface ProductionStudioProps {
  variations: Variations;
}

const ProductionStudio: React.FC<ProductionStudioProps> = ({ variations }) => {
  const [fabricWidth, setFabricWidth] = useState(150);
  const [orders, setOrders] = useState<Array<{size: string, quantity: number, category: 'adult' | 'child'}>>([
    { size: 'M', quantity: 2, category: 'adult' },
    { size: 'L', quantity: 2, category: 'adult' },
  ]);

  const marker = useMemo(() => calculateMarkerLayout(orders, variations, fabricWidth), [orders, variations, fabricWidth]);

  const downloadTechPack = () => {
    const techPackData = {
      timestamp: new Date().toISOString(),
      fabricWidth,
      totalLength: marker.totalLength,
      efficiency: marker.efficiency,
      pieces: marker.pieces.map(p => ({ label: p.label, x: p.x, y: p.y, w: p.width, h: p.height })),
      readme: `
TECH PACK: STITCHCRAFT PRODUCTION
==================================
Case: Production Run ${new Date().toLocaleDateString()}
Fabric Width: ${fabricWidth} cm
Total Length Required: ${(marker.totalLength/100).toFixed(2)} m
Nesting Efficiency: ${marker.efficiency.toFixed(1)}%

PRINTING INSTRUCTIONS:
- Use the provided SVG for 1:1 scale plotter printing.
- For A4 tiled printing, use the PDF export (if available).
- Import the points JSON for custom CAD adjustments.
      `
    };

    const blob = new Blob([JSON.stringify(techPackData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `techpack-${fabricWidth}cm.json`;
    link.click();
  };

  const updateQty = (size: string, category: 'adult' | 'child', val: number) => {
    setOrders(prev => {
      const idx = prev.findIndex(o => o.size === size && o.category === category);
      if (idx > -1) {
        const next = [...prev];
        next[idx] = { ...next[idx], quantity: Math.max(0, val) };
        return next;
      }
      return [...prev, { size, quantity: val, category }];
    });
  };

  return (
    <div className="space-y-10 pb-20 animate-in fade-in duration-700">
      <div className="bg-white p-8 rounded-[3rem] shadow-2xl border border-slate-100">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-10 gap-6">
          <h3 className="text-2xl font-black text-slate-900 flex items-center gap-3">
            <span className="w-3 h-10 bg-emerald-600 rounded-full"></span>
            استوديو الإنتاج الصناعي (Marker Studio)
          </h3>
          <div className="flex gap-4">
             <button onClick={downloadTechPack} className="px-6 py-3 bg-blue-600 text-white font-black rounded-2xl text-xs hover:bg-blue-700 transition-all shadow-xl">تصدير Tech Pack</button>
             <button className="px-6 py-3 bg-slate-900 text-white font-black rounded-2xl text-xs hover:bg-blue-600 transition-all shadow-xl">تصدير Marker SVG</button>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-12">
           <div className="bg-slate-50 p-6 rounded-[2rem] border border-slate-100">
             <h4 className="text-xs font-black text-slate-400 uppercase tracking-widest mb-6">طلبية المقاسات</h4>
             <div className="grid grid-cols-4 gap-4">
               {['XS', 'S', 'M', 'L', 'XL'].map(s => (
                 <div key={s} className="bg-white p-3 rounded-2xl shadow-sm">
                   <p className="text-[10px] font-black mb-2 text-center">{s}</p>
                   <input 
                    type="number" 
                    value={orders.find(o => o.size === s)?.quantity || 0} 
                    onChange={(e) => updateQty(s, 'adult', parseInt(e.target.value) || 0)}
                    className="w-full text-center text-xs font-black border-none focus:ring-0"
                   />
                 </div>
               ))}
             </div>
           </div>

           <div className="grid grid-cols-2 gap-6">
              <div className="bg-indigo-600 p-6 rounded-[2rem] text-white">
                 <p className="text-[10px] font-black opacity-70 mb-1">كفاءة الرص (Nesting)</p>
                 <p className="text-4xl font-black">{marker.efficiency.toFixed(1)}%</p>
              </div>
              <div className="bg-slate-900 p-6 rounded-[2rem] text-white">
                 <p className="text-[10px] font-black opacity-70 mb-1">طول الماركر</p>
                 <p className="text-4xl font-black">{(marker.totalLength/100).toFixed(2)} م</p>
              </div>
           </div>
        </div>

        <div className="relative bg-slate-50 rounded-[3.5rem] border border-slate-200 overflow-auto p-12 shadow-inner">
           <svg 
            width={cmToPx(fabricWidth)} 
            height={cmToPx(marker.totalLength)} 
            viewBox={`0 0 ${cmToPx(fabricWidth)} ${cmToPx(marker.totalLength)}`}
            className="bg-white shadow-2xl mx-auto border border-slate-200"
           >
            {marker.pieces.map((p, idx) => (
              <g key={idx} transform={`translate(${cmToPx(p.x)}, ${cmToPx(p.y)})`}>
                <path d={p.path} fill={p.type === 'front' ? '#dcfce7' : '#dbeafe'} stroke="#1e293b" strokeWidth="1" />
                <text x="5" y="15" fontSize="8" fontWeight="black" fill="#334155">{p.label}</text>
              </g>
            ))}
           </svg>
        </div>
      </div>
    </div>
  );
};

export default ProductionStudio;
