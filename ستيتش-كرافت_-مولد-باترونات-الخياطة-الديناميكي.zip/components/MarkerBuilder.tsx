
import React, { useState, useMemo } from 'react';
import { GarmentSize, Variations, MarkerLayout } from '../types';
import { calculateMarkerLayout, cmToPx } from '../services/patternLogic';

interface MarkerBuilderProps {
  variations: Variations;
}

const MarkerBuilder: React.FC<MarkerBuilderProps> = ({ variations }) => {
  const [fabricWidth, setFabricWidth] = useState(150);
  const [orientation, setOrientation] = useState<'portrait' | 'landscape'>('portrait');
  const [orders, setOrders] = useState<Array<{size: string, quantity: number, category: 'adult' | 'child'}>>([
    { size: 'S', quantity: 0, category: 'adult' },
    { size: 'M', quantity: 1, category: 'adult' },
    { size: 'L', quantity: 1, category: 'adult' },
    { size: 'XL', quantity: 0, category: 'adult' },
  ]);
  const [isProcessing, setIsProcessing] = useState(false);

  const marker = useMemo(() => calculateMarkerLayout(orders, variations, fabricWidth), [orders, variations, fabricWidth]);

  const runNesting = () => {
    setIsProcessing(true);
    setTimeout(() => setIsProcessing(false), 1200);
  };

  const updateQty = (size: string, category: 'adult' | 'child', val: number) => {
    setOrders(prev => {
      const idx = prev.findIndex(o => o.size === size && o.category === category);
      if (idx > -1) {
        const next = [...prev];
        next[idx] = { ...next[idx], quantity: Math.max(0, val) };
        return next;
      }
      return [...prev, { size, quantity: val, category }];
    });
  };

  return (
    <div className="space-y-6 pb-24 animate-in fade-in slide-in-from-right-4 duration-700">
      <div className="bg-surface p-md rounded-card shadow-card border border-muted">
        <div className="flex flex-col gap-2 mb-lg">
          <h2 className="text-textPrimary flex items-center gap-sm">
            <span className="w-1 h-6 bg-accent rounded-pill"></span>
            باني الماركر (Marker Builder)
          </h2>
          <p className="small-text text-textSecondary font-medium">تحديد الكميات وإعدادات رص قطع الباترون</p>
        </div>

        <div className="space-y-lg">
          {/* Fabric Settings */}
          <div className="bg-background p-md rounded-card border border-muted">
            <label className="block text-[10px] font-bold text-textSecondary mb-4 uppercase tracking-widest px-1">إعدادات القماش (cm)</label>
            <div className="flex items-center gap-md">
               <input 
                type="range" 
                min="90" max="180" step="5"
                value={fabricWidth}
                onChange={(e) => setFabricWidth(parseInt(e.target.value))}
                className="flex-1 accent-primary h-1.5 rounded-pill cursor-pointer"
               />
               <span className="text-sm font-black text-primary w-14 text-center bg-surface border border-muted rounded py-1">{fabricWidth}</span>
            </div>
          </div>

          {/* Orientation & Spacing */}
          <div className="grid grid-cols-2 gap-md">
             <div className="bg-background p-md rounded-card border border-muted">
                <label className="block text-[10px] font-bold text-textSecondary mb-2 uppercase tracking-widest">الاتجاه</label>
                <select 
                  className="w-full bg-surface border-none rounded small-text font-bold p-1 focus:ring-1 focus:ring-primary"
                  value={orientation}
                  onChange={(e) => setOrientation(e.target.value as any)}
                >
                  <option value="portrait">طولي</option>
                  <option value="landscape">عرضي</option>
                </select>
             </div>
             <div className="bg-background p-md rounded-card border border-muted">
                <label className="block text-[10px] font-bold text-textSecondary mb-2 uppercase tracking-widest">المسافات</label>
                <div className="flex items-center gap-1">
                   <span className="small-text font-bold">1.5 سم</span>
                </div>
             </div>
          </div>

          {/* Quantities */}
          <div className="bg-background p-md rounded-card border border-muted">
             <label className="block text-[10px] font-bold text-textSecondary mb-4 uppercase tracking-widest">اختيار المقاسات والكميات</label>
             <div className="grid grid-cols-4 gap-sm">
               {orders.map(o => (
                 <div key={o.size} className={`bg-surface p-2 rounded-lg shadow-sm border transition-all flex flex-col items-center gap-1 ${o.quantity > 0 ? 'border-primary/40' : 'border-muted'}`}>
                   <span className="text-[10px] font-black text-textPrimary">{o.size}</span>
                   <input 
                    type="number" 
                    value={o.quantity} 
                    onChange={(e) => updateQty(o.size, o.category, parseInt(e.target.value) || 0)}
                    className="w-full text-center text-xs font-black border-none focus:ring-0 p-0"
                   />
                 </div>
               ))}
             </div>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 gap-md">
             <div className="bg-primary/5 p-md rounded-card border border-primary/10">
                <p className="text-[10px] font-bold text-primary uppercase mb-1">الكفاءة (Optimized)</p>
                <p className="text-xl font-black text-primary">{marker.efficiency.toFixed(1)}%</p>
             </div>
             <div className="bg-textPrimary p-md rounded-card border border-textPrimary shadow-sm">
                <p className="text-[10px] font-bold text-muted uppercase mb-1">طول القماش</p>
                <p className="text-xl font-black text-white">{(marker.totalLength/100).toFixed(2)} م</p>
             </div>
          </div>

          <button 
            onClick={runNesting}
            disabled={isProcessing}
            className="w-full bg-primary text-white py-lg rounded-card font-bold body-text shadow-elevated active:scale-95 transition-all flex items-center justify-center gap-md disabled:opacity-50 touch-target"
          >
            {isProcessing ? (
              <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-pill animate-spin"></div>
            ) : 'Run Nesting'}
          </button>
        </div>

        {/* Visual Preview */}
        <div className="mt-lg relative bg-background rounded-card border border-muted overflow-hidden min-h-[300px] flex items-center justify-center shadow-inner">
           <svg 
            width="100%"
            height="100%"
            viewBox={`0 0 ${cmToPx(fabricWidth)} ${cmToPx(marker.totalLength)}`}
            className="bg-surface shadow-card mx-auto"
           >
            {marker.pieces.map((p, idx) => (
              <g key={idx} transform={`translate(${cmToPx(p.x)}, ${cmToPx(p.y)})`}>
                <path d={p.path} fill={p.type === 'front' ? '#E7F5EF' : '#EBF2FE'} stroke="#0B6E4F" strokeWidth="0.5" opacity="0.8" />
                <text x="2" y="10" fontSize="5" fontWeight="900" fill="#0B6E4F" className="opacity-40">{p.label}</text>
              </g>
            ))}
           </svg>
        </div>

        {/* Export Options */}
        <div className="mt-md flex flex-col gap-sm">
           <div className="grid grid-cols-2 gap-sm">
             <button className="h-11 bg-muted text-textPrimary small-text font-bold rounded-button btn-press touch-target">Export PDF (A4)</button>
             <button className="h-11 bg-muted text-textPrimary small-text font-bold rounded-button btn-press touch-target">Export DXF</button>
           </div>
           <button className="h-12 bg-textPrimary text-white body-text font-bold rounded-button shadow-card btn-press touch-target">Export PDF (A0)</button>
        </div>
      </div>
    </div>
  );
};

export default MarkerBuilder;
