
import React from 'react';

interface DashboardProps {
  onNavigate: (tab: any, params?: any) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate }) => {
  const categories = [
    { id: 'adult', title: 'الأزياء الحريمي', desc: 'جونلات، بلوزات، فساتين برنسيس', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z', color: 'bg-primary' },
    { id: 'men', title: 'الأزياء الرجالي', desc: 'قمصان، بيجامات، أرواب شامبر', icon: 'M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z', color: 'bg-slate-800' },
    { id: 'child', title: 'ملابس الأطفال', desc: 'من سن 2 إلى 16 سنة', icon: 'M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z', color: 'bg-accent' },
  ];

  const models = [
    { name: 'الجونلة العادية', cat: 'حريمي', page: 'ص 14' },
    { name: 'القميص الرجالي', cat: 'رجالي', page: 'ص 273' },
    { name: 'فستان طفلة', cat: 'أطفال', page: 'ص 1062' },
    { name: 'الكورساج الأساسي', cat: 'أساسيات', page: 'ص 134' },
  ];

  return (
    <div className="space-y-lg page-fade-in pb-24">
      <div className="space-y-md px-1">
        <h2 className="text-textPrimary font-black text-xl">قوائم الموديلات</h2>
        <div className="grid grid-cols-1 gap-md">
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => onNavigate('sizes', { category: cat.id })}
              className="flex items-center gap-md p-md bg-surface border border-muted rounded-card shadow-card hover:shadow-elevated transition-all group text-right btn-press card-hover"
            >
              <div className={`${cat.color} w-14 h-14 rounded-2xl flex items-center justify-center text-white shadow-lg`}>
                <svg className="w-7 h-7" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d={cat.icon} />
                </svg>
              </div>
              <div className="flex-1">
                <h4 className="body-text font-bold text-textPrimary">{cat.title}</h4>
                <p className="small-text text-textSecondary">{cat.desc}</p>
              </div>
              <svg className="w-5 h-5 text-muted group-hover:text-primary transition-colors" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"/></svg>
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-md px-1">
        <div className="flex justify-between items-center px-1">
          <h2 className="text-textPrimary font-bold">نماذج من الموسوعة</h2>
          <span className="small-text text-primary font-bold">عرض الكل</span>
        </div>
        <div className="grid grid-cols-2 gap-sm">
          {models.map((mod, i) => (
            <div key={i} className="bg-white p-md rounded-card border border-muted shadow-card flex flex-col gap-1">
              <span className="text-[10px] font-black text-accent uppercase tracking-widest">{mod.cat}</span>
              <p className="small-text font-bold text-textPrimary">{mod.name}</p>
              <p className="text-[9px] text-textSecondary opacity-60 font-bold">{mod.page}</p>
            </div>
          ))}
        </div>
      </div>

      <button 
        onClick={() => onNavigate('pattern')}
        className="fixed bottom-24 left-6 w-16 h-16 bg-primary text-white rounded-pill shadow-elevated flex items-center justify-center btn-press z-50 transition-transform hover:scale-105 active:scale-95"
      >
        <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 6v6m0 0v6m0-6h6m-6 0H6"/></svg>
      </button>
    </div>
  );
};

export default Dashboard;
