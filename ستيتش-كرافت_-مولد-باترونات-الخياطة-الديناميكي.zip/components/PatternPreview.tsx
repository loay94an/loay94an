
import React, { useState } from 'react';
import { PatternDimensions, Point, Measurements, Variations } from '../types';
import { cmToPx } from '../services/patternLogic';
import MockupPreview from './MockupPreview';

interface PatternPreviewProps {
  dims: PatternDimensions;
  seamAllowance: number;
  measurements: Measurements;
  variations: Variations;
}

const PatternPreview: React.FC<PatternPreviewProps> = ({ dims, seamAllowance, measurements, variations }) => {
  const [activePiece, setActivePiece] = useState<'front' | 'back' | 'sleeve'>('front');
  const [viewMode, setViewMode] = useState<'preview' | 'steps' | 'mockup'>('preview');
  const [showRefPoints, setShowRefPoints] = useState(true);
  const [showSeam, setShowSeam] = useState(false);
  const [showGrid, setShowGrid] = useState(false);
  const [zoom, setZoom] = useState(1);
  
  const padding = 20;
  const currentPiece = dims[activePiece];

  const downloadSVG = () => {
    const svgData = document.getElementById('main-pattern-svg')?.outerHTML;
    if (!svgData) return;
    const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `stitchcraft-${activePiece}-${dims.sizeLabel}.svg`;
    link.click();
  };

  return (
    <div className="bg-surface p-md rounded-card shadow-card border border-muted flex flex-col gap-md animate-in fade-in duration-500">
      <div className="flex border-b border-muted">
          {(['preview', 'steps', 'mockup'] as const).map(mode => (
             <button
              key={mode}
              onClick={() => setViewMode(mode)}
              className={`flex-1 flex flex-col items-center gap-xs py-2 transition-colors ${viewMode === mode ? 'text-primary' : 'text-textSecondary opacity-60'}`}
             >
               <span className="text-[10px] font-black uppercase tracking-widest">{mode === 'preview' ? 'المعاينة' : mode === 'steps' ? 'خطوات الرسم' : 'المحاكاة'}</span>
               {viewMode === mode && <div className="w-full h-0.5 bg-primary mt-1"></div>}
             </button>
          ))}
      </div>

      {viewMode === 'mockup' ? (
        <MockupPreview measurements={measurements} variations={variations} />
      ) : viewMode === 'steps' ? (
        <div className="space-y-4 p-4 text-right">
          <h3 className="body-text font-bold text-primary mb-4 flex items-center gap-2">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253"/></svg>
            قواعد الرسم الهندسي (الموسوعة)
          </h3>
          <div className="space-y-3">
            {currentPiece.steps.map((step, i) => (
              <div key={i} className="flex gap-4 items-start p-4 bg-background rounded-xl border border-muted shadow-sm transition-all hover:border-primary/30 group">
                <span className="bg-primary/10 text-primary w-8 h-8 rounded-full flex items-center justify-center text-sm font-black flex-shrink-0 group-hover:bg-primary group-hover:text-white transition-colors">{i+1}</span>
                <p className="small-text text-textPrimary leading-relaxed font-bold py-1">{step}</p>
              </div>
            ))}
          </div>
          <div className="mt-8 p-4 bg-amber-50 rounded-xl border border-amber-100">
             <p className="text-[11px] text-amber-700 font-bold leading-relaxed">تحذير: يجب مراعاة دقة الميليمتر عند الرسم اليدوي على الورق لضمان مطابقة قطع الباترون عند الخياطة.</p>
          </div>
        </div>
      ) : (
        <>
          <div className="flex flex-col gap-sm">
            <div className="flex p-xs bg-background rounded-lg">
              {(['front', 'back', 'sleeve'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActivePiece(tab)}
                  className={`flex-1 py-sm small-text font-bold rounded-lg transition-all ${activePiece === tab ? 'bg-surface shadow-sm text-primary' : 'text-textSecondary'}`}
                >
                  {tab === 'front' ? 'الصدر' : tab === 'back' ? 'الظهر' : 'الكم'}
                </button>
              ))}
            </div>
          </div>

          <div className="relative bg-background rounded-card border border-muted overflow-hidden min-h-[450px] flex items-center justify-center shadow-inner group">
            <div className="absolute top-md left-md z-10 flex flex-col gap-xs transition-opacity opacity-0 group-hover:opacity-100">
               <button onClick={() => setZoom(prev => Math.min(prev + 0.2, 3))} className="w-11 h-11 bg-surface rounded-lg shadow-card flex items-center justify-center text-textSecondary btn-press touch-target border border-muted">
                 <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M12 4v16m8-8H4"/></svg>
               </button>
               <button onClick={() => setZoom(prev => Math.max(prev - 0.2, 0.5))} className="w-11 h-11 bg-surface rounded-lg shadow-card flex items-center justify-center text-textSecondary btn-press touch-target border border-muted">
                 <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2.5" d="M20 12H4"/></svg>
               </button>
               <button onClick={() => setShowGrid(!showGrid)} className={`w-11 h-11 rounded-lg shadow-card flex items-center justify-center transition-colors btn-press touch-target border border-muted ${showGrid ? 'bg-primary text-white' : 'bg-surface text-textSecondary'}`}>
                 <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 10h16M4 14h16M4 18h16"/></svg>
               </button>
            </div>

            <div className="w-full h-full flex items-center justify-center transition-transform duration-300" style={{ transform: `scale(${zoom})` }}>
              <svg 
                id="main-pattern-svg" 
                viewBox={`0 0 ${cmToPx(currentPiece.width + padding * 2)} ${cmToPx(currentPiece.height + padding * 2)}`} 
                className="w-full h-auto drop-shadow-elevated"
              >
                {showGrid && (
                  <defs>
                    <pattern id="grid" width="50" height="50" patternUnits="userSpaceOnUse">
                      <path d="M 50 0 L 0 0 0 50" fill="none" stroke="#e2e8f0" strokeWidth="0.5"/>
                    </pattern>
                  </defs>
                )}
                {showGrid && <rect width="100%" height="100%" fill="url(#grid)" />}
                
                <g transform={`translate(${cmToPx(padding)}, ${cmToPx(padding)})`}>
                  <path 
                    d={currentPiece.path} 
                    fill="none" 
                    stroke="#0F172A" 
                    strokeWidth="2" 
                    strokeLinecap="round" 
                    strokeLinejoin="round" 
                  />
                  {showRefPoints && currentPiece.referencePoints.map((p, idx) => (
                    <g key={idx}>
                      <circle cx={cmToPx(p.x)} cy={cmToPx(p.y)} r="3" fill="#EF4444" />
                      <text x={cmToPx(p.x) + 5} y={cmToPx(p.y) - 5} fontSize="9" fontWeight="900" fill="#0F172A" className="select-none">{p.label || idx + 1}</text>
                    </g>
                  ))}
                </g>
              </svg>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-sm">
            <button 
              onClick={() => setShowRefPoints(!showRefPoints)}
              className={`h-11 small-text font-bold rounded-button border transition-all btn-press ${showRefPoints ? 'bg-error/5 text-error border-error/10' : 'bg-background text-textSecondary border-background'}`}
            >
              {showRefPoints ? 'إخفاء النقاط' : 'إظهار النقاط'}
            </button>
            <button 
              onClick={downloadSVG} 
              className="h-11 bg-primary text-white small-text font-bold rounded-button shadow-card btn-press touch-target"
            >
              Export SVG (1:1)
            </button>
          </div>
        </>
      )}
    </div>
  );
};

export default PatternPreview;
