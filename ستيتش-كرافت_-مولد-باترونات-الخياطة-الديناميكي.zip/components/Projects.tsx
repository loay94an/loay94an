
import React, { useState } from 'react';

const Projects: React.FC = () => {
  const [search, setSearch] = useState('');
  
  const projects = [
    { id: '1', name: 'تيشيرت صيفي M', date: '2024-03-20', status: 'completed' },
    { id: '2', name: 'سترة مقاس XL', date: '2024-03-18', status: 'draft' },
    { id: '3', name: 'باترون طفلة 6', date: '2024-03-15', status: 'completed' },
    { id: '4', name: 'قميص رجالي مخصص', date: '2024-03-10', status: 'completed' },
  ];

  const filtered = projects.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-lg page-fade-in pb-24">
      <div className="bg-white p-md rounded-card shadow-card border border-muted">
        <h2 className="mb-md">قائمة المشاريع</h2>
        <div className="relative">
          <input 
            type="text" 
            placeholder="بحث عن مشروع..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-md py-sm pl-10 border border-muted rounded-button focus:ring-2 focus:ring-primary/10 focus:border-primary small-text bg-background"
          />
          <svg className="w-5 h-5 absolute right-3 top-1/2 -translate-y-1/2 text-textSecondary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        </div>
      </div>

      <div className="space-y-sm">
        {filtered.map(proj => (
          <div key={proj.id} className="bg-white p-md rounded-card border border-muted shadow-card flex justify-between items-center card-hover">
            <div className="flex flex-col">
              <span className="body-text font-bold text-textPrimary">{proj.name}</span>
              <span className="small-text text-textSecondary">{proj.date}</span>
            </div>
            <div className="flex gap-sm">
              <button className="p-sm text-textSecondary hover:text-primary btn-press">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 7v8a2 2 0 002 2h6M8 7V5a2 2 0 012-2h4.586a1 1 0 01.707.293l4.414 4.414a1 1 0 01.293.707V15a2 2 0 01-2 2h-2M8 7H6a2 2 0 00-2 2v10a2 2 0 002 2h8a2 2 0 002-2v-2"/></svg>
              </button>
              <button className="p-sm text-textSecondary hover:text-primary btn-press">
                 <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12c0-.482-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.316a3 3 0 105.368 2.684 3 3 0 00-5.368-2.684z"/></svg>
              </button>
              <button className="p-sm text-primary btn-press">
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z"/><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 12a9 9 0 11-18 0 9 9 0 0118 0z"/></svg>
              </button>
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="p-xl text-center text-textSecondary opacity-50">لا توجد مشاريع مطابقة للبحث</div>
        )}
      </div>
    </div>
  );
};

export default Projects;
