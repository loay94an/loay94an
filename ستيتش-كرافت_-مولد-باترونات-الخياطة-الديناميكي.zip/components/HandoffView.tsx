
import React, { useState } from 'react';

const HandoffView: React.FC = () => {
  const [activeSection, setActiveSection] = useState<'figma' | 'expo' | 'script'>('figma');

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    alert('تم النسخ إلى الحافظة!');
  };

  const packageJson = `{
  "name": "pattern-app",
  "version": "1.0.0",
  "main": "node_modules/expo/AppEntry.js",
  "scripts": {
    "start": "expo start",
    "android": "expo start --android",
    "ios": "expo start --ios",
    "web": "expo start --web"
  },
  "dependencies": {
    "expo": "~48.0.0",
    "react": "18.2.0",
    "react-native": "0.71.8",
    "react-native-svg": "13.4.0",
    "react-navigation": "^4.4.4",
    "@react-navigation/native": "^6.0.13",
    "@react-navigation/native-stack": "^6.9.0"
  }
}`;

  const shellScript = `#!/bin/bash
mkdir -p handoff
cat > handoff/design-tokens.json <<'JSON'
{ "colors": { "primary": "#0B6E4F", ... } }
JSON
# ... باقي السكربت لتوليد الحزمة
zip -r handoff_package.zip handoff
echo "Created handoff_package.zip"`;

  return (
    <div className="space-y-6 page-fade-in pb-24">
      <div className="bg-surface p-md rounded-card shadow-card border border-muted">
        <h2 className="text-textPrimary mb-2 flex items-center gap-2">
          <svg className="w-6 h-6 text-primary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/></svg>
          حزمة التسليم والإنتاج (Handoff)
        </h2>
        <p className="small-text text-textSecondary">قم بتصدير أصول التصميم، رموز التطوير، وسكربتات الإنتاج دفعة واحدة.</p>
      </div>

      <div className="flex bg-muted p-1 rounded-lg">
        <button 
          onClick={() => setActiveSection('figma')}
          className={`flex-1 py-2 small-text font-bold rounded-md transition-all ${activeSection === 'figma' ? 'bg-surface shadow-sm text-primary' : 'text-textSecondary'}`}
        >Figma Starter</button>
        <button 
          onClick={() => setActiveSection('expo')}
          className={`flex-1 py-2 small-text font-bold rounded-md transition-all ${activeSection === 'expo' ? 'bg-surface shadow-sm text-primary' : 'text-textSecondary'}`}
        >Mobile Starter</button>
        <button 
          onClick={() => setActiveSection('script')}
          className={`flex-1 py-2 small-text font-bold rounded-md transition-all ${activeSection === 'script' ? 'bg-surface shadow-sm text-primary' : 'text-textSecondary'}`}
        >Production Script</button>
      </div>

      {activeSection === 'figma' && (
        <div className="bg-surface p-md rounded-card shadow-card border border-muted space-y-4 animate-in fade-in duration-300">
          <div className="flex justify-between items-center">
            <h3 className="body-text font-bold text-textPrimary">دليل إعداد Figma</h3>
            <span className="px-2 py-1 bg-accent/10 text-accent text-[10px] font-bold rounded uppercase">Recommended</span>
          </div>
          <ul className="space-y-3">
            {[
              "قم بإنشاء صفحات: 00StyleTokens, 01UIKit, 02Screens.",
              "استخدم ملف design-tokens.json لتحديد متغيرات الألوان والخطوط.",
              "اعتمد نظام شبكة Grid 8px لضمان التناسق الهندسي.",
              "قم بتصدير الأيقونات كـ SVGs بمقاسات 24px و 48px."
            ].map((step, i) => (
              <li key={i} className="small-text text-textSecondary flex gap-3">
                <span className="w-5 h-5 bg-muted rounded-full flex items-center justify-center text-[10px] font-bold text-primary flex-shrink-0">{i+1}</span>
                {step}
              </li>
            ))}
          </ul>
          <button className="w-full py-3 bg-primary text-white small-text font-bold rounded-button btn-press">تصدير Tokens لـ Figma</button>
        </div>
      )}

      {activeSection === 'expo' && (
        <div className="bg-surface p-md rounded-card shadow-card border border-muted space-y-4 animate-in fade-in duration-300">
          <h3 className="body-text font-bold text-textPrimary">مشروع React Native (Expo)</h3>
          <div className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-1">
                <span className="text-[10px] font-bold text-textSecondary uppercase">package.json</span>
                <button onClick={() => copyToClipboard(packageJson)} className="text-[10px] font-bold text-primary hover:underline">Copy</button>
              </div>
              <pre className="p-3 bg-muted rounded-lg text-[10px] font-mono text-textPrimary overflow-x-auto">
                {packageJson}
              </pre>
            </div>
          </div>
        </div>
      )}

      {activeSection === 'script' && (
        <div className="bg-surface p-md rounded-card shadow-card border border-muted space-y-4 animate-in fade-in duration-300">
          <h3 className="body-text font-bold text-textPrimary">سكربت إنشاء الحزمة (Shell)</h3>
          <p className="small-text text-textSecondary">قم بتشغيل هذا السكربت محلياً لجمع كافة ملفات المشروع في ملف ZIP واحد جاهز للتسليم.</p>
          <div className="relative">
            <pre className="p-3 bg-slate-900 text-slate-100 rounded-lg text-[10px] font-mono overflow-x-auto">
              {shellScript}
            </pre>
            <button 
              onClick={() => copyToClipboard(shellScript)}
              className="absolute top-2 left-2 px-2 py-1 bg-white/10 text-white text-[10px] font-bold rounded hover:bg-white/20 transition-all"
            >Copy</button>
          </div>
          <div className="p-sm bg-primary/5 border border-primary/10 rounded-lg">
            <p className="text-[10px] text-primary font-bold">ملاحظة: يتطلب تشغيل السكربت وجود Bash ونظام ملفات Unix/Linux أو macOS.</p>
          </div>
        </div>
      )}

      <div className="bg-white p-md rounded-card border border-muted shadow-card">
        <h3 className="body-text font-bold text-textPrimary mb-3">قائمة الأصول (Asset Checklist)</h3>
        <div className="space-y-2">
          {[
            { name: "Icons (SVG)", status: "Ready" },
            { name: "Mockups (PNG)", status: "Pending" },
            { name: "Example Patterns", status: "Ready" },
            { name: "Production README", status: "Ready" }
          ].map((item, i) => (
            <div key={i} className="flex justify-between items-center p-sm bg-background rounded-lg border border-muted/50">
              <span className="small-text text-textPrimary">{item.name}</span>
              <span className={`text-[10px] font-bold px-2 py-0.5 rounded-pill ${item.status === 'Ready' ? 'bg-success/10 text-success' : 'bg-accent/10 text-accent'}`}>{item.status}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default HandoffView;
