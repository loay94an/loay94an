
import React, { useState } from 'react';
import { Measurements, Variations, FitType, GarmentSize } from '../types';
import { ADULT_SIZES, CHILD_SIZES } from '../services/patternLogic';

interface ControlsProps {
  measurements: Measurements;
  variations: Variations;
  onMeasurementsChange: (m: Partial<Measurements>) => void;
  onVariationsChange: (v: Partial<Variations>) => void;
  onGenerateAdvice: () => void;
  loading: boolean;
}

const Controls: React.FC<ControlsProps> = ({ 
  measurements, 
  variations, 
  onMeasurementsChange, 
  onVariationsChange,
  onGenerateAdvice,
  loading
}) => {
  const [search, setSearch] = useState('');
  const inputClass = "w-full px-md py-sm border border-muted rounded-button focus:ring-2 focus:ring-primary/10 focus:border-primary small-text font-medium transition-all bg-background shadow-sm";
  const labelClass = "block text-[10px] font-bold text-textSecondary mb-1 uppercase tracking-widest px-xs";

  const handleMChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    onMeasurementsChange({ [name]: parseFloat(value) || 0 });
    onVariationsChange({ selectedSize: 'custom' });
  };

  const adultSizes = Object.keys(ADULT_SIZES);
  const childSizes = Object.keys(CHILD_SIZES);
  const currentSizes = variations.sizeCategory === 'adult' ? adultSizes : childSizes;
  const filteredSizes = currentSizes.filter(s => s.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="space-y-lg page-fade-in pb-24">
      <div className="bg-surface p-md rounded-card shadow-card border border-muted">
        <div className="flex justify-between items-center mb-md">
           <h2 className="text-textPrimary">إدارة جداول المقاسات</h2>
           <button className="p-sm text-primary btn-press touch-target">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12"/></svg>
           </button>
        </div>

        <div className="flex p-xs bg-background rounded-lg mb-md">
          <button 
            onClick={() => onVariationsChange({ sizeCategory: 'adult', selectedSize: 'M' })}
            className={`flex-1 py-sm small-text font-bold rounded-lg transition-all btn-press ${variations.sizeCategory === 'adult' ? 'bg-surface shadow-sm text-primary' : 'text-textSecondary'}`}
          >بالغين (Adult)</button>
          <button 
            onClick={() => onVariationsChange({ sizeCategory: 'child', selectedSize: '6' })}
            className={`flex-1 py-sm small-text font-bold rounded-lg transition-all btn-press ${variations.sizeCategory === 'child' ? 'bg-surface shadow-sm text-primary' : 'text-textSecondary'}`}
          >أطفال (Children)</button>
        </div>

        <div className="relative mb-md">
          <input 
            type="text" 
            placeholder="بحث عن مقاس..." 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-md py-sm border border-muted rounded-button focus:ring-2 focus:ring-primary/10 focus:border-primary small-text bg-background pr-10"
          />
          <svg className="w-5 h-5 absolute right-3 top-1/2 -translate-y-1/2 text-textSecondary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"/></svg>
        </div>

        <div className="space-y-sm max-h-[200px] overflow-y-auto pr-1">
          {filteredSizes.map(size => (
            <div 
              key={size}
              onClick={() => onVariationsChange({ selectedSize: size })}
              className={`p-md rounded-lg border transition-all btn-press flex justify-between items-center cursor-pointer ${variations.selectedSize === size ? 'bg-primary/5 border-primary shadow-sm' : 'bg-background border-muted'}`}
            >
              <div className="flex items-center gap-md">
                <span className="body-text font-black text-textPrimary">{size}</span>
                <span className="small-text text-textSecondary">الصدر: {measurements.chestWidth} سم</span>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-surface p-md rounded-card shadow-card border border-muted space-y-md">
        <h3 className="text-[12px] font-bold text-textSecondary uppercase tracking-widest px-xs">القياسات الأساسية (سم)</h3>
        <div className="grid grid-cols-2 gap-md">
          <div>
            <label className={labelClass}>محيط الصدر</label>
            <input type="number" name="chestWidth" value={measurements.chestWidth} onChange={handleMChange} className={inputClass} />
          </div>
          <div>
            <label className={labelClass}>محيط الهنش</label>
            <input type="number" name="hipCircumference" value={measurements.hipCircumference} onChange={handleMChange} className={inputClass} />
          </div>
          <div>
            <label className={labelClass}>محيط الوسط</label>
            <input type="number" name="waistWidth" value={measurements.waistWidth} onChange={handleMChange} className={inputClass} />
          </div>
          <div>
            <label className={labelClass}>محيط الرقبة</label>
            <input type="number" name="neckCircumference" value={measurements.neckCircumference} onChange={handleMChange} className={inputClass} />
          </div>
          <div>
            <label className={labelClass}>طول الجسم</label>
            <input type="number" name="bodyLength" value={measurements.bodyLength} onChange={handleMChange} className={inputClass} />
          </div>
          <div>
            <label className={labelClass}>طول الكم</label>
            <input type="number" name="sleeveLength" value={measurements.sleeveLength} onChange={handleMChange} className={inputClass} />
          </div>
        </div>
      </div>

      <button
        onClick={onGenerateAdvice}
        disabled={loading}
        className="w-full bg-primary text-white body-text font-bold py-lg rounded-card shadow-elevated transition-all btn-press flex items-center justify-center gap-md disabled:opacity-50 touch-target"
      >
        {loading ? (
          <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-pill animate-spin"></div>
        ) : 'توليد الباترون والتعليمات'}
      </button>
    </div>
  );
};

export default Controls;
