
import React from 'react';
import { Measurements, Variations } from '../types';

interface MockupPreviewProps {
  measurements: Measurements;
  variations: Variations;
}

const MockupPreview: React.FC<MockupPreviewProps> = ({ measurements, variations }) => {
  const isOversized = variations.fit === 'oversized';
  const isSlim = variations.fit === 'slim';
  
  const heightAdj = variations.lengthAdjust * 1.5;
  const sleeveLen = variations.sleeveStyle === 'long' ? 140 : 50;
  const sleeveWidth = isOversized ? 25 : 18;

  const fitLabels: Record<string, string> = { 'slim': 'ضيق', 'regular': 'عادي', 'oversized': 'واسع جداً' };
  const sleeveLabels: Record<string, string> = { 'short': 'قصير', 'long': 'طويل', 'raglan': 'راجلان' };

  return (
    <div className="bg-white p-8 rounded-[2.5rem] shadow-xl border border-slate-100 flex flex-col items-center h-full">
      <div className="w-full flex justify-between items-center mb-10">
        <h3 className="text-xl font-black text-slate-900 tracking-tight italic">المحاكاة البصرية</h3>
        <div className="flex gap-1">
          <div className="w-2.5 h-2.5 rounded-full bg-blue-500"></div>
          <div className="w-2.5 h-2.5 rounded-full bg-blue-300"></div>
          <div className="w-2.5 h-2.5 rounded-full bg-blue-100"></div>
        </div>
      </div>

      <div className="relative w-full max-w-[260px] aspect-[3/4] flex items-center justify-center bg-slate-50 rounded-[3rem] border border-slate-100 group transition-all duration-700 hover:bg-white hover:shadow-2xl hover:shadow-blue-500/10">
        <svg viewBox="0 0 200 240" className="w-full h-full p-8 drop-shadow-[0_25px_30px_rgba(0,0,0,0.15)] transition-transform duration-700 group-hover:scale-110">
          <defs>
            <linearGradient id="shirtGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#2563eb" />
              <stop offset="100%" stopColor="#1e40af" />
            </linearGradient>
            <filter id="shadow">
              <feDropShadow dx="0" dy="4" stdDeviation="5" floodOpacity="0.2" />
            </filter>
          </defs>
          
          <path 
            d={`M 60,45 
               L 140,45 
               L ${140 + (isOversized ? 15 : isSlim ? -5 : 5)},${60 + heightAdj/4 + 110} 
               L ${60 - (isOversized ? 15 : isSlim ? -5 : 5)},${60 + heightAdj/4 + 110} 
               Z`} 
            fill="url(#shirtGrad)"
            className="transition-all duration-700 ease-in-out"
            filter="url(#shadow)"
          />

          <path 
            d={`M 60,45 L ${60 - sleeveWidth},${45 + sleeveLen/2} L 60,${60 + sleeveLen/2} Z`}
            fill="#1d4ed8"
            className="transition-all duration-500 ease-in-out"
          />

          <path 
            d={`M 140,45 L ${140 + sleeveWidth},${45 + sleeveLen/2} L 140,${60 + sleeveLen/2} Z`}
            fill="#1d4ed8"
            className="transition-all duration-500 ease-in-out"
          />

          {variations.hood && (
            <path 
              d="M 75,45 C 75,10 125,10 125,45 Z" 
              fill="#1e3a8a" 
              className="opacity-95 transition-all duration-500"
            />
          )}

          <ellipse cx="100" cy="45" rx="35" ry="8" fill="#1e3a8a" />
        </svg>
        
        <div className="absolute top-8 right-8">
           <div className={`text-[10px] font-black px-4 py-1.5 rounded-full text-white shadow-xl tracking-widest ${isOversized ? 'bg-indigo-600' : isSlim ? 'bg-rose-600' : 'bg-blue-600'}`}>
             قصة {fitLabels[variations.fit]}
           </div>
        </div>
      </div>

      <div className="mt-12 w-full grid grid-cols-2 gap-4">
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 hover:bg-blue-50 transition-colors group">
          <p className="text-[10px] text-slate-400 font-black mb-1">الطول النهائي</p>
          <p className="text-lg font-black text-slate-800">{(measurements.bodyLength + variations.lengthAdjust).toFixed(1)} سم</p>
        </div>
        <div className="bg-slate-50 p-4 rounded-2xl border border-slate-100 hover:bg-blue-50 transition-colors group">
          <p className="text-[10px] text-slate-400 font-black mb-1">نمط الأكمام</p>
          <p className="text-lg font-black text-slate-800">{sleeveLabels[variations.sleeveStyle]}</p>
        </div>
      </div>
    </div>
  );
};

export default MockupPreview;
