
export interface Measurements {
  chestWidth: number;
  bodyLength: number;
  shoulderWidth: number;
  sleeveLength: number;
  armholeDepth: number;
  neckDepth: number;
  waistWidth: number;
  hipCircumference: number;
  neckCircumference: number;
  sideLength?: number;
}

export type FitType = 'slim' | 'regular' | 'oversized';
export type SleeveStyle = 'short' | 'long' | 'raglan';
export type GarmentSize = 'XS' | 'S' | 'M' | 'L' | 'XL' | 'XXL' | 'custom' | string;

export interface Variations {
  fit: FitType;
  hood: boolean;
  lengthAdjust: number;
  sleeveStyle: SleeveStyle;
  selectedSize: GarmentSize;
  sizeCategory: 'adult' | 'child' | 'men';
  ease: number;
  seamAllowance: number;
  showNotches: boolean;
}

export interface Point {
  x: number;
  y: number;
  label?: string;
}

export interface PatternPieceInfo {
  width: number;
  height: number;
  path: string;
  referencePoints: Point[];
  steps: string[];
}

export interface PatternDimensions {
  front: PatternPieceInfo;
  back: PatternPieceInfo;
  sleeve: PatternPieceInfo;
  hood: PatternPieceInfo | null;
  collar: PatternPieceInfo | null;
  sizeLabel?: string;
}

export interface MarkerPiece {
  x: number;
  y: number;
  width: number;
  height: number;
  label: string;
  type: string;
  path: string;
}

export interface MarkerLayout {
  fabricWidth: number;
  totalLength: number;
  pieces: MarkerPiece[];
  efficiency: number;
  usedArea: number;
}

export interface StylingAdvice {
  fabricRecommendation: string;
  yardageEstimate: string;
  difficulty: string;
  tips: string[];
}
