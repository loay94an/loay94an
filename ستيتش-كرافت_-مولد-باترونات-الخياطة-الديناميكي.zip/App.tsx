
import React, { useState, useEffect } from 'react';
import Controls from './components/Controls';
import PatternPreview from './components/PatternPreview';
import MarkerBuilder from './components/MarkerBuilder';
import Navigation from './components/Navigation';
import Dashboard from './components/Dashboard';
import HandoffView from './components/HandoffView';
import { Measurements, Variations, PatternDimensions, StylingAdvice } from './types';
import { computePatternDimensions, getSizeMeasurements } from './services/patternLogic';
import { getStylingAdvice } from './services/geminiService';

type TabId = 'home' | 'sizes' | 'pattern' | 'marker' | 'handoff';

const App: React.FC = () => {
  const [activeTab, setActiveTab] = useState<TabId>('home');
  const [variations, setVariations] = useState<Variations>({
    fit: 'regular',
    hood: false,
    lengthAdjust: 0,
    sleeveStyle: 'long',
    selectedSize: 'M',
    sizeCategory: 'adult',
    ease: 3.0,
    seamAllowance: 1.0,
    showNotches: true
  });

  const [activeMeasurements, setActiveMeasurements] = useState<Measurements>(getSizeMeasurements(variations.selectedSize, variations.sizeCategory));
  const [dims, setDims] = useState<PatternDimensions>(computePatternDimensions(activeMeasurements, variations));
  const [advice, setAdvice] = useState<StylingAdvice | null>(null);
  const [loadingAdvice, setLoadingAdvice] = useState(false);

  useEffect(() => {
    const updatedM = variations.selectedSize === 'custom' 
      ? activeMeasurements 
      : getSizeMeasurements(variations.selectedSize, variations.sizeCategory);
    
    setActiveMeasurements(updatedM);
    setDims(computePatternDimensions(updatedM, variations));
  }, [variations.selectedSize, variations.sizeCategory]);

  const handleMChange = (m: Partial<Measurements>) => setActiveMeasurements(prev => ({ ...prev, ...m }));
  const handleVChange = (v: Partial<Variations>) => setVariations(prev => ({ ...prev, ...v }));

  const handleGenerateAdvice = async () => {
    setLoadingAdvice(true);
    try {
      const result = await getStylingAdvice(activeMeasurements, variations);
      setAdvice(result);
      setActiveTab('pattern'); 
    } catch (error) {
      console.error("Gemini Error:", error);
    } finally {
      setLoadingAdvice(false);
    }
  };

  const getTitle = () => {
    switch(activeTab) {
      case 'home': return 'الرئيسية';
      case 'sizes': return 'المقاسات والتخصيص';
      case 'pattern': return 'معاينة الباترون';
      case 'marker': return 'باني الماركر';
      case 'handoff': return 'حزمة التصدير';
      default: return 'ستيتش كرافت';
    }
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <Dashboard onNavigate={(id, params) => {
          if(params?.category) handleVChange({ sizeCategory: params.category });
          setActiveTab(id);
        }} />;
      case 'sizes':
        return (
          <Controls 
            measurements={activeMeasurements} 
            variations={variations} 
            onMeasurementsChange={handleMChange}
            onVariationsChange={handleVChange}
            onGenerateAdvice={handleGenerateAdvice}
            loading={loadingAdvice}
          />
        );
      case 'pattern':
        return (
          <div className="space-y-md page-fade-in pb-24">
             {advice && (
                <div className="bg-primary p-md rounded-card shadow-elevated text-white flex justify-between items-center">
                   <div>
                     <p className="text-[10px] font-bold opacity-70 uppercase tracking-widest mb-1">الخامة الموصى بها</p>
                     <p className="body-text font-black leading-tight">{advice.fabricRecommendation}</p>
                   </div>
                   <div className="text-left">
                     <p className="text-[10px] font-bold opacity-70 uppercase tracking-widest mb-1">الكمية</p>
                     <p className="body-text font-black">{advice.yardageEstimate}</p>
                   </div>
                </div>
             )}
             <PatternPreview 
                dims={dims} 
                seamAllowance={variations.seamAllowance} 
                measurements={activeMeasurements}
                variations={variations}
             />
             {advice && (
                <div className="bg-surface p-md rounded-card shadow-card border border-primary/5">
                  <h3 className="body-text font-bold text-textPrimary mb-md flex items-center gap-sm">
                    <span className="w-1.5 h-5 bg-accent rounded-pill"></span>
                    نصائح التنفيذ (Tech Pack)
                  </h3>
                  <div className="space-y-sm text-right">
                    <div className="grid grid-cols-2 gap-sm">
                      <div className="p-sm bg-background rounded-lg">
                        <p className="text-[10px] font-bold text-textSecondary uppercase mb-xs tracking-widest">المستوى</p>
                        <p className="small-text font-bold text-textPrimary">{advice.difficulty}</p>
                      </div>
                      <div className="p-sm bg-background rounded-lg">
                        <p className="text-[10px] font-bold text-textSecondary uppercase mb-xs tracking-widest">محيط الصدر</p>
                        <p className="small-text font-bold text-textPrimary">{activeMeasurements.chestWidth} سم</p>
                      </div>
                    </div>
                    <div className="bg-background p-md rounded-lg">
                       <p className="text-[10px] font-bold text-textSecondary uppercase mb-sm tracking-widest">تلميحات تقنية من الموسوعة</p>
                       <ul className="space-y-2">
                         {advice.tips.map((tip, i) => (
                           <li key={i} className="small-text text-textPrimary font-bold flex gap-2 justify-start flex-row-reverse">
                             <span className="text-primary font-black">•</span>
                             {tip}
                           </li>
                         ))}
                       </ul>
                    </div>
                  </div>
                </div>
              )}
          </div>
        );
      case 'marker':
        return <MarkerBuilder variations={variations} />;
      case 'handoff':
        return <HandoffView />;
      default:
        return <Dashboard onNavigate={(id) => setActiveTab(id)} />;
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <header className="bg-surface border-b border-muted sticky top-0 z-50 h-16 flex items-center px-lg shadow-sm">
        <div className="w-full flex items-center justify-between max-w-lg mx-auto">
          <div className="flex items-center gap-sm">
            {activeTab !== 'home' && (
              <button onClick={() => setActiveTab('home')} className="p-sm -mr-2 btn-press touch-target">
                <svg className="w-6 h-6 text-textSecondary" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7"/></svg>
              </button>
            )}
            <h1 className="text-textPrimary tracking-tight font-black">{getTitle()}</h1>
          </div>
          <button className="w-10 h-10 rounded-lg bg-background border border-muted flex items-center justify-center text-textSecondary btn-press touch-target shadow-sm">
             <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"/></svg>
          </button>
        </div>
      </header>
      <main className="max-w-lg mx-auto px-md mt-md pb-xxl">{renderContent()}</main>
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
};

export default App;
