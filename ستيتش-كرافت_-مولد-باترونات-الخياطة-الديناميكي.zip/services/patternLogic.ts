
import { Measurements, Variations, PatternDimensions, GarmentSize, MarkerLayout, MarkerPiece, Point, PatternPieceInfo } from '../types';

// جداول المقاسات النموذجية من الموسوعة (ص 383 للنساء، ص 384 للرجال، ص 385 للأطفال)
export const ADULT_SIZES: Record<string, Measurements> = {
  '38': { chestWidth: 82, bodyLength: 64, shoulderWidth: 13, sleeveLength: 58, armholeDepth: 20, neckDepth: 7, waistWidth: 64, hipCircumference: 96, neckCircumference: 30 },
  '40': { chestWidth: 86, bodyLength: 65, shoulderWidth: 13, sleeveLength: 58, armholeDepth: 20.5, neckDepth: 7, waistWidth: 68, hipCircumference: 100, neckCircumference: 31 },
  '42': { chestWidth: 92, bodyLength: 66, shoulderWidth: 13.5, sleeveLength: 59, armholeDepth: 21, neckDepth: 7.5, waistWidth: 72, hipCircumference: 104, neckCircumference: 32.5 },
  'M':  { chestWidth: 100, bodyLength: 68, shoulderWidth: 14, sleeveLength: 60, armholeDepth: 22, neckDepth: 8, waistWidth: 80, hipCircumference: 112, neckCircumference: 35 },
  '48': { chestWidth: 108, bodyLength: 70, shoulderWidth: 14.5, sleeveLength: 61, armholeDepth: 23, neckDepth: 8.5, waistWidth: 88, hipCircumference: 120, neckCircumference: 37.5 },
};

export const CHILD_SIZES: Record<string, Measurements> = {
  '2':  { chestWidth: 58, bodyLength: 35, shoulderWidth: 8, sleeveLength: 30, armholeDepth: 14, neckDepth: 5, waistWidth: 56, hipCircumference: 64, neckCircumference: 23 },
  '6':  { chestWidth: 68, bodyLength: 48, shoulderWidth: 10, sleeveLength: 40, armholeDepth: 16, neckDepth: 6, waistWidth: 60, hipCircumference: 74, neckCircumference: 25.5 },
  '12': { chestWidth: 80, bodyLength: 58, shoulderWidth: 12.5, sleeveLength: 52, armholeDepth: 19, neckDepth: 7, waistWidth: 66, hipCircumference: 86, neckCircumference: 29 },
};

export const MEN_SIZES: Record<string, Measurements> = {
  'S': { chestWidth: 96, bodyLength: 70, shoulderWidth: 15, sleeveLength: 62, armholeDepth: 24, neckDepth: 8, waistWidth: 84, hipCircumference: 100, neckCircumference: 38 },
  'L': { chestWidth: 112, bodyLength: 74, shoulderWidth: 17, sleeveLength: 65, armholeDepth: 26, neckDepth: 9, waistWidth: 96, hipCircumference: 114, neckCircumference: 42 },
};

export const getSizeMeasurements = (size: GarmentSize, category: Variations['sizeCategory']): Measurements => {
  const table = category === 'adult' ? ADULT_SIZES : category === 'men' ? MEN_SIZES : CHILD_SIZES;
  return table[size] || (category === 'adult' ? ADULT_SIZES['M'] : category === 'men' ? MEN_SIZES['S'] : CHILD_SIZES['6']);
};

export const computePatternDimensions = (
  measurements: Measurements,
  variations: Variations
): PatternDimensions => {
  const { chestWidth, bodyLength, shoulderWidth, sleeveLength, armholeDepth, neckDepth, waistWidth, hipCircumference, neckCircumference } = measurements;
  const { fit, hood, lengthAdjust, sleeveStyle, selectedSize, ease: userEase } = variations;

  // الحسابات بناءً على الموسوعة (الكورساج الأساسي ص 135)
  const baseEase = fit === 'oversized' ? 6 : fit === 'slim' ? 1 : userEase || 3;
  const backWidth = (chestWidth / 4) + baseEase - 1.5; 
  const frontWidth = (chestWidth / 4) + baseEase + 1.5; 
  
  const totalHeight = bodyLength + lengthAdjust;
  const neckWBack = neckCircumference / 5; 
  const neckWFront = neckCircumference / 5;
  const armholeLine = armholeDepth + 2; 

  const backSteps = [
    `ارسم مستطيل الظهر بعرض ${backWidth.toFixed(1)} سم وطول ${totalHeight.toFixed(1)} سم`,
    `حدد تقويرة الرقبة الخلفية بعرض ${neckWBack.toFixed(1)} سم وعمق 1.5 سم`,
    `ارسم خط الكتف المائل بمقدار 3 سم نزولاً من الزاوية`,
    `حدد حردة الإبط الخلفية وصولاً إلى خط الصدر`
  ];

  const frontSteps = [
    `ارسم مستطيل الصدر بعرض ${frontWidth.toFixed(1)} سم`,
    `حدد تقويرة الرقبة الأمامية بعمق ${neckDepth.toFixed(1)} سم`,
    `ارسم بنسة الصدر الأساسية (ص 153) إذا كان الموديل مجسماً`,
    `ارسم حردة الإبط الأمامية (أعمق من الخلف بـ 1 سم)`
  ];

  const backPath = `M 0,0 L ${neckWBack},0 Q ${neckWBack},1.5 0,1.5 L 0,0 M ${neckWBack},0 L ${backWidth},3 L ${backWidth},${armholeLine} L ${backWidth},${totalHeight} L 0,${totalHeight} Z`;
  const frontPath = `M 0,${neckDepth} Q 0,0 ${neckWFront},0 L ${frontWidth},2 L ${frontWidth},${armholeLine} L ${frontWidth},${totalHeight} L 0,${totalHeight} Z`;

  // حردة الكم (ص 226-228)
  const sleeveW = (chestWidth / 4) + 4;
  const sleeveCapH = (armholeDepth / 3) * 2;
  const sleevePath = `M 0,${sleeveCapH} C 0,0 ${sleeveW},0 ${sleeveW},${sleeveCapH} L ${sleeveW},${sleeveLength} L 0,${sleeveLength} Z`;

  return {
    front: { width: frontWidth, height: totalHeight, path: frontPath, referencePoints: [{x:neckWFront, y:0, label:'أ'}], steps: frontSteps },
    back: { width: backWidth, height: totalHeight, path: backPath, referencePoints: [{x:neckWBack, y:0, label:'ب'}], steps: backSteps },
    sleeve: { width: sleeveW, height: sleeveLength, path: sleevePath, referencePoints: [], steps: ["تحديد ارتفاع رأس الكم", "رسم دوران الكم"] },
    hood: hood ? { width: 30, height: 35, path: `M 0,35 Q 0,0 25,0 L 30,5 L 30,35 Z`, referencePoints: [], steps: ["رسم القلنسوة"] } : null,
    collar: null,
    sizeLabel: selectedSize
  };
};

export const calculateMarkerLayout = (
  orders: Array<{ size: GarmentSize, quantity: number, category: Variations['sizeCategory'] }>,
  variations: Variations,
  fabricWidthCm: number
): MarkerLayout => {
  const piecesToPlace: Array<{ w: number, h: number, type: string, label: string, path: string }> = [];
  
  orders.forEach(order => {
    if (order.quantity <= 0) return;
    const m = getSizeMeasurements(order.size, order.category);
    const dims = computePatternDimensions(m, { ...variations, selectedSize: order.size });
    
    for (let i = 0; i < order.quantity; i++) {
      piecesToPlace.push({ w: dims.front.width, h: dims.front.height, type: 'front', label: `أمام ${order.size}`, path: dims.front.path });
      piecesToPlace.push({ w: dims.back.width, h: dims.back.height, type: 'back', label: `خلف ${order.size}`, path: dims.back.path });
      piecesToPlace.push({ w: dims.sleeve.width, h: dims.sleeve.height, type: 'sleeve', label: `كم ${order.size}`, path: dims.sleeve.path });
      piecesToPlace.push({ w: dims.sleeve.width, h: dims.sleeve.height, type: 'sleeve', label: `كم ${order.size}`, path: dims.sleeve.path });
    }
  });

  piecesToPlace.sort((a, b) => b.h - a.h);
  const pieces: MarkerPiece[] = [];
  const spacing = 1.5;
  let curX = spacing;
  let curY = spacing;
  let rowH = 0;
  let usedArea = 0;

  piecesToPlace.forEach(p => {
    if (curX + p.w + spacing > fabricWidthCm) {
      curY += rowH + spacing;
      curX = spacing;
      rowH = 0;
    }
    pieces.push({ x: curX, y: curY, width: p.w, height: p.h, label: p.label, type: p.type, path: p.path });
    usedArea += (p.w * p.h);
    curX += p.w + spacing;
    rowH = Math.max(rowH, p.h);
  });

  const totalLength = curY + rowH + spacing;
  const efficiency = (usedArea / (fabricWidthCm * totalLength)) * 100;

  return { fabricWidth: fabricWidthCm, totalLength, pieces, efficiency, usedArea };
};

export const cmToPx = (cm: number) => cm * 5;
