
import { GoogleGenAI, Type } from "@google/genai";
import { Measurements, Variations, StylingAdvice } from '../types';

export const getStylingAdvice = async (
  measurements: Measurements,
  variations: Variations
): Promise<StylingAdvice> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const prompt = `
    أنت خبير خياطة وتصميم أزياء. قم بإنشاء تقنية (Tech Pack) لقطعة ملابس بالمواصفات التالية:
    - القياسات: ${JSON.stringify(measurements)}
    - الإضافات: القصة: ${variations.fit}، القلنسوة: ${variations.hood ? 'نعم' : 'لا'}، الكم: ${variations.sleeveStyle}.
    
    المطلوب رد بصيغة JSON يحتوي على:
    1. fabricRecommendation: نوع القماش المثالي بالعربية.
    2. yardageEstimate: كمية القماش المطلوبة بالأمتار.
    3. difficulty: مستوى الصعوبة (مبتدئ، متوسط، محترف).
    4. tips: قائمة من 4 نصائح تقنية للخياطة.
    
    يجب أن يكون النص بالعربية بالكامل.
  `;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            fabricRecommendation: { type: Type.STRING },
            yardageEstimate: { type: Type.STRING },
            difficulty: { type: Type.STRING },
            tips: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ["fabricRecommendation", "yardageEstimate", "difficulty", "tips"]
        }
      }
    });

    return JSON.parse(response.text || '{}');
  } catch (error) {
    console.error("Gemini Error:", error);
    return {
      fabricRecommendation: "قطن جيرسي عالي الجودة",
      yardageEstimate: "2.5 متر تقريباً",
      difficulty: "متوسط",
      tips: [
        "اغسل القماش مسبقاً لتجنب انكماشه بعد الخياطة",
        "استخدم غرزة الزجزاج أو ماكينة الأوفرلوك للتعامل مع تمدد القماش",
        "تأكد من مطابقة نقاط الكتف بدقة قبل توصيل الأكمام",
        "اترك مسافة 1 سم للخياطة حول الحواف"
      ]
    };
  }
};
