
import { Fabric, Gender, Measurements, GarmentStyle, FabricColor, PatternDesign, StyleItem, PricingRule, Order, CollarType, SleeveType, PricingPlan, User, UserRole } from './types';

export const INITIAL_STYLES: StyleItem[] = [
  { id: GarmentStyle.SHIRT, label: 'قميص رجالي فاخر', icon: '👔', description: 'قصة سليم فيت عصرية', occasion: 'FORMAL', season: 'ALL', gender: Gender.MALE },
  { id: GarmentStyle.SUIT, label: 'بدلة رسمية إيطالية', icon: '🤵', description: 'تصميم قطعتين للمناسبات', occasion: 'FORMAL', season: 'WINTER', gender: Gender.MALE },
  { id: GarmentStyle.BISHT, label: 'بشت ملكي أصيل', icon: '🕌', description: 'تراث وفخامة للمناسبات الكبرى', occasion: 'CEREMONY', season: 'ALL', gender: Gender.MALE },
  { id: GarmentStyle.PRINCESS_CUT_DRESS, label: 'فستان البرنسيس', icon: '👗', description: 'أناقة فرنسية خالدة', occasion: 'EVENING', season: 'ALL', gender: Gender.FEMALE },
  { id: GarmentStyle.MERMAID_DRESS, label: 'فستان المرميد', icon: '🧜‍♀️', description: 'إبراز القوام بلمسة فنية', occasion: 'EVENING', season: 'ALL', gender: Gender.FEMALE },
  { id: GarmentStyle.COWL_NECK_DRESS, label: 'فستان بياقة منسدلة', icon: '💃', description: 'تصميم انسيابي ناعم', occasion: 'EVENING', season: 'SUMMER', gender: Gender.FEMALE },
  { id: GarmentStyle.CORSET_TOP, label: 'كورسيه عصري', icon: '👚', description: 'تحديد الخصر بأسلوب فني', occasion: 'EVENING', season: 'ALL', gender: Gender.FEMALE },
  { id: GarmentStyle.ABAYA, label: 'عباءة كريب عصرية', icon: '👘', description: 'لمسة من الرقي اليومي', occasion: 'DAILY', season: 'ALL', gender: Gender.FEMALE },
  { id: GarmentStyle.KIDS_SUIT, label: 'طقم أطفال رسمي', icon: '🤴', description: 'تصميم مريح للأمراء الصغار', occasion: 'CEREMONY', season: 'ALL', gender: Gender.CHILDREN }
];

export const INITIAL_FABRICS: Fabric[] = [
  {
    id: 'cotton-1',
    name: 'قطن مصري 100%',
    description: 'نعومة فائقة ومسامية مثالية للصيف.',
    color: '#FFFFFF',
    thickness: 'medium',
    material: 'قطن',
    image: 'https://images.unsplash.com/photo-1528459801416-a9e53bbf4e17?auto=format&fit=crop&w=400&q=80',
    properties: { stretch: 'منخفضة', breathability: 'عالية جداً', durability: 'ممتازة' },
    physics: { mass: 1.0, stiffness: 0.8, damping: 0.3 }
  },
  {
    id: 'silk-1',
    name: 'حرير طبيعي ملكي',
    description: 'انسيابية مطلقة وملمس بارد للمناسبات.',
    color: '#FFF0F5',
    thickness: 'thin',
    material: 'حرير',
    image: 'https://images.unsplash.com/photo-1606132226758-005164f9979c?auto=format&fit=crop&w=400&q=80',
    properties: { stretch: 'لا يوجد', breathability: 'متوسطة', durability: 'حساسة' },
    physics: { mass: 0.6, stiffness: 0.4, damping: 0.1 }
  },
  {
    id: 'wool-1',
    name: 'صوف ميرينو شتوي',
    description: 'دفء مثالي ووزن فخم للبدل والسترات.',
    color: '#2a2a2a',
    thickness: 'thick',
    material: 'صوف',
    image: 'https://images.unsplash.com/photo-1598418037385-059a46452f36?auto=format&fit=crop&w=400&q=80',
    properties: { stretch: 'متوسطة', breathability: 'عالية', durability: 'جيدة جداً' },
    physics: { mass: 2.0, stiffness: 0.7, damping: 0.6 }
  },
  {
    id: 'denim-1',
    name: 'جينز ياباني فاخر',
    description: 'متانة عالية ومظهر كاجوال عصري.',
    color: '#1a2a4a',
    thickness: 'thick',
    material: 'جينز',
    image: 'https://images.unsplash.com/photo-1542272454315-4c01d7abdf4a?auto=format&fit=crop&w=400&q=80',
    properties: { stretch: 'قليلة', breathability: 'منخفضة', durability: 'قصوى' },
    physics: { mass: 2.2, stiffness: 0.9, damping: 0.5 }
  }
];

export const INITIAL_COLORS: FabricColor[] = [
  { id: 'c1', name: 'أسود فاحم', hex: '#000000', category: 'BASIC' },
  { id: 'c2', name: 'أبيض ناصع', hex: '#FFFFFF', category: 'BASIC' },
  { id: 'c3', name: 'كحلي دبلوماسي', hex: '#001a33', category: 'BASIC' },
  { id: 'c4', name: 'بيج رملي', hex: '#d2b48c', category: 'NEUTRAL' },
  { id: 'c5', name: 'ذهبي ملكي', hex: '#C5A021', category: 'METALLIC' }
];

export const STANDARD_SIZES: Record<string, Measurements> = {
  'S': { height: 165, chest: 88, waist: 72, hips: 96, shoulderWidth: 40, armLength: 58, neckCircumference: 36, waistToFloor: 100 },
  'M': { height: 175, chest: 96, waist: 80, hips: 104, shoulderWidth: 44, armLength: 61, neckCircumference: 38, waistToFloor: 105 },
  'L': { height: 182, chest: 104, waist: 88, hips: 112, shoulderWidth: 48, armLength: 64, neckCircumference: 40, waistToFloor: 110 },
  'XL': { height: 188, chest: 112, waist: 96, hips: 120, shoulderWidth: 52, armLength: 66, neckCircumference: 42, waistToFloor: 115 }
};

export const PATTERNS: PatternDesign[] = [
  { id: 'p1', name: 'سادة (كلاسيك)', type: 'PLAIN', preview: 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=' },
  { id: 'p2', name: 'مقلم (إيطالي)', type: 'STRIPED', preview: 'https://www.transparenttextures.com/patterns/pinstriped-suit.png' },
  { id: 'p3', name: 'تطريز ذهبي', type: 'FLORAL', preview: 'https://www.transparenttextures.com/patterns/gray-floral.png' }
];

export const INITIAL_PRICING: PricingRule[] = [
  { styleId: GarmentStyle.SHIRT, basePrice: 280, fabricMultipliers: { 'cotton-1': 1.0, 'silk-1': 1.6 } },
  { styleId: GarmentStyle.SUIT, basePrice: 1800, fabricMultipliers: { 'wool-1': 1.2, 'silk-1': 1.8 } },
  { styleId: GarmentStyle.BISHT, basePrice: 2500, fabricMultipliers: { 'silk-1': 1.5 } }
];

export const DEFAULT_PLANS: PricingPlan[] = [
  { id: 'basic', name: 'النسخة الفضية', price: 99, features: ['بترون 19 حقل', 'تصدير PDF محدود', 'إدارة 10 عملاء'] },
  { id: 'pro', name: 'النسخة الذهبية', price: 299, features: ['بترونات غير محدودة', 'تصدير PDF احترافي', 'إدارة عملاء شاملة'] },
  { id: 'enterprise', name: 'النسخة الماسية', price: 799, features: ['نطاق مخصص', 'دعم فني 24/7', 'تقارير ذكاء أعمال'] }
];

export const INITIAL_ORDERS: Order[] = [
  {
    id: 'ord-001',
    customerName: 'سارة الأحمد',
    phone: '0501234567',
    address: 'الرياض، حي النرجس، شارع الأمير محمد بن سلمان',
    paymentMethod: 'CARD',
    status: 'COMPLETED',
    createdAt: Date.now() - (1000 * 60 * 60 * 24 * 7), // 7 days ago
    details: {
      gender: Gender.FEMALE,
      style: GarmentStyle.ABAYA,
      measurements: {
        height: 160, chest: 90, waist: 70, hips: 100, shoulderWidth: 42,
        armLength: 58, neckCircumference: 36, waistToFloor: 100
      },
      fabric: INITIAL_FABRICS[0], // Cotton
      color: INITIAL_COLORS[0], // Black
      pattern: PATTERNS[0],
      sleeveType: SleeveType.BASIC,
      collarType: CollarType.NONE,
      totalPrice: 350
    }
  },
  {
    id: 'ord-002',
    customerName: 'خالد الفيصل',
    phone: '0559876543',
    address: 'جدة، حي الحمراء، شارع الأندلس',
    paymentMethod: 'CASH',
    status: 'PROCESSING',
    createdAt: Date.now() - (1000 * 60 * 60 * 24 * 3), // 3 days ago
    details: {
      gender: Gender.MALE,
      style: GarmentStyle.SHIRT,
      measurements: {
        height: 178, chest: 100, waist: 85, hips: 105, shoulderWidth: 48,
        armLength: 62, neckCircumference: 40, waistToFloor: 105
      },
      fabric: INITIAL_FABRICS[1], // Silk
      color: INITIAL_COLORS[2], // Navy
      pattern: PATTERNS[1],
      sleeveType: SleeveType.BASIC,
      collarType: CollarType.MANDARIN,
      totalPrice: 420
    }
  },
  {
    id: 'ord-003',
    customerName: 'ليلى العبدالله',
    phone: '0531122334',
    address: 'الدمام، حي الزهور، طريق الملك فهد',
    paymentMethod: 'CARD',
    status: 'PENDING',
    createdAt: Date.now() - (1000 * 60 * 60 * 24 * 1), // 1 day ago
    details: {
      gender: Gender.FEMALE,
      style: GarmentStyle.PRINCESS_CUT_DRESS,
      measurements: {
        height: 165, chest: 92, waist: 68, hips: 98, shoulderWidth: 38,
        armLength: 55, neckCircumference: 34, waistToFloor: 110
      },
      fabric: INITIAL_FABRICS[1], // Silk
      color: INITIAL_COLORS[4], // Gold
      pattern: PATTERNS[0],
      sleeveType: SleeveType.PUFF,
      collarType: CollarType.SCOOP,
      totalPrice: 850
    }
  }
];

// Initial users for authentication
export const INITIAL_USERS: User[] = [
  { id: "admin-001", username: "loay94an1@gmail.com", password: "12345677", role: UserRole.ADMIN },
  { id: "assistant-001", username: "assistant1", password: "pass123", role: UserRole.ASSISTANT },
  { id: "viewer-001", username: "viewer1", password: "viewpass", role: UserRole.VIEWER }
];