
import React, { useState, useRef } from 'react';
import { Measurements, MeasurementProfile, BrandingSettings } from '../types';
import { STANDARD_SIZES } from '../constants';
import jsPDF from 'jspdf';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../firebase'; 

interface Props {
  userId: string;
  value: Measurements;
  onChange: (m: Measurements) => void;
  savedProfiles: MeasurementProfile[];
  onSaveProfile: (name: string, m: Measurements) => void;
  onDeleteProfile: (id: string) => void;
  onSelectProfile: (m: Measurements) => void;
  branding?: BrandingSettings;
  onBackToHub: () => void; 
}

const modelLibrary = [
  { name: "موديل رجل", url: "https://placehold.co/400x600/1e293b/FFF?text=Male+Model" },
  { name: "موديل امرأة", url: "https://placehold.co/400x600/1e293b/FFF?text=Female+Model" },
  { name: "موديل طفل", url: "https://placehold.co/400x600/1e293b/FFF?text=Child+Model" }
];

const MEASUREMENT_GROUPS_AR = [
  {
    title: "الجذع والكتف",
    fields: {
      chest: "محيط الصدر",
      waist: "محيط الخصر",
      hips: "محيط الورك",
      shoulderWidth: "عرض الكتف الكلي",
      backWidth: "عرض الظهر",
      bodiceLength: "طول الصدر الكلي",
      backLength: "طول الظهر",
      bustPointToPoint: "بين الثديين",
      shoulderToBust: "من الكتف للثدي"
    }
  },
  {
    title: "الأطراف والرقبة",
    fields: {
      neckCircumference: "محيط الرقبة",
      armLength: "طول الكم",
      armCircumference: "محيط الذراع",
      cuffCircumference: "محيط الإسوارة",
      armholeCircumference: "محيط حفرة الإبط"
    }
  },
  {
    title: "الارتفاعات السفلية",
    fields: {
      height: "الطول الكلي",
      waistToHip: "من الخصر للورك",
      waistToKnee: "من الخصر للركبة",
      waistToFloor: "طول الساق للأرض",
      skirtLength: "طول التنورة المطلوب"
    }
  }
];

export const SizeInput: React.FC<Props> = ({ userId, value, onChange, savedProfiles, onSaveProfile, onDeleteProfile, onSelectProfile, branding, onBackToHub }) => {
  const [activeTab, setActiveTab] = useState<'standard' | 'advanced' | 'profiles'>('standard');
  const [profileName, setProfileName] = useState("");
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [activeAdvancedGroup, setActiveAdvancedGroup] = useState(0);
  const blueprintRef = useRef<HTMLDivElement>(null);

  const handleFieldChange = (field: string, val: number) => {
    onChange({ ...value, [field]: val });
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    
    // Check if storage is initialized
    if (!storage) {
        alert("⚠️ خدمة التخزين السحابي غير متصلة. التطبيق يعمل في وضع غير متصل.");
        // Optional: Local object URL preview
        const file = e.target.files[0];
        const localUrl = URL.createObjectURL(file);
        setImageUrl(localUrl);
        return;
    }

    const file = e.target.files[0];
    const storageRef = ref(storage, `clients/${userId}/profile.jpg`);
    try {
      await uploadBytes(storageRef, file);
      const url = await getDownloadURL(storageRef);
      setImageUrl(url);
      alert("✅ تم تحميل الصورة بنجاح!");
    } catch (error) {
      console.error("Error uploading image:", error);
      alert("❌ فشل تحميل الصورة.");
    }
  };

  const exportPDF = async () => {
    const doc = new jsPDF();
    
    // Add Branding Header
    doc.setFontSize(22);
    doc.setTextColor(branding?.primaryColor || '#000000');
    doc.text(branding?.companyName || "تقرير القياسات الفنية", 105, 25, { align: 'center' });
    
    doc.setFontSize(16);
    doc.setTextColor(50, 50, 50);
    doc.text("تقرير القياسات الفنية للعميل", 105, 45, { align: 'center' });
    
    let y = 60; // Cursor for text measurements on the Left side
    let visualY = 60; // Cursor for images on the Right side

    // --- 1. Measurements List (Right aligned for Arabic PDF, positioned on left of page visually) ---
    doc.setFontSize(12);
    doc.setTextColor(0, 0, 0);

    Object.entries(value).forEach(([k, v]) => {
      // Find Arabic Label
      let arabicLabel = k;
      for (const group of MEASUREMENT_GROUPS_AR) {
        if ((group.fields as any)[k]) {
          arabicLabel = (group.fields as any)[k];
          break;
        }
      }

      if (v) {
        // If we hit bottom of page
        if (y > 270) {
           doc.addPage();
           y = 20;
           visualY = 20;
        }
        // X=190 aligns to right side of page (Arabic standard), measurements list
        doc.text(`${arabicLabel}: ${v} cm`, 190, y, { align: 'right' });
        y += 8;
      }
    });

    // --- 2. Visuals (Images & Blueprint) positioned on the Left/Center ---
    
    // Add Client Image if available
    if (imageUrl) {
      try {
        // Position image at x=20 (Left side)
        doc.addImage(imageUrl, "JPEG", 20, visualY, 70, 90); 
        visualY += 100; 
      } catch (e) {
        console.warn("Could not add image to PDF", e);
      }
    }

    // Add Blueprint SVG
    if (blueprintRef.current) {
        const svgElement = blueprintRef.current.querySelector("svg");
        if (svgElement) {
            try {
                // Serialize SVG to XML string
                const svgData = new XMLSerializer().serializeToString(svgElement);
                
                // Replace "currentColor" with the primary color (or black) ensuring visibility on white PDF
                const coloredSvgData = svgData.replace(/currentColor/g, branding?.primaryColor || '#000000');

                // Create a temporary canvas to rasterize the SVG
                const canvas = document.createElement("canvas");
                const ctx = canvas.getContext("2d");
                const img = new Image();
                const svgBlob = new Blob([coloredSvgData], { type: "image/svg+xml;charset=utf-8" });
                const url = URL.createObjectURL(svgBlob);

                await new Promise<void>((resolve) => {
                    img.onload = () => {
                        canvas.width = 1000;
                        canvas.height = 1500;
                        if (ctx) {
                            ctx.fillStyle = "#ffffff"; // White background
                            ctx.fillRect(0, 0, canvas.width, canvas.height);
                            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                            const imgData = canvas.toDataURL("image/png");
                            
                            // Check for page break
                            if (visualY + 110 > 280) {
                                doc.addPage();
                                visualY = 20;
                            }
                            
                            doc.setFontSize(10);
                            doc.text("المخطط الهندسي (Blueprint):", 55, visualY - 5, { align: 'center' });
                            doc.addImage(imgData, 'PNG', 20, visualY, 70, 105);
                        }
                        URL.revokeObjectURL(url);
                        resolve();
                    };
                    img.src = url;
                });
            } catch (e) {
                console.error("Error adding blueprint to PDF", e);
            }
        }
    }

    doc.save("measurements.pdf");
  };

  const exportPNG = () => {
    if (!blueprintRef.current) return;
    const svgElement = blueprintRef.current.querySelector("svg");
    if (!svgElement) return;

    const svgData = new XMLSerializer().serializeToString(svgElement);
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d")!;
    const img = new Image();
    const svgBlob = new Blob([svgData], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(svgBlob);

    img.onload = () => {
      canvas.width = 1200;
      canvas.height = 1800;
      ctx.fillStyle = "#ffffff";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 100, 100, 1000, 1600);
      URL.revokeObjectURL(url);
      const link = document.createElement("a");
      link.href = canvas.toDataURL("image/png");
      link.download = "measurements_blueprint.png";
      link.click();
    };
    img.src = url;
  };

  const renderBlueprint = () => (
    <div ref={blueprintRef} className="relative w-full aspect-[2/3] bg-slate-800/20 rounded-3xl border border-white/5 flex items-center justify-center p-4 overflow-hidden">
      <svg viewBox="0 0 100 150" className="w-full h-full text-primary opacity-40">
        <path d="M50 10 L60 20 L65 40 L85 40 L80 140 L20 140 L15 40 L35 40 L40 20 Z" fill="none" stroke="currentColor" strokeWidth="0.5" strokeDasharray="2,2" />
        <circle cx="50" cy="8" r="5" fill="none" stroke="currentColor" strokeWidth="0.5" />
        <line x1="30" y1="50" x2="70" y2="50" stroke="currentColor" strokeWidth="1" />
        <text x="50" y="48" fontSize="3" textAnchor="middle" fill="currentColor">CHEST: {value.chest}cm</text>
        <line x1="35" y1="80" x2="65" y2="80" stroke="currentColor" strokeWidth="1" />
        <text x="50" y="78" fontSize="3" textAnchor="middle" fill="currentColor">WAIST: {value.waist}cm</text>
      </svg>
    </div>
  );

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6 sm:space-y-10 animate-in fade-in duration-1000 pb-20 relative">
      <button 
        onClick={onBackToHub} 
        className="absolute top-0 right-0 px-4 sm:px-6 py-2 sm:py-3 rounded-2xl bg-slate-800 text-slate-400 flex items-center gap-2 hover:bg-slate-700 transition-all border border-white/5 text-xs sm:text-sm font-black z-20"
      >
        <span className="text-lg sm:text-xl">🏠</span>
        <span className="hidden sm:inline">العودة للقائمة الرئيسية</span>
        <span className="sm:hidden">خروج</span>
      </button>

      {/* Adjusted tab buttons for better mobile responsiveness */}
      <div className="flex bg-slate-900/80 backdrop-blur-2xl p-1.5 sm:p-2 rounded-3xl border border-white/5 w-full md:w-fit mx-auto shadow-2xl overflow-x-auto no-scrollbar">
        <button onClick={() => setActiveTab('standard')} className={`flex-1 px-4 sm:px-10 py-3 rounded-2xl font-black text-[10px] sm:text-xs whitespace-nowrap transition-all ${activeTab === 'standard' ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}>مقاسات جاهزة</button>
        <button onClick={() => setActiveTab('advanced')} className={`flex-1 px-4 sm:px-10 py-3 rounded-2xl font-black text-[10px] sm:text-xs whitespace-nowrap transition-all ${activeTab === 'advanced' ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}>المنهج الفني</button>
        <button onClick={() => setActiveTab('profiles')} className={`flex-1 px-4 sm:px-10 py-3 rounded-2xl font-black text-[10px] sm:text-xs whitespace-nowrap transition-all ${activeTab === 'profiles' ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}>الأرشيف</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8">
        <div className="lg:col-span-8 bg-slate-900 rounded-[2.5rem] sm:rounded-[4rem] p-6 sm:p-10 border border-white/5 shadow-2xl min-h-[500px] sm:min-h-[600px]">
          {activeTab === 'standard' && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 py-6 sm:py-10">
              {Object.keys(STANDARD_SIZES).map((size) => (
                <button key={size} onClick={() => onSelectProfile(STANDARD_SIZES[size])} className={`group py-10 sm:py-20 rounded-[2rem] sm:rounded-[3rem] border-2 transition-all ${JSON.stringify(value) === JSON.stringify(STANDARD_SIZES[size]) ? 'border-primary bg-primary/5 text-primary scale-105 shadow-2xl' : 'border-white/5 bg-slate-800/40 text-slate-500'}`}>
                  <span className="text-4xl sm:text-6xl font-black mb-2 block">{size}</span>
                  <span className="text-[9px] sm:text-[10px] font-bold uppercase tracking-widest">Standard Fit</span>
                </button>
              ))}
            </div>
          )}

          {activeTab === 'advanced' && (
             <div className="space-y-8 sm:space-y-12 max-h-[700px] overflow-y-auto no-scrollbar pr-0 sm:pr-2">
                <div className="flex bg-slate-800 p-1.5 sm:p-2 rounded-2xl border border-white/5 w-full mx-auto shadow-lg mb-8 overflow-x-auto no-scrollbar">
                {MEASUREMENT_GROUPS_AR.map((group, idx) => (
                  <button 
                    key={idx} 
                    onClick={() => setActiveAdvancedGroup(idx)}
                    className={`flex-1 px-4 sm:px-6 py-2 rounded-xl text-[10px] font-black whitespace-nowrap transition-all ${activeAdvancedGroup === idx ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}
                  >
                    {group.title}
                  </button>
                ))}
              </div>

              {MEASUREMENT_GROUPS_AR.map((group, idx) => (
                <div key={idx} className={`${activeAdvancedGroup === idx ? 'block' : 'hidden'} space-y-6`}>
                  <h3 className="text-lg sm:text-xl font-black text-white flex items-center gap-3">
                    <span className="w-1.5 sm:w-2 h-6 bg-primary rounded-full"></span>
                    {group.title}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-6">
                    {Object.entries(group.fields).map(([field, label]) => (
                      <div key={field} className="space-y-3 group">
                        <div className="flex justify-between items-center text-[10px] font-black text-slate-500 uppercase tracking-widest group-hover:text-primary transition-colors">
                          <label>{label}</label>
                          <span className="text-primary">{(value as any)[field] || 0} سم</span>
                        </div>
                        <input 
                          type="range" 
                          min={0} 
                          max={250} 
                          value={(value as any)[field] || 0} 
                          onChange={(e) => handleFieldChange(field, parseInt(e.target.value))} 
                          className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-primary" 
                        />
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}

          {activeTab === 'profiles' && (
            <div className="grid grid-cols-1 gap-4">
              {savedProfiles.length === 0 ? (
                <div className="py-20 sm:py-40 text-center opacity-30">
                  <span className="text-6xl sm:text-8xl block mb-4">📭</span>
                  <p className="font-black text-lg sm:text-xl">لا توجد ملفات مقاسات محفوظة</p>
                </div>
              ) : savedProfiles.map(p => (
                <div key={p.id} className="p-6 sm:p-8 bg-slate-800/40 rounded-[2rem] sm:rounded-[3rem] border border-white/5 flex flex-col sm:flex-row items-center justify-between gap-4 group hover:border-primary/30 transition-all">
                  <div className="text-center sm:text-right w-full sm:w-auto">
                    <h5 className="text-white font-black text-lg sm:text-xl mb-1">{p.name}</h5>
                    <span className="text-[10px] font-black text-slate-500 uppercase">{new Date(p.createdAt).toLocaleDateString('ar-SA')}</span>
                  </div>
                  <div className="flex gap-3 w-full sm:w-auto">
                    <button onClick={() => onSelectProfile(p.measurements)} className="flex-1 sm:flex-none bg-primary px-6 sm:px-10 py-3 sm:py-4 rounded-2xl text-white font-black text-xs shadow-xl active:scale-95 transition-all">استخدام</button>
                    <button onClick={() => onDeleteProfile(p.id)} className="bg-red-500/10 text-red-500 px-4 sm:px-6 py-3 sm:py-4 rounded-2xl hover:bg-red-500 hover:text-white transition-all">🗑️</button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="lg:col-span-4 space-y-6 sm:space-y-8">
           <div className="bg-slate-900 rounded-[2.5rem] sm:rounded-[3.5rem] p-6 sm:p-10 border border-white/5 shadow-2xl space-y-6">
            <h3 className="text-xl sm:text-2xl font-black text-white mb-6">صورة العميل / الموديل</h3>
            
            <div className="grid grid-cols-3 gap-2 mb-4">
                {modelLibrary.map((model, i) => (
                    <button key={i} onClick={() => setImageUrl(model.url)} className="p-2 rounded-xl bg-slate-800 hover:bg-primary/20 transition-all border border-white/5">
                        <span className="text-[10px] sm:text-xs text-white">{model.name}</span>
                    </button>
                ))}
            </div>

            <div className="space-y-4">
              <label className="w-full flex flex-col items-center justify-center p-6 sm:p-8 border-2 border-dashed border-white/10 rounded-3xl cursor-pointer hover:bg-white/5 transition-all">
                <span className="text-4xl sm:text-5xl mb-4">📸</span>
                <span className="text-xs sm:text-sm font-bold text-white mb-2">اضغط لرفع صورة</span>
                <span className="text-[9px] sm:text-[10px] text-slate-500 uppercase">JPEG, PNG, GIF</span>
                <input type="file" hidden accept="image/*" onChange={handleImageUpload} />
              </label>
              {imageUrl && (
                <div className="relative w-full aspect-square bg-slate-800 rounded-3xl overflow-hidden border border-white/5">
                  <img src={imageUrl} alt="Client/Model" className="w-full h-full object-contain" />
                  <button onClick={() => setImageUrl(null)} className="absolute top-4 left-4 w-9 h-9 rounded-full bg-red-500/20 text-red-500 flex items-center justify-center text-xs font-black hover:bg-red-500 hover:text-white transition-all">✕</button>
                </div>
              )}
            </div>
          </div>

          <div className="bg-slate-900 rounded-[2.5rem] sm:rounded-[3.5rem] p-6 sm:p-10 border border-white/5 shadow-2xl flex flex-col gap-6 sm:gap-8">
            <h3 className="text-xl sm:text-2xl font-black text-white">تخطيط هندسي</h3>
            {renderBlueprint()}
            <div className="flex gap-2">
               <button onClick={exportPDF} className="flex-1 bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 py-3 sm:py-4 rounded-2xl font-black text-[10px] sm:text-xs hover:bg-emerald-500 hover:text-white transition-all">تصدير PDF</button>
               <button onClick={exportPNG} className="flex-1 bg-primary/10 text-primary border border-primary/20 py-3 sm:py-4 rounded-2xl font-black text-[10px] sm:text-xs hover:bg-primary hover:text-white transition-all">تصدير PNG</button>
            </div>
          </div>
          
          <div className="bg-slate-900 rounded-[2.5rem] sm:rounded-[3.5rem] p-6 sm:p-10 border border-white/5 shadow-2xl space-y-6">
            <input 
              type="text" 
              placeholder="اسم الملف الشخصي..." 
              value={profileName} 
              onChange={(e) => setProfileName(e.target.value)} 
              className="w-full bg-slate-800 border border-white/5 p-4 sm:p-6 rounded-3xl outline-none text-white font-black text-base sm:text-lg" 
            />
            <button onClick={() => { if(profileName) { onSaveProfile(profileName, value); setProfileName(""); } }} className="w-full bg-primary text-white py-4 sm:py-6 rounded-3xl font-black text-lg sm:text-xl shadow-2xl shadow-primary/20 active:scale-95 transition-all">حفظ القياسات ✓</button>
          </div>
        </div>
      </div>
    </div>
  );
};
