
import React from 'react';
import { AppStep } from '../types';

interface Props {
  currentStep: AppStep;
}

const steps = [
  { id: AppStep.GENDER_SELECTION, icon: '🏷️' },
  { id: AppStep.SIZE_INPUT, icon: '📏' },
  { id: AppStep.FABRIC_SELECTION, icon: '🧵' },
  { id: AppStep.COLOR_SELECTION, icon: '🎨' },
  { id: AppStep.STYLE_SELECTION, icon: '👗' },
  { id: AppStep.PATTERN_EDITOR, icon: '📐' },
  { id: AppStep.PREVIEW_3D, icon: '🕶️' },
  { id: AppStep.CHECKOUT, icon: '💳' }
];

export const StepProgressBar: React.FC<Props> = ({ currentStep }) => {
  return (
    <div className="w-full max-w-6xl mx-auto px-4 overflow-x-auto custom-scrollbar no-scrollbar">
      <div className="flex items-center justify-between min-w-[400px] gap-2 px-2">
        {steps.map((step, index) => {
          const isActive = step.id === currentStep;
          const isCompleted = step.id < currentStep;

          return (
            <div key={step.id} className="flex flex-col items-center flex-1">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center text-lg transition-all duration-500 transform ${
                  isActive
                    ? 'bg-primary text-white scale-110 shadow-lg shadow-primary/30 rotate-3'
                    : isCompleted
                    ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                    : 'bg-slate-800 text-slate-500 border border-white/5'
                }`}
              >
                {isCompleted ? '✓' : step.icon}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
