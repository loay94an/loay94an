
import React, { useState } from 'react';
import { Gender, GarmentStyle, Occasion, Season, StyleItem, BrandingSettings } from '../types';

interface Props {
  gender: Gender;
  selected: GarmentStyle | null;
  onSelect: (style: GarmentStyle) => void;
  availableStyles: StyleItem[];
  onBackToHub: () => void; // New prop
  branding: BrandingSettings; // New prop
}

const occasionLabels: Record<Occasion, string> = {
  ALL: 'الكل',
  FORMAL: 'رسمي',
  DAILY: 'يومي',
  SPORTS: 'رياضي',
  EVENING: 'سهرة',
  CEREMONY: 'احتفال'
};

export const StyleSelection: React.FC<Props> = ({ gender, selected, onSelect, availableStyles, onBackToHub, branding }) => {
  const [activeOccasion, setActiveOccasion] = useState<Occasion>('ALL');
  
  const filteredOptions = availableStyles.filter(opt => 
    activeOccasion === 'ALL' || opt.occasion === activeOccasion
  );

  return (
    <div className="w-full space-y-8 relative">
      <button 
        onClick={onBackToHub} 
        className="absolute top-0 right-0 px-6 py-3 rounded-2xl bg-slate-800 text-slate-400 flex items-center gap-2 hover:bg-slate-700 transition-all border border-white/5 text-sm font-black z-20"
      >
        <span className="text-xl">🏠</span>
        <span>العودة للقائمة الرئيسية</span>
      </button>

      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-2 justify-center">
        {Object.keys(occasionLabels).map((occ) => (
          <button
            key={occ}
            onClick={() => setActiveOccasion(occ as Occasion)}
            className={`px-5 py-2.5 rounded-full text-[10px] font-black uppercase tracking-widest transition-all ${
              activeOccasion === occ ? 'bg-primary text-white shadow-lg' : 'bg-slate-900 border border-white/5 text-slate-500'
            }`}
          >
            {occasionLabels[occ as Occasion]}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {filteredOptions.map((opt) => (
          <button
            key={opt.id}
            onClick={() => onSelect(opt.id)}
            className={`flex flex-col items-center gap-4 p-8 rounded-[3rem] bg-slate-900 border-2 transition-all group ${
              selected === opt.id ? 'border-primary ring-4 ring-primary/10' : 'border-white/5 hover:border-white/10'
            }`}
          >
            <div className="w-24 h-24 bg-slate-800 rounded-3xl flex items-center justify-center text-5xl group-hover:scale-110 transition-transform">
              {opt.icon}
            </div>
            <div className="text-center">
              <h3 className="text-xl font-black text-white mb-1">{opt.label}</h3>
              <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest">{opt.description}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};