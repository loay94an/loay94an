
import React, { useState } from 'react';
import { User, BrandingSettings, UserRole } from '../types';

interface Props {
  onLogin: (user: User) => void;
  allUsers: User[]; // List of all registered users
  branding: BrandingSettings;
  onBackToHub: () => void; // New prop
}

export const LoginScreen: React.FC<Props> = ({ onLogin, allUsers, branding, onBackToHub }) => {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    const user = allUsers.find(u => u.username === username && u.password === password);

    if (user) {
      onLogin(user);
    } else {
      setError('اسم المستخدم أو كلمة المرور غير صحيحة.');
    }
  };

  return (
    <div className="min-h-screen bg-dark flex items-center justify-center p-6 animate-in fade-in duration-500" style={{ fontFamily: branding.fontFamily }}>
      <div className="bg-slate-900 rounded-[4rem] p-8 sm:p-12 border border-white/5 shadow-2xl max-w-lg w-full text-center space-y-8 relative">
        <button 
          onClick={onBackToHub} 
          className="absolute top-8 right-8 px-6 py-3 rounded-2xl bg-slate-800 text-slate-400 flex items-center gap-2 hover:bg-slate-700 transition-all border border-white/5 text-sm font-black z-20"
        >
          <span className="text-xl">🏠</span>
          <span>العودة للقائمة الرئيسية</span>
        </button>

        <div className="w-24 h-24 bg-primary rounded-3xl flex items-center justify-center text-5xl mx-auto shadow-2xl rotate-3" style={{ backgroundColor: branding.primaryColor }}>🔐</div>
        <h2 className="text-4xl font-black text-white mb-2" style={{ color: branding.primaryColor }}>تسجيل الدخول</h2>
        <p className="text-slate-500 font-medium mb-10">الرجاء إدخال بيانات الاعتماد للمتابعة إلى لوحة تحكم المطور.</p>

        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2 text-right">
            <label htmlFor="username" className="text-[10px] font-black text-slate-500 uppercase tracking-widest mr-2">اسم المستخدم</label>
            <input
              id="username"
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-slate-800 border border-white/5 p-5 rounded-2xl outline-none focus:ring-2 focus:ring-primary/40 font-bold text-white placeholder:text-slate-700"
              placeholder="البريد الإلكتروني أو اسم المستخدم"
              required
            />
          </div>
          <div className="space-y-2 text-right">
            <label htmlFor="password" className="text-[10px] font-black text-slate-500 uppercase tracking-widest mr-2">كلمة المرور</label>
            <input
              id="password"
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-slate-800 border border-white/5 p-5 rounded-2xl outline-none focus:ring-2 focus:ring-primary/40 font-bold text-white placeholder:text-slate-700"
              placeholder="كلمة المرور"
              required
            />
          </div>

          {error && (
            <div className="bg-red-500/10 text-red-500 p-4 rounded-xl text-sm font-bold border border-red-500/20" role="alert">
              {error}
            </div>
          )}

          <button
            type="submit"
            className="w-full bg-primary text-white py-6 rounded-3xl font-black text-xl shadow-2xl shadow-primary/30 active:scale-95 hover:scale-[1.02] transition-all"
            style={{ backgroundColor: branding.primaryColor }}
          >
            تسجيل الدخول
          </button>
        </form>
      </div>
    </div>
  );
};