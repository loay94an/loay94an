

import React, { useState } from 'react';
import { OrderDetails, Order, BrandingSettings } from '../types';

interface Props {
  orderDetails: OrderDetails;
  onConfirm: (order: Order) => void;
  onBackToHub: () => void; // New prop
  branding: BrandingSettings; // New prop
}

export const Checkout: React.FC<Props> = ({ orderDetails, onConfirm, onBackToHub, branding }) => {
  const [loading, setLoading] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<'CARD' | 'CASH'>('CARD');
  const [customerData, setCustomerData] = useState({
    name: '',
    phone: '',
    address: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      const newOrder: Order = {
        id: `ord-${Date.now()}`, // Unique ID for the order
        customerName: customerData.name,
        phone: customerData.phone,
        address: customerData.address,
        paymentMethod: paymentMethod,
        status: 'PENDING', // Default status for new orders
        createdAt: Date.now(),
        details: orderDetails // Include all design details
      };
      onConfirm(newOrder);
      // Optional: Redirect to success page or clear form
    }, 2000);
  };

  // Safely get style string to prevent TypeError if orderDetails.style is null/undefined
  const garmentStyleString = orderDetails.style ? String(orderDetails.style) : '';

  return (
    <div className="w-full max-w-5xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-12 pb-32 animate-in fade-in duration-700 relative">
      <button 
        onClick={onBackToHub} 
        className="absolute top-0 right-0 px-6 py-3 rounded-2xl bg-slate-800 text-slate-400 flex items-center gap-2 hover:bg-slate-700 transition-all border border-white/5 text-sm font-black z-20"
      >
        <span className="text-xl">🏠</span>
        <span>العودة للقائمة الرئيسية</span>
      </button>

      <div className="lg:col-span-7 space-y-8">
        <div className="bg-slate-900 rounded-[3rem] p-6 sm:p-10 border border-white/5 shadow-2xl">
          <h3 className="text-2xl font-black text-white mb-8">تفاصيل السلة</h3>
          <div className="flex items-center gap-6 p-6 bg-slate-800/40 rounded-3xl border border-white/5">
             <div className="w-24 h-24 bg-slate-800 rounded-2xl flex items-center justify-center text-5xl">
                {/* Fixed TypeError: Cannot read properties of null (reading 'includes') */}
                {(garmentStyleString.includes('SHIRT')) ? '👔' : (garmentStyleString.includes('DRESS')) ? '👗' : '👗'}
             </div>
             <div className="flex-1">
                <h4 className="text-xl font-black text-white">{orderDetails.style.replace('_', ' ')}</h4>
                <p className="text-slate-500 text-sm font-bold uppercase tracking-widest mt-1">{orderDetails.fabric.name}</p>
             </div>
             <div className="text-left">
                <span className="text-2xl font-black text-primary">{orderDetails.totalPrice} ر.س</span>
             </div>
          </div>

          <div className="mt-12 space-y-6">
            <h4 className="text-lg font-black text-white">طريقة الدفع</h4>
            <div className="grid grid-cols-2 gap-4">
              <button 
                type="button"
                onClick={() => setPaymentMethod('CARD')}
                className={`p-6 rounded-2xl border-2 transition-all flex items-center gap-4 ${paymentMethod === 'CARD' ? 'border-primary bg-primary/10' : 'border-white/5 bg-slate-800/40'}`}
              >
                <span className="text-2xl">💳</span>
                <span className="font-black text-sm">بطاقة ائتمان</span>
              </button>
              <button 
                type="button"
                onClick={() => setPaymentMethod('CASH')}
                className={`p-6 rounded-2xl border-2 transition-all flex items-center gap-4 ${paymentMethod === 'CASH' ? 'border-primary bg-primary/10' : 'border-white/5 bg-slate-800/40'}`}
              >
                <span className="text-2xl">💵</span>
                <span className="font-black text-sm">الدفع عند الاستلام</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="lg:col-span-5">
        <form onSubmit={handleSubmit} className="bg-slate-900 rounded-[3rem] p-6 sm:p-10 border border-white/5 shadow-2xl sticky top-32">
          <h3 className="text-2xl font-black text-white mb-8">إتمام الشراء</h3>
          <div className="space-y-6">
             <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mr-2">الاسم الكامل</label>
                <input 
                  required 
                  type="text" 
                  value={customerData.name}
                  onChange={e => setCustomerData({...customerData, name: e.target.value})}
                  className="w-full bg-slate-800 border border-white/5 p-5 rounded-2xl outline-none focus:ring-2 focus:ring-primary/40 font-bold text-white placeholder:text-slate-700" 
                  placeholder="مثال: فهد العتيبي"
                />
             </div>
             <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mr-2">رقم الجوال</label>
                <input 
                  required 
                  type="tel" 
                  value={customerData.phone}
                  onChange={e => setCustomerData({...customerData, phone: e.target.value})}
                  className="w-full bg-slate-800 border border-white/5 p-5 rounded-2xl outline-none focus:ring-2 focus:ring-primary/40 font-bold text-white placeholder:text-slate-700" 
                  placeholder="05xxxxxxx"
                />
             </div>
             <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest mr-2">عنوان الشحن</label>
                <textarea 
                  required
                  value={customerData.address}
                  onChange={e => setCustomerData({...customerData, address: e.target.value})}
                  className="w-full bg-slate-800 border border-white/5 p-5 rounded-2xl outline-none focus:ring-2 focus:ring-primary/40 font-bold text-white placeholder:text-slate-700 h-28"
                  placeholder="المدينة، الحي، اسم الشارع..."
                ></textarea>
             </div>

             <div className="pt-8 border-t border-white/5 space-y-4">
                <div className="flex justify-between items-center text-sm">
                   <span className="text-slate-500 font-bold">المجموع الفرعي</span>
                   <span className="text-white font-black">{orderDetails.totalPrice} ر.س</span>
                </div>
                <div className="flex justify-between items-center text-sm">
                   <span className="text-slate-500 font-bold">الشحن والتوصيل</span>
                   <span className="text-emerald-500 font-black">مجاني</span>
                </div>
                <div className="flex justify-between items-center pt-4">
                   <span className="text-lg font-black text-white">الإجمالي</span>
                   <span className="text-3xl font-black text-primary">{orderDetails.totalPrice} ر.س</span>
                </div>
             </div>

             <button
                type="submit"
                disabled={loading}
                className={`w-full py-6 rounded-3xl font-black text-xl transition-all shadow-2xl mt-8 ${
                  loading ? 'bg-slate-700 text-slate-500' : 'bg-primary text-white shadow-primary/30 active:scale-95 hover:scale-[1.02]'
                }`}
              >
                {loading ? 'جاري تأكيد الطلب...' : 'تأكيد الشراء الآن 🛍️'}
             </button>
          </div>
        </form>
      </div>
    </div>
  );
};