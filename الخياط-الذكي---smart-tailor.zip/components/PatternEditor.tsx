
import React, { useState, useRef } from 'react';
import { Measurements, Gender, GarmentStyle, SleeveType, CollarType, BrandingSettings } from '../types';
import { FullPatternService } from '../FullPatternService';
import jsPDF from 'jspdf';

interface Props {
  gender: Gender;
  style: GarmentStyle;
  measurements: Measurements;
  onUpdate: (m: Measurements) => void;
  branding?: BrandingSettings;
  onBackToHub: () => void; // New prop
}

export const PatternEditor: React.FC<Props> = ({ gender, style, measurements, onUpdate, branding: propBranding, onBackToHub }) => {
  const [seamAllowance, setSeamAllowance] = useState(1.5);
  const [ease, setEase] = useState(2.5);
  const [activeSleeve, setActiveSleeve] = useState<SleeveType>(SleeveType.BASIC);
  const [activeCollar, setActiveCollar] = useState<CollarType>(CollarType.MANDARIN);
  const [zoom, setZoom] = useState(0.85);
  const [view, setView] = useState<'front' | 'back' | 'sleeve' | 'collar'>('front');
  const svgRef = useRef<SVGSVGElement>(null);
  
  const branding = propBranding || {
    companyName: "الخياط الذكي برو",
    logoUrl: "",
    primaryColor: "#2563eb",
    logoPosition: "top-right"
  };

  const scale = 2.0;

  const getPatternPath = () => {
    if (view === 'collar') return FullPatternService.generateCollar(activeCollar, measurements, scale);
    if (view === 'sleeve') return FullPatternService.generateSleeve(activeSleeve, measurements, scale);
    if (style === GarmentStyle.PANTS) return FullPatternService.generatePants(gender, view === 'front', measurements, ease, scale);
    return FullPatternService.generateBodice(gender, view === 'front', measurements, ease, scale, style);
  };

  const handleManualAdjustment = (field: keyof Measurements, delta: number) => {
    onUpdate({ ...measurements, [field]: Math.max(0, ((measurements[field] as number) || 0) + delta) });
  };

  const exportPDF = () => {
    const doc = new jsPDF('p', 'mm', 'a4');
    doc.setTextColor(branding.primaryColor);
    doc.setFontSize(24);
    doc.text(branding.companyName, 105, 20, { align: 'center' });
    doc.setFontSize(14);
    doc.setTextColor(50, 50, 50);
    doc.text(`بترون تخصصي: ${style.replace('_', ' ')} - ${view === 'front' ? 'الأمام' : 'الخلف'}`, 20, 40);
    
    doc.setFontSize(10);
    doc.text("القياسات الفنية المعتمدة:", 20, 55);
    const mEntries = Object.entries(measurements).filter(([_, v]) => typeof v === 'number' && (v as number) > 0);
    mEntries.forEach(([k, v], i) => {
      doc.text(`${k}: ${v}cm`, 20, 65 + (i * 5));
    });

    doc.save(`smart_tailor_pattern_${style}.pdf`);
  };

  return (
    <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-8 animate-in fade-in duration-700 relative">
      <button 
        onClick={onBackToHub} 
        className="absolute top-8 right-8 px-6 py-3 rounded-2xl bg-slate-800 text-slate-400 flex items-center gap-2 hover:bg-slate-700 transition-all border border-white/5 text-sm font-black z-20"
      >
        <span className="text-xl">🏠</span>
        <span>العودة للقائمة الرئيسية</span>
      </button>

      <div className="lg:col-span-8 flex flex-col gap-6">
        {/* Adjusted tab buttons for better mobile responsiveness */}
        <div className="flex bg-slate-900/60 p-2 rounded-3xl border border-white/5 shadow-2xl backdrop-blur-xl overflow-x-auto no-scrollbar">
          <TabBtn active={view === 'front'} onClick={() => setView('front')} label="الأمام" />
          <TabBtn active={view === 'back'} onClick={() => setView('back')} label="الخلف" />
          <TabBtn active={view === 'sleeve'} onClick={() => setView('sleeve')} label="الأكمام" />
          <TabBtn active={view === 'collar'} onClick={() => setView('collar')} label="الياقة" />
        </div>

        <div className="relative bg-slate-950 rounded-[4rem] h-[500px] lg:h-[700px] border-4 border-slate-900 overflow-hidden flex items-center justify-center shadow-2xl">
          <div className="absolute top-8 left-8 z-20 flex flex-col gap-3">
             <button onClick={exportPDF} className="bg-primary hover:bg-blue-600 text-white px-8 py-4 rounded-2xl font-black text-xs shadow-2xl transition-all">تصدير PDF 📄</button>
          </div>

          <div className="transition-transform duration-700 ease-[cubic-bezier(0.23,1,0.32,1)]" style={{ transform: `scale(${zoom})` }}>
             <svg ref={svgRef} width="450" height="750" viewBox="-50 -50 400 750" className="drop-shadow-[0_0_80px_rgba(37,99,235,0.2)]">
                <path d={getPatternPath()} fill="none" stroke={branding.primaryColor} strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" />
             </svg>
          </div>
        </div>
      </div>

      <div className="lg:col-span-4 flex flex-col gap-6">
        <div className="bg-slate-900/80 backdrop-blur-3xl rounded-[3.5rem] p-6 sm:p-10 border border-white/5 shadow-2xl h-full flex flex-col">
          <h3 className="text-xl font-black text-white mb-10 flex items-center gap-3">
             <span className="w-2 h-8 bg-primary rounded-full"></span>
             جدول تعديل القياسات
          </h3>
          
          <div className="space-y-8 flex-1 overflow-y-auto no-scrollbar pr-2">
            <div className="bg-slate-800/40 rounded-3xl p-6 border border-white/5 space-y-4">
              <AdjustmentItem label="محيط الصدر" field="chest" value={measurements.chest} onAdjust={handleManualAdjustment} />
              <AdjustmentItem label="محيط الخصر" field="waist" value={measurements.waist} onAdjust={handleManualAdjustment} />
              <AdjustmentItem label="محيط الورك" field="hips" value={measurements.hips} onAdjust={handleManualAdjustment} />
              <AdjustmentItem label="عرض الكتف" field="shoulderWidth" value={measurements.shoulderWidth} onAdjust={handleManualAdjustment} />
              <AdjustmentItem label="طول الكم" field="armLength" value={measurements.armLength} onAdjust={handleManualAdjustment} />
            </div>
            
            <div className="pt-6 border-t border-white/10 space-y-8">
               <RangeControl label="نسبة الراحة (Ease)" value={ease} min={0} max={20} onChange={setEase} />
               <RangeControl label="الزوم (Zoom)" value={zoom} min={0.5} max={1.5} onChange={setZoom} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const TabBtn = ({ active, onClick, label }: any) => (
  <button onClick={onClick} className={`flex-1 py-4 px-6 rounded-2xl text-[11px] font-black transition-all ${active ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}>{label}</button>
);

const AdjustmentItem = ({ label, field, value, onAdjust }: any) => (
  <div className="flex items-center justify-between group">
    <div className="text-right">
       <span className="text-[10px] font-black text-slate-500 block uppercase tracking-wider">{label}</span>
       <span className="text-white font-black text-lg tracking-tighter">{value} <small className="text-[10px] opacity-40">سم</small></span>
    </div>
    <div className="flex gap-2">
       <button onClick={() => onAdjust(field, -1)} className="w-9 h-9 rounded-xl bg-slate-900 text-white font-black flex items-center justify-center border border-white/5 hover:bg-slate-700 transition-all active:scale-90">-</button>
       <button onClick={() => onAdjust(field, 1)} className="w-9 h-9 rounded-xl bg-slate-900 text-white font-black flex items-center justify-center border border-white/5 hover:bg-slate-700 transition-all active:scale-90">+</button>
    </div>
  </div>
);

const RangeControl = ({ label, value, min, max, onChange }: any) => (
  <div className="space-y-4">
    <div className="flex justify-between text-[11px] font-black text-slate-400">
      <span className="text-primary">{typeof value === 'number' ? value.toFixed(1) : value} سم</span>
      <span className="uppercase tracking-widest">{label}</span>
    </div>
    <input type="range" min={min} max={max} step={0.1} value={value} onChange={(e) => onChange(parseFloat(e.target.value))} className="w-full h-1.5 bg-slate-800 rounded-xl appearance-none cursor-pointer accent-primary" />
  </div>
);