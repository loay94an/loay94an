
import React, { useState } from 'react';
import { Fabric, BrandingSettings } from '../types';
// Removed direct import from constants, now using props
// import { INITIAL_FABRICS as FABRICS } from '../constants';

interface Props {
  selected: Fabric | null;
  onSelect: (fabric: Fabric) => void;
  fabrics: Fabric[]; // Added fabrics prop
  onBackToHub: () => void; // New prop
  branding: BrandingSettings; // New prop
}

export const FabricSelection: React.FC<Props> = ({ selected, onSelect, fabrics, onBackToHub, branding }) => {
  const [hovered, setHovered] = useState<string | null>(null);

  return (
    <div className="w-full space-y-12 animate-in fade-in duration-700 relative">
      <button 
        onClick={onBackToHub} 
        className="absolute top-0 right-0 px-6 py-3 rounded-2xl bg-slate-800 text-slate-400 flex items-center gap-2 hover:bg-slate-700 transition-all border border-white/5 text-sm font-black z-20"
      >
        <span className="text-xl">🏠</span>
        <span>العودة للقائمة الرئيسية</span>
      </button>

      <div className="text-center space-y-3">
        <h2 className="text-3xl font-black text-white">مكتبة الأقمشة الفاخرة</h2>
        <p className="text-slate-500 font-medium">اختر النسيج الذي يتناسب مع رؤيتك وتصميمك</p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 px-2">
        {fabrics.map((fabric) => (
          <div
            key={fabric.id}
            onClick={() => onSelect(fabric)}
            onMouseEnter={() => setHovered(fabric.id)}
            onMouseLeave={() => setHovered(null)}
            className={`relative bg-slate-900 rounded-[2.5rem] border-2 transition-all group cursor-pointer overflow-hidden ${
              selected?.id === fabric.id ? 'border-primary ring-4 ring-primary/10 scale-105 shadow-2xl z-10' : 'border-white/5 hover:border-white/10'
            }`}
          >
            <div className="h-48 sm:h-64 relative overflow-hidden">
              <img src={fabric.image} alt={fabric.name} className="w-full h-full object-cover group-hover:scale-125 transition-transform duration-1000" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-950/90 via-slate-950/20 to-transparent"></div>
              
              <div className="absolute top-4 right-4">
                <span className="text-[10px] font-black uppercase tracking-widest bg-primary px-3 py-1.5 rounded-full shadow-lg">
                  {fabric.material}
                </span>
              </div>

              <div className="absolute bottom-4 left-4 right-4">
                 <h3 className="text-xl font-black text-white">{fabric.name}</h3>
              </div>
            </div>

            <div className="p-6 space-y-6">
              <p className="text-slate-400 text-xs font-medium leading-relaxed h-10 overflow-hidden line-clamp-2">
                {fabric.description}
              </p>
              
              <div className="space-y-3 pt-4 border-t border-white/5">
                <PropertyRow label="المرونة" value={fabric.properties.stretch} />
                <PropertyRow label="المسامية" value={fabric.properties.breathability} />
                <PropertyRow label="المتانة" value={fabric.properties.durability} />
              </div>

              <div className="flex items-center justify-between pt-2">
                <div className="flex gap-1.5">
                   {Array.from({ length: 3 }).map((_, i) => (
                     <div key={i} className={`w-1.5 h-1.5 rounded-full ${i < (fabric.thickness === 'thin' ? 1 : fabric.thickness === 'medium' ? 2 : 3) ? 'bg-primary' : 'bg-slate-800'}`}></div>
                   ))}
                </div>
                <span className="text-[9px] font-black text-slate-500 uppercase tracking-widest">مستوى السماكة</span>
              </div>
            </div>

            {selected?.id === fabric.id && (
              <div className="absolute inset-0 border-4 border-primary/20 pointer-events-none rounded-[2.5rem]"></div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

const PropertyRow = ({ label, value }: { label: string, value: string }) => (
  <div className="flex justify-between items-center text-[10px] font-bold">
    <span className="text-slate-500 uppercase tracking-widest">{label}</span>
    <span className="text-slate-300">{value}</span>
  </div>
);