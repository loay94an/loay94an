
import React, { useState } from 'react';
import { Fabric, FabricColor, StyleItem, PricingRule, Order, BrandingSettings, SectionConfig, ActivityLog, Gender, GarmentStyle, User, UserRole } from '../types';
import jsPDF from 'jspdf';
import 'jspdf-autotable';
import { StatsDashboard } from './StatsDashboard'; // Import StatsDashboard
import { Firestore } from 'firebase/firestore'; // Import Firestore type

interface Props {
  fabrics: Fabric[];
  setFabrics: (f: Fabric[]) => void;
  styles: StyleItem[];
  setStyles: (s: StyleItem[]) => void;
  colors: FabricColor[];
  setColors: (c: FabricColor[]) => void;
  pricing: PricingRule[];
  setPricing: (p: PricingRule[]) => void;
  orders: Order[];
  setOrders: (o: Order[]) => void;
  branding: BrandingSettings;
  setBranding: (b: BrandingSettings) => void;
  config: SectionConfig;
  setConfig: (c: SectionConfig) => void;
  onClose: () => void;
  activityLogs: ActivityLog[];
  currentUser: User; // Currently logged-in user
  allUsers: User[]; // All registered users
  onAddUser: (username: string, password: string, role: UserRole) => void;
  onUpdateUserRole: (userId: string, newRole: UserRole) => void; // New prop
  onDeleteUser: (userId: string) => void; // New prop
  onLogout: () => void; // Logout function
  db: Firestore; // Pass db to DevDashboard
}

export const DevDashboard: React.FC<Props> = ({ 
  fabrics, setFabrics, styles, setStyles, colors, setColors, pricing, setPricing,
  orders, setOrders, branding, setBranding, config, setConfig, onClose, activityLogs,
  currentUser, allUsers, onAddUser, onUpdateUserRole, onDeleteUser, onLogout, db
}) => {
  const [activeTab, setActiveTab] = useState<'BRANDING' | 'LOGS' | 'PRICING' | 'FABRICS' | 'STYLES' | 'COLORS' | 'ORDERS' | 'CONFIG' | 'USER_MANAGEMENT'>('BRANDING');
  const [isSidebarOpen, setIsSidebarOpen] = useState(false); // State for mobile sidebar visibility

  // State for adding new user
  const [newUsername, setNewUsername] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [newUserRole, setNewUserRole] = useState<UserRole>(UserRole.ASSISTANT);

  const exportLogs = () => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.text("سجل نشاطات النظام", 105, 20, { align: 'center' });
    doc.setFontSize(10);
    activityLogs.forEach((log, i) => {
       doc.text(`${new Date(log.timestamp).toLocaleString()} - ${log.action}: ${log.details}`, 14, 40 + (i * 10));
    });
    doc.save("activity_log.pdf");
  };

  const handleSidebarToggle = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const handleTabClick = (tab: 'BRANDING' | 'LOGS' | 'PRICING' | 'FABRICS' | 'STYLES' | 'COLORS' | 'ORDERS' | 'CONFIG' | 'USER_MANAGEMENT') => {
    setActiveTab(tab);
    setIsSidebarOpen(false); // Close sidebar on tab click for mobile
  };

  const dummyAdd = (itemType: string) => alert(`Functionality to add ${itemType} will be implemented here.`);
  const dummyEdit = (itemType: string, id: string) => alert(`Functionality to edit ${itemType} with ID: ${id} will be implemented here.`);
  const dummyDelete = (itemType: string, id: string) => alert(`Functionality to delete ${itemType} with ID: ${id} will be implemented here.`);

  const handleAddNewUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (newUsername && newPassword) {
      onAddUser(newUsername, newPassword, newUserRole);
      setNewUsername('');
      setNewPassword('');
      setNewUserRole(UserRole.ASSISTANT); // Reset to default
    } else {
      alert("الرجاء إدخال اسم المستخدم وكلمة المرور.");
    }
  };


  return (
    <div className="fixed inset-0 z-[500] bg-dark flex flex-col animate-in fade-in duration-300 overflow-hidden" dir="rtl">
      {/* Overlay for mobile sidebar */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-[550] lg:hidden" 
          onClick={handleSidebarToggle}
        ></div>
      )}

      <div className="flex h-full">
        {/* Sidebar */}
        <aside className={`fixed inset-y-0 right-0 w-80 bg-slate-900 border-l border-white/5 p-8 flex flex-col gap-6 
                           lg:static lg:translate-x-0 z-[600] 
                           transform transition-transform duration-300 ease-in-out 
                           ${isSidebarOpen ? 'translate-x-0' : 'translate-x-full'}`}>
           <div className="mb-10 text-center">
              <div className="w-20 h-20 bg-primary rounded-3xl flex items-center justify-center text-4xl mx-auto mb-4 shadow-2xl">⚙️</div>
              <h2 className="text-2xl font-black text-white">إدارة المنشأة</h2>
              <p className="text-slate-500 text-sm">{currentUser.username} ({currentUser.role === UserRole.ADMIN ? 'مدير' : 'مساعد'})</p>
           </div>
           <nav className="flex-1 space-y-2 overflow-y-auto custom-scrollbar">
              <SidebarBtn active={activeTab === 'BRANDING'} onClick={() => handleTabClick('BRANDING')} icon="🏢" label="إعدادات الهوية" />
              <SidebarBtn active={activeTab === 'LOGS'} onClick={() => handleTabClick('LOGS')} icon="📋" label="سجل النشاطات" />
              <SidebarBtn active={activeTab === 'FABRICS'} onClick={() => handleTabClick('FABRICS')} icon="🧵" label="إدارة الأقمشة" />
              <SidebarBtn active={activeTab === 'STYLES'} onClick={() => handleTabClick('STYLES')} icon="👗" label="إدارة الموديلات" />
              <SidebarBtn active={activeTab === 'COLORS'} onClick={() => handleTabClick('COLORS')} icon="🎨" label="إدارة الألوان" />
              <SidebarBtn active={activeTab === 'PRICING'} onClick={() => handleTabClick('PRICING')} icon="💰" label="إدارة الأسعار" />
              <SidebarBtn active={activeTab === 'ORDERS'} onClick={() => handleTabClick('ORDERS')} icon="📦" label="إحصائيات الطلبات" />
              <SidebarBtn active={activeTab === 'CONFIG'} onClick={() => handleTabClick('CONFIG')} icon="⚙️" label="الإعدادات العامة" />
              {currentUser.role === UserRole.ADMIN && (
                <SidebarBtn active={activeTab === 'USER_MANAGEMENT'} onClick={() => handleTabClick('USER_MANAGEMENT')} icon="👥" label="إدارة المستخدمين" />
              )}
           </nav>
           
           <div className="space-y-3 mt-4">
               <button onClick={onClose} className="w-full flex items-center justify-center gap-3 py-4 bg-slate-800 text-slate-300 rounded-3xl font-black text-xs hover:bg-slate-700 hover:text-white transition-all border border-white/5">
                 <span className="text-lg">🏠</span>
                 <span>العودة للرئيسية</span>
               </button>
               <button onClick={onLogout} className="w-full flex items-center justify-center gap-3 py-4 bg-red-500/10 text-red-500 rounded-3xl font-black text-xs hover:bg-red-500 hover:text-white transition-all border border-red-500/10">
                 <span className="text-lg">🚪</span>
                 <span>تسجيل الخروج</span>
               </button>
           </div>

        </aside>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-4 sm:p-12 bg-dark/20 backdrop-blur-3xl custom-scrollbar lg:mr-80">
           {/* Hamburger menu for mobile */}
           <button 
             onClick={handleSidebarToggle}
             className="lg:hidden fixed top-6 left-6 z-[601] w-12 h-12 rounded-full bg-slate-800 text-white flex items-center justify-center text-2xl shadow-lg"
           >
             ☰
           </button>

           {activeTab === 'BRANDING' && (
             <section className="max-w-4xl mx-auto space-y-12">
                <div className="bg-slate-900 p-8 sm:p-12 rounded-[4rem] border border-white/5 shadow-2xl space-y-8">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">إعدادات الهوية (Branding)</h3>
                   
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                      <div className="space-y-4">
                         <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">اسم الشركة</label>
                         <input value={branding.companyName} onChange={(e) => setBranding({...branding, companyName: e.target.value})} className="w-full bg-slate-800 border border-white/5 p-6 rounded-3xl text-white font-black" />
                      </div>
                      <div className="space-y-4">
                         <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">الخط الافتراضي</label>
                         <select value={branding.fontFamily} onChange={(e) => setBranding({...branding, fontFamily: e.target.value})} className="w-full bg-slate-800 border border-white/5 p-6 rounded-3xl text-white font-black outline-none">
                            <option value="Tajawal">Tajawal (Default)</option>
                            <option value="Arial">Arial</option>
                            <option value="Cairo">Cairo</option>
                         </select>
                      </div>
                      <div className="space-y-4">
                         <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">اللون الأساسي</label>
                         <div className="flex gap-4 items-center bg-slate-800 p-3 rounded-2xl border border-white/5">
                            <input type="color" value={branding.primaryColor} onChange={(e) => setBranding({...branding, primaryColor: e.target.value})} className="h-14 w-20 bg-transparent border-none cursor-pointer" />
                            <span className="text-white font-mono text-xs">{branding.primaryColor}</span>
                         </div>
                      </div>
                      <div className="space-y-4">
                         <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">اللون الثانوي</label>
                         <div className="flex gap-4 items-center bg-slate-800 p-3 rounded-2xl border border-white/5">
                            <input type="color" value={branding.secondaryColor} onChange={(e) => setBranding({...branding, secondaryColor: e.target.value})} className="h-14 w-20 bg-transparent border-none cursor-pointer" />
                            <span className="text-white font-mono text-xs">{branding.secondaryColor}</span>
                         </div>
                      </div>
                   </div>

                   <div className="space-y-4">
                      <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">رابط الشعار (Logo URL)</label>
                      <input value={branding.logoUrl} onChange={(e) => setBranding({...branding, logoUrl: e.target.value})} placeholder="https://..." className="w-full bg-slate-800 border border-white/5 p-6 rounded-3xl text-white font-black" />
                   </div>

                   <button onClick={() => alert("✅ تم حفظ إعدادات الهوية")} className="w-full bg-primary py-7 rounded-3xl font-black text-white text-xl shadow-2xl active:scale-95 transition-all">حفظ الإعدادات</button>
                </div>
             </section>
           )}

           {activeTab === 'LOGS' && (
             <section className="max-w-5xl mx-auto space-y-8">
                <div className="flex justify-between items-center flex-col sm:flex-row gap-4 sm:gap-0">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">سجل النشاطات الأخير</h3>
                   <button onClick={exportLogs} className="bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 px-8 py-4 rounded-2xl font-black text-xs hover:bg-emerald-500 hover:text-white transition-all w-full sm:w-auto">تصدير PDF سجل</button>
                </div>
                <div className="space-y-4">
                   {activityLogs.map(log => (
                     <div key={log.id} className="p-6 sm:p-8 bg-slate-900 border border-white/5 rounded-[2.5rem] flex flex-col sm:flex-row justify-between sm:items-center group hover:border-primary/30 transition-all gap-4">
                        <div>
                           <h4 className="text-lg sm:text-xl font-black text-white mb-1 sm:mb-2">{log.action}</h4>
                           <p className="text-slate-500 text-sm font-bold">{log.details}</p>
                        </div>
                        <div className="text-right sm:text-left">
                           <span className="text-xs font-black text-slate-600 block mb-1 uppercase tracking-widest">{new Date(log.timestamp).toLocaleDateString()}</span>
                           <span className="text-primary font-black text-lg">{new Date(log.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
                        </div>
                     </div>
                   ))}
                </div>
             </section>
           )}

           {activeTab === 'FABRICS' && (
             <section className="max-w-5xl mx-auto space-y-8">
                <div className="flex justify-between items-center flex-col sm:flex-row gap-4 sm:gap-0">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">إدارة الأقمشة</h3>
                   <button onClick={() => dummyAdd('قماش جديد')} className="bg-primary/10 text-primary border border-primary/20 px-8 py-4 rounded-2xl font-black text-xs hover:bg-primary hover:text-white transition-all w-full sm:w-auto">إضافة قماش جديد</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {fabrics.map(fabric => (
                    <div key={fabric.id} className="bg-slate-900 rounded-3xl p-6 border border-white/5 flex flex-col gap-4">
                      <div className="flex items-center gap-4">
                        <img src={fabric.image} alt={fabric.name} className="w-16 h-16 object-cover rounded-xl" />
                        <div>
                          <h4 className="font-black text-white">{fabric.name}</h4>
                          <p className="text-slate-500 text-xs">{fabric.material}</p>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-auto">
                        <button onClick={() => dummyEdit('قماش', fabric.id)} className="flex-1 bg-indigo-500/10 text-indigo-500 py-3 rounded-xl text-xs hover:bg-indigo-500 hover:text-white transition-all">تعديل</button>
                        <button onClick={() => dummyDelete('قماش', fabric.id)} className="flex-1 bg-red-500/10 text-red-500 py-3 rounded-xl text-xs hover:bg-red-500 hover:text-white transition-all">حذف</button>
                      </div>
                    </div>
                  ))}
                </div>
             </section>
           )}

           {activeTab === 'STYLES' && (
             <section className="max-w-5xl mx-auto space-y-8">
                <div className="flex justify-between items-center flex-col sm:flex-row gap-4 sm:gap-0">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">إدارة الموديلات</h3>
                   <button onClick={() => dummyAdd('موديل جديد')} className="bg-primary/10 text-primary border border-primary/20 px-8 py-4 rounded-2xl font-black text-xs hover:bg-primary hover:text-white transition-all w-full sm:w-auto">إضافة موديل جديد</button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {styles.map(style => (
                    <div key={style.id} className="bg-slate-900 rounded-3xl p-6 border border-white/5 flex flex-col gap-4">
                      <div className="flex items-center gap-4">
                        <span className="text-4xl">{style.icon}</span>
                        <div>
                          <h4 className="font-black text-white">{style.label}</h4>
                          <p className="text-slate-500 text-xs">{style.gender} - {style.occasion}</p>
                        </div>
                      </div>
                      <div className="flex gap-2 mt-auto">
                        <button onClick={() => dummyEdit('موديل', style.id)} className="flex-1 bg-indigo-500/10 text-indigo-500 py-3 rounded-xl text-xs hover:bg-indigo-500 hover:text-white transition-all">تعديل</button>
                        <button onClick={() => dummyDelete('موديل', style.id)} className="flex-1 bg-red-500/10 text-red-500 py-3 rounded-xl text-xs hover:bg-red-500 hover:text-white transition-all">حذف</button>
                      </div>
                    </div>
                  ))}
                </div>
             </section>
           )}

           {activeTab === 'COLORS' && (
             <section className="max-w-5xl mx-auto space-y-8">
                <div className="flex justify-between items-center flex-col sm:flex-row gap-4 sm:gap-0">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">إدارة الألوان</h3>
                   <button onClick={() => dummyAdd('لون جديد')} className="bg-primary/10 text-primary border border-primary/20 px-8 py-4 rounded-2xl font-black text-xs hover:bg-primary hover:text-white transition-all w-full sm:w-auto">إضافة لون جديد</button>
                </div>
                <div className="grid grid-cols-5 md:grid-cols-6 lg:grid-cols-8 gap-4">
                  {colors.map(color => (
                    <div key={color.id} className="bg-slate-900 rounded-3xl p-4 border border-white/5 flex flex-col items-center gap-2">
                      <div className="w-12 h-12 rounded-full border border-white/20" style={{ backgroundColor: color.hex }}></div>
                      <h4 className="font-black text-white text-xs">{color.name}</h4>
                      <div className="flex gap-1 mt-auto">
                        <button onClick={() => dummyEdit('لون', color.id)} className="w-6 h-6 bg-indigo-500/10 text-indigo-500 rounded-full text-xs flex items-center justify-center hover:bg-indigo-500 hover:text-white transition-all">✏️</button>
                        <button onClick={() => dummyDelete('لون', color.id)} className="w-6 h-6 bg-red-500/10 text-red-500 rounded-full text-xs flex items-center justify-center hover:bg-red-500 hover:text-white transition-all">🗑️</button>
                      </div>
                    </div>
                  ))}
                </div>
             </section>
           )}

           {activeTab === 'PRICING' && (
             <section className="max-w-5xl mx-auto space-y-8">
                <div className="flex justify-between items-center flex-col sm:flex-row gap-4 sm:gap-0">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">إدارة الأسعار</h3>
                   <button onClick={() => dummyAdd('قاعدة تسعير جديدة')} className="bg-primary/10 text-primary border border-primary/20 px-8 py-4 rounded-2xl font-black text-xs hover:bg-primary hover:text-white transition-all w-full sm:w-auto">إضافة قاعدة تسعير</button>
                </div>
                <div className="space-y-4">
                  {pricing.map(rule => (
                    <div key={rule.styleId} className="bg-slate-900 rounded-3xl p-6 border border-white/5 flex flex-col sm:flex-row justify-between items-center gap-4">
                      <div>
                        <h4 className="font-black text-white">{rule.styleId.replace(/_/g, ' ')}</h4>
                        <p className="text-slate-500 text-sm">السعر الأساسي: {rule.basePrice} ر.س</p>
                      </div>
                      <div className="flex gap-2">
                        <button onClick={() => dummyEdit('قاعدة تسعير', rule.styleId)} className="flex-1 bg-indigo-500/10 text-indigo-500 py-3 px-6 rounded-xl text-xs hover:bg-indigo-500 hover:text-white transition-all">تعديل</button>
                        <button onClick={() => dummyDelete('قاعدة تسعير', rule.styleId)} className="flex-1 bg-red-500/10 text-red-500 py-3 px-6 rounded-xl text-xs hover:bg-red-500 hover:text-white transition-all">حذف</button>
                      </div>
                    </div>
                  ))}
                </div>
             </section>
           )}
           
           {activeTab === 'ORDERS' && (
             <section className="max-w-5xl mx-auto space-y-8">
                <h3 className="text-2xl sm:text-3xl font-black text-white mb-6">إحصائيات الطلبات</h3>
                <StatsDashboard orders={orders} branding={branding} /> {/* Pass branding here */}
             </section>
           )}

           {activeTab === 'CONFIG' && (
             <section className="max-w-4xl mx-auto space-y-8">
                <div className="bg-slate-900 p-8 sm:p-12 rounded-[4rem] border border-white/5 shadow-2xl space-y-8">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">الإعدادات العامة للتطبيق</h3>
                   
                   <div className="space-y-6">
                      <div className="space-y-2">
                         <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">تعليمات لوحة المطور</label>
                         <textarea 
                            value={config.instructions} 
                            onChange={(e) => setConfig({...config, instructions: e.target.value})} 
                            className="w-full bg-slate-800 border border-white/5 p-6 rounded-3xl text-white font-black h-32" 
                            placeholder="اكتب هنا التعليمات الخاصة بلوحة تحكم المطور..."
                         />
                      </div>

                      <h4 className="text-lg font-black text-white mt-8">تفعيل/تعطيل أقسام لوحة المطور</h4>
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                         {currentUser.role === UserRole.ADMIN && (
                            <>
                               <ToggleSwitch label="إدارة الأقمشة" checked={config.fabrics} onChange={(val) => setConfig({...config, fabrics: val})} />
                               <ToggleSwitch label="إدارة الأسعار" checked={config.prices} onChange={(val) => setConfig({...config, prices: val})} />
                               <ToggleSwitch label="إحصائيات الطلبات" checked={config.orders} onChange={(val) => setConfig({...config, orders: val})} />
                            </>
                         )}
                         {/* These are accessible to all roles (admin/assistant/viewer) */}
                         <ToggleSwitch label="إدارة الموديلات" checked={config.models} onChange={(val) => setConfig({...config, models: val})} />
                         <ToggleSwitch label="إدارة الألوان" checked={config.colors} onChange={(val) => setConfig({...config, colors: val})} />
                      </div>
                   </div>

                   <button onClick={() => alert("✅ تم حفظ الإعدادات العامة")} className="w-full bg-primary py-7 rounded-3xl font-black text-white text-xl shadow-2xl active:scale-95 transition-all">حفظ الإعدادات العامة</button>
                </div>
             </section>
           )}

           {currentUser.role === UserRole.ADMIN && activeTab === 'USER_MANAGEMENT' && (
             <section className="max-w-4xl mx-auto space-y-8">
                <div className="bg-slate-900 p-8 sm:p-12 rounded-[4rem] border border-white/5 shadow-2xl space-y-8">
                   <h3 className="text-2xl sm:text-3xl font-black text-white">إدارة المستخدمين</h3>
                   
                   <div className="space-y-6">
                      <h4 className="text-lg font-black text-white">المستخدمون الحاليون</h4>
                      <div className="space-y-4">
                         {allUsers.map((user) => (
                            <div key={user.id} className="flex justify-between items-center bg-slate-800 p-4 rounded-2xl border border-white/5">
                               <span className="text-white font-bold text-sm">{user.username}</span>
                               <span className={`px-3 py-1 rounded-full text-xs font-black ${
                                 user.role === UserRole.ADMIN ? 'bg-red-500/20 text-red-500' : 
                                 user.role === UserRole.ASSISTANT ? 'bg-green-500/20 text-green-500' :
                                 'bg-blue-500/20 text-blue-500'
                               }`}>
                                  {user.role === UserRole.ADMIN ? 'مدير' : user.role === UserRole.ASSISTANT ? 'مساعد' : 'مشاهد'}
                               </span>
                               <div className="flex gap-2">
                                  {user.id !== currentUser.id && ( // Prevent admin from changing their own role or deleting themselves
                                    <>
                                       <select 
                                         value={user.role} 
                                         onChange={(e) => onUpdateUserRole(user.id, e.target.value as UserRole)} 
                                         className="w-fit bg-slate-700 border border-white/5 p-2 rounded-xl outline-none text-white font-bold text-xs"
                                       >
                                          <option value={UserRole.ADMIN}>مدير</option>
                                          <option value={UserRole.ASSISTANT}>مساعد</option>
                                          <option value={UserRole.VIEWER}>مشاهد</option>
                                       </select>
                                       <button onClick={() => onDeleteUser(user.id)} className="w-8 h-8 rounded-full bg-red-500/10 text-red-500 text-xs flex items-center justify-center hover:bg-red-500 hover:text-white transition-all">🗑️</button>
                                    </>
                                  )}
                               </div>
                            </div>
                         ))}
                      </div>

                      <h4 className="text-lg font-black text-white mt-8">إضافة مطور جديد</h4>
                      <form onSubmit={handleAddNewUser} className="space-y-4">
                         <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">اسم المستخدم</label>
                            <input 
                               type="text" 
                               value={newUsername} 
                               onChange={(e) => setNewUsername(e.target.value)} 
                               className="w-full bg-slate-800 border border-white/5 p-5 rounded-2xl outline-none text-white font-bold placeholder:text-slate-700" 
                               placeholder="مثال: user@example.com"
                               required
                            />
                         </div>
                         <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">كلمة المرور</label>
                            <input 
                               type="password" 
                               value={newPassword} 
                               onChange={(e) => setNewPassword(e.target.value)} 
                               className="w-full bg-slate-800 border border-white/5 p-5 rounded-2xl outline-none text-white font-bold placeholder:text-slate-700" 
                               placeholder="كلمة المرور"
                               required
                            />
                         </div>
                         <div className="space-y-2">
                            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">الدور</label>
                            <select 
                               value={newUserRole} 
                               onChange={(e) => setNewUserRole(e.target.value as UserRole)} 
                               className="w-full bg-slate-800 border border-white/5 p-5 rounded-2xl outline-none text-white font-bold"
                            >
                               <option value={UserRole.ASSISTANT}>مساعد</option>
                               <option value={UserRole.ADMIN}>مدير</option>
                               <option value={UserRole.VIEWER}>مشاهد</option>
                            </select>
                         </div>
                         <button type="submit" className="w-full bg-primary py-6 rounded-3xl font-black text-xl text-white shadow-2xl active:scale-95 transition-all">إضافة مستخدم</button>
                      </form>
                   </div>
                </div>
             </section>
           )}
        </main>
      </div>
    </div>
  );
};

const SidebarBtn = ({ active, onClick, icon, label, disabled = false }: any) => (
  <button 
    onClick={onClick} 
    className={`w-full flex items-center gap-4 p-5 rounded-3xl transition-all font-black text-sm 
               ${active ? 'bg-primary text-white shadow-2xl scale-[1.05]' : 'text-slate-500 hover:bg-white/5'}
               ${disabled ? 'opacity-50 cursor-not-allowed' : ''}`}
    disabled={disabled}
  >
    <span className="text-2xl">{icon}</span>
    <span className="tracking-tight">{label}</span>
  </button>
);

const ToggleSwitch = ({ label, checked, onChange }: { label: string; checked: boolean; onChange: (checked: boolean) => void }) => (
  <div className="flex items-center justify-between bg-slate-800 p-5 rounded-2xl border border-white/5">
    <span className="text-white font-bold text-sm">{label}</span>
    <label className="relative inline-flex items-center cursor-pointer">
      <input type="checkbox" checked={checked} onChange={(e) => onChange(e.target.checked)} className="sr-only peer" />
      <div className="w-11 h-6 bg-slate-700 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary/40 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:right-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary"></div>
    </label>
  </div>
);
