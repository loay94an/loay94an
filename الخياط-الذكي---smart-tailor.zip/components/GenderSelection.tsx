
import React from 'react';
import { Gender, BrandingSettings } from '../types';

interface Props {
  selected: Gender | null;
  onSelect: (gender: Gender) => void;
  onBackToHub: () => void; // New prop
  branding: BrandingSettings; // New prop
}

export const GenderSelection: React.FC<Props> = ({ selected, onSelect, onBackToHub, branding }) => {
  const options = [
    { id: Gender.MALE, label: 'رجالي', icon: '🤵', desc: 'بترونات كلاسيكية ورسمية', color: 'blue' },
    { id: Gender.FEMALE, label: 'نسائي', icon: '💃', desc: 'أناقة وتفاصيل فنية ناعمة', color: 'rose' },
    { id: Gender.CHILDREN, label: 'أطفال', icon: '🎈', desc: 'تصاميم مريحة وعملية', color: 'amber' }
  ];

  return (
    <div className="w-full max-w-3xl mx-auto space-y-4 relative">
      <button 
        onClick={onBackToHub} 
        className="absolute top-0 right-0 px-6 py-3 rounded-2xl bg-slate-800 text-slate-400 flex items-center gap-2 hover:bg-slate-700 transition-all border border-white/5 text-sm font-black z-20"
      >
        <span className="text-xl">🏠</span>
        <span>العودة للقائمة الرئيسية</span>
      </button>

      <h2 className="text-2xl font-black text-white text-center mb-8">اختر فئة التصميم</h2>
      <div className="grid grid-cols-1 gap-4">
        {options.map((opt) => (
          <button
            key={opt.id}
            onClick={() => onSelect(opt.id)}
            className={`flex items-center gap-6 p-6 rounded-[2rem] bg-slate-900 border-2 transition-all group ${
              selected === opt.id ? 'border-primary ring-4 ring-primary/10' : 'border-white/5 hover:border-white/10'
            }`}
          >
            <div className="w-20 h-20 bg-slate-800 rounded-2xl flex items-center justify-center text-4xl group-hover:scale-110 transition-transform">
              {opt.icon}
            </div>
            <div className="text-right">
              <h3 className="text-xl font-black text-white">{opt.label}</h3>
              <p className="text-slate-500 text-sm font-medium">{opt.desc}</p>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};