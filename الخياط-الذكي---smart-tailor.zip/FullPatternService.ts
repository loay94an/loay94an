
import { Measurements, Gender, SleeveType, GarmentStyle, CollarType } from './types';

export class PathBuilder {
  private d: string[] = [];
  
  moveTo(x: number, y: number): this {
    this.d.push(`M ${x} ${y}`);
    return this;
  }
  
  lineTo(x: number, y: number): this {
    this.d.push(`L ${x} ${y}`);
    return this;
  }
  
  cubicCurveTo(x1: number, y1: number, x2: number, y2: number, x: number, y: number): this {
    this.d.push(`C ${x1} ${y1}, ${x2} ${y2}, ${x} ${y}`);
    return this;
  }
  
  closePath(): this {
    this.d.push('Z');
    return this;
  }
  
  build(): string {
    return this.d.join(' ');
  }
}

export class FullPatternService {
  /**
   * توليد بترون الياقات الاحترافي بناءً على محيط الرقبة ونوع الياقة المختار
   * تم تطويره ليشمل جميع الموديلات العالمية
   */
  static generateCollar(type: CollarType, measurements: Measurements, scale: number = 2.0): string {
    const neckHalf = (measurements.neckCircumference / 2) * scale;
    const builder = new PathBuilder();
    
    if (type === CollarType.STAND || type === CollarType.MANDARIN) {
      const h = (type === CollarType.MANDARIN ? 3.5 : 4.5) * scale;
      builder.moveTo(0, 0)
             .lineTo(neckHalf, 0)
             .cubicCurveTo(neckHalf + 5, 0, neckHalf + 5, -h, neckHalf, -h)
             .lineTo(0, -h)
             .closePath();
    } else if (type === CollarType.PETER_PAN) {
      const h = 6 * scale;
      builder.moveTo(0, 0)
             .cubicCurveTo(neckHalf * 0.5, h, neckHalf * 1.2, h, neckHalf, 0)
             .cubicCurveTo(neckHalf * 0.8, -h, neckHalf * 0.3, -h, 0, 0)
             .closePath();
    } else if (type === CollarType.SHAWL || type === CollarType.PEAKED_LAPEL || type === CollarType.NOTCHED) {
      const lapelWidth = type === CollarType.PEAKED_LAPEL ? 14 * scale : 11 * scale;
      builder.moveTo(0, 0)
             .lineTo(neckHalf, 35)
             .lineTo(neckHalf + lapelWidth, -65)
             .lineTo(15, -95)
             .cubicCurveTo(8, -95, 0, -55, 0, 0)
             .closePath();
    } else if (type === CollarType.SAILOR) {
      const flapBack = 22 * scale;
      const flapWidth = 18 * scale;
      builder.moveTo(0, 0)
             .lineTo(neckHalf, 0)
             .lineTo(neckHalf, flapBack)
             .lineTo(neckHalf - flapWidth, flapBack)
             .lineTo(0, 0)
             .closePath();
    } else if (type === CollarType.ROUND || type === CollarType.V_NECK || type === CollarType.SCOOP) {
      const vDepth = type === CollarType.V_NECK ? 22 * scale : type === CollarType.SCOOP ? 18 * scale : 10 * scale;
      builder.moveTo(0, 0)
             .cubicCurveTo(neckHalf * 0.3, vDepth, neckHalf * 0.7, vDepth, neckHalf, 0)
             .lineTo(neckHalf, -4 * scale)
             .cubicCurveTo(neckHalf * 0.7, vDepth - 5 * scale, neckHalf * 0.3, vDepth - 5 * scale, 0, -4 * scale)
             .closePath();
    } else {
      builder.moveTo(0, 0)
             .lineTo(neckHalf, 0)
             .lineTo(neckHalf + 10, -32)
             .lineTo(10, -38)
             .lineTo(0, -18)
             .closePath();
    }
    return builder.build();
  }

  /**
   * توليد بترون الجسم المطور مع حسابات البنس والقصات التخصصية بناءً على قياسات الكتب الفنية الـ 19
   */
  static generateBodice(gender: Gender, isFront: boolean, measurements: Measurements, ease: number, scale: number = 2.0, style?: GarmentStyle): string {
    const { 
      chest, waist, hips, shoulderWidth, height, 
      backWidth, backLength, shoulderToBust, bustPointToPoint,
      waistToHip, bodiceLength, waistToArmhole
    } = measurements;
    
    const chestQ = (chest / 4) + (ease / 4);
    const waistQ = (waist / 4) + (ease / 4);
    const hipsQ = (hips / 4) + (ease / 4);
    
    const neckW = (chest / 12) + 2.5;
    const neckD = isFront ? neckW + 6 : 3;
    
    const armholeD = waistToArmhole ? waistToArmhole * scale : ((chest / 6) + 11) * scale;
    const effectiveBackWidth = (backWidth || (shoulderWidth * 0.9)) / 2;
    
    let pieceLength = height * 0.45; 
    if ([GarmentStyle.ABAYA, GarmentStyle.BISHT, GarmentStyle.KAFTAN, GarmentStyle.TRENCH_COAT, GarmentStyle.TAILORED_COAT].includes(style!)) pieceLength = height * 0.96;
    if (style === GarmentStyle.EVENING_GOWN || style === GarmentStyle.MERMAID_DRESS || style === GarmentStyle.PRINCESS_CUT_DRESS || style === GarmentStyle.COWL_NECK_DRESS) pieceLength = height * 0.94;

    const builder = new PathBuilder();
    
    builder.moveTo(0, pieceLength * scale).lineTo(0, neckD * scale);
    
    if (style === GarmentStyle.COWL_NECK_DRESS && isFront) {
      // Cowl neck Drape pattern
      builder.lineTo(neckW * 2.5 * scale, -10 * scale)
             .lineTo((shoulderWidth / 2) * scale, 15 * scale);
    } else {
      builder.cubicCurveTo((neckW * 0.45) * scale, neckD * scale, neckW * scale, (neckD * 0.45) * scale, neckW * scale, 0);
      const slope = gender === Gender.MALE ? 5.2 : 4.4;
      builder.lineTo((shoulderWidth / 2) * scale, slope * scale);
    }

    builder.cubicCurveTo(effectiveBackWidth * scale, armholeD * 0.4, (chestQ * 0.9) * scale, armholeD * 0.8, chestQ * scale, armholeD);

    const waistY = (backLength || (bodiceLength ? bodiceLength * 0.9 : 44)) * scale;
    const hipsY = (waistY + (waistToHip || 20) * scale);

    if (style === GarmentStyle.PRINCESS_CUT_DRESS || style === GarmentStyle.MERMAID_DRESS) {
      builder.lineTo(chestQ * scale, waistY);
      if (style === GarmentStyle.MERMAID_DRESS) {
        const kneeY = (measurements.waistToKnee || 62) * scale + waistY;
        builder.lineTo(waistQ * 0.85 * scale, waistY)
               .lineTo(hipsQ * scale, hipsY)
               .lineTo(hipsQ * 0.75 * scale, kneeY) 
               .cubicCurveTo(hipsQ * 3 * scale, kneeY + 40, hipsQ * 6 * scale, pieceLength * scale, hipsQ * 8 * scale, pieceLength * scale); 
      } else {
        builder.lineTo(waistQ * scale, waistY)
               .cubicCurveTo(hipsQ * 1.5 * scale, hipsY, hipsQ * 4 * scale, hipsY + 30, hipsQ * 6 * scale, pieceLength * scale);
      }
    } else if (style === GarmentStyle.BISHT || style === GarmentStyle.KAFTAN || style === GarmentStyle.ABAYA) {
      const sweep = style === GarmentStyle.BISHT ? 8 : 4;
      builder.lineTo(chestQ * sweep * scale, armholeD)
             .lineTo(chestQ * (sweep - 0.5) * scale, pieceLength * scale);
    } else if (style === GarmentStyle.TAILORED_COAT) {
      builder.lineTo(chestQ * 1.2 * scale, waistY)
             .lineTo(hipsQ * 1.3 * scale, hipsY)
             .lineTo(hipsQ * 1.4 * scale, pieceLength * scale);
    } else {
      builder.lineTo(waistQ * scale, waistY)
             .lineTo(hipsQ * scale, hipsY)
             .lineTo(hipsQ * scale, pieceLength * scale);
    }

    builder.lineTo(0, pieceLength * scale).closePath();
    return builder.build();
  }

  /**
   * توليد بترون الأكمام المتطور
   */
  static generateSleeve(type: SleeveType, measurements: Measurements, scale: number = 2.0): string {
    const { armLength, chest, armCircumference, cuffCircumference } = measurements;
    const builder = new PathBuilder();
    
    const bicepW = (armCircumference || (chest / 4 + 6));
    const crownH = (chest / 10 + 9);
    
    let cH = crownH * scale;
    let bW = bicepW * scale;
    let len = armLength * scale;
    let wW = (cuffCircumference || (chest / 6 + 7)) * scale;

    if (type === SleeveType.PUFF) { cH *= 3.0; bW *= 1.8; }
    if (type === SleeveType.BISHOP) { bW *= 1.45; wW *= 0.7; }
    if (type === SleeveType.BELL) { wW *= 2.4; }
    if (type === SleeveType.LEG_MUTTON) { bW *= 2.2; cH *= 2.5; wW *= 0.6; }
    if (type === SleeveType.PETAL) { len *= 0.35; wW *= 1.4; }
    if (type === SleeveType.KIMONO) { bW *= 2.8; wW *= 2.8; cH *= 0.35; }
    if (type === SleeveType.DOLMAN) { bW *= 3.5; cH *= 0.15; }
    if (type === SleeveType.TWO_PIECE_SUIT) { bW *= 1.25; len *= 1.08; }

    const wristOffset = (bW - wW) / 2;

    builder.moveTo(wristOffset, len);
    builder.lineTo(0, cH);
    builder.cubicCurveTo(bW * 0.25, -8 * scale, bW * 0.75, -8 * scale, bW, cH);
    builder.lineTo(wristOffset + wW, len);
    builder.lineTo(wristOffset, len);
    builder.closePath();
    
    return builder.build();
  }

  static generatePants(gender: Gender, isFront: boolean, measurements: Measurements, ease: number, scale: number = 2.0): string {
    const { waist, hips, height, waistToFloor, waistToHip } = measurements;
    const builder = new PathBuilder();
    
    const waistQ = (waist / 4) + (isFront ? -1.5 : 7.5);
    const hipsQ = (hips / 4) + (ease / 4.5);
    const rise = (hips / 4) + (gender === Gender.MALE ? 14 : 12); 
    const legLen = (waistToFloor || (height * 0.68)) * scale;
    const crotchExt = (hips / 20) * (isFront ? 2.8 : 6.2);

    builder.moveTo(0, 0)
           .lineTo(waistQ * scale, 0)
           .lineTo(hipsQ * scale, rise * scale)
           .lineTo(hipsQ * 0.9 * scale, legLen)
           .lineTo(0, legLen)
           .lineTo(-crotchExt * scale, rise * scale);

    builder.cubicCurveTo(-crotchExt * 0.55 * scale, rise * 0.9 * scale, 0, rise * 0.35 * scale, 0, 0);

    builder.closePath();
    return builder.build();
  }
}
