
import React, { useState, useEffect } from 'react';
import { AppStep, Gender, Measurements, Fabric, GarmentStyle, FabricColor, PatternDesign, BrandingSettings, ActivityLog, Order, StyleItem, PricingRule, SectionConfig, User, UserRole, SleeveType, CollarType } from './types';
import { StepProgressBar } from './components/StepProgressBar';
import { GenderSelection } from './components/GenderSelection';
import { StyleSelection } from './components/StyleSelection';
import { SizeInput } from './components/SizeInput';
import { FabricSelection } from './components/FabricSelection';
import { ColorSelection } from './components/ColorSelection';
import { PatternEditor } from './components/PatternEditor';
import { Model3DPreview } from './components/Model3DPreview';
import { Checkout } from './components/Checkout';
import { DevDashboard } from './components/DevDashboard';
import { LoginScreen } from './components/LoginScreen'; 
import { STANDARD_SIZES, INITIAL_COLORS, PATTERNS, INITIAL_FABRICS, INITIAL_STYLES, INITIAL_PRICING, INITIAL_USERS, INITIAL_ORDERS } from './constants';
import { db, storage } from './firebase'; 
import { doc, getDoc, setDoc, collection, getDocs, deleteDoc } from 'firebase/firestore';

const App: React.FC = () => {
  const [step, setStep] = useState<AppStep | 'HUB'>('HUB');
  const [language, setLanguage] = useState<'ar' | 'en'>('ar');
  const [gender, setGender] = useState<Gender | null>(null);
  const [style, setStyle] = useState<GarmentStyle | null>(null);
  const [measurements, setMeasurements] = useState<Measurements>(STANDARD_SIZES['M']);
  const [fabric, setFabric] = useState<Fabric | null>(INITIAL_FABRICS[0]);
  const [selectedColor, setSelectedColor] = useState<FabricColor | null>(INITIAL_COLORS[0]);
  const [selectedPattern, setSelectedPattern] = useState<PatternDesign | null>(PATTERNS[0]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  
  const [orders, setOrders] = useState<Order[]>(() => {
    const savedOrders = localStorage.getItem('smart_tailor_orders');
    return savedOrders ? JSON.parse(savedOrders) : INITIAL_ORDERS;
  });
  const [savedProfiles, setSavedProfiles] = useState<any[]>([]); 
  const [userId] = useState<string>("guest_" + Math.random().toString(36).substr(2, 9));

  // Authentication state
  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('smart_tailor_user');
    return savedUser ? JSON.parse(savedUser) : null;
  });
  const [allUsers, setAllUsers] = useState<User[]>([]);

  // State for developer dashboard mutable data
  const [fabrics, setFabrics] = useState<Fabric[]>(INITIAL_FABRICS);
  const [styles, setStyles] = useState<StyleItem[]>(INITIAL_STYLES);
  const [colors, setColors] = useState<FabricColor[]>(INITIAL_COLORS);
  const [pricing, setPricing] = useState<PricingRule[]>(INITIAL_PRICING);
  
  const [config, setConfig] = useState<SectionConfig>(() => {
    const savedConfig = localStorage.getItem('smart_tailor_config');
    return savedConfig ? JSON.parse(savedConfig) : {
      fabrics: true,
      models: true,
      colors: true,
      prices: true,
      orders: true,
      instructions: "مرحباً بك في لوحة تحكم المطور. هنا يمكنك إدارة جميع جوانب تطبيقك."
    };
  });

  const [branding, setBranding] = useState<BrandingSettings>(() => {
    const saved = localStorage.getItem('smart_tailor_branding');
    return saved ? JSON.parse(saved) : {
      companyName: "الخياط الذكي برو",
      logoUrl: "",
      primaryColor: "#2563eb",
      secondaryColor: "#f50057",
      fontFamily: "Tajawal",
      logoPosition: "top-right"
    };
  });

  useEffect(() => {
    const savedLogs = localStorage.getItem('smart_tailor_logs');
    if (savedLogs) setActivityLogs(JSON.parse(savedLogs));
    
    const localProfiles = localStorage.getItem('smart_tailor_profiles');
    if (localProfiles) setSavedProfiles(JSON.parse(localProfiles));
  }, []);

  // Effect to load config from Firestore (only if db exists and user is logged in)
  useEffect(() => {
    const fetchConfigFromFirestore = async () => {
      // Check if db is initialized and we have a user
      if (currentUser && db) {
        try {
          const docRef = doc(db, "settings", "sections");
          const docSnap = await getDoc(docRef);
          if (docSnap.exists()) {
            setConfig(docSnap.data() as SectionConfig);
          } else {
            // Optionally, save the current local config to Firestore if it doesn't exist
            await setDoc(docRef, config);
          }
        } catch (error) {
          console.error("Error fetching config from Firestore:", error);
        }
      }
      // If offline or failed, we rely on state initialized from localStorage
    };

    fetchConfigFromFirestore();
  }, [currentUser]);

  // Effect to save config to localStorage or Firestore when it changes
  useEffect(() => {
    localStorage.setItem('smart_tailor_config', JSON.stringify(config));

    const saveConfigToFirestore = async () => {
      if (currentUser && db) {
        try {
          const docRef = doc(db, "settings", "sections");
          await setDoc(docRef, config);
        } catch (error) {
          console.error("Error saving config to Firestore:", error);
        }
      }
    };
    saveConfigToFirestore();
  }, [config, currentUser]);

  // Effect to load allUsers from Firestore or LocalStorage
  useEffect(() => {
    const fetchUsersFromFirestore = async () => {
      let users: User[] = [];
      
      if (db) {
        try {
          const querySnapshot = await getDocs(collection(db, "users"));
          querySnapshot.forEach((docSnap) => {
            users.push({ id: docSnap.id, ...(docSnap.data() as Omit<User, 'id'>) });
          });
          
          if (users.length === 0) {
             // If db works but is empty, try to seed it
             try {
               for (const initialUser of INITIAL_USERS) {
                  const newUserRef = doc(collection(db, "users"));
                  await setDoc(newUserRef, initialUser);
                  users.push({ ...initialUser, id: newUserRef.id });
               }
             } catch (e) {
               console.warn("Could not seed initial users to Firestore");
             }
          }
        } catch (error) {
          console.error("Error accessing Firestore users:", error);
        }
      }
      
      if (users.length > 0) {
         setAllUsers(users);
         return;
      }
      
      // Fallback to local storage or constants if Firestore is offline/unconfigured
      const savedUsers = localStorage.getItem('smart_tailor_all_users');
      if (savedUsers) {
        const parsedUsers = JSON.parse(savedUsers);
        
        // Force update Admin credentials from constants to ensure developer access
        // This solves issues where old password persists in local storage
        const updatedUsers = parsedUsers.map((u: User) => {
           if (u.role === UserRole.ADMIN) {
               const adminConst = INITIAL_USERS.find(iu => iu.role === UserRole.ADMIN);
               return adminConst ? { ...u, password: adminConst.password, username: adminConst.username } : u;
           }
           return u;
        });
        
        // Ensure admin exists
        const adminConst = INITIAL_USERS.find(iu => iu.role === UserRole.ADMIN);
        if (adminConst && !updatedUsers.some((u: User) => u.role === UserRole.ADMIN)) {
            updatedUsers.push(adminConst);
        }
        
        setAllUsers(updatedUsers);
      } else {
        setAllUsers(INITIAL_USERS);
      }
    };
    fetchUsersFromFirestore();
  }, []);

  // Effect to save allUsers to localStorage (fallback)
  useEffect(() => {
    localStorage.setItem('smart_tailor_all_users', JSON.stringify(allUsers));
  }, [allUsers]);

  useEffect(() => {
    localStorage.setItem('smart_tailor_orders', JSON.stringify(orders));
  }, [orders]);


  const addLog = (action: string, details: string) => {
    const newLog = { id: Date.now().toString(), action, details, timestamp: Date.now() };
    const updated = [newLog, ...activityLogs].slice(0, 50);
    setActivityLogs(updated);
    localStorage.setItem('smart_tailor_logs', JSON.stringify(updated));
  };
  
  const handleSaveProfile = (name: string, m: Measurements) => {
      const newProfile = { id: Date.now().toString(), name, measurements: m, createdAt: Date.now() };
      const updated = [...savedProfiles, newProfile];
      setSavedProfiles(updated);
      localStorage.setItem('smart_tailor_profiles', JSON.stringify(updated));
      addLog("حفظ مقاسات", name);
  };

  const handleDeleteProfile = (id: string) => {
      const updated = savedProfiles.filter(p => p.id !== id);
      setSavedProfiles(updated);
      localStorage.setItem('smart_tailor_profiles', JSON.stringify(updated));
  };

  const handleLogin = (user: User) => {
    setCurrentUser(user);
    localStorage.setItem('smart_tailor_user', JSON.stringify(user));
    setStep('HUB'); 
  };

  const handleLogout = () => {
    setCurrentUser(null);
    localStorage.removeItem('smart_tailor_user');
    setStep('HUB');
  };

  // Firestore-integrated user management functions
  const handleAddUser = async (username: string, password: string, role: UserRole) => {
    try {
      if (db) {
        const newUserRef = doc(collection(db, "users"));
        const newUser: User = { id: newUserRef.id, username, password, role };
        await setDoc(newUserRef, newUser);
        setAllUsers(prev => [...prev, newUser]);
      } else {
        // Offline mode
        const newUser: User = { id: `local-${Date.now()}`, username, password, role };
        setAllUsers(prev => [...prev, newUser]);
      }
      addLog("إضافة مستخدم", `المستخدم ${username} بالدور ${role}`);
      alert("✅ تم إضافة المطور بنجاح!");
    } catch (error) {
      console.error("Error adding user:", error);
      alert("❌ فشل إضافة المستخدم.");
    }
  };

  const handleUpdateUserRole = async (userId: string, newRole: UserRole) => {
    try {
      if (db && !userId.startsWith('local-')) {
        const userRef = doc(db, "users", userId);
        await setDoc(userRef, { role: newRole }, { merge: true });
      }
      setAllUsers(prev => prev.map(user => user.id === userId ? { ...user, role: newRole } : user));
      addLog("تحديث دور المستخدم", `تم تحديث دور المستخدم ${userId} إلى ${newRole}`);
      alert("✅ تم تحديث الدور بنجاح!");
    } catch (error) {
      console.error("Error updating user role:", error);
      alert("❌ فشل تحديث دور المستخدم.");
    }
  };

  const handleDeleteUser = async (userId: string) => {
    if (window.confirm("هل أنت متأكد أنك تريد حذف هذا المستخدم؟")) {
      try {
        if (db && !userId.startsWith('local-')) {
          const userRef = doc(db, "users", userId);
          await deleteDoc(userRef);
        }
        setAllUsers(prev => prev.filter(user => user.id !== userId));
        addLog("حذف مستخدم", `تم حذف المستخدم ${userId}`);
        alert("✅ تم حذف المستخدم بنجاح!");
      } catch (error) {
        console.error("Error deleting user:", error);
        alert("❌ فشل حذف المستخدم.");
      }
    }
  };

  const handleAddOrder = (newOrder: Order) => {
    setOrders(prev => [...prev, newOrder]);
    addLog("طلب جديد", `تم استلام طلب جديد من ${newOrder.customerName}`);
  };

  const t = (ar: string, en: string) => (language === 'ar' ? ar : 'en');
  const onBackToHub = () => setStep('HUB');

  const renderHub = () => (
    <div className="w-full max-w-6xl mx-auto py-8 sm:py-12 px-4 sm:px-6 animate-in fade-in duration-1000">
      <header className="flex flex-col md:flex-row justify-between items-center mb-10 sm:mb-16 gap-6 sm:gap-8">
         <div className="flex items-center gap-4 sm:gap-6">
            <div className="w-16 h-16 sm:w-20 sm:h-20 bg-primary rounded-3xl flex items-center justify-center text-4xl sm:text-5xl shadow-2xl rotate-3" style={{ backgroundColor: branding.primaryColor }}>🧵</div>
            <h1 className="text-3xl sm:text-5xl font-black text-white tracking-tighter" style={{ color: branding.primaryColor, fontFamily: branding.fontFamily }}>{branding.companyName}</h1>
         </div>
         <button 
           onClick={() => setLanguage(language === 'ar' ? 'en' : 'ar')}
           className="px-6 sm:px-8 py-3 sm:py-4 bg-slate-800 rounded-2xl border border-white/5 font-black text-xs hover:bg-slate-700 transition-all flex items-center gap-3 w-full md:w-auto justify-center"
         >
           🌐 {t('تغيير اللغة', 'Switch Language')}
         </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
         <HubCard 
           title={t("رحلة التفصيل الذكية", "Smart Tailoring Journey")} 
           desc={t("ابدأ تصميم قطعتك خطوة بخطوة من الصفر", "Start designing your piece step by step")}
           icon="✂️" 
           onClick={() => setStep(AppStep.GENDER_SELECTION)} 
           primary 
           color={branding.primaryColor}
         />
         <HubCard 
           title={t("إدخال المقاسات", "Measurements")} 
           desc={t("أدخل مقاساتك مع معاينة رسومية وتصدير PDF", "Graphical preview and PDF export")}
           icon="📏" 
           onClick={() => setStep(AppStep.SIZE_INPUT)} 
         />
         <HubCard 
           title={t("لوحة تحكم المطور", "Developer Dashboard")} 
           desc={t("إدارة الهوية، السجل، الأسعار، والمزيد", "Manage branding, logs, pricing, and more")}
           icon="⚙️" 
           onClick={() => {
             if (currentUser) {
               setStep(AppStep.DEV_DASHBOARD);
             } else {
               setStep(AppStep.LOGIN);
             }
           }} 
           color={branding.secondaryColor}
         />
      </div>
    </div>
  );

  const renderContent = () => {
    if (step === AppStep.LOGIN) {
      // Check if trying to access dashboard specifically
      return <LoginScreen onLogin={handleLogin} allUsers={allUsers} branding={branding} onBackToHub={onBackToHub} />;
    }

    if (step === AppStep.DEV_DASHBOARD && !currentUser) {
        return <LoginScreen onLogin={handleLogin} allUsers={allUsers} branding={branding} onBackToHub={onBackToHub} />;
    }

    if (step === 'HUB') return renderHub();

    switch (step) {
      case AppStep.GENDER_SELECTION:
        return <GenderSelection selected={gender} onSelect={(g) => { setGender(g); addLog("اختيار الجنس", g); setStep(AppStep.SIZE_INPUT); }} branding={branding} onBackToHub={onBackToHub} />;
      case AppStep.SIZE_INPUT:
        return <SizeInput 
            userId={userId}
            value={measurements} 
            onChange={setMeasurements} 
            savedProfiles={savedProfiles} 
            onSaveProfile={handleSaveProfile} 
            onDeleteProfile={handleDeleteProfile} 
            onSelectProfile={setMeasurements} 
            branding={branding}
            onBackToHub={onBackToHub} 
        />;
      case AppStep.FABRIC_SELECTION:
        return <FabricSelection selected={fabric} onSelect={(f) => { setFabric(f); addLog("اختيار القماش", f.name); setStep(AppStep.COLOR_SELECTION); }} fabrics={fabrics} branding={branding} onBackToHub={onBackToHub} />;
      case AppStep.COLOR_SELECTION:
        return <ColorSelection 
            selectedColor={selectedColor} 
            selectedPattern={selectedPattern} 
            onSelectColor={(c) => { setSelectedColor(c); addLog("اختيار اللون", c.name); }}
            onSelectPattern={(p) => { setSelectedPattern(p); addLog("اختيار النقشة", p.name); setStep(AppStep.STYLE_SELECTION); }} 
            customColors={colors}
            branding={branding} 
            onBackToHub={onBackToHub}
        />;
      case AppStep.STYLE_SELECTION:
        return <StyleSelection gender={gender!} selected={style} onSelect={(s) => { setStyle(s); addLog("اختيار الموديل", s); setStep(AppStep.PATTERN_EDITOR); }} availableStyles={styles.filter(s => s.gender === gender)} branding={branding} onBackToHub={onBackToHub} />;
      case AppStep.PATTERN_EDITOR:
        return <PatternEditor gender={gender!} style={style!} measurements={measurements} onUpdate={(m) => { setMeasurements(m); addLog("تعديل يدوي", "تغيير قياسات البترون"); }} branding={branding} onBackToHub={onBackToHub} />;
      case AppStep.PREVIEW_3D:
        return <Model3DPreview style={style!} measurements={measurements} fabric={fabric!} color={selectedColor!} pattern={selectedPattern!} branding={branding} onBackToHub={onBackToHub} />;
      case AppStep.CHECKOUT:
        return (
          <Checkout 
            orderDetails={{ 
              gender: gender!, 
              style: style!, 
              measurements: measurements, 
              fabric: fabric!, 
              color: selectedColor!, 
              pattern: selectedPattern!,
              sleeveType: SleeveType.BASIC, 
              collarType: CollarType.NONE, 
              totalPrice: 450 
            } as any} 
            onConfirm={handleAddOrder} 
            branding={branding}
            onBackToHub={onBackToHub}
          />
        );
      case AppStep.DEV_DASHBOARD:
        return (
          <DevDashboard 
            fabrics={fabrics} 
            setFabrics={setFabrics} 
            styles={styles} 
            setStyles={setStyles} 
            colors={colors} 
            setColors={setColors} 
            pricing={pricing} 
            setPricing={setPricing} 
            orders={orders} 
            setOrders={setOrders} 
            branding={branding} 
            setBranding={(b) => { setBranding(b); localStorage.setItem('smart_tailor_branding', JSON.stringify(b)); }} 
            config={config} 
            setConfig={setConfig} 
            onClose={() => setStep('HUB')} 
            activityLogs={activityLogs} 
            currentUser={currentUser!} 
            allUsers={allUsers}
            onAddUser={handleAddUser}
            onUpdateUserRole={handleUpdateUserRole} 
            onDeleteUser={handleDeleteUser} 
            onLogout={handleLogout}
            db={db} 
          />
        );
      case AppStep.SUCCESS:
        return (
          <div className="text-center py-20 sm:py-32 animate-in zoom-in duration-700">
             <div className="text-7xl sm:text-9xl mb-8 sm:mb-12">🎉</div>
             <h2 className="text-3xl sm:text-5xl font-black text-white mb-6">{t('تهانينا! تم استلام طلبك', 'Congratulations! Order Received')}</h2>
             <button onClick={() => setStep('HUB')} className="bg-primary px-8 sm:px-12 py-4 sm:py-6 rounded-3xl font-black text-white text-lg sm:text-xl shadow-2xl" style={{ backgroundColor: branding.primaryColor }}>{t('العودة للرئيسية', 'Back to Home')}</button>
          </div>
        );
      default: return null;
    }
  };

  return (
    <div className="min-h-screen bg-dark text-slate-200 selection:bg-primary/30" style={{ fontFamily: branding.fontFamily }}>
      {step !== 'HUB' && step !== AppStep.DEV_DASHBOARD && step !== AppStep.SUCCESS && step !== AppStep.LOGIN && (
        <header className="sticky top-0 z-[100] glass px-4 sm:px-8 h-20 sm:h-24 flex items-center justify-between border-b border-white/5">
           <div className="flex items-center gap-2 sm:gap-4 cursor-pointer" onClick={() => setStep('HUB')}>
              <div className="w-10 h-10 sm:w-12 sm:h-12 bg-primary rounded-2xl flex items-center justify-center text-xl sm:text-2xl shadow-xl" style={{ backgroundColor: branding.primaryColor }}>🧵</div>
              <h1 className="text-lg sm:text-2xl font-black text-white hidden sm:block">{branding.companyName}</h1>
           </div>
           <StepProgressBar currentStep={step as AppStep} />
           {currentUser && (
             <button onClick={handleLogout} className="w-fit px-4 sm:px-6 py-2 sm:py-3 rounded-2xl bg-red-500/10 text-red-500 flex items-center justify-center hover:bg-red-500/20 transition-all border border-red-500/20 text-xs font-black">خروج</button>
           )}
           {!currentUser && (
             <button onClick={() => setStep('HUB')} className="w-10 h-10 sm:w-12 sm:h-12 rounded-2xl bg-slate-800 text-slate-400 flex items-center justify-center hover:bg-red-500/10 hover:text-red-500 transition-all border border-white/5">✕</button>
           )}
        </header>
      )}
      <main className="container mx-auto py-4 sm:py-10 px-4 sm:px-0">
         {renderContent()}
      </main>
      
      {typeof step === 'number' && step < AppStep.CHECKOUT && step !== AppStep.LOGIN && (
        <nav className="fixed bottom-0 left-0 right-0 z-[200] glass px-4 sm:px-8 py-4 sm:py-6 pb-8 sm:pb-12 flex items-center justify-center border-t border-white/5">
           <button 
             onClick={() => setStep(step + 1)} 
             className="w-full sm:w-auto bg-primary text-white px-8 sm:px-24 py-4 sm:py-6 rounded-3xl font-black text-xl sm:text-2xl shadow-2xl active:scale-95 transition-all flex items-center justify-center gap-4 sm:gap-6" 
             style={{ backgroundColor: branding.primaryColor }}
           >
              <span>{t('الخطوة التالية', 'Next Step')}</span>
              <span className="text-2xl sm:text-3xl">←</span>
           </button>
        </nav>
      )}
    </div>
  );
};

const HubCard = ({ title, desc, icon, onClick, primary, color }: any) => (
  <button 
    onClick={onClick}
    className={`p-6 sm:p-10 rounded-[2.5rem] sm:rounded-[3.5rem] text-right transition-all transform hover:scale-[1.03] active:scale-95 flex flex-col gap-4 sm:gap-6 relative overflow-hidden group border h-full ${
      primary ? 'text-white shadow-2xl' : 'bg-slate-900 border-white/5 hover:border-primary/30'
    }`}
    style={primary ? { backgroundColor: color || '#2563eb' } : {}}
  >
     <div className="text-5xl sm:text-7xl group-hover:rotate-12 transition-transform self-start">{icon}</div>
     <div className="mt-auto">
        <h3 className="text-2xl sm:text-3xl font-black mb-2 sm:mb-3">{title}</h3>
        <p className={`${primary ? 'text-white/80' : 'text-slate-500'} font-bold text-xs sm:text-sm leading-relaxed`}>{desc}</p>
     </div>
     {!primary && (
       <div className="absolute top-0 right-0 w-20 h-20 sm:w-24 sm:h-24 bg-primary/5 rounded-bl-full"></div>
     )}
  </button>
);

export default App;