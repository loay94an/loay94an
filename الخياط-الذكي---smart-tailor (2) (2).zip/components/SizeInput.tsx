
import React, { useState, useRef, useMemo } from 'react';
import { Measurements, MeasurementProfile, BrandingSettings, Gender } from '../types';
import { STANDARD_SIZES, CHILDREN_SIZES, TRANSLATIONS } from '../constants';
import { FullPatternService } from '../FullPatternService';
import jsPDF from 'jspdf';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import { storage } from '../firebase'; 

interface Props {
  userId: string;
  value: Measurements;
  onChange: (m: Measurements) => void;
  savedProfiles: MeasurementProfile[];
  onSaveProfile: (name: string, m: Measurements) => void;
  onDeleteProfile: (id: string) => void;
  onSelectProfile: (m: Measurements) => void;
  branding?: BrandingSettings;
  onBackToHub: () => void; 
  language: 'ar' | 'en';
  gender: Gender | null;
  onImageChange: (url: string | null) => void;
}

const modelLibrary = [
  { name: "Male Model", url: "https://placehold.co/400x600/1e293b/FFF?text=Male+Model" },
  { name: "Female Model", url: "https://placehold.co/400x600/1e293b/FFF?text=Female+Model" },
  { name: "Child Model", url: "https://placehold.co/400x600/1e293b/FFF?text=Child+Model" }
];

export const SizeInput: React.FC<Props> = ({ userId, value, onChange, savedProfiles, onSaveProfile, onDeleteProfile, onSelectProfile, branding, onBackToHub, language, gender, onImageChange }) => {
  const [activeTab, setActiveTab] = useState<'standard' | 'detailed' | 'profiles'>('detailed');
  const [activeGroup, setActiveGroup] = useState<'upper' | 'middle' | 'lower'>('upper');
  const [profileName, setProfileName] = useState("");
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  
  // Pattern Visualization State
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const svgRef = useRef<SVGSVGElement>(null);

  const txt = TRANSLATIONS[language];

  // 19 Fields Grouped
  const INPUT_GROUPS = [
    {
      id: 'upper',
      titleAr: 'أعلى الجسم',
      titleEn: 'Upper Body',
      fields: [
        { key: 'backWidth', labelAr: 'عرض الظهر', labelEn: 'Back Width' },
        { key: 'shoulderLength', labelAr: 'طول الكتف', labelEn: 'Shoulder Length' },
        { key: 'backLength', labelAr: 'طول الظهر', labelEn: 'Back Length' },
        { key: 'armLength', labelAr: 'طول الكم', labelEn: 'Arm Length' },
        { key: 'armCircumference', labelAr: 'محيط الذراع', labelEn: 'Arm Circumference' },
        { key: 'cuffCircumference', labelAr: 'محيط الاسوارة', labelEn: 'Cuff Circumference' },
        { key: 'neckCircumference', labelAr: 'محيط الرقبة', labelEn: 'Neck Circumference' },
        { key: 'chest', labelAr: 'محيط الصدر', labelEn: 'Chest' },
        { key: 'bodiceLength', labelAr: 'طول الصدر', labelEn: 'Bodice Length' },
        { key: 'shoulderToBust', labelAr: 'المسافة من اعلى الكتف الى الثدي', labelEn: 'Shoulder to Bust' },
        { key: 'bustPointToPoint', labelAr: 'المسافة بين الثديين', labelEn: 'Bust Point to Point' }
      ]
    },
    {
      id: 'middle',
      titleAr: 'الوسط',
      titleEn: 'Middle Body',
      fields: [
        { key: 'waist', labelAr: 'محيط الخصر', labelEn: 'Waist' },
        { key: 'waistToHip', labelAr: 'المسافة من الخصر الى الورك', labelEn: 'Waist to Hip' },
        { key: 'waistToKnee', labelAr: 'المسافة من الخصر الى الركبة', labelEn: 'Waist to Knee' },
        { key: 'waistToArmhole', labelAr: 'المسافة من الخصر الى الابط', labelEn: 'Waist to Armhole' },
        { key: 'armholeCircumference', labelAr: 'محيط الابط', labelEn: 'Armhole Circumference' }
      ]
    },
    {
      id: 'lower',
      titleAr: 'الأسفل',
      titleEn: 'Lower Body',
      fields: [
        { key: 'hips', labelAr: 'محيط الورك', labelEn: 'Hips' },
        { key: 'waistToFloor', labelAr: 'طول الساق من الخصر الى اسفل القدم', labelEn: 'Waist to Floor' },
        { key: 'skirtLength', labelAr: 'طول التنورة', labelEn: 'Skirt Length' }
      ]
    }
  ];

  const handleFieldChange = (field: string, val: number) => {
    onChange({ ...value, [field]: val });
  };

  const handleReset = () => {
      onChange(STANDARD_SIZES['M']);
      setZoom(1);
      setPan({ x: 0, y: 0 });
  };

  // Generate the Pattern Data based on measurements
  const patternData = useMemo(() => {
    return FullPatternService.generateMasterBlock(gender || Gender.FEMALE, value);
  }, [value, gender]);

  const updateImage = (url: string | null) => {
      setImageUrl(url);
      onImageChange(url);
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!e.target.files?.[0]) return;
    const file = e.target.files[0];
    if (storage) {
        const storageRef = ref(storage, `clients/${userId}/profile.jpg`);
        try {
          await uploadBytes(storageRef, file);
          const url = await getDownloadURL(storageRef);
          updateImage(url);
          alert(language === 'ar' ? "✅ تم تحميل الصورة بنجاح!" : "✅ Image uploaded successfully!");
          return;
        } catch (error) {
          console.warn("Firebase upload failed, falling back to local:", error);
        }
    }
    const reader = new FileReader();
    reader.onloadend = () => { updateImage(reader.result as string); };
    reader.readAsDataURL(file);
  };

  const exportPDF = () => {
    const doc = new jsPDF();
    doc.setFontSize(22);
    doc.setTextColor(branding?.primaryColor || '#000');
    doc.text(branding?.companyName || "Pattern Report", 105, 20, { align: 'center' });
    
    // Draw simple representation of the pattern
    if (svgRef.current) {
        // Capture svg as image (simplified for this example, could use svg2pdf for vector)
        const svgData = new XMLSerializer().serializeToString(svgRef.current);
        const canvas = document.createElement("canvas");
        const ctx = canvas.getContext("2d");
        const img = new Image();
        img.onload = () => {
            canvas.width = 600;
            canvas.height = 800;
            if(ctx) {
                ctx.fillStyle = "white";
                ctx.fillRect(0,0,600,800);
                ctx.drawImage(img, 0, 0, 600, 800);
                const imgData = canvas.toDataURL("image/png");
                doc.addImage(imgData, 'PNG', 50, 40, 110, 150);
                doc.save("master_pattern.pdf");
            }
        };
        img.src = "data:image/svg+xml;base64," + window.btoa(unescape(encodeURIComponent(svgData)));
    } else {
        doc.save("measurements.pdf");
    }
  };

  const activeSizes = gender === Gender.CHILDREN ? CHILDREN_SIZES : STANDARD_SIZES;

  return (
    <div className="w-full max-w-7xl mx-auto space-y-6 sm:space-y-10 animate-in fade-in duration-1000 pb-20 relative pt-12">
      <button 
        onClick={onBackToHub} 
        className="absolute top-0 right-0 z-50 w-12 h-12 bg-slate-800/50 backdrop-blur-md border border-white/10 rounded-full flex items-center justify-center text-slate-300 hover:text-white hover:bg-slate-700 transition-all shadow-lg group"
        title={txt.backToHome}
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2.5} stroke="currentColor" className="w-6 h-6 transform group-hover:-translate-x-1 transition-transform">
          <path strokeLinecap="round" strokeLinejoin="round" d="M9 15L3 9m0 0l6-6M3 9h12a6 6 0 010 12h-3" />
        </svg>
      </button>

      {/* Main Mode Tabs */}
      <div className="flex bg-slate-900/80 backdrop-blur-2xl p-1.5 sm:p-2 rounded-3xl border border-white/5 w-full md:w-fit mx-auto shadow-2xl overflow-x-auto no-scrollbar">
        <button onClick={() => setActiveTab('detailed')} className={`flex-1 px-4 sm:px-10 py-3 rounded-2xl font-black text-[10px] sm:text-xs whitespace-nowrap transition-all ${activeTab === 'detailed' ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}>{language === 'ar' ? 'إدخال مفصل (19)' : 'Detailed Input (19)'}</button>
        <button onClick={() => setActiveTab('standard')} className={`flex-1 px-4 sm:px-10 py-3 rounded-2xl font-black text-[10px] sm:text-xs whitespace-nowrap transition-all ${activeTab === 'standard' ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}>{txt.standardSizes}</button>
        <button onClick={() => setActiveTab('profiles')} className={`flex-1 px-4 sm:px-10 py-3 rounded-2xl font-black text-[10px] sm:text-xs whitespace-nowrap transition-all ${activeTab === 'profiles' ? 'bg-primary text-white shadow-xl' : 'text-slate-500 hover:text-slate-300'}`}>{txt.archives}</button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 sm:gap-8">
        {/* Left Side: Inputs or Profile Selection */}
        <div className="lg:col-span-5 bg-slate-900 rounded-[2.5rem] sm:rounded-[3rem] p-6 border border-white/5 shadow-2xl flex flex-col h-[600px] sm:h-[750px] relative overflow-hidden">
          
          {activeTab === 'detailed' && (
             <div className="flex flex-col h-full">
                {/* Measurement Group Tabs */}
                <div className="flex bg-slate-800 p-1 rounded-xl border border-white/5 w-full mx-auto shadow-lg mb-4 overflow-x-auto no-scrollbar">
                  {INPUT_GROUPS.map((group) => (
                    <button 
                      key={group.id} 
                      onClick={() => setActiveGroup(group.id as any)}
                      className={`flex-1 px-2 py-2 rounded-lg text-xs font-black whitespace-nowrap transition-all ${activeGroup === group.id ? 'bg-primary text-white shadow-md' : 'text-slate-500 hover:text-slate-300'}`}
                    >
                      {language === 'ar' ? group.titleAr : group.titleEn}
                    </button>
                  ))}
                </div>

                {/* Fields Grid */}
                <div className="flex-1 overflow-y-auto custom-scrollbar pb-4 pr-2">
                  {INPUT_GROUPS.map((group) => (
                    <div key={group.id} className={`${activeGroup === group.id ? 'block' : 'hidden'} animate-in fade-in slide-in-from-bottom-2`}>
                      <div className="space-y-3">
                        {group.fields.map((field) => (
                          <div key={field.key} className="bg-slate-800/50 p-3 rounded-2xl border border-white/5 hover:border-primary/30 transition-all flex justify-between items-center group">
                            <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest group-hover:text-primary transition-colors">
                              {language === 'ar' ? field.labelAr : field.labelEn}
                            </label>
                            <input 
                              type="number" 
                              min={0} 
                              max={300} 
                              value={(value as any)[field.key] || ''} 
                              onChange={(e) => handleFieldChange(field.key, parseFloat(e.target.value))} 
                              className="w-20 bg-slate-900 border border-white/10 rounded-lg p-2 text-white text-center font-black focus:border-primary outline-none" 
                              placeholder="0"
                            />
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
            </div>
          )}

          {activeTab === 'standard' && (
             <div className="flex flex-col gap-4 overflow-y-auto custom-scrollbar h-full">
                {Object.keys(activeSizes).map((size) => (
                <button key={size} onClick={() => onSelectProfile(activeSizes[size])} className={`w-full py-6 rounded-2xl border-2 transition-all ${JSON.stringify(value) === JSON.stringify(activeSizes[size]) ? 'border-primary bg-primary/10 text-primary' : 'border-white/5 bg-slate-800/40 text-slate-500'}`}>
                  <span className="text-3xl font-black block">{size}</span>
                  <span className="text-[10px] font-bold uppercase">Standard</span>
                </button>
              ))}
             </div>
          )}

          {activeTab === 'profiles' && (
             <div className="flex flex-col gap-4 overflow-y-auto custom-scrollbar h-full">
               {savedProfiles.map(p => (
                 <div key={p.id} className="p-4 bg-slate-800/40 rounded-2xl border border-white/5 flex flex-col gap-3">
                   <div className="flex justify-between items-center">
                     <h5 className="font-bold text-white">{p.name}</h5>
                     <span className="text-[10px] text-slate-500">{new Date(p.createdAt).toLocaleDateString()}</span>
                   </div>
                   <div className="flex gap-2">
                     <button onClick={() => onSelectProfile(p.measurements)} className="flex-1 bg-primary py-2 rounded-lg text-xs font-black text-white">{txt.use}</button>
                     <button onClick={() => onDeleteProfile(p.id)} className="w-8 bg-red-500/10 text-red-500 rounded-lg">🗑️</button>
                   </div>
                 </div>
               ))}
               {savedProfiles.length === 0 && <p className="text-center text-slate-500 py-10">{txt.noProfiles}</p>}
             </div>
          )}
        </div>

        {/* Right Side: Professional Pattern Visualizer */}
        <div className="lg:col-span-7 flex flex-col gap-4 h-[600px] sm:h-[750px]">
           <div className="relative flex-1 bg-slate-950 rounded-[2.5rem] border-4 border-slate-900 overflow-hidden shadow-2xl group">
             
             {/* Toolbar */}
             <div className="absolute top-4 left-4 right-4 z-20 flex justify-between items-start pointer-events-none">
                <div className="pointer-events-auto flex flex-col gap-2">
                   <button onClick={() => setZoom(z => Math.min(z + 0.1, 3))} className="w-10 h-10 bg-slate-800 text-white rounded-xl shadow-lg border border-white/10 hover:bg-slate-700 font-bold">+</button>
                   <button onClick={() => setZoom(z => Math.max(z - 0.1, 0.5))} className="w-10 h-10 bg-slate-800 text-white rounded-xl shadow-lg border border-white/10 hover:bg-slate-700 font-bold">-</button>
                   <button onClick={handleReset} className="w-10 h-10 bg-red-500/20 text-red-500 rounded-xl shadow-lg border border-red-500/20 hover:bg-red-500 hover:text-white font-bold text-xs">R</button>
                </div>
                <div className="pointer-events-auto bg-slate-900/80 backdrop-blur px-4 py-2 rounded-xl border border-white/10">
                   <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider">{language === 'ar' ? 'معاينة البترون الأساسي' : 'Master Pattern Preview'}</span>
                </div>
             </div>

             {/* SVG Canvas */}
             <div className="w-full h-full flex items-center justify-center cursor-grab active:cursor-grabbing bg-[radial-gradient(#1e293b_1px,transparent_1px)] bg-[length:20px_20px]" 
                  onMouseDown={(e) => {
                    const startX = e.clientX - pan.x;
                    const startY = e.clientY - pan.y;
                    const onMove = (mv: MouseEvent) => setPan({ x: mv.clientX - startX, y: mv.clientY - startY });
                    const onUp = () => { window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); };
                    window.addEventListener('mousemove', onMove);
                    window.addEventListener('mouseup', onUp);
                  }}
             >
                <div style={{ transform: `translate(${pan.x}px, ${pan.y}px) scale(${zoom})`, transition: 'transform 0.1s ease-out' }}>
                   <svg 
                      ref={svgRef}
                      width="500" 
                      height="800" 
                      viewBox={`-${patternData.width/2} -50 ${patternData.width} ${patternData.height}`} 
                      className="overflow-visible drop-shadow-2xl"
                   >
                      <defs>
                         <marker id="dot" viewBox="0 0 10 10" refX="5" refY="5" markerWidth="4" markerHeight="4">
                           <circle cx="5" cy="5" r="5" fill="#f50057" />
                         </marker>
                      </defs>

                      {/* 1. Dimensions (Blue) */}
                      {patternData.dimensions.map((line, i) => (
                        <g key={i}>
                           <line 
                             x1={line.x1} y1={line.y1} x2={line.x2} y2={line.y2} 
                             stroke="#2563eb" 
                             strokeWidth="1.5" 
                             strokeDasharray={line.isDimension ? "5,5" : "none"}
                             opacity="0.7"
                           />
                           {/* Mirror for symmetry */}
                           <line 
                             x1={-line.x1} y1={line.y1} x2={-line.x2} y2={line.y2} 
                             stroke="#2563eb" 
                             strokeWidth="1.5" 
                             strokeDasharray={line.isDimension ? "5,5" : "none"}
                             opacity="0.7"
                           />
                           {/* Label */}
                           {!line.isDimension && (
                             <text x={line.x2 + 10} y={line.y2} fontSize="10" fill="#2563eb" alignmentBaseline="middle">{line.label}</text>
                           )}
                        </g>
                      ))}

                      {/* 2. Contour (Black) */}
                      <path d={patternData.contours} fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
                      {/* Mirror Contour */}
                      <path d={patternData.contours} fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" transform="scale(-1, 1)" />

                      {/* 3. Points (Red) */}
                      {patternData.points.map((pt, i) => (
                        <g key={i}>
                           <circle cx={pt.x} cy={pt.y} r="4" fill="#f50057" stroke="white" strokeWidth="1" />
                           <circle cx={-pt.x} cy={pt.y} r="4" fill="#f50057" stroke="white" strokeWidth="1" />
                           <text x={pt.x + 8} y={pt.y - 8} fontSize="8" fill="#f50057">{pt.label}</text>
                        </g>
                      ))}
                      
                      {/* Center Line */}
                      <line x1="0" y1="0" x2="0" y2={patternData.height} stroke="white" strokeWidth="0.5" strokeDasharray="10,5" opacity="0.3" />

                   </svg>
                </div>
             </div>
           </div>

           {/* Action Buttons */}
           <div className="bg-slate-900 rounded-[2rem] p-6 border border-white/5 flex flex-wrap gap-4 items-center justify-between">
              <div className="flex-1 min-w-[200px]">
                 <input 
                    type="text" 
                    placeholder={txt.profileName} 
                    value={profileName} 
                    onChange={(e) => setProfileName(e.target.value)} 
                    className="w-full bg-slate-800 border border-white/10 p-4 rounded-2xl text-white font-bold outline-none"
                 />
              </div>
              <div className="flex gap-2">
                 <button onClick={() => { if(profileName) { onSaveProfile(profileName, value); setProfileName(""); } }} className="bg-primary text-white px-6 py-4 rounded-2xl font-black text-sm hover:bg-blue-600 transition-all shadow-lg">{txt.saveMeasurements}</button>
                 <button onClick={exportPDF} className="bg-emerald-500/10 text-emerald-500 border border-emerald-500/20 px-6 py-4 rounded-2xl font-black text-sm hover:bg-emerald-500 hover:text-white transition-all">Export PDF</button>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};
