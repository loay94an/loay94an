
import { Component, ChangeDetectionStrategy, output, signal, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatternModel } from '../../models/pattern.model';
import { GeminiService, AiPatternAnalysis } from '../../services/gemini.service';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { BodyShapeSelectorComponent } from '../body-shape-selector/body-shape-selector.component';

type AiStep = 'body-shape' | 'prompt' | 'processing' | 'confirm';

@Component({
  selector: 'app-ai-design',
  standalone: true,
  imports: [CommonModule, BodyShapeSelectorComponent],
  templateUrl: './ai-design.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AiDesignComponent {
  analysisComplete = output<PatternModel>();
  back = output<void>();

  private geminiService = inject(GeminiService);
  private sanitizer = inject(DomSanitizer);

  step = signal<AiStep>('body-shape');
  prompt = signal<string>('فستان صيفي بسيط بياقة دائرية وأكمام قصيرة للمرأة.');
  selectedBodyShape = signal<string | null>(null);
  generatedImageBase64 = signal<string | null>(null);
  analysisResult = signal<AiPatternAnalysis | null>(null);
  error = signal<string | null>(null);
  processingMessage = signal('جاري تحليل الوصف...');

  generatedImageUrl = computed<SafeUrl | null>(() => {
    const base64 = this.generatedImageBase64();
    if (base64) {
      return this.sanitizer.bypassSecurityTrustUrl(`data:image/png;base64,${base64}`);
    }
    return null;
  });

  isLoading = computed(() => this.step() === 'processing');

  updatePrompt(event: Event) {
    this.prompt.set((event.target as HTMLTextAreaElement).value);
  }
  
  startOver(): void {
    this.step.set('body-shape');
    this.generatedImageBase64.set(null);
    this.analysisResult.set(null);
    this.selectedBodyShape.set(null);
    this.error.set(null);
  }

  onBodyShapeSelected(shape: string): void {
    const finalShape = shape === 'none' ? null : shape;
    this.selectedBodyShape.set(finalShape);
    this.step.set('prompt');
  }

  async processPrompt(): Promise<void> {
    const userPrompt = this.prompt();
    if (!userPrompt.trim()) {
      this.error.set('يرجى كتابة وصف للتصميم.');
      return;
    }

    this.step.set('processing');
    this.error.set(null);
    this.generatedImageBase64.set(null);
    this.analysisResult.set(null);

    try {
      // Step 1: Analyze the text to get category and measurements.
      this.processingMessage.set('جاري تحليل الوصف...');
      const analysis = await this.geminiService.analyzeGarmentText(userPrompt);
      this.analysisResult.set(analysis);
      
      // Step 2: Generate an image for visual confirmation using the pre-selected body shape.
      this.processingMessage.set('يتم الآن توليد صورة...');
      const base64 = await this.geminiService.generateImageFromText(userPrompt, this.selectedBodyShape());
      this.generatedImageBase64.set(base64);
      this.step.set('confirm');
    } catch (err) {
      this.error.set(err instanceof Error ? err.message : 'An unknown error occurred during analysis.');
      this.step.set('prompt'); // Go back to prompt on error
    }
  }

  confirmDesign(): void {
    const analysis = this.analysisResult();
    const imageUrl = this.generatedImageUrl();

    if (!analysis || !imageUrl) {
      this.error.set('حدث خطأ، البيانات المطلوبة غير متوفرة.');
      this.step.set('prompt');
      return;
    }

    const aiModel: PatternModel = {
      id: 'ai-' + Date.now(),
      name: analysis.garmentName,
      category: analysis.category,
      imageUrl: imageUrl as string,
      difficulty: 'متوسط',
      requiredMeasurements: analysis.requiredMeasurements,
    };

    this.analysisComplete.emit(aiModel);
  }
}
