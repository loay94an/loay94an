
import { Component, ChangeDetectionStrategy, output, signal, inject, computed } from '@angular/core';
import { DomSanitizer, SafeUrl } from '@angular/platform-browser';
import { CommonModule } from '@angular/common';
import { PatternModel } from '../../models/pattern.model';
import { GeminiService, AiPatternAnalysis } from '../../services/gemini.service';

type CustomDesignStep = 'upload' | 'processing' | 'confirm';

@Component({
  selector: 'app-custom-design',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './custom-design.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CustomDesignComponent {
  analysisComplete = output<PatternModel>();
  back = output<void>();

  private sanitizer = inject(DomSanitizer);
  private geminiService = inject(GeminiService);

  step = signal<CustomDesignStep>('upload');
  prompt = signal<string>('');
  
  // Garment Image State
  uploadedFile = signal<File | null>(null);
  previewUrl = signal<SafeUrl | null>(null);
  isDragging = signal<boolean>(false);

  // Fabric Image State
  fabricFile = signal<File | null>(null);
  fabricPreviewUrl = signal<SafeUrl | null>(null);
  isDraggingFabric = signal<boolean>(false);

  // Processing State
  processingMessage = signal<string>('');
  error = signal<string | null>(null);
  
  // Confirmation State
  generatedImageBase64 = signal<string | null>(null);
  analysisResult = signal<AiPatternAnalysis | null>(null);

  isLoading = computed(() => this.step() === 'processing');

  generatedImageUrl = computed<SafeUrl | null>(() => {
    const base64 = this.generatedImageBase64();
    if (base64) {
      return this.sanitizer.bypassSecurityTrustUrl(`data:image/png;base64,${base64}`);
    }
    return null;
  });

  // --- Garment File Handlers ---
  onFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) this.handleFile(input.files[0]);
  }
  onDragOver(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging.set(true);
  }
  onDragLeave(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging.set(false);
  }
  onDrop(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDragging.set(false);
    if (event.dataTransfer?.files && event.dataTransfer.files[0]) this.handleFile(event.dataTransfer.files[0]);
  }
  handleFile(file: File): void {
    if (!file.type.startsWith('image/')) {
      this.error.set('Please upload a valid image file for the garment.');
      return;
    }
    this.uploadedFile.set(file);
    this.previewUrl.set(this.sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(file)));
    this.error.set(null);
  }
  removeGarmentImage(): void {
    this.uploadedFile.set(null);
    this.previewUrl.set(null);
  }

  // --- Fabric File Handlers ---
  onFabricFileSelected(event: Event): void {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files[0]) this.handleFabricFile(input.files[0]);
  }
  onFabricDragOver(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDraggingFabric.set(true);
  }
  onFabricDragLeave(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDraggingFabric.set(false);
  }
  onFabricDrop(event: DragEvent): void {
    event.preventDefault();
    event.stopPropagation();
    this.isDraggingFabric.set(false);
    if (event.dataTransfer?.files && event.dataTransfer.files[0]) this.handleFabricFile(event.dataTransfer.files[0]);
  }
  handleFabricFile(file: File): void {
    if (!file.type.startsWith('image/')) {
      this.error.set('Please upload a valid image file for the fabric.');
      return;
    }
    this.fabricFile.set(file);
    this.fabricPreviewUrl.set(this.sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(file)));
    this.error.set(null);
  }
  removeFabricImage(): void {
    this.fabricFile.set(null);
    this.fabricPreviewUrl.set(null);
  }

  updatePrompt(event: Event) {
    this.prompt.set((event.target as HTMLTextAreaElement).value);
  }

  async processDesign(): Promise<void> {
    const garmentFile = this.uploadedFile();
    if (!garmentFile) {
      this.error.set('الرجاء تحميل صورة لشكل الموديل أولاً.');
      return;
    }

    this.step.set('processing');
    this.error.set(null);
    const userPrompt = this.prompt();
    const fabricFile = this.fabricFile();

    try {
      if (fabricFile) {
        // --- NEW FLOW: Combine garment, fabric, and prompt ---
        this.processingMessage.set('يتم الآن دمج الصور والوصف...');
        const garmentBase64 = await this.fileToBase64(garmentFile);
        const fabricBase64 = await this.fileToBase64(fabricFile);

        const detailedPrompt = await this.geminiService.createImagePromptFromParts(
          garmentBase64, garmentFile.type,
          fabricBase64, fabricFile.type,
          userPrompt
        );

        this.processingMessage.set('يتم الآن توليد صورة التصميم الجديد...');
        const newImageBase64 = await this.geminiService.generateImageFromText(detailedPrompt);
        this.generatedImageBase64.set(newImageBase64);

        this.processingMessage.set('يتم الآن تحليل التصميم الجديد لتحديد المقاسات...');
        const analysis = await this.geminiService.analyzeGarmentImage(newImageBase64, 'image/png', 'Analyze this generated garment.');
        this.analysisResult.set(analysis);

        this.step.set('confirm');
      } else {
        // --- ORIGINAL FLOW: Analyze just the garment image ---
        this.processingMessage.set('يتم الآن تحليل صورة الموديل...');
        const base64Image = await this.fileToBase64(garmentFile);
        const analysis: AiPatternAnalysis = await this.geminiService.analyzeGarmentImage(base64Image, garmentFile.type, userPrompt);

        const customModel: PatternModel = {
          id: 'custom-' + Date.now(),
          name: analysis.garmentName,
          category: analysis.category,
          imageUrl: this.previewUrl() as string,
          difficulty: 'متوسط',
          requiredMeasurements: analysis.requiredMeasurements,
        };
        this.analysisComplete.emit(customModel);
      }
    } catch (err) {
      this.error.set(err instanceof Error ? err.message : 'An unknown error occurred.');
      this.step.set('upload'); // Go back to the start on error
    }
  }

  confirmDesign(): void {
    const analysis = this.analysisResult();
    const imageUrl = this.generatedImageUrl();
    if (!analysis || !imageUrl) {
      this.error.set('حدث خطأ، البيانات المطلوبة غير متوفرة.');
      this.step.set('upload');
      return;
    }
    const aiModel: PatternModel = {
      id: 'ai-' + Date.now(),
      name: analysis.garmentName,
      category: analysis.category,
      imageUrl: imageUrl as string,
      difficulty: 'متوسط',
      requiredMeasurements: analysis.requiredMeasurements,
    };
    this.analysisComplete.emit(aiModel);
  }

  startOver(): void {
    this.step.set('upload');
    this.generatedImageBase64.set(null);
    this.analysisResult.set(null);
    this.error.set(null);
  }

  private fileToBase64(file: File): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const result = (reader.result as string).split(',')[1];
        resolve(result);
      };
      reader.onerror = error => reject(error);
    });
  }
}
