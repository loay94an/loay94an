import { Component, ChangeDetectionStrategy, output, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PatternModel } from '../../models/pattern.model';
import { GeminiService, AiPatternAnalysis, OnlinePatternResult } from '../../services/gemini.service';

type SearchStep = 'search' | 'loading' | 'results' | 'analyzing';

@Component({
  selector: 'app-online-search',
  imports: [CommonModule],
  templateUrl: './online-search.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class OnlineSearchComponent {
  analysisComplete = output<PatternModel>();
  back = output<void>();

  private geminiService = inject(GeminiService);

  step = signal<SearchStep>('search');
  query = signal<string>('free t-shirt pattern for women');
  searchResults = signal<OnlinePatternResult[]>([]);
  error = signal<string | null>(null);

  updateQuery(event: Event): void {
    this.query.set((event.target as HTMLInputElement).value);
  }

  async searchPatterns(): Promise<void> {
    if (!this.query().trim()) {
      this.error.set('يرجى إدخال عبارة بحث.');
      return;
    }
    this.step.set('loading');
    this.error.set(null);
    this.searchResults.set([]);

    try {
      const results = await this.geminiService.searchForPatternsOnline(this.query());
      if (results.length === 0) {
        this.error.set('لم يتم العثور على نتائج. حاول استخدام عبارة بحث مختلفة.');
        this.step.set('search');
      } else {
        this.searchResults.set(results);
        this.step.set('results');
      }
    } catch (err) {
      this.error.set(err instanceof Error ? err.message : 'An unknown error occurred during search.');
      this.step.set('search');
    }
  }
  
  async selectAndAnalyze(pattern: OnlinePatternResult): Promise<void> {
    this.step.set('analyzing');
    this.error.set(null);

    try {
      // Fetch image from URL and convert to base64
      const response = await fetch(pattern.imageUrl);
       if (!response.ok) {
        throw new Error(`Failed to fetch image. Status: ${response.statusText}`);
      }
      const blob = await response.blob();
      const base64Image = await this.blobToBase64(blob);

      // Analyze the image with Gemini
      const analysis: AiPatternAnalysis = await this.geminiService.analyzeGarmentImage(
        base64Image,
        blob.type,
        `Analyze this sewing pattern found online, titled "${pattern.sourceTitle}".`
      );

      // Create a PatternModel from the analysis
      const customModel: PatternModel = {
        id: 'online-' + Date.now(),
        name: analysis.garmentName,
        category: analysis.category,
        imageUrl: pattern.imageUrl,
        difficulty: 'متوسط',
        requiredMeasurements: analysis.requiredMeasurements,
      };

      this.analysisComplete.emit(customModel);

    } catch (err) {
      console.error(err);
      let errorMessage = 'Could not analyze the selected pattern. It might be inaccessible or in an unsupported format.';
      if (err instanceof TypeError && (err.message.includes('Failed to fetch') || err.message.includes('NetworkError'))) {
        errorMessage = 'تعذر جلب الصورة بسبب قيود أمان المتصفح (CORS). الرجاء تجربة باترون آخر من مصدر مختلف.';
      } else if (err instanceof Error) {
        errorMessage = err.message;
      }
      this.error.set(errorMessage);
      this.step.set('results'); // Go back to results on error
    }
  }

  private blobToBase64(blob: Blob): Promise<string> {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(blob);
      reader.onload = () => {
        const result = (reader.result as string).split(',')[1];
        resolve(result);
      };
      reader.onerror = error => reject(error);
    });
  }
}
