import { Component, ChangeDetectionStrategy, output } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface BodyShape {
  key: string;
  name: string;
  description: string;
  icon: string;
}

@Component({
  selector: 'app-body-shape-selector',
  imports: [CommonModule],
  templateUrl: './body-shape-selector.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class BodyShapeSelectorComponent {
  shapeSelected = output<string>();

  bodyShapes: BodyShape[] = [
    { key: 'hourglass', name: 'الساعة الرملية', description: 'أكتاف وأرداف متوازنة مع خصر محدد.', icon: 'https://api.iconify.design/mdi:hourglass.svg' },
    { key: 'pear', name: 'الكمثرى (المثلث)', description: 'الأرداف أعرض من الأكتاف.', icon: 'https://api.iconify.design/mdi:triangle-outline.svg' },
    { key: 'inverted-triangle', name: 'المثلث المقلوب', description: 'الأكتاف والصدر أعرض من الأرداف.', icon: 'https://api.iconify.design/mdi:triangle-outline.svg?rotate=180deg' },
    { key: 'rectangle', name: 'المستطيل', description: 'الأكتاف والخصر والأرداف بنفس العرض تقريباً.', icon: 'https://api.iconify.design/mdi:rectangle-outline.svg' },
    { key: 'apple', name: 'التفاحة', description: 'الخصر ممتلئ وأعرض من الأكتاف والأرداف.', icon: 'https://api.iconify.design/mdi:circle-outline.svg' },
  ];

  selectShape(shape: string): void {
    this.shapeSelected.emit(shape);
  }
}
