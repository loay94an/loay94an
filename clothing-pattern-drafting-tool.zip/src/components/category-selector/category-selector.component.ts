import { Component, ChangeDetectionStrategy, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Category } from '../../models/pattern.model';

interface CategoryOption {
  key: Category;
  name: string;
  icon: string;
}

@Component({
  selector: 'app-category-selector',
  imports: [CommonModule],
  templateUrl: './category-selector.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class CategorySelectorComponent {
  categorySelected = output<Category>();

  categories: CategoryOption[] = [
    { key: 'child', name: 'طفل', icon: 'https://api.iconify.design/fa-solid:child.svg' },
    { key: 'woman', name: 'امرأة', icon: 'https://api.iconify.design/ph:dress-fill.svg' },
    { key: 'man', name: 'رجل', icon: 'https://api.iconify.design/mdi:account-tie.svg' },
  ];

  selectCategory(category: Category): void {
    this.categorySelected.emit(category);
  }
}
