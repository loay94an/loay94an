
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
}

export const Layout: React.FC<LayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-[#f8fafc]">
      <header className="bg-white/80 backdrop-blur-md border-b border-slate-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-14 sm:h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 sm:w-10 sm:h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-100 flex-shrink-0">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 sm:h-6 sm:w-6 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M14.121 14.121L19 19m-7-7l7-7m-7 7l-2.879 2.879M12 12L9.121 9.121m0 5.758L6 18l-3-3 3.121-3.121m0 0L9.121 9.121M12 12l3-3 3 3-3 3-3-3z" />
              </svg>
            </div>
            <div className="overflow-hidden">
              <h1 className="text-sm sm:text-xl font-black text-slate-900 truncate tracking-tight">Tailor Studio</h1>
              <p className="text-[9px] sm:text-xs text-slate-500 truncate font-medium">نظام هندسة البترونات</p>
            </div>
          </div>
          <nav className="flex gap-4">
            <button className="text-[11px] sm:text-sm text-slate-600 hover:text-indigo-600 font-bold transition-colors">الدعم</button>
          </nav>
        </div>
      </header>
      <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-8">
        {children}
      </main>
      <footer className="bg-white border-t border-slate-200 py-6 text-center">
        <p className="text-slate-400 text-[10px] sm:text-xs font-bold uppercase tracking-widest">
          Tailor Studio &copy; {new Date().getFullYear()} // Precision Engineering
        </p>
      </footer>
    </div>
  );
};
