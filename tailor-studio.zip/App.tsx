
import React, { useState, useMemo, useRef, useCallback, useEffect } from 'react';
import { Layout } from './components/Layout.tsx';
import { 
  Measurement, PatternPreset, SizingStandard, 
  PatternCategory, PatternOutput
} from './types.ts';
import { generatePattern } from './services/patternEngine.ts';
import { processUserAlgorithm } from './services/geminiService.ts';

const SIZING_STANDARDS: Record<SizingStandard, { name: string; measurements: Measurement[] }> = {
  'EU-34': { name: 'EU 34 (XS)', measurements: [{ label: 'bust', value: 80 }, { label: 'waist', value: 62 }, { label: 'hips', value: 86 }, { label: 'neck', value: 35 }, { label: 'back_length', value: 40 }, { label: 'shoulder_width', value: 34 }, { label: 'arm_length', value: 56 }, { label: 'piece_length', value: 60 }, { label: 'arm_circumference', value: 26 }] },
  'EU-36': { name: 'EU 36 (S)', measurements: [{ label: 'bust', value: 84 }, { label: 'waist', value: 66 }, { label: 'hips', value: 90 }, { label: 'neck', value: 36 }, { label: 'back_length', value: 40.5 }, { label: 'shoulder_width', value: 36 }, { label: 'arm_length', value: 57 }, { label: 'piece_length', value: 62 }, { label: 'arm_circumference', value: 27 }] },
  'EU-38': { name: 'EU 38 (M)', measurements: [{ label: 'bust', value: 88 }, { label: 'waist', value: 70 }, { label: 'hips', value: 94 }, { label: 'neck', value: 37 }, { label: 'back_length', value: 41 }, { label: 'shoulder_width', value: 38 }, { label: 'arm_length', value: 58 }, { label: 'piece_length', value: 65 }, { label: 'arm_circumference', value: 28 }] },
  'EU-40': { name: 'EU 40 (L)', measurements: [{ label: 'bust', value: 92 }, { label: 'waist', value: 74 }, { label: 'hips', value: 98 }, { label: 'neck', value: 38 }, { label: 'back_length', value: 42 }, { label: 'shoulder_width', value: 40 }, { label: 'arm_length', value: 60 }, { label: 'piece_length', value: 66 }, { label: 'arm_circumference', value: 30 }] },
  'EU-42': { name: 'EU 42 (XL)', measurements: [{ label: 'bust', value: 96 }, { label: 'waist', value: 78 }, { label: 'hips', value: 102 }, { label: 'neck', value: 39 }, { label: 'back_length', value: 43 }, { label: 'shoulder_width', value: 42 }, { label: 'arm_length', value: 62 }, { label: 'piece_length', value: 67 }, { label: 'arm_circumference', value: 32 }] },
  'EU-44': { name: 'EU 44 (XXL)', measurements: [{ label: 'bust', value: 100 }, { label: 'waist', value: 82 }, { label: 'hips', value: 106 }, { label: 'neck', value: 40 }, { label: 'back_length', value: 44 }, { label: 'shoulder_width', value: 44 }, { label: 'arm_length', value: 63 }, { label: 'piece_length', value: 68 }, { label: 'arm_circumference', value: 34 }] },
  'EU-46': { name: 'EU 46 (3XL)', measurements: [{ label: 'bust', value: 104 }, { label: 'waist', value: 86 }, { label: 'hips', value: 110 }, { label: 'neck', value: 41 }, { label: 'back_length', value: 45 }, { label: 'shoulder_width', value: 46 }, { label: 'arm_length', value: 64 }, { label: 'piece_length', value: 70 }, { label: 'arm_circumference', value: 36 }] },
  'US-2': { name: 'US 2', measurements: [{ label: 'bust', value: 82.5 }, { label: 'waist', value: 64 }, { label: 'hips', value: 89 }, { label: 'neck', value: 35 }, { label: 'back_length', value: 39 }, { label: 'shoulder_width', value: 35 }, { label: 'arm_length', value: 55 }, { label: 'piece_length', value: 60 }, { label: 'arm_circumference', value: 26 }] },
  'US-4': { name: 'US 4', measurements: [{ label: 'bust', value: 85 }, { label: 'waist', value: 66 }, { label: 'hips', value: 91.5 }, { label: 'neck', value: 35.5 }, { label: 'back_length', value: 39.5 }, { label: 'shoulder_width', value: 36 }, { label: 'arm_length', value: 56 }, { label: 'piece_length', value: 62 }, { label: 'arm_circumference', value: 27 }] },
  'US-6': { name: 'US 6', measurements: [{ label: 'bust', value: 86.5 }, { label: 'waist', value: 68.5 }, { label: 'hips', value: 92.5 }, { label: 'neck', value: 36 }, { label: 'back_length', value: 40 }, { label: 'shoulder_width', value: 37 }, { label: 'arm_length', value: 57 }, { label: 'piece_length', value: 64 }, { label: 'arm_circumference', value: 28 }] },
  'US-8': { name: 'US 8', measurements: [{ label: 'bust', value: 89 }, { label: 'waist', value: 71 }, { label: 'hips', value: 95 }, { label: 'neck', value: 37 }, { label: 'back_length', value: 41 }, { label: 'shoulder_width', value: 38 }, { label: 'arm_length', value: 58 }, { label: 'piece_length', value: 65 }, { label: 'arm_circumference', value: 29 }] },
  'US-10': { name: 'US 10', measurements: [{ label: 'bust', value: 92.5 }, { label: 'waist', value: 75 }, { label: 'hips', value: 99 }, { label: 'neck', value: 38 }, { label: 'back_length', value: 42 }, { label: 'shoulder_width', value: 40 }, { label: 'arm_length', value: 60 }, { label: 'piece_length', value: 66 }, { label: 'arm_circumference', value: 31 }] },
  'US-12': { name: 'US 12', measurements: [{ label: 'bust', value: 96.5 }, { label: 'waist', value: 79 }, { label: 'hips', value: 103 }, { label: 'neck', value: 39 }, { label: 'back_length', value: 43 }, { label: 'shoulder_width', value: 42 }, { label: 'arm_length', value: 62 }, { label: 'piece_length', value: 67 }, { label: 'arm_circumference', value: 33 }] },
  'MEN-S': { name: 'Men S', measurements: [{ label: 'bust', value: 92 }, { label: 'waist', value: 78 }, { label: 'hips', value: 94 }, { label: 'neck', value: 38 }, { label: 'back_length', value: 46 }, { label: 'shoulder_width', value: 44 }, { label: 'arm_length', value: 62 }, { label: 'piece_length', value: 70 }, { label: 'arm_circumference', value: 28 }] },
  'MEN-M': { name: 'Men M', measurements: [{ label: 'bust', value: 100 }, { label: 'waist', value: 86 }, { label: 'hips', value: 102 }, { label: 'neck', value: 40 }, { label: 'back_length', value: 48 }, { label: 'shoulder_width', value: 46 }, { label: 'arm_length', value: 63 }, { label: 'piece_length', value: 72 }, { label: 'arm_circumference', value: 30 }] },
  'MEN-L': { name: 'Men L', measurements: [{ label: 'bust', value: 108 }, { label: 'waist', value: 94 }, { label: 'hips', value: 110 }, { label: 'neck', value: 42 }, { label: 'back_length', value: 50 }, { label: 'shoulder_width', value: 48 }, { label: 'arm_length', value: 64 }, { label: 'piece_length', value: 74 }, { label: 'arm_circumference', value: 32 }] },
  'MEN-XL': { name: 'Men XL', measurements: [{ label: 'bust', value: 116 }, { label: 'waist', value: 102 }, { label: 'hips', value: 118 }, { label: 'neck', value: 44 }, { label: 'back_length', value: 52 }, { label: 'shoulder_width', value: 50 }, { label: 'arm_length', value: 65 }, { label: 'piece_length', value: 76 }, { label: 'arm_circumference', value: 34 }] },
  'KIDS-2Y': { name: 'Kids 2Y', measurements: [{ label: 'bust', value: 52 }, { label: 'waist', value: 50 }, { label: 'hips', value: 54 }, { label: 'neck', value: 24 }, { label: 'back_length', value: 21 }, { label: 'shoulder_width', value: 22 }, { label: 'arm_length', value: 30 }, { label: 'piece_length', value: 35 }, { label: 'arm_circumference', value: 18 }] },
  'KIDS-4Y': { name: 'Kids 4Y', measurements: [{ label: 'bust', value: 56 }, { label: 'waist', value: 53 }, { label: 'hips', value: 58 }, { label: 'neck', value: 26 }, { label: 'back_length', value: 24 }, { label: 'shoulder_width', value: 24 }, { label: 'arm_length', value: 36 }, { label: 'piece_length', value: 40 }, { label: 'arm_circumference', value: 19 }] },
  'KIDS-6Y': { name: 'Kids 6Y', measurements: [{ label: 'bust', value: 60 }, { label: 'waist', value: 56 }, { label: 'hips', value: 62 }, { label: 'neck', value: 28 }, { label: 'back_length', value: 27 }, { label: 'shoulder_width', value: 26 }, { label: 'arm_length', value: 42 }, { label: 'piece_length', value: 45 }, { label: 'arm_circumference', value: 20 }] },
  'KIDS-8Y': { name: 'Kids 8Y', measurements: [{ label: 'bust', value: 64 }, { label: 'waist', value: 59 }, { label: 'hips', value: 66 }, { label: 'neck', value: 30 }, { label: 'back_length', value: 30 }, { label: 'shoulder_width', value: 28 }, { label: 'arm_length', value: 48 }, { label: 'piece_length', value: 50 }, { label: 'arm_circumference', value: 21 }] },
};

const PRESETS: Record<PatternPreset, { category: PatternCategory; title: string; icon: string }> = {
  'bodice-basic': { category: 'Women', title: 'Basic Bodice', icon: '👕' },
  'dress-basic': { category: 'Women', title: 'Basic Dress', icon: '👗' },
  'blouse-basic': { category: 'Women', title: 'Basic Blouse', icon: '👚' },
  'skirt-basic': { category: 'Women', title: 'Basic Skirt', icon: '👗' },
  'skirt-circle': { category: 'Women', title: 'Circle Skirt', icon: '💃' },
  'shirt-basic': { category: 'Men', title: 'Basic Shirt', icon: '👔' },
  'pants-basic': { category: 'Men', title: 'Basic Pants', icon: '👖' },
  'shorts-basic': { category: 'Men', title: 'Casual Shorts', icon: '🩳' },
  'collar-basic': { category: 'Accessories', title: 'Classic Collar', icon: '👔' },
  'jacket-basic': { category: 'Men', title: 'Casual Jacket', icon: '🧥' },
  'custom-lab': { category: 'Accessories', title: 'Algorithm Lab', icon: '🧪' },
};

const CATEGORIES: PatternCategory[] = ['Women', 'Men', 'Children', 'Accessories'];

export default function App() {
  const [activeCategory, setActiveCategory] = useState<PatternCategory>('Women');
  const [activePreset, setActivePreset] = useState<PatternPreset>('bodice-basic');
  const [activeStandard, setActiveStandard] = useState<SizingStandard>('EU-40');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [viewBox, setViewBox] = useState({ x: -100, y: -100, w: 2000, h: 1200 });
  const [isPanning, setIsPanning] = useState(false);
  const [labInput, setLabInput] = useState("");
  const [isProcessingLab, setIsProcessingLab] = useState(false);
  const [labResult, setLabResult] = useState<PatternOutput | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);
  const panStartRef = useRef({ x: 0, y: 0 });

  const currentMeasurements = useMemo(() => SIZING_STANDARDS[activeStandard].measurements, [activeStandard]);

  const patternData = useMemo(() => {
    if (activePreset === 'custom-lab' && labResult) return labResult;
    return generatePattern(activePreset, currentMeasurements, activeCategory);
  }, [activePreset, currentMeasurements, activeCategory, labResult]);

  const handleZoom = useCallback((factor: number) => {
    setViewBox(prev => ({
      ...prev,
      w: prev.w * factor,
      h: prev.h * factor,
      x: prev.x + (prev.w - prev.w * factor) / 2,
      y: prev.y + (prev.h - prev.h * factor) / 2,
    }));
  }, []);

  const handleProcessLab = async () => {
    if (!labInput.trim()) return;
    setIsProcessingLab(true);
    try {
      const result = await processUserAlgorithm(labInput, currentMeasurements);
      setLabResult(result);
      setActivePreset('custom-lab');
    } catch (e) {
      alert("حدث خطأ أثناء معالجة الخوارزمية. تأكد من صحة المنطق.");
    } finally {
      setIsProcessingLab(false);
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsPanning(true);
    panStartRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isPanning) return;
    const dx = e.clientX - panStartRef.current.x;
    const dy = e.clientY - panStartRef.current.y;
    const svg = svgRef.current;
    if (!svg) return;
    const rect = svg.getBoundingClientRect();
    const moveX = (dx / rect.width) * viewBox.w;
    const moveY = (dy / rect.height) * viewBox.h;
    setViewBox(prev => ({ ...prev, x: prev.x - moveX, y: prev.y - moveY }));
    panStartRef.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => setIsPanning(false);

  useEffect(() => {
    setViewBox({
      x: -50,
      y: -50,
      w: Math.max(patternData.width + 100, 1000),
      h: Math.max(patternData.height + 100, 800)
    });
  }, [patternData.width, patternData.height]);

  const filteredPresets = Object.entries(PRESETS).filter(([_, p]) => p.category === activeCategory);

  return (
    <Layout>
      <div className="flex flex-col gap-4 mb-4">
        {/* Category Filter */}
        <div className="bg-white rounded-2xl p-2 border border-slate-200 shadow-sm flex gap-2 overflow-x-auto custom-scrollbar">
          {CATEGORIES.map(cat => (
            <button
              key={cat}
              onClick={() => {
                setActiveCategory(cat);
                const first = Object.entries(PRESETS).find(([_, p]) => p.category === cat)?.[0];
                if (first) setActivePreset(first as PatternPreset);
              }}
              className={`whitespace-nowrap px-6 py-2 rounded-xl text-xs font-bold transition-all ${activeCategory === cat ? 'bg-indigo-600 text-white shadow-md' : 'text-slate-600 hover:bg-slate-50'}`}
            >
              {cat === 'Women' ? 'نسائي' : cat === 'Men' ? 'رجالي' : cat === 'Children' ? 'أطفال' : 'إكسسوارات'}
            </button>
          ))}
        </div>

        {/* Model Presets */}
        <div className="bg-white rounded-2xl p-2 border border-slate-200 shadow-sm flex gap-2 overflow-x-auto custom-scrollbar">
          {filteredPresets.map(([id, p]) => (
            <button
              key={id}
              onClick={() => setActivePreset(id as PatternPreset)}
              className={`flex-shrink-0 flex items-center gap-2 px-4 py-3 rounded-xl text-[10px] font-bold transition-all border ${activePreset === id ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-white text-slate-600 border-slate-100 hover:bg-slate-50'}`}
            >
              <span className="text-base">{p.icon}</span>
              <span className="whitespace-nowrap">{p.title}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Lab Input Section */}
      {activePreset === 'custom-lab' && (
        <div className="mb-6 bg-slate-900 rounded-3xl p-6 border border-indigo-500/30 shadow-2xl">
          <h3 className="text-indigo-400 font-bold mb-4 flex items-center gap-2">
            <span className="text-xl">🧪</span> مختبر خوارزميات البترونات
          </h3>
          <textarea
            value={labInput}
            onChange={(e) => setLabInput(e.target.value)}
            placeholder="أدخل خوارزمية الرسم هنا (مثلاً: ارسم مربعاً بطول الصدر ثم قوساً للرقبة...)"
            className="w-full h-32 bg-slate-800 text-indigo-100 p-4 rounded-xl border border-slate-700 focus:border-indigo-500 outline-none font-mono text-sm custom-scrollbar resize-none"
          />
          <button
            onClick={handleProcessLab}
            disabled={isProcessingLab}
            className={`mt-4 w-full py-4 rounded-xl font-bold transition-all flex items-center justify-center gap-3 ${isProcessingLab ? 'bg-slate-700 text-slate-400' : 'bg-indigo-600 text-white hover:bg-indigo-500 shadow-lg shadow-indigo-900/40'}`}
          >
            {isProcessingLab ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                جاري التحليل الهندسي...
              </>
            ) : (
              <>
                <span>✨</span> معالجة وتنسيق الخوارزمية
              </>
            )}
          </button>
        </div>
      )}

      {/* Drawing Board */}
      <div className="relative bg-[#0f172a] rounded-[2.5rem] overflow-hidden border border-slate-800 shadow-2xl h-[65vh] sm:h-[calc(100vh-340px)] mb-8">
        <div className="absolute inset-0 blueprint-grid opacity-30 pointer-events-none"></div>

        {/* Floating Controls */}
        <div className="absolute top-6 right-6 z-30 flex flex-col gap-3">
          <button onClick={() => handleZoom(0.8)} className="w-12 h-12 bg-slate-800/90 backdrop-blur rounded-2xl text-white font-black text-2xl border border-slate-700 shadow-xl flex items-center justify-center hover:bg-slate-700 transition-colors">+</button>
          <button onClick={() => handleZoom(1.2)} className="w-12 h-12 bg-slate-800/90 backdrop-blur rounded-2xl text-white font-black text-2xl border border-slate-700 shadow-xl flex items-center justify-center hover:bg-slate-700 transition-colors">−</button>
        </div>

        {/* Viewport Canvas */}
        <svg 
          ref={svgRef}
          viewBox={`${viewBox.x} ${viewBox.y} ${viewBox.w} ${viewBox.h}`}
          className="w-full h-full cursor-grab active:cursor-grabbing select-none touch-none"
          onWheel={(e) => handleZoom(e.deltaY > 0 ? 1.1 : 0.9)}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
          onMouseLeave={handleMouseUp}
        >
          {patternData.paths.map((path, idx) => (
            <g key={idx}>
              <path 
                d={path.d} 
                className={`${path.className} drop-shadow-[0_0_15px_rgba(99,102,241,0.2)]`}
                strokeWidth={3}
                fill="none"
                strokeLinecap="round"
                strokeLinejoin="round"
                vectorEffect="non-scaling-stroke"
              />
              {path.label && (
                <text 
                  x={10} 
                  y={10} 
                  className="fill-slate-500 text-[12px] font-bold pointer-events-none"
                  style={{ transform: `translate(${idx * 20}px, ${idx * 20}px)` }}
                >
                  {path.label}
                </text>
              )}
            </g>
          ))}
        </svg>

        {/* Overlay Tools */}
        <div className="absolute bottom-8 left-8 z-20">
           <div className="bg-slate-900/95 backdrop-blur-2xl p-4 rounded-[2rem] border border-slate-700 flex flex-col gap-2 shadow-2xl min-w-[180px]">
              <label className="text-[10px] font-black text-slate-500 uppercase px-3 tracking-tighter">نظام التحجيم العالمي</label>
              <select 
                value={activeStandard}
                onChange={(e) => setActiveStandard(e.target.value as SizingStandard)}
                className="bg-slate-800/50 text-white text-sm font-bold outline-none px-4 py-3 rounded-xl cursor-pointer border border-slate-700/50 appearance-none"
              >
                {Object.entries(SIZING_STANDARDS).map(([key, value]) => (
                  <option key={key} value={key} className="bg-slate-900">{value.name}</option>
                ))}
              </select>
           </div>
        </div>

        {/* Export Button */}
        <div className="absolute bottom-8 right-8 z-20">
           <button 
             onClick={() => {
                const svgContent = svgRef.current?.outerHTML || '';
                const blob = new Blob([svgContent], { type: 'image/svg+xml' });
                const url = URL.createObjectURL(blob);
                const link = document.createElement('a');
                link.href = url;
                link.download = `TailorStudio_Custom_Pattern.svg`;
                link.click();
             }}
             className="w-20 h-20 bg-indigo-600 rounded-full flex items-center justify-center shadow-[0_0_40px_rgba(79,70,229,0.4)] hover:bg-indigo-500 active:scale-90 transition-all group"
           >
             <span className="text-3xl group-hover:scale-110 transition-transform">💾</span>
           </button>
        </div>
      </div>
    </Layout>
  );
}
