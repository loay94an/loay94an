import pytest
import numpy as np
try:
    from scipy.optimize import least_squares
    HAS_SCIPY = True
except ImportError:
    HAS_SCIPY = False

class BezierCurve:
    def __init__(self, p0, p1, p2, p3):
        self.p0 = np.array(p0, dtype=float)
        self.p1 = np.array(p1, dtype=float)
        self.p2 = np.array(p2, dtype=float)
        self.p3 = np.array(p3, dtype=float)

    def derivatives(self, t):
        p0, p1, p2, p3 = self.p0, self.p1, self.p2, self.p3
        d1 = 3*((1-t)**2)*(p1-p0) + 6*(1-t)*t*(p2-p1) + 3*(t**2)*(p3-p2)
        d2 = 6*(1-t)*(p2-2*p1+p0) + 6*t*(p3-2*p2+p1)
        return d1, d2

def solve_g2_numerical(curveA, curveB, weight_second=1.0):
    """
    محلل G2 عددي يستخدم least_squares لتقليل الفجوة في المشتقات عند نقطة الاتصال.
    """
    if not HAS_SCIPY:
        return None
    
    def residuals(x):
        dp2 = np.array([x[0], x[1]])
        dp1 = np.array([x[2], x[3]])
        p2_new = curveA.p2 + dp2
        p1_new = curveB.p1 + dp1
        
        # المشتقات عند نهاية المنحنى A (t=1)
        d1A_new = 3 * (curveA.p3 - p2_new)
        d2A_new = 6 * (curveA.p3 - 2*p2_new + curveA.p1)
        
        # المشتقات عند بداية المنحنى B (t=0)
        d1B_new = 3 * (p1_new - curveB.p0)
        d2B_new = 6 * (curveB.p2 - 2*p1_new + curveB.p0)
        
        res_d1 = d1A_new - d1B_new
        res_d2 = (d2A_new - d2B_new) * weight_second
        return np.concatenate([res_d1, res_d2])

    x0 = np.zeros(4)
    res = least_squares(residuals, x0, xtol=1e-8, ftol=1e-8)
    
    if res.success:
        curveA.p2 = curveA.p2 + np.array([res.x[0], res.x[1]])
        curveB.p1 = curveB.p1 + np.array([res.x[2], res.x[3]])
    return res

def test_g2_continuity_improvement():
    """
    اختبار يتحقق من أن المحلل العددي يحسن استمرارية G2 بشكل ملحوظ.
    """
    if not HAS_SCIPY:
        pytest.skip("scipy required for this test")

    # إعداد منحنيين متصلين بكسرة واضحة في المشتقات
    p0A, p1A, p2A, p3A = [0,0], [10,5], [20,15], [30,10]
    p0B, p1B, p2B, p3B = [30,10], [40,5], [50,15], [60,0]
    
    cA = BezierCurve(p0A, p1A, p2A, p3A)
    cB = BezierCurve(p0B, p1B, p2B, p3B)
    
    # حساب الفروق الأولية
    d1A, d2A = 3*(cA.p3-cA.p2), 6*(cA.p3-2*cA.p2+cA.p1)
    d1B, d2B = 3*(cB.p1-cB.p0), 6*(cB.p2-2*cB.p1+cB.p0)
    
    init_d1_diff = np.linalg.norm(d1A - d1B)
    init_d2_diff = np.linalg.norm(d2A - d2B)
    
    # تنفيذ الحل
    solve_g2_numerical(cA, cB)
    
    # حساب الفروق النهائية
    d1A_f, d2A_f = 3*(cA.p3-cA.p2), 6*(cA.p3-2*cA.p2+cA.p1)
    d1B_f, d2B_f = 3*(cB.p1-cB.p0), 6*(cB.p2-2*cB.p1+cB.p0)
    
    final_d1_diff = np.linalg.norm(d1A_f - d1B_f)
    final_d2_diff = np.linalg.norm(d2A_f - d2B_f)
    
    print(f"\nInitial D1 Diff: {init_d1_diff:.6f}, Final: {final_d1_diff:.6f}")
    print(f"Initial D2 Diff: {init_d2_diff:.6f}, Final: {final_d2_diff:.6f}")
    
    assert final_d1_diff < 1e-4, f"D1 discontinuity too high: {final_d1_diff}"
    assert final_d2_diff < 1e-3, f"D2 discontinuity too high: {final_d2_diff}"

def test_curvature_consistency():
    """
    يتحقق من أن الانحناء (Curvature) متناسق عند نقطة الاتصال.
    """
    if not HAS_SCIPY:
        pytest.skip("scipy required")

    p0A, p1A, p2A, p3A = [0,0], [10,0], [20,0], [30,0]
    p0B, p1B, p2B, p3B = [30,0], [40,10], [50,20], [60,30]
    
    cA = BezierCurve(p0A, p1A, p2A, p3A)
    cB = BezierCurve(p0B, p1B, p2B, p3B)
    
    solve_g2_numerical(cA, cB)
    
    # حساب الانحناء: k = |x'y'' - y'x''| / (x'^2 + y'^2)^1.5
    def get_k(curve, t_val):
        d1, d2 = curve.derivatives(t_val)
        num = np.abs(d1[0]*d2[1] - d1[1]*d2[0])
        den = np.power(d1[0]**2 + d1[1]**2, 1.5)
        return num / den if den != 0 else 0

    kA = get_k(cA, 1.0)
    kB = get_k(cB, 0.0)
    
    assert np.abs(kA - kB) < 1e-3, f"Curvature mismatch: {kA} vs {kB}"

if __name__ == "__main__":
    pytest.main([__file__])
