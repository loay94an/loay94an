
import { Point, SvgPath, Measurement, PatternOutput, PatternPiece, PatternPreset } from '../types.ts';

/**
 * PathBuilder: Programmatic SVG path generator
 */
class PathBuilder {
  private d: string[] = [];

  moveTo(x: number, y: number) { this.d.push(`M ${x} ${y}`); return this; }
  lineTo(x: number, y: number) { this.d.push(`L ${x} ${y}`); return this; }
  cubic(x1: number, y1: number, x2: number, y2: number, x: number, y: number) {
    this.d.push(`C ${x1} ${y1}, ${x2} ${y2}, ${x} ${y}`); return this;
  }
  quad(x1: number, y1: number, x: number, y: number) {
    this.d.push(`Q ${x1} ${y1}, ${x} ${y}`); return this;
  }
  close() { this.d.push('Z'); return this; }
  build() { return this.d.join(' '); }
}

/**
 * Adaptive Bezier Sampling: ensures smooth segments for manufacturing
 */
function adaptiveSampleBezier(
  p0: Point, p1: Point, p2: Point, p3: Point,
  maxSeg = 0.5, maxDepth = 14
): Point[] {
  const out: Point[] = [];
  const bez = (a: Point, b: Point, c: Point, d: Point, t: number) => {
    const u = 1 - t;
    return {
      x: u * u * u * a.x + 3 * u * u * t * b.x + 3 * u * t * t * c.x + t * t * t * d.x,
      y: u * u * u * a.y + 3 * u * u * t * b.y + 3 * u * t * t * c.y + t * t * t * d.y
    };
  };

  const subdiv = (a: Point, b: Point, c: Point, d: Point, depth: number) => {
    const mid = bez(a, b, c, d, 0.5);
    const lm = { x: (a.x + d.x) / 2, y: (a.y + d.y) / 2 };
    const dx = mid.x - lm.x, dy = mid.y - lm.y;

    if (Math.hypot(dx, dy) > maxSeg && depth < maxDepth) {
      const a1 = { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 };
      const b1 = { x: (b.x + c.x) / 2, y: (b.y + c.y) / 2 };
      const c1 = { x: (c.x + d.x) / 2, y: (c.y + d.y) / 2 };
      const a2 = { x: (a1.x + b1.x) / 2, y: (a1.y + b1.y) / 2 };
      const b2 = { x: (b1.x + c1.x) / 2, y: (b1.y + c1.y) / 2 };
      const m = { x: (a2.x + b2.x) / 2, y: (a2.y + b2.y) / 2 };
      subdiv(a, a1, a2, m, depth + 1);
      subdiv(m, b2, c1, d, depth + 1);
    } else {
      out.push(a);
      out.push(d);
    }
  };

  subdiv(p0, p1, p2, p3, 0);
  
  // Clean up duplicates
  const res: Point[] = [];
  for (const pt of out) {
    if (!res.length || Math.hypot(res[res.length - 1].x - pt.x, res[res.length - 1].y - pt.y) > 1e-9) {
      res.push(pt);
    }
  }
  return res;
}

function bezierLength(p0: Point, p1: Point, p2: Point, p3: Point): number {
  const pts = adaptiveSampleBezier(p0, p1, p2, p3, 0.5, 14);
  let L = 0;
  for (let i = 1; i < pts.length; i++) {
    L += Math.hypot(pts[i].x - pts[i - 1].x, pts[i].y - pts[i - 1].y);
  }
  return L;
}

/**
 * Robust SVG Path Translation
 */
function translatePath(d: string, dx: number, dy: number): string {
  return d.replace(/([a-zA-Z])([^a-zA-Z]*)/g, (match, cmd, args) => {
    const nums = args.trim().split(/[\s,]+/).map(Number);
    if (nums.some(isNaN)) return match;
    
    const moved = nums.map((n: number, i: number) => i % 2 === 0 ? n + dx : n + dy);
    return `${cmd} ${moved.join(' ')} `;
  }).trim();
}

// --- GENERATORS ---

const SCALE = 10;

/**
 * Professional Bodice Piece (Used for Bodice, Dress, Blouse, Shirt, Jacket)
 */
function generateBodicePiece(meas: Measurement[], isFront: boolean, category: string, presetId?: string): PatternPiece {
  const get = (l: string) => meas.find(m => m.label === l)?.value || 0;
  const bust = get('bust') || 92;
  const waist = get('waist') || 74;
  const hips = get('hips') || 98;
  const sw = get('shoulder_width') || 38;
  let pl = get('piece_length') || 45;

  // Custom lengths for specific garments
  if (presetId === 'dress-basic') pl = 100; // Default full dress length
  if (presetId === 'blouse-basic') pl = 65; // Default blouse length

  const ease = category === 'Men' ? 3 : 2;
  const qBust = (bust / 4) + ease;
  const qWaist = (waist / 4) + ease + 0.5;
  const qHips = (hips / 4) + ease;

  const armDepth = (bust / 10) + (category === 'Women' ? 10.5 : 12);
  const neckW = (bust / 20) + 2;
  const neckD = isFront ? (bust / 12) + 1 : 2;
  const shoulderSlope = category === 'Children' ? 3 : 4.5;

  const p = {
    neckDrop: { x: 0, y: neckD },
    neckTop: { x: neckW, y: 0 },
    shoulderTip: { x: sw / 2, y: shoulderSlope },
    bustSide: { x: qBust, y: armDepth },
    waistSide: { x: qWaist, y: armDepth + 22 },
    hipSide: { x: qHips, y: pl },
  };

  // Control points
  const nC1 = { x: p.neckDrop.x + p.neckTop.x * 0.55, y: p.neckDrop.y };
  const nC2 = { x: p.neckTop.x * 0.9, y: p.neckDrop.y * 0.55 };

  const h = p.bustSide.y - p.shoulderTip.y;
  const aC1 = { x: p.shoulderTip.x - (isFront ? 2.5 : 0.75), y: p.shoulderTip.y + h * 0.35 };
  const aC2 = { 
    x: isFront ? (p.bustSide.x * 0.6) : (p.bustSide.x * 0.8), 
    y: p.bustSide.y - h * 0.3 
  };

  const pb = new PathBuilder()
    .moveTo(0, p.hipSide.y * SCALE)
    .lineTo(0, p.neckDrop.y * SCALE)
    .cubic(nC1.x * SCALE, nC1.y * SCALE, nC2.x * SCALE, nC2.y * SCALE, p.neckTop.x * SCALE, p.neckTop.y * SCALE)
    .lineTo(p.shoulderTip.x * SCALE, p.shoulderTip.y * SCALE)
    .cubic(aC1.x * SCALE, aC1.y * SCALE, aC2.x * SCALE, aC2.y * SCALE, p.bustSide.x * SCALE, p.bustSide.y * SCALE)
    .lineTo(p.waistSide.x * SCALE, p.waistSide.y * SCALE)
    .lineTo(p.hipSide.x * SCALE, p.hipSide.y * SCALE)
    .close();

  const armholeLen = bezierLength(p.shoulderTip, aC1, aC2, p.bustSide);

  const label = isFront ? 'الأمام' : 'الخلف';
  return {
    paths: [{ d: pb.build(), className: isFront ? 'stroke-indigo-600 fill-none' : 'stroke-slate-600 fill-none', label }],
    width: qHips * SCALE,
    height: pl * SCALE,
    name: isFront ? 'Front' : 'Back',
    metadata: { armholeLength: armholeLen }
  };
}

/**
 * Professional Sleeve
 */
function generateSleeve(meas: Measurement[], totalArmhole: number): PatternPiece {
  const get = (l: string) => meas.find(m => m.label === l)?.value || 0;
  const len = get('arm_length') || 60;
  const bicep = (get('arm_circumference') || 28) + 6;
  
  const capH = totalArmhole / 3.2;
  const wrist = bicep * 0.75;

  const p = {
    capTop: { x: bicep / 2, y: 0 },
    left: { x: 0, y: capH },
    right: { x: bicep, y: capH },
    hemL: { x: (bicep - wrist) / 2, y: len },
    hemR: { x: (bicep + wrist) / 2, y: len }
  };

  const pb = new PathBuilder()
    .moveTo(p.hemL.x * SCALE, p.hemL.y * SCALE)
    .lineTo(p.left.x * SCALE, p.left.y * SCALE)
    .cubic(p.left.x * SCALE, (p.left.y - capH * 0.8) * SCALE, (p.capTop.x - bicep * 0.2) * SCALE, 0, p.capTop.x * SCALE, 0)
    .cubic((p.capTop.x + bicep * 0.2) * SCALE, 0, p.right.x * SCALE, (p.right.y - capH * 0.8) * SCALE, p.right.x * SCALE, p.right.y * SCALE)
    .lineTo(p.hemR.x * SCALE, p.hemR.y * SCALE)
    .close();

  return {
    paths: [{ d: pb.build(), className: 'stroke-emerald-600 fill-none', label: 'الكم' }],
    width: bicep * SCALE,
    height: len * SCALE,
    name: 'Sleeve'
  };
}

/**
 * Professional Pants & Shorts
 */
function generatePants(meas: Measurement[], isShorts: boolean = false): PatternPiece {
  const get = (l: string) => meas.find(m => m.label === l)?.value || 0;
  const waist = get('waist') || 74;
  const hips = get('hips') || 98;
  const len = isShorts ? 40 : 100; // Shorts are typically ~40cm total length

  const qW = (waist / 4) + 2;
  const qH = (hips / 4) + 2;

  const pb = new PathBuilder()
    .moveTo(0, 0)
    .lineTo(qW * SCALE, 0)
    .lineTo((qH + (isShorts ? 4 : 10)) * SCALE, len * SCALE)
    .lineTo(0, len * SCALE)
    .close();

  const label = isShorts ? 'الشورت' : 'البنطلون';
  return {
    paths: [{ d: pb.build(), className: isShorts ? 'stroke-cyan-600 fill-none' : 'stroke-blue-600 fill-none', label }],
    width: (qH + 15) * SCALE,
    height: len * SCALE,
    name: isShorts ? 'Shorts' : 'Pants'
  };
}

/**
 * Professional Collar
 */
function generateCollar(meas: Measurement[]): PatternPiece {
  const neck = (meas.find(m => m.label === 'neck')?.value || 38) / 2;
  const h = 4.5;

  const pb = new PathBuilder()
    .moveTo(0, 0)
    .lineTo(neck * SCALE, 0)
    .lineTo(neck * SCALE, h * SCALE)
    .lineTo(0, h * SCALE)
    .close();

  return {
    paths: [{ d: pb.build(), className: 'stroke-amber-600 fill-none', label: 'الياقة' }],
    width: neck * SCALE,
    height: h * SCALE,
    name: 'Collar'
  };
}

/**
 * Main Pattern Service Entry Point
 */
export const generatePattern = (presetId: PatternPreset, measurements: Measurement[], category: string): PatternOutput => {
  const pieces: PatternPiece[] = [];
  let totalWidth = 0;
  let maxHeight = 0;
  const PADDING = 100; // mm gap between pieces

  const add = (piece: PatternPiece) => {
    // Translate paths to current offset
    const dx = totalWidth;
    const dy = 0;
    
    piece.paths = piece.paths.map(p => ({
      ...p,
      d: p.d ? translatePath(p.d, dx, dy) : undefined,
      x: p.x !== undefined ? p.x + dx : undefined,
      y: p.y !== undefined ? p.y + dy : undefined
    }));

    pieces.push(piece);
    totalWidth += piece.width + PADDING;
    maxHeight = Math.max(maxHeight, piece.height);
  };

  // Logic to decide which pieces to generate based on Preset ID
  if (
    presetId.includes('bodice') || 
    presetId.includes('shirt') || 
    presetId.includes('jacket') || 
    presetId.includes('dress') || 
    presetId.includes('blouse')
  ) {
    const front = generateBodicePiece(measurements, true, category, presetId);
    add(front);
    const back = generateBodicePiece(measurements, false, category, presetId);
    add(back);

    const totalArmhole = (front.metadata?.armholeLength || 0) + (back.metadata?.armholeLength || 0);
    if (totalArmhole > 0) {
      add(generateSleeve(measurements, totalArmhole));
    }
  }

  if (presetId.includes('shorts')) {
    add(generatePants(measurements, true));
  } else if (presetId.includes('pants')) {
    add(generatePants(measurements, false));
  }

  if (presetId.includes('collar')) {
    add(generateCollar(measurements));
  }

  if (presetId.includes('skirt')) {
    const w = (measurements.find(m => m.label === 'waist')?.value || 74) / 4 + 2;
    const h = (measurements.find(m => m.label === 'piece_length')?.value || 60);
    const pb = new PathBuilder().moveTo(0,0).lineTo(w*SCALE, 0).lineTo((w+5)*SCALE, h*SCALE).lineTo(0, h*SCALE).close();
    add({ paths: [{ d: pb.build(), className: 'stroke-pink-600 fill-none', label: 'التنورة' }], width: (w+5)*SCALE, height: h*SCALE, name: 'Skirt' });
  }

  const allPaths = pieces.flatMap(p => p.paths);

  return {
    paths: allPaths,
    width: totalWidth,
    height: maxHeight + PADDING,
    diagnostics: []
  };
};
