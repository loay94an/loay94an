
import { GoogleGenAI, Type } from "@google/genai";
import { PatternOutput } from "../types.ts";

export const processUserAlgorithm = async (
  rawAlgorithm: string,
  measurements: any[]
): Promise<PatternOutput> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  const measurementsText = measurements.map(m => `"${m.label}": ${m.value}`).join(', ');

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-pro-preview',
      contents: `
        الخوارزمية المرسلة من المستخدم:
        ${rawAlgorithm}

        القياسات المتاحة للتطبيق:
        {${measurementsText}}

        المهمة: قم بتحويل هذه الخوارزمية إلى بيانات هندسية بتنسيق JSON.
      `,
      config: {
        systemInstruction: `
          أنت خبير في هندسة البترونات ونظم CAD. مهمتك هي تفسير خوارزمية الرسم التي يرسلها المستخدم وتحويلها إلى مصفوفة من مسارات SVG (d-path).
          يجب أن تكون النتيجة بتنسيق JSON حصراً ويحتوي على:
          1. paths: مصفوفة من الكائنات { "d": string, "className": string, "label": string }.
          2. width: العرض الإجمالي للبترون بالمليمتر.
          3. height: الارتفاع الإجمالي للبترون بالمليمتر.

          استخدم مقياس رسم (Scale) بحيث أن 1 وحدة = 10 ملم (1 سم).
          تأكد من أن المسارات مغلقة 'Z' وتتبع منطق الخوارزمية بدقة.
          إذا كانت الخوارزمية تفتقر لبعض التفاصيل التقنية، أكملها بناءً على أفضل الممارسات الهندسية.
        `,
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            paths: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  d: { type: Type.STRING },
                  className: { type: Type.STRING },
                  label: { type: Type.STRING }
                },
                required: ["d", "className", "label"]
              }
            },
            width: { type: Type.NUMBER },
            height: { type: Type.NUMBER }
          },
          required: ["paths", "width", "height"]
        },
        temperature: 0.2,
      },
    });

    return JSON.parse(response.text || "{}") as PatternOutput;
  } catch (error: any) {
    console.error("Gemini Lab Error:", error);
    throw new Error("فشل الذكاء الاصطناعي في ترجمة الخوارزمية الهندسية.");
  }
};

export const refineAlgorithm = async (
  parts: any[], 
  measurements: any[],
  pieceSettings?: any
): Promise<string> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const measurementsText = measurements.map(m => `"${m.label}": ${m.value}`).join(', ');
  const partsText = JSON.stringify(parts, null, 2);

  const response = await ai.models.generateContent({
    model: 'gemini-3-pro-preview',
    contents: `القياسات: {${measurementsText}}. الكود: ${partsText}.`,
    config: {
      systemInstruction: "أنت مهندس CAD. قم بتحسين الكود لضمان استمرارية G2 ودقة القص.",
      temperature: 0.1,
    },
  });

  return response.text || "";
};
