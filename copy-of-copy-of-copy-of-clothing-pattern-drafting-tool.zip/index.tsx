

import { bootstrapApplication } from '@angular/platform-browser';
import { provideHttpClient } from '@angular/common/http';
import { provideZonelessChangeDetection } from '@angular/core';
import { provideAnimations } from '@angular/platform-browser/animations';

import { AppComponent } from './src/app.component';
import { GEMINI_API_KEY } from './src/app/gemini-api-key.token';

bootstrapApplication(AppComponent, {
  providers: [
    provideZonelessChangeDetection(),
    provideHttpClient(),
    provideAnimations(),
    { provide: GEMINI_API_KEY, useValue: process.env.API_KEY },
  ],
}).catch(err => console.error(err));

// AI Studio always uses an `index.tsx` file for all project types.