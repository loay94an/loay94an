import { Component, ChangeDetectionStrategy, input, output, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Category, PatternModel } from '../../models/pattern.model';

@Component({
  selector: 'app-model-selector',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './model-selector.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ModelSelectorComponent {
  category = input.required<Category>();
  childGender = input<'boy' | 'girl' | null>(null);
  modelSelected = output<PatternModel>();

  private allModels: PatternModel[] = [
    // Woman
    { id: 'w-zip-polo-image', name: 'بلوزة بسحاب (تصميم جاهز)', category: 'woman', imageUrl: 'https://api.iconify.design/tabler:shirt-zip.svg', difficulty: 'صعب', sleeveType: null, collarType: null, requiredMeasurements: []},
    { id: 'm-hoodie-unisex-image', name: 'هودي للجنسين (تصميم جاهز)', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:hoodie.svg', difficulty: 'متوسط', sleeveType: null, collarType: null, requiredMeasurements: []},
    { id: 'w-lab-coat-image', name: 'جاكيت مختبر (تصميم جاهز)', category: 'woman', imageUrl: 'https://api.iconify.design/healthicons:lab-coat-outline.svg', difficulty: 'متوسط', sleeveType: null, collarType: null, requiredMeasurements: []},
    { id: 'm-tshirt-adult-image', name: 'تيشيرت للبالغين (تصميم جاهز)', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:tshirt-crew.svg', difficulty: 'سهل', sleeveType: null, collarType: null, requiredMeasurements: []},
    { id: 'w-blouse', name: 'بلوزة أساسية', category: 'woman', imageUrl: 'https://api.iconify.design/map:blouse.svg', difficulty: 'متوسط', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-blouse-darted', name: 'بلوزة ببنسات', category: 'woman', imageUrl: 'https://api.iconify.design/map:blouse.svg', difficulty: 'صعب', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff', 'darted'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-dress', name: 'فستان أساسي', category: 'woman', imageUrl: 'https://api.iconify.design/ph:dress-fill.svg', difficulty: 'متوسط', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-dress-darted', name: 'فستان ببنسات', category: 'woman', imageUrl: 'https://api.iconify.design/ph:dress-fill.svg', difficulty: 'صعب', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff', 'darted'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-skirt', name: 'تنورة أساسية', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:skirt.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'pieceLength'] },
    { id: 'w-skirt-darted', name: 'تنورة مستقيمة (بنسل)', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:skirt.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'hips', 'pieceLength'] },
    { id: 'w-blouse-raglan', name: 'بلوزة بكم رجلان', category: 'woman', imageUrl: 'https://api.iconify.design/icon-park-outline:raglan-sleeve.svg', difficulty: 'صعب', sleeveType: 'raglan', requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-kimono', name: 'كيمونو', category: 'woman', imageUrl: 'https://api.iconify.design/iconoir:kaftan.svg', difficulty: 'متوسط', sleeveType: 'kimono', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength'] },
    { id: 'w-skirt-pleated', name: 'تنورة بكسرات', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:skirt.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'pieceLength'] },
    { id: 'w-skirt-circle', name: 'تنورة كلوش', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:circle-slice-8.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'pieceLength'] },
    { id: 'w-skirt-double-circle', name: 'تنورة دوبل كلوش', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:circle-double.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'pieceLength'] },
    { id: 'w-pants', name: 'بنطال', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'hips', 'pieceLength', 'inlegLength', 'waistToFloor'] },
    { id: 'w-jumpsuit', name: 'جمبسوت', category: 'woman', imageUrl: 'https://api.iconify.design/gis:jumpsuit.svg', difficulty: 'صعب', sleeveType: 'basic', requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderToCrotch', 'inlegLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-abaya', name: 'عباءة', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:robe.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'shoulderWidth', 'pieceLength', 'sleeveLength'] },
    { id: 'w-cardigan', name: 'كارديغان', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:cardigan.svg', difficulty: 'متوسط', sleeveType: 'basic', collarType: 'shawl', availableSleeveTypes: ['basic', 'puff'], requiredMeasurements: ['bust', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },

    // Man
    { id: 'm-hoodie-unisex-image', name: 'هودي للجنسين (تصميم جاهز)', category: 'man', imageUrl: 'https://api.iconify.design/mdi:hoodie.svg', difficulty: 'متوسط', sleeveType: null, collarType: null, requiredMeasurements: []},
    { id: 'm-tshirt-adult-image', name: 'تيشيرت للبالغين (تصميم جاهز)', category: 'man', imageUrl: 'https://api.iconify.design/mdi:tshirt-crew.svg', difficulty: 'سهل', sleeveType: null, collarType: null, requiredMeasurements: []},
    { id: 'm-social-pants-image', name: 'بنطال رسمي رجالي (تصميم جاهز)', category: 'man', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'صعب', sleeveType: null, collarType: null, requiredMeasurements: []},
    { id: 'm-shirt', name: 'قميص', category: 'man', imageUrl: 'https://api.iconify.design/ion:shirt-outline.svg', difficulty: 'متوسط', sleeveType: 'basic', collarType: 'stand', requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },
    { id: 'm-pants', name: 'بنطال', category: 'man', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'صعب', requiredMeasurements: ['waist', 'hips', 'pieceLength', 'inlegLength', 'waistToFloor'] },
    { id: 'm-tshirt', name: 'تيشيرت', category: 'man', imageUrl: 'https://api.iconify.design/mdi:tshirt-crew.svg', difficulty: 'سهل', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'shoulderWidth', 'sleeveLength', 'armCircumference'] },
    { id: 'm-jacket', name: 'جاكيت', category: 'man', imageUrl: 'https://api.iconify.design/mdi:jacket.svg', difficulty: 'صعب', sleeveType: 'basic', requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'm-jacket-formal', name: 'جاكيت رسمي', category: 'man', imageUrl: 'https://api.iconify.design/mdi:jacket-outline.svg', difficulty: 'احترافي', sleeveType: 'twopiece', availableSleeveTypes: ['basic', 'twopiece'], collarType: 'notch', requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },
    { id: 'm-polo', name: 'قميص بولو', category: 'man', imageUrl: 'https://api.iconify.design/mdi:polo.svg', difficulty: 'سهل', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'shoulderWidth', 'sleeveLength'] },
    { id: 'm-shorts', name: 'شورت', category: 'man', imageUrl: 'https://api.iconify.design/mdi:shorts.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'inlegLength'] },
    { id: 'm-thobe', name: 'ثوب', category: 'man', imageUrl: 'https://api.iconify.design/iconoir:kaftan.svg', difficulty: 'متوسط', sleeveType: 'basic', collarType: 'mandarin', requiredMeasurements: ['bust', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'neckCircumference'] },

    // Child - Girls
    { id: 'c-dress', name: 'فستان', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/ph:dress-fill.svg', difficulty: 'متوسط', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff'], requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'c-skirt-girl', name: 'تنورة', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/mdi:skirt.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'pieceLength'] },
    { id: 'c-blouse-girl', name: 'بلوزة', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/map:blouse.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'c-leggings', name: 'بنطال ضيق (ليقنز)', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'inlegLength'] },
    { id: 'c-jumpsuit', name: 'أفرول طويل (جمبسوت)', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/gis:jumpsuit.svg', difficulty: 'صعب', sleeveType: 'basic', requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderToCrotch', 'inlegLength', 'sleeveLength', 'armCircumference'] },
    { id: 'c-romper', name: 'أفرول (رومبير)', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/material-symbols:romper.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'hips', 'shoulderWidth', 'shoulderToCrotch', 'sleeveLength', 'armCircumference'] },
    { id: 'c-pajamas-girl', name: 'طقم بيجاما', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/mdi:pajamas.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength', 'waist', 'hips', 'inlegLength'] },
    { id: 'c-party-dress-girl', name: 'فستان سهرة', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/ph:dress-fill.svg', difficulty: 'صعب', sleeveType: 'basic', requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'c-playsuit-girl', name: 'بلاي سوت', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/material-symbols:romper.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'hips', 'shoulderWidth', 'shoulderToCrotch'] },
    { id: 'c-nightgown-girl', name: 'ثوب نوم', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/ph:dress-fill.svg', difficulty: 'سهل', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength'] },
    { id: 'c-coat-girl', name: 'معطف', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/mdi:jacket.svg', difficulty: 'صعب', sleeveType: 'basic', requiredMeasurements: ['bust', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },

    // Child - Boys
    { id: 'c-shirt', name: 'قميص', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/ion:shirt-outline.svg', difficulty: 'سهل', sleeveType: 'basic', collarType: 'stand', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },
    { id: 'c-pants', name: 'بنطال', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'pieceLength', 'inlegLength'] },
    { id: 'c-tshirt-boy', name: 'تيشيرت', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:tshirt-crew.svg', difficulty: 'سهل', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'shoulderWidth'] },
    { id: 'c-shorts-boy', name: 'شورت', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:shorts.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'inlegLength'] },
    { id: 'c-hoodie-boy', name: 'هودي', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:hoodie.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'c-pajamas-boy', name: 'طقم بيجاما', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:pajamas.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength', 'waist', 'hips', 'inlegLength'] },
    { id: 'c-vest-boy', name: 'فيست', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:vest.svg', difficulty: 'متوسط', requiredMeasurements: ['bust', 'pieceLength', 'shoulderWidth'] },
    { id: 'c-overalls-boy', name: 'دنغري', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/gis:overalls.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'hips', 'inlegLength', 'shoulderToCrotch'] },
    { id: 'c-sweatpants-boy', name: 'بنطال رياضي', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'pieceLength', 'inlegLength'] },
    { id: 'c-robe-boy', name: 'روب', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:robe.svg', difficulty: 'سهل', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength', 'shoulderWidth'] },
  ];

  availableModels = computed(() => {
    return this.allModels.filter(m => {
      if (m.category !== this.category()) {
        return false;
      }
      if (this.category() === 'child') {
        // For children, we must also match the gender
        return m.gender === this.childGender();
      }
      return true; // For man/woman, just match category
    });
  });
  
  categoryName = computed(() => {
    if (this.category() === 'child') {
      return this.childGender() === 'boy' ? 'الأولاد' : 'البنات';
    }
    switch(this.category()) {
      case 'woman': return 'النسائية';
      case 'man': return 'الرجالية';
      default: return 'الأطفال';
    }
  });

  selectModel(model: PatternModel): void {
    this.modelSelected.emit(model);
  }

  getModelDescription(model: PatternModel): string {
    if (model.requiredMeasurements.length === 0) {
      return 'باترون جاهز بمقاسات قياسية ثابتة.';
    }

    const parts: string[] = [];
    const modelId = model.id;

    // Determine main garment type
    if (modelId.includes('dress') || modelId.includes('jumpsuit') || modelId.includes('abaya') || modelId.includes('thobe') || modelId.includes('robe') || modelId.includes('kimono')) {
      // These are full-body or major pieces, no need to say 'bodice'
    } else if (modelId.includes('bodice') || modelId.includes('shirt') || modelId.includes('blouse') || modelId.includes('jacket') || modelId.includes('cardigan') || modelId.includes('polo') || modelId.includes('hoodie') || modelId.includes('tshirt') || modelId.includes('coat')) {
      parts.push('كورساج');
    } else if (modelId.includes('skirt')) {
      parts.push('تنورة');
    } else if (modelId.includes('pants') || modelId.includes('shorts')) {
      parts.push('بنطال');
    }
    
    if (model.sleeveType) {
        const sleeveLabels: { [key: string]: string } = {
            'basic': 'كم أساسي', 'puff': 'كم منفوخ', 'twopiece': 'كم قطعتين', 
            'raglan': 'كم رجلان', 'kimono': 'كم كيمونو', 'darted': 'كم تايلور'
        };
        const label = sleeveLabels[model.sleeveType as keyof typeof sleeveLabels];
        if(label) parts.push(label);
    }

    if (model.collarType) {
         const collarLabels: { [key: string]: string } = {
            'stand': 'ياقة قميص', 'mandarin': 'ياقة ماندرين', 
            'shawl': 'ياقة شال', 'notch': 'ياقة جاكيت'
        };
        const label = collarLabels[model.collarType as keyof typeof collarLabels];
        if(label) parts.push(label);
    }
    
    if (modelId.includes('darted')) {
      if (!parts.includes('بنسات')) parts.push('بنسات');
    }

    if (parts.length === 0) {
      return 'باترون ديناميكي يتكيف مع مقاساتك.';
    }

    return `يشمل: ${parts.join('، ')}.`;
  }
}