import { Component, ChangeDetectionStrategy, input, computed, inject, signal, output, ElementRef, afterNextRender } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Measurements, PatternModel, PatternData, Unit } from '../../models/pattern.model';
import { PatternService } from '../../services/pattern.service';
import { GeminiService, OnlinePatternResult } from '../../services/gemini.service';

@Component({
  selector: 'app-pattern-viewer',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pattern-viewer.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
  styles: [`
    .stroke-dasharray {
      stroke-dasharray: 5, 5;
    }
  `]
})
export class PatternViewerComponent {
  model = input.required<PatternModel>();
  measurements = input.required<Measurements>();
  back = output<void>();

  private patternService = inject(PatternService);
  private geminiService = inject(GeminiService);
  private elementRef = inject(ElementRef<HTMLElement>);

  // --- Search State ---
  isSearching = signal(false);
  searchError = signal<string | null>(null);
  similarPatterns = signal<OnlinePatternResult[]>([]);

  // --- View State Signals ---
  showMeasurements = signal(true);
  unit = signal<Unit>('cm');
  zoomLevel = signal(1);
  panX = signal(0);
  panY = signal(0);
  isPanning = signal(false);

  // --- Private state for interactions ---
  private panStart = { x: 0, y: 0 };
  private lastPan = { x: 0, y: 0 };
  private pinchStartDistance = 0;
  private lastZoom = 1;

  patternData = computed<PatternData>(() => {
    return this.patternService.generatePattern(this.model(), this.measurements(), { 
      showMeasurements: this.showMeasurements(),
      unit: this.unit() 
    });
  });

  constructor() {
    afterNextRender(() => {
      this.calculateInitialZoom();
    });
  }
  
  private calculateInitialZoom(): void {
    const container = this.elementRef.nativeElement.querySelector('.svg-container');
    if (!container) return;

    const data = this.patternData();
    const containerWidth = container.clientWidth;
    const containerHeight = container.clientHeight;
    
    const padding = 80;
    const effectiveWidth = containerWidth - padding;
    const effectiveHeight = containerHeight - padding;

    if (data.width <= 0 || data.height <= 0 || effectiveWidth <= 0 || effectiveHeight <= 0) {
        this.zoomLevel.set(1);
        return;
    }

    const scaleX = effectiveWidth / data.width;
    const scaleY = effectiveHeight / data.height;

    const initialZoom = Math.min(scaleX, scaleY);
    this.zoomLevel.set(initialZoom);
    this.panX.set(0);
    this.panY.set(0);
  }

  // --- View Control Methods ---
  zoomIn(): void {
    this.zoomLevel.update(z => Math.min(z * 1.2, 10));
  }

  zoomOut(): void {
    this.zoomLevel.update(z => Math.max(z / 1.2, 0.1));
  }
  
  resetZoom(): void {
    this.calculateInitialZoom();
  }

  printPattern(): void {
    window.print();
  }

  exportAsSvg(): void {
    const data = this.patternData();
    const styles = `
      <style>
        path { fill: none; }
        .stroke-red-600 { stroke: #dc2626; } .fill-red-500\\/10 { fill: rgba(239, 68, 68, 0.1); }
        .stroke-blue-600 { stroke: #2563eb; } .fill-blue-500\\/10 { fill: rgba(59, 130, 246, 0.1); }
        .stroke-green-600 { stroke: #16a34a; } .fill-green-500\\/10 { fill: rgba(34, 197, 94, 0.1); }
        .stroke-orange-600 { stroke: #ea580c; } .fill-orange-500\\/10 { fill: rgba(249, 115, 22, 0.1); }
        .stroke-purple-600 { stroke: #9333ea; } .fill-purple-500\\/10 { fill: rgba(168, 85, 247, 0.1); }
        .stroke-2 { stroke-width: 2px; } .stroke-black { stroke: #000; } .stroke-1 { stroke-width: 1px; }
        .stroke-dasharray { stroke-dasharray: 5, 5; }
        .fill-gray-700 { fill: #374151; } .text-lg { font-size: 18px; } .font-bold { font-weight: 700; } .text-xs { font-size: 12px; }
      </style>`;
    const pathsHtml = data.paths.map(p => p.label ? `<text x="${p.x}" y="${p.y}" class="${p.class}" font-family="sans-serif" dominant-baseline="middle" text-anchor="middle">${p.label}</text>` : `<path d="${p.d}" class="${p.class}" fill-rule="evenodd" />`).join('');
    const fullSvg = `<svg width="${data.width}" height="${data.height}" viewBox="0 0 ${data.width} ${data.height}" xmlns="http://www.w3.org/2000/svg">${styles}${pathsHtml}</svg>`;
    const blob = new Blob([fullSvg], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `pattern-${this.model().id}-${this.measurements().bust}cm.svg`;
    document.body.appendChild(anchor);
    anchor.click();
    document.body.removeChild(anchor);
    URL.revokeObjectURL(url);
  }

  async searchForSimilarPatterns(): Promise<void> {
    this.isSearching.set(true);
    this.searchError.set(null);
    this.similarPatterns.set([]);
    try {
      const query = `${this.model().name} sewing pattern`;
      const results = await this.geminiService.searchForPatternsOnline(query);
      if (results.length === 0) {
        this.searchError.set('لم يتم العثور على باترونات مشابهة.');
      }
      this.similarPatterns.set(results);
    } catch (err) {
      this.searchError.set(err instanceof Error ? err.message : 'An unknown error occurred during search.');
    } finally {
      this.isSearching.set(false);
    }
  }
  
  closeSearchModal(): void {
    this.isSearching.set(false);
    this.searchError.set(null);
    this.similarPatterns.set([]);
  }

  // --- Wheel Event for Zooming ---
  onWheel(event: WheelEvent): void {
    event.preventDefault();
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    const scaleAmount = event.deltaY > 0 ? 0.9 : 1.1;
    const mouseX = event.clientX - rect.left;
    const mouseY = event.clientY - rect.top;

    const oldZoom = this.zoomLevel();
    const newZoom = Math.max(0.1, Math.min(oldZoom * scaleAmount, 10));
    
    // This logic ensures zooming is centered on the cursor
    const worldX = (mouseX - this.panX()) / oldZoom;
    const worldY = (mouseY - this.panY()) / oldZoom;
    const newPanX = mouseX - worldX * newZoom;
    const newPanY = mouseY - worldY * newZoom;

    this.zoomLevel.set(newZoom);
    this.panX.set(newPanX);
    this.panY.set(newPanY);
  }

  // --- Mouse Events for Panning ---
  onMouseDown(event: MouseEvent): void {
    if (event.button !== 0) return;
    event.preventDefault();
    this.isPanning.set(true);
    this.panStart.x = event.clientX;
    this.panStart.y = event.clientY;
    this.lastPan.x = this.panX();
    this.lastPan.y = this.panY();
  }

  onMouseMove(event: MouseEvent): void {
    if (!this.isPanning()) return;
    event.preventDefault();
    const dx = event.clientX - this.panStart.x;
    const dy = event.clientY - this.panStart.y;
    this.panX.set(this.lastPan.x + dx);
    this.panY.set(this.lastPan.y + dy);
  }

  onMouseUp(): void { this.isPanning.set(false); }
  onMouseLeave(): void { this.isPanning.set(false); }

  private getTouchDistance(touches: TouchList): number {
    const dx = touches[0].clientX - touches[1].clientX;
    const dy = touches[0].clientY - touches[1].clientY;
    return Math.sqrt(dx * dx + dy * dy);
  }

  // --- Touch Events for Panning & Zooming ---
  onTouchStart(event: TouchEvent): void {
    if (event.touches.length === 1) {
      this.isPanning.set(true);
      this.panStart.x = event.touches[0].clientX;
      this.panStart.y = event.touches[0].clientY;
      this.lastPan.x = this.panX();
      this.lastPan.y = this.panY();
    } else if (event.touches.length === 2) {
      this.isPanning.set(false);
      this.pinchStartDistance = this.getTouchDistance(event.touches);
      this.lastZoom = this.zoomLevel();
    }
  }

  onTouchMove(event: TouchEvent): void {
    event.preventDefault();
    if (event.touches.length === 1 && this.isPanning()) {
      const dx = event.touches[0].clientX - this.panStart.x;
      const dy = event.touches[0].clientY - this.panStart.y;
      this.panX.set(this.lastPan.x + dx);
      this.panY.set(this.lastPan.y + dy);
    } else if (event.touches.length === 2) {
      const newDistance = this.getTouchDistance(event.touches);
      const scale = newDistance / this.pinchStartDistance;
      const newZoom = Math.max(0.1, Math.min(this.lastZoom * scale, 10));
      this.zoomLevel.set(newZoom);
    }
  }

  onTouchEnd(event: TouchEvent): void {
    this.isPanning.set(false);
    if (event.touches.length < 2) {
      this.pinchStartDistance = 0;
    }
  }
}
