import { Component, ChangeDetectionStrategy, output, signal, computed, inject, ElementRef, afterNextRender, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Category, Measurements, PatternModel, PatternData, StandardSize } from '../../models/pattern.model';
import { PatternService } from '../../services/pattern.service';

declare var jspdf: any;

@Component({
  selector: 'app-pattern-drafting',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './pattern-drafting.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class PatternDraftingComponent {
  back = output<void>();

  private patternService = inject(PatternService);
  private elementRef = inject(ElementRef<HTMLElement>);

  // --- UI STATE SIGNALS ---
  draftingStep = signal<'model' | 'measurements' | 'preview'>('model');
  showMeasurements = signal<boolean>(true);

  // --- STATE SIGNALS ---
  selectedCategory = signal<Category>('woman');
  selectedChildGender = signal<'boy' | 'girl'>('girl');
  selectedModelId = signal<string | null>(null);
  selectedSleeveType = signal<'basic' | 'puff' | 'twopiece' | 'darted' | null>(null);
  measurements = signal<Measurements>({
    bust: 92, waist: 74, hips: 98, shoulderWidth: 40, pieceLength: 60, 
    sleeveLength: 58, armCircumference: 30, inlegLength: 78, 
    waistToFloor: 105, shoulderToCrotch: 76, sleevePuffRatio: 1.5, neckCircumference: 38
  });
  selectedStandardSizeName = signal<string | null>(null);
  
  // --- View State Signals ---
  zoomLevel = signal(1);
  panX = signal(0);
  panY = signal(0);
  isPanning = signal(false);

  // --- PDF Generation State ---
  showPdfModal = signal<boolean>(false);
  isGeneratingPdf = signal<boolean>(false);
  selectedPaperSize = signal<'a4' | 'letter'>('a4');
  pdfError = signal<string | null>(null);

  // --- Private state for interactions ---
  private panStart = { x: 0, y: 0 };
  private lastPan = { x: 0, y: 0 };
  private pinchStartDistance = 0;
  private lastZoom = 1;

  // --- DATA & LABELS ---
  draftingSteps: { key: 'model' | 'measurements' | 'preview', name: string }[] = [
    { key: 'model', name: 'الموديل' },
    { key: 'measurements', name: 'المقاسات' },
    { key: 'preview', name: 'المعاينة' },
  ];

  sleeveTypeLabels: { [key: string]: string } = {
    basic: 'كم أساسي',
    puff: 'كم منفوخ',
    twopiece: 'كم قطعتين',
    darted: 'كم ببنسة (تايلور)',
  };

  measurementLabels: { [key in keyof Measurements]: string } = {
    bust: 'محيط الصدر', waist: 'محيط الخصر', hips: 'محيط الأرداف',
    shoulderWidth: 'عرض الكتف', pieceLength: 'طول القطعة', sleeveLength: 'طول الكم',
    armCircumference: 'محيط الذراع', inlegLength: 'طول الساق الداخلي', waistToFloor: 'الطول من الخصر للأرض',
    shoulderToCrotch: 'طول الجذع (من الكتف للحجر)', sleevePuffRatio: 'نسبة كشكشة الكم',
    neckCircumference: 'محيط الرقبة'
  };

  private womanStandardSizes: StandardSize[] = [
    { name: 'XS', numericSize: '34', measurements: { bust: 82, waist: 64, hips: 90, shoulderWidth: 38, pieceLength: 58, sleeveLength: 57, armCircumference: 26, inlegLength: 77, waistToFloor: 104, shoulderToCrotch: 73, sleevePuffRatio: 1.5, neckCircumference: 35 }},
    { name: 'S', numericSize: '36', measurements: { bust: 86, waist: 68, hips: 94, shoulderWidth: 39, pieceLength: 59, sleeveLength: 58, armCircumference: 28, inlegLength: 78, waistToFloor: 105, shoulderToCrotch: 75, sleevePuffRatio: 1.5, neckCircumference: 36 }},
    { name: 'M', numericSize: '38', measurements: { bust: 90, waist: 72, hips: 98, shoulderWidth: 40, pieceLength: 60, sleeveLength: 59, armCircumference: 30, inlegLength: 78, waistToFloor: 106, shoulderToCrotch: 76, sleevePuffRatio: 1.5, neckCircumference: 37 }},
    { name: 'L', numericSize: '40', measurements: { bust: 94, waist: 76, hips: 102, shoulderWidth: 41, pieceLength: 61, sleeveLength: 60, armCircumference: 32, inlegLength: 79, waistToFloor: 107, shoulderToCrotch: 78, sleevePuffRatio: 1.5, neckCircumference: 38 }},
    { name: 'XL', numericSize: '42', measurements: { bust: 100, waist: 82, hips: 108, shoulderWidth: 42, pieceLength: 62, sleeveLength: 60, armCircumference: 34, inlegLength: 79, waistToFloor: 108, shoulderToCrotch: 80, sleevePuffRatio: 1.5, neckCircumference: 39 }},
    { name: 'XXL', numericSize: '44', measurements: { bust: 106, waist: 88, hips: 114, shoulderWidth: 43, pieceLength: 63, sleeveLength: 61, armCircumference: 36, inlegLength: 80, waistToFloor: 109, shoulderToCrotch: 82, sleevePuffRatio: 1.5, neckCircumference: 40 }},
    { name: '3XL', numericSize: '46', measurements: { bust: 112, waist: 94, hips: 120, shoulderWidth: 44, pieceLength: 64, sleeveLength: 61, armCircumference: 38, inlegLength: 80, waistToFloor: 110, shoulderToCrotch: 83, sleevePuffRatio: 1.5, neckCircumference: 41 }},
  ];

  private manStandardSizes: StandardSize[] = [
    { name: 'S', numericSize: '46', measurements: { bust: 92, waist: 80, hips: 96, shoulderWidth: 44, pieceLength: 70, sleeveLength: 63, armCircumference: 32, inlegLength: 81, waistToFloor: 108, shoulderToCrotch: 82, sleevePuffRatio: 1.5, neckCircumference: 39 }},
    { name: 'M', numericSize: '48', measurements: { bust: 96, waist: 84, hips: 100, shoulderWidth: 45, pieceLength: 72, sleeveLength: 64, armCircumference: 34, inlegLength: 82, waistToFloor: 109, shoulderToCrotch: 84, sleevePuffRatio: 1.5, neckCircumference: 40 }},
    { name: 'L', numericSize: '50', measurements: { bust: 100, waist: 88, hips: 104, shoulderWidth: 46, pieceLength: 74, sleeveLength: 65, armCircumference: 36, inlegLength: 83, waistToFloor: 110, shoulderToCrotch: 86, sleevePuffRatio: 1.5, neckCircumference: 41 }},
    { name: 'XL', numericSize: '52', measurements: { bust: 104, waist: 92, hips: 108, shoulderWidth: 47, pieceLength: 76, sleeveLength: 66, armCircumference: 38, inlegLength: 84, waistToFloor: 111, shoulderToCrotch: 88, sleevePuffRatio: 1.5, neckCircumference: 42 }},
    { name: 'XXL', numericSize: '54', measurements: { bust: 108, waist: 96, hips: 112, shoulderWidth: 48, pieceLength: 78, sleeveLength: 67, armCircumference: 40, inlegLength: 85, waistToFloor: 112, shoulderToCrotch: 90, sleevePuffRatio: 1.5, neckCircumference: 43 }},
    { name: '3XL', numericSize: '56', measurements: { bust: 112, waist: 100, hips: 116, shoulderWidth: 49, pieceLength: 80, sleeveLength: 68, armCircumference: 42, inlegLength: 86, waistToFloor: 113, shoulderToCrotch: 91, sleevePuffRatio: 1.5, neckCircumference: 44 }},
  ];

  private childStandardSizes: StandardSize[] = [
    { name: 'سنة', numericSize: '1', measurements: { bust: 50, waist: 49, hips: 52, shoulderWidth: 22, pieceLength: 36, sleeveLength: 28, armCircumference: 17, inlegLength: 30, waistToFloor: 48, shoulderToCrotch: 42, sleevePuffRatio: 1.5, neckCircumference: 25 }},
    { name: 'سنتان', numericSize: '2', measurements: { bust: 52, waist: 50, hips: 54, shoulderWidth: 23, pieceLength: 40, sleeveLength: 32, armCircumference: 18, inlegLength: 34, waistToFloor: 53, shoulderToCrotch: 44, sleevePuffRatio: 1.5, neckCircumference: 26 }},
    { name: '4 سنوات', numericSize: '4', measurements: { bust: 56, waist: 53, hips: 58, shoulderWidth: 25, pieceLength: 46, sleeveLength: 38, armCircumference: 19, inlegLength: 43, waistToFloor: 63, shoulderToCrotch: 48, sleevePuffRatio: 1.5, neckCircumference: 27 }},
    { name: '6 سنوات', numericSize: '6', measurements: { bust: 60, waist: 56, hips: 63, shoulderWidth: 27, pieceLength: 52, sleeveLength: 43, armCircumference: 20, inlegLength: 52, waistToFloor: 73, shoulderToCrotch: 52, sleevePuffRatio: 1.5, neckCircumference: 28 }},
    { name: '8 سنوات', numericSize: '8', measurements: { bust: 66, waist: 59, hips: 68, shoulderWidth: 29, pieceLength: 58, sleeveLength: 48, armCircumference: 22, inlegLength: 60, waistToFloor: 83, shoulderToCrotch: 56, sleevePuffRatio: 1.5, neckCircumference: 30 }},
    { name: '10 سنوات', numericSize: '10', measurements: { bust: 72, waist: 62, hips: 74, shoulderWidth: 31, pieceLength: 64, sleeveLength: 52, armCircumference: 24, inlegLength: 67, waistToFloor: 91, shoulderToCrotch: 60, sleevePuffRatio: 1.5, neckCircumference: 32 }},
    { name: '12 سنة', numericSize: '12', measurements: { bust: 78, waist: 65, hips: 80, shoulderWidth: 33, pieceLength: 70, sleeveLength: 56, armCircumference: 26, inlegLength: 73, waistToFloor: 98, shoulderToCrotch: 64, sleevePuffRatio: 1.5, neckCircumference: 33 }},
    { name: '14 سنة', numericSize: '14', measurements: { bust: 84, waist: 68, hips: 86, shoulderWidth: 35, pieceLength: 76, sleeveLength: 59, armCircumference: 28, inlegLength: 78, waistToFloor: 104, shoulderToCrotch: 68, sleevePuffRatio: 1.5, neckCircumference: 34 }},
  ];

  private allModels: PatternModel[] = [
    // Woman
    { id: 'w-blouse', name: 'بلوزة أساسية', category: 'woman', imageUrl: 'https://api.iconify.design/map:blouse.svg', difficulty: 'متوسط', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-blouse-darted', name: 'بلوزة ببنسات', category: 'woman', imageUrl: 'https://api.iconify.design/map:blouse.svg', difficulty: 'صعب', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff', 'darted'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-dress-darted', name: 'فستان ببنسات', category: 'woman', imageUrl: 'https://api.iconify.design/ph:dress-fill.svg', difficulty: 'صعب', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff', 'darted'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-skirt', name: 'تنورة نصف كلوش', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:skirt.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'pieceLength'] },
    { id: 'w-skirt-darted', name: 'تنورة مستقيمة (بنسل)', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:skirt.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'hips', 'pieceLength'] },
    { id: 'w-blouse-raglan', name: 'بلوزة بكم رجلان', category: 'woman', imageUrl: 'https://api.iconify.design/icon-park-outline:raglan-sleeve.svg', difficulty: 'صعب', sleeveType: 'raglan', requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-kimono', name: 'كيمونو', category: 'woman', imageUrl: 'https://api.iconify.design/iconoir:kaftan.svg', difficulty: 'متوسط', sleeveType: 'kimono', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength'] },
    { id: 'w-dress', name: 'فستان أساسي', category: 'woman', imageUrl: 'https://api.iconify.design/ph:dress-fill.svg', difficulty: 'متوسط', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff'], requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-skirt-pleated', name: 'تنورة بكسرات', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:skirt.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'pieceLength'] },
    { id: 'w-skirt-circle', name: 'تنورة كلوش', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:circle-slice-8.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'pieceLength'] },
    { id: 'w-skirt-double-circle', name: 'تنورة دوبل كلوش', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:circle-double.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'pieceLength'] },
    { id: 'w-pants', name: 'بنطال', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'متوسط', requiredMeasurements: ['waist', 'hips', 'pieceLength', 'inlegLength', 'waistToFloor'] },
    { id: 'w-jumpsuit', name: 'جمبسوت', category: 'woman', imageUrl: 'https://api.iconify.design/gis:jumpsuit.svg', difficulty: 'صعب', sleeveType: 'basic', requiredMeasurements: ['bust', 'waist', 'hips', 'shoulderToCrotch', 'inlegLength', 'sleeveLength', 'armCircumference'] },
    { id: 'w-abaya', name: 'عباءة', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:robe.svg', difficulty: 'متوسط', sleeveType: 'basic', requiredMeasurements: ['bust', 'shoulderWidth', 'pieceLength', 'sleeveLength'] },
    { id: 'w-cardigan', name: 'كارديغان', category: 'woman', imageUrl: 'https://api.iconify.design/mdi:cardigan.svg', difficulty: 'متوسط', sleeveType: 'basic', collarType: 'shawl', availableSleeveTypes: ['basic', 'puff'], requiredMeasurements: ['bust', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },
    { id: 'm-shirt', name: 'قميص', category: 'man', imageUrl: 'https://api.iconify.design/ion:shirt-outline.svg', difficulty: 'متوسط', sleeveType: 'basic', collarType: 'stand', requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },
    { id: 'm-pants', name: 'بنطال', category: 'man', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'صعب', requiredMeasurements: ['waist', 'hips', 'pieceLength', 'inlegLength', 'waistToFloor'] },
    { id: 'm-tshirt', name: 'تيشيرت', category: 'man', imageUrl: 'https://api.iconify.design/mdi:tshirt-crew.svg', difficulty: 'سهل', sleeveType: 'basic', requiredMeasurements: ['bust', 'pieceLength', 'shoulderWidth', 'sleeveLength', 'armCircumference'] },
    { id: 'm-jacket', name: 'جاكيت', category: 'man', imageUrl: 'https://api.iconify.design/mdi:jacket.svg', difficulty: 'صعب', sleeveType: 'basic', requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'm-jacket-formal', name: 'جاكيت رسمي', category: 'man', imageUrl: 'https://api.iconify.design/mdi:jacket-outline.svg', difficulty: 'احترافي', sleeveType: 'twopiece', availableSleeveTypes: ['basic', 'twopiece'], collarType: 'notch', requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },
    { id: 'm-thobe', name: 'ثوب', category: 'man', imageUrl: 'https://api.iconify.design/iconoir:kaftan.svg', difficulty: 'متوسط', sleeveType: 'basic', collarType: 'mandarin', requiredMeasurements: ['bust', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'neckCircumference'] },
    { id: 'c-dress', name: 'فستان', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/ph:dress-fill.svg', difficulty: 'متوسط', sleeveType: 'basic', availableSleeveTypes: ['basic', 'puff'], requiredMeasurements: ['bust', 'waist', 'shoulderWidth', 'pieceLength', 'sleeveLength', 'armCircumference'] },
    { id: 'c-skirt-girl', name: 'تنورة', category: 'child', gender: 'girl', imageUrl: 'https://api.iconify.design/mdi:skirt.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'pieceLength'] },
    { id: 'c-shirt', name: 'قميص', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/ion:shirt-outline.svg', difficulty: 'سهل', sleeveType: 'basic', collarType: 'stand', requiredMeasurements: ['bust', 'pieceLength', 'sleeveLength', 'armCircumference', 'neckCircumference'] },
    { id: 'c-pants', name: 'بنطال', category: 'child', gender: 'boy', imageUrl: 'https://api.iconify.design/mdi:pants.svg', difficulty: 'سهل', requiredMeasurements: ['waist', 'hips', 'pieceLength', 'inlegLength'] },
  ];

  // --- COMPUTED SIGNALS ---
  currentDraftingStepIndex = computed(() => this.draftingSteps.findIndex(s => s.key === this.draftingStep()));

  standardSizes = computed<StandardSize[]>(() => {
    switch(this.selectedCategory()) {
      case 'child': return this.childStandardSizes;
      case 'man': return this.manStandardSizes;
      case 'woman': return this.womanStandardSizes;
      default: return this.womanStandardSizes;
    }
  });

  availableModels = computed(() => this.allModels.filter(m => {
    if (m.category !== this.selectedCategory()) return false;
    if (this.selectedCategory() === 'child' && m.gender !== this.selectedChildGender()) return false;
    return true;
  }));

  currentModel = computed(() => {
    const modelId = this.selectedModelId();
    if (!modelId) return null;
    return this.allModels.find(m => m.id === modelId) ?? null;
  });
  
  requiredMeasurements = computed(() => {
    const model = this.currentModel();
    if (!model) return [];
    
    const reqs = new Set(model.requiredMeasurements);
    const sleeveType = model.availableSleeveTypes ? this.selectedSleeveType() : model.sleeveType;

    if (sleeveType === 'puff') {
      reqs.add('sleevePuffRatio');
    }

    return Array.from(reqs);
  });

  patternData = computed<PatternData>(() => {
    const model = this.currentModel();
    if (!model) return { paths: [], width: 100, height: 100 };

    const finalSleeveType = model.availableSleeveTypes ? this.selectedSleeveType() : model.sleeveType;
    
    const modelForGeneration: PatternModel = { ...model, sleeveType: finalSleeveType as any };

    return this.patternService.generatePattern(modelForGeneration, this.measurements(), { showMeasurements: this.showMeasurements() });
  });

  pdfLayout = computed(() => {
    const data = this.patternData();
    if (!data || data.width === 0 || data.height === 0) {
      return { cols: 0, rows: 0, totalPages: 0 };
    }
    const paperSize = this.selectedPaperSize();

    const POINTS_PER_CM = 72 / 2.54;
    const SVG_UNITS_PER_CM = 10;
    const SCALE_FACTOR = POINTS_PER_CM / SVG_UNITS_PER_CM;
    const MARGIN_CM = 1;
    const MARGIN_PTS = MARGIN_CM * POINTS_PER_CM;

    const paperDimensions = {
      a4: { width: 21.0, height: 29.7 },
      letter: { width: 21.6, height: 27.9 }
    };
    const pageDimCm = paperDimensions[paperSize];
    const pageDimPts = { width: pageDimCm.width * POINTS_PER_CM, height: pageDimCm.height * POINTS_PER_CM };
    const printableAreaPts = {
      width: pageDimPts.width - (2 * MARGIN_PTS),
      height: pageDimPts.height - (2 * MARGIN_PTS)
    };

    const patternDimPts = { width: data.width * SCALE_FACTOR, height: data.height * SCALE_FACTOR };
    const cols = Math.ceil(patternDimPts.width / printableAreaPts.width);
    const rows = Math.ceil(patternDimPts.height / printableAreaPts.height);
    
    return { cols, rows, totalPages: cols * rows };
  });

  constructor() {
    effect(() => {
      // Automatically select a default size when the category changes.
      const sizes = this.standardSizes();
      if (sizes.length > 0) {
        const defaultSize = sizes.find(s => s.name === 'M') || sizes[Math.floor(sizes.length / 2)];
        this.selectStandardSize(defaultSize!);
      }
    }, { allowSignalWrites: true });

    effect(() => {
      if (this.draftingStep() === 'preview') {
        afterNextRender(() => this.calculateInitialZoom());
      }
    });
  }

  // --- EVENT HANDLERS ---
  onCategoryChange(event: Event) {
    const newCategory = (event.target as HTMLSelectElement).value as Category;
    this.selectedCategory.set(newCategory);
    this.selectedModelId.set(null);
  }

  onChildGenderChange(event: Event) {
    this.selectedChildGender.set((event.target as HTMLInputElement).value as 'boy' | 'girl');
    this.selectedModelId.set(null);
  }

  selectStandardSize(size: StandardSize): void {
    this.measurements.set(size.measurements);
    this.selectedStandardSizeName.set(size.name);
  }

  selectModel(model: PatternModel): void {
    this.selectedModelId.set(model.id);
    if (model.availableSleeveTypes && model.sleeveType) {
        this.selectedSleeveType.set(model.sleeveType as 'basic' | 'puff' | 'twopiece' | 'darted');
    } else {
        this.selectedSleeveType.set(null);
    }
    this.draftingStep.set('measurements');
  }

  goToPreview(): void {
    this.draftingStep.set('preview');
  }

  goBackTo(step: 'model' | 'measurements'): void {
    this.draftingStep.set(step);
  }

  updateMeasurement(field: keyof Measurements, value: string): void {
    this.measurements.update(m => ({ ...m, [field]: parseFloat(value) || 0 }));
  }
  
  updateSleeveType(event: Event): void {
    const newSleeveType = (event.target as HTMLSelectElement).value as 'basic' | 'puff' | 'twopiece' | 'darted';
    this.selectedSleeveType.set(newSleeveType);
  }

  printPattern = () => window.print();

  exportAsSvg(): void {
    const data = this.patternData();
    const styles = `<style>path{fill:none;}.stroke-red-600{stroke:#dc2626;}.fill-red-500\\/10{fill:rgba(239,68,68,0.1);}.stroke-blue-600{stroke:#2563eb;}.fill-blue-500\\/10{fill:rgba(59,130,246,0.1);}.stroke-green-600{stroke:#16a34a;}.fill-green-500\\/10{fill:rgba(34,197,94,0.1);}.stroke-purple-600{stroke:#9333ea;}.fill-purple-500\\/10{fill:rgba(168,85,247,0.1);}.stroke-pink-600{stroke:#db2777;}.fill-pink-500\\/10{fill:rgba(236,72,153,0.1);}.stroke-indigo-600{stroke:#4f46e5;}.fill-indigo-500\\/10{fill:rgba(99,102,241,0.1);}.stroke-teal-600{stroke:#0d9488;}.fill-teal-500\\/10{fill:rgba(20,184,166,0.1);}.stroke-cyan-600{stroke:#0891b2;}.fill-cyan-500\\/10{fill:rgba(6,182,212,0.1);}.stroke-orange-600{stroke:#f97316;}.fill-orange-500\\/10{fill:rgba(251,146,60,0.1);}.stroke-2{stroke-width:2px;}.stroke-black{stroke:#000;}.stroke-1{stroke-width:1px;}.stroke-dasharray{stroke-dasharray:5,5;}.fill-gray-700{fill:#374151;}.text-lg{font-size:18px;}.font-bold{font-weight:700;}.text-xs{font-size:12px;}.text-sm{font-size:14px;}.fill-slate-600{fill:#475569;}.stroke-slate-500{stroke:#64748b;}.stroke-slate-400{stroke:#94a3b8;}.fill-none{fill:none;}</style>`;
    const pathsHtml = data.paths.map(p => p.label ? `<text x="${p.x}" y="${p.y}" class="${p.class}" font-family="sans-serif" dominant-baseline="middle" text-anchor="middle">${p.label}</text>` : `<path d="${p.d}" class="${p.class}" fill-rule="evenodd" />`).join('');
    const fullSvg = `<svg width="${data.width}" height="${data.height}" viewBox="0 0 ${data.width} ${data.height}" xmlns="http://www.w3.org/2000/svg">${styles}${pathsHtml}</svg>`;
    const blob = new Blob([fullSvg], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `pattern-draft.svg`;
    a.click();
    URL.revokeObjectURL(url);
  }

  async generatePdf(): Promise<void> {
    this.isGeneratingPdf.set(true);
    this.pdfError.set(null);
    await new Promise(resolve => setTimeout(resolve, 50));

    try {
      const { jsPDF } = jspdf;
      const data = this.patternData();
      const layout = this.pdfLayout();

      const POINTS_PER_CM = 72 / 2.54;
      const SVG_UNITS_PER_CM = 10;
      const SCALE_FACTOR = POINTS_PER_CM / SVG_UNITS_PER_CM;
      const MARGIN_CM = 1;
      const MARGIN_PTS = MARGIN_CM * POINTS_PER_CM;
      
      const paperSize = this.selectedPaperSize();
      const paperDimensions = {
        a4: { width: 21.0, height: 29.7 },
        letter: { width: 21.6, height: 27.9 }
      };
      const pageDimCm = paperDimensions[paperSize];
      const pageDimPts = { width: pageDimCm.width * POINTS_PER_CM, height: pageDimCm.height * POINTS_PER_CM };
      const printableAreaPts = {
        width: pageDimPts.width - (2 * MARGIN_PTS),
        height: pageDimPts.height - (2 * MARGIN_PTS)
      };
      const patternDimPts = { width: data.width * SCALE_FACTOR, height: data.height * SCALE_FACTOR };

      const styles = `<style>path{fill:none;}.stroke-red-600{stroke:#dc2626;}.fill-red-500\\/10{fill:rgba(239,68,68,0.1);}.stroke-blue-600{stroke:#2563eb;}.fill-blue-500\\/10{fill:rgba(59,130,246,0.1);}.stroke-green-600{stroke:#16a34a;}.fill-green-500\\/10{fill:rgba(34,197,94,0.1);}.stroke-purple-600{stroke:#9333ea;}.fill-purple-500\\/10{fill:rgba(168,85,247,0.1);}.stroke-pink-600{stroke:#db2777;}.fill-pink-500\\/10{fill:rgba(236,72,153,0.1);}.stroke-indigo-600{stroke:#4f46e5;}.fill-indigo-500\\/10{fill:rgba(99,102,241,0.1);}.stroke-teal-600{stroke:#0d9488;}.fill-teal-500\\/10{fill:rgba(20,184,166,0.1);}.stroke-cyan-600{stroke:#0891b2;}.fill-cyan-500\\/10{fill:rgba(6,182,212,0.1);}.stroke-orange-600{stroke:#f97316;}.fill-orange-500\\/10{fill:rgba(251,146,60,0.1);}.stroke-2{stroke-width:2px;}.stroke-black{stroke:#000;}.stroke-1{stroke-width:1px;}.stroke-dasharray{stroke-dasharray:5,5;}.fill-gray-700{fill:#374151;}.text-lg{font-size:18px;}.font-bold{font-weight:700;}.text-xs{font-size:12px;}.text-sm{font-size:14px;}.fill-slate-600{fill:#475569;}.stroke-slate-500{stroke:#64748b;}.stroke-slate-400{stroke:#94a3b8;}.fill-none{fill:none;}</style>`;
      const pathsHtml = data.paths.map(p => p.label ? `<text x="${p.x}" y="${p.y}" class="${p.class}" font-family="sans-serif" dominant-baseline="middle" text-anchor="middle">${p.label}</text>` : `<path d="${p.d}" class="${p.class}" fill-rule="evenodd" />`).join('');
      const svgString = `<svg width="${patternDimPts.width}" height="${patternDimPts.height}" viewBox="0 0 ${data.width} ${data.height}" xmlns="http://www.w3.org/2000/svg">${styles}${pathsHtml}</svg>`;
      const svgElement = new DOMParser().parseFromString(svgString, "image/svg+xml").documentElement;

      const pdf = new jsPDF({ orientation: 'portrait', unit: 'pt', format: paperSize });
      
      for (let i = 0; i < layout.rows; i++) {
        for (let j = 0; j < layout.cols; j++) {
          if (i > 0 || j > 0) pdf.addPage(paperSize, 'portrait');
          
          const offsetX = -j * printableAreaPts.width;
          const offsetY = -i * printableAreaPts.height;

          await pdf.svg(svgElement, {
              x: MARGIN_PTS + offsetX,
              y: MARGIN_PTS + offsetY,
              width: patternDimPts.width,
              height: patternDimPts.height,
          });

          const pageNum = i * layout.cols + j + 1;
          pdf.setFontSize(8);
          pdf.setTextColor('#888888');
          const gridLabel = `(Row ${i + 1}, Col ${j + 1})`;
          pdf.text(`Page ${pageNum} of ${layout.totalPages} ${gridLabel}`, MARGIN_PTS, MARGIN_PTS / 2);
          
          const crossSize = 12;
          pdf.setDrawColor('#000000');
          pdf.setLineWidth(0.5);
          const drawCross = (x:number, y:number) => {
            pdf.line(x - crossSize / 2, y, x + crossSize / 2, y);
            pdf.line(x, y - crossSize / 2, x, y + crossSize / 2);
          };
          drawCross(MARGIN_PTS, MARGIN_PTS);
          drawCross(pageDimPts.width - MARGIN_PTS, MARGIN_PTS);
          drawCross(MARGIN_PTS, pageDimPts.height - MARGIN_PTS);
          drawCross(pageDimPts.width - MARGIN_PTS, pageDimPts.height - MARGIN_PTS);
        }
      }

      pdf.save(`Pattern-${this.currentModel()?.id || 'custom'}.pdf`);
    } catch (err) {
      console.error("PDF generation failed:", err);
      this.pdfError.set(err instanceof Error ? err.message : 'An unknown error occurred.');
    } finally {
      this.isGeneratingPdf.set(false);
      this.showPdfModal.set(false);
    }
  }
  
  private calculateInitialZoom(): void {
    const container = this.elementRef.nativeElement.querySelector('.svg-container');
    if (!container) return;

    const data = this.patternData();
    const containerWidth = container.clientWidth;
    const containerHeight = container.clientHeight;
    
    const padding = 80;
    const effectiveWidth = containerWidth - padding;
    const effectiveHeight = containerHeight - padding;

    if (data.width <= 0 || data.height <= 0 || effectiveWidth <= 0 || effectiveHeight <= 0) {
        this.zoomLevel.set(1);
        return;
    }

    const scaleX = effectiveWidth / data.width;
    const scaleY = effectiveHeight / data.height;

    const initialZoom = Math.min(scaleX, scaleY);
    this.zoomLevel.set(initialZoom);
    this.panX.set(0);
    this.panY.set(0);
  }

  // --- View Control Methods ---
  zoomIn = () => this.zoomLevel.update(z => Math.min(z * 1.2, 10));
  zoomOut = () => this.zoomLevel.update(z => Math.max(z / 1.2, 0.1));
  resetZoom = () => this.calculateInitialZoom();

  // --- Wheel Event for Zooming ---
  onWheel(event: WheelEvent): void {
    event.preventDefault();
    const rect = (event.currentTarget as HTMLElement).getBoundingClientRect();
    const scaleAmount = event.deltaY > 0 ? 0.9 : 1.1;
    const mouseX = event.clientX - rect.left;
    const mouseY = event.clientY - rect.top;

    const oldZoom = this.zoomLevel();
    const newZoom = Math.max(0.1, Math.min(oldZoom * scaleAmount, 10));
    
    // This logic ensures zooming is centered on the cursor
    const worldX = (mouseX - this.panX()) / oldZoom;
    const worldY = (mouseY - this.panY()) / oldZoom;
    const newPanX = mouseX - worldX * newZoom;
    const newPanY = mouseY - worldY * newZoom;

    this.zoomLevel.set(newZoom);
    this.panX.set(newPanX);
    this.panY.set(newPanY);
  }

  // --- Mouse Events for Panning ---
  onMouseDown(event: MouseEvent): void {
    if (event.button !== 0) return;
    event.preventDefault();
    this.isPanning.set(true);
    this.panStart.x = event.clientX;
    this.panStart.y = event.clientY;
    this.lastPan.x = this.panX();
    this.lastPan.y = this.panY();
  }

  onMouseMove(event: MouseEvent): void {
    if (!this.isPanning()) return;
    event.preventDefault();
    const dx = event.clientX - this.panStart.x;
    const dy = event.clientY - this.panStart.y;
    this.panX.set(this.lastPan.x + dx);
    this.panY.set(this.lastPan.y + dy);
  }

  onMouseUp(): void { this.isPanning.set(false); }
  onMouseLeave(): void { this.isPanning.set(false); }

  private getTouchDistance(touches: TouchList): number {
    const dx = touches[0].clientX - touches[1].clientX;
    const dy = touches[0].clientY - touches[1].clientY;
    return Math.sqrt(dx * dx + dy * dy);
  }

  // --- Touch Events for Panning & Zooming ---
  onTouchStart(event: TouchEvent): void {
    if (event.touches.length === 1) {
      this.isPanning.set(true);
      this.panStart.x = event.touches[0].clientX;
      this.panStart.y = event.touches[0].clientY;
      this.lastPan.x = this.panX();
      this.lastPan.y = this.panY();
    } else if (event.touches.length === 2) {
      this.isPanning.set(false);
      this.pinchStartDistance = this.getTouchDistance(event.touches);
      this.lastZoom = this.zoomLevel();
    }
  }

  onTouchMove(event: TouchEvent): void {
    event.preventDefault();
    if (event.touches.length === 1 && this.isPanning()) {
      const dx = event.touches[0].clientX - this.panStart.x;
      const dy = event.touches[0].clientY - this.panStart.y;
      this.panX.set(this.lastPan.x + dx);
      this.panY.set(this.lastPan.y + dy);
    } else if (event.touches.length === 2) {
      const newDistance = this.getTouchDistance(event.touches);
      const scale = newDistance / this.pinchStartDistance;
      const newZoom = Math.max(0.1, Math.min(this.lastZoom * scale, 10));
      this.zoomLevel.set(newZoom);
    }
  }

  onTouchEnd(event: TouchEvent): void {
    this.isPanning.set(false);
    if (event.touches.length < 2) {
      this.pinchStartDistance = 0;
    }
  }
}