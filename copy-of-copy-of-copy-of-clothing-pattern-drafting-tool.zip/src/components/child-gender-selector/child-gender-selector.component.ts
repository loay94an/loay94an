import { Component, ChangeDetectionStrategy, output } from '@angular/core';

interface GenderOption {
  key: 'boy' | 'girl';
  name: string;
  icon: string;
}

@Component({
  selector: 'app-child-gender-selector',
  standalone: true,
  templateUrl: './child-gender-selector.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class ChildGenderSelectorComponent {
  genderSelected = output<'boy' | 'girl'>();

  genders: GenderOption[] = [
    { key: 'girl', name: 'بنت', icon: 'https://api.iconify.design/ph:dress-duotone.svg' },
    { key: 'boy', name: 'ولد', icon: 'https://api.iconify.design/ion:shirt-outline.svg' },
  ];

  selectGender(gender: 'boy' | 'girl'): void {
    this.genderSelected.emit(gender);
  }
}