import { Component, ChangeDetectionStrategy, input, output, signal, effect, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Measurements, PatternModel, StandardSize, Unit } from '../../models/pattern.model';

@Component({
  selector: 'app-measurements',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './measurements.component.html',
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class MeasurementsComponent {
  model = input.required<PatternModel>();
  measurementsReady = output<Measurements>();

  activeTab = signal<'standard' | 'custom'>('standard');
  selectedStandardSize = signal<StandardSize | null>(null);
  showHelpGuide = signal<boolean>(false);
  unit = signal<Unit>('cm');
  
  // Base measurements are always stored in CM
  measurements = signal<Measurements>({
    bust: 92, waist: 74, hips: 98, shoulderWidth: 40, pieceLength: 60, sleeveLength: 58, armCircumference: 30, inlegLength: 78, waistToFloor: 105, shoulderToCrotch: 76, sleevePuffRatio: 1.5, neckCircumference: 38
  });

  isAiModel = computed(() => {
    const modelId = this.model().id;
    return modelId.startsWith('custom-') || modelId.startsWith('ai-') || modelId.startsWith('online-');
  });

  isFixedSizePattern = computed(() => this.model().requiredMeasurements.length === 0);

  private category = computed(() => this.model().category);

  requiredMeasurementsKeys = computed(() => this.model().requiredMeasurements);

  measurementLabels: { [key in keyof Measurements]: string } = {
    bust: 'محيط الصدر',
    waist: 'محيط الخصر',
    hips: 'محيط الأرداف',
    shoulderWidth: 'عرض الكتف',
    pieceLength: 'طول القطعة',
    sleeveLength: 'طول الكم',
    armCircumference: 'محيط الذراع',
    inlegLength: 'طول الساق الداخلي',
    waistToFloor: 'الطول من الخصر للأرض',
    shoulderToCrotch: 'طول الجذع (من الكتف للحجر)',
    sleevePuffRatio: 'نسبة كشكشة الكم (مثال: 1.5)',
    neckCircumference: 'محيط الرقبة',
  };

  measurementGuides: { [key in keyof Measurements]?: { title: string; instructions: string; icon: string } } = {
    bust: { title: 'محيط الصدر', instructions: 'مرري شريط القياس حول أقصى امتلاء لمنطقة الصدر والإبقاء عليه موازياً للأرض.', icon: 'https://api.iconify.design/icon-park-outline:chest.svg' },
    waist: { title: 'محيط الخصر', instructions: 'مرري شريط القياس حول أضيق جزء في محيط الخصر، عادة فوق السرة.', icon: 'https://api.iconify.design/la:ruler-horizontal.svg' },
    hips: { title: 'محيط الأرداف', instructions: 'مرري شريط القياس حول أقصى امتلاء لمنطقة الأرداف مع ضم القدمين.', icon: 'https://api.iconify.design/icon-park-outline:hips.svg' },
    shoulderWidth: { title: 'عرض الكتف', instructions: 'قيسي المسافة بين عظمتي الكتفين من الخلف.', icon: 'https://api.iconify.design/la:arrows-alt-h.svg' },
    pieceLength: { title: 'طول القطعة', instructions: 'قيسي من أعلى نقطة في الكتف إلى الطول المرغوب للقطعة (بلوزة، فستان، إلخ).', icon: 'https://api.iconify.design/la:ruler-vertical.svg' },
    sleeveLength: { title: 'طول الكم', instructions: 'قيسي من عظمة الكتف إلى الطول المرغوب للكم، مع ثني المرفق قليلاً.', icon: 'https://api.iconify.design/material-symbols:straighten-outline.svg' },
    armCircumference: { title: 'محيط الذراع', instructions: 'مرري شريط القياس حول أعرض جزء في أعلى الذراع.', icon: 'https://api.iconify.design/mdi:arm-flex-outline.svg' },
    inlegLength: { title: 'طول الساق الداخلي', instructions: 'قيسي من أعلى نقطة في الفخذ من الداخل وحتى الطول المطلوب للبنطال.', icon: 'https://api.iconify.design/ph:ruler-duotone.svg' },
    waistToFloor: { title: 'الطول من الخصر للأرض', instructions: 'قيسي من خط الخصر الطبيعي إلى الأرض من الجانب.', icon: 'https://api.iconify.design/mdi:human-male-height.svg' },
    shoulderToCrotch: { title: 'طول الجذع', instructions: 'قيسي من منتصف الكتف، مروراً بين الساقين، وحتى نفس النقطة على الظهر.', icon: 'https://api.iconify.design/mdi:vector-polyline.svg' },
  };

  validationMessages = computed(() => {
    const messages: { [key: string]: { message: string, type: 'warning' | 'info' } } = {};
    const m = this.measurements();
    const isRequired = (key: keyof Measurements) => this.isRequired(key);

    // --- Warnings for potentially incorrect measurements ---
    if (isRequired('waist') && isRequired('bust') && m.waist >= m.bust) {
      messages['waist'] = { message: 'الخصر يبدو أكبر من الصدر أو يساويه. هذا قد يكون صحيحاً لبعض أشكال الجسم (كالتفاحة)، يرجى التأكد من القياس.', type: 'warning' };
    }
    if (isRequired('waist') && isRequired('hips') && m.waist >= m.hips && !messages['waist']) { // Avoid overriding previous waist message
      messages['waist'] = { message: 'الخصر أكبر من الأرداف أو يساويه. يرجى التأكد من القياس.', type: 'warning' };
    }
    if (isRequired('shoulderWidth') && isRequired('bust') && m.shoulderWidth >= m.bust / 2) {
      messages['shoulderWidth'] = { message: 'عرض الكتف يبدو كبيراً جداً بالنسبة للصدر. تأكد من القياس بين عظمتي الكتف.', type: 'warning' };
    }
    if (isRequired('inlegLength') && isRequired('waistToFloor') && m.inlegLength >= m.waistToFloor) {
      messages['inlegLength'] = { message: 'طول الساق الداخلي يجب أن يكون أقل من الطول الكلي من الخصر للأرض.', type: 'warning' };
    }
    if (isRequired('armCircumference') && isRequired('sleeveLength') && m.armCircumference > m.sleeveLength) {
      messages['armCircumference'] = { message: 'محيط الذراع لا ينبغي أن يكون أكبر من طول الكم.', type: 'warning' };
    }
    if (isRequired('sleevePuffRatio') && m.sleevePuffRatio && (m.sleevePuffRatio < 1 || m.sleevePuffRatio > 3)) {
      messages['sleevePuffRatio'] = { message: 'النسبة المثالية للكشكشة تكون بين 1 و 3.', type: 'warning' };
    }

    // --- Informational messages about body shape ---
    if (isRequired('hips') && isRequired('bust') && !messages['hips'] && !messages['bust']) {
        const ratio = m.hips / m.bust;
        if (ratio > 1.05) { // Hips significantly larger than bust -> Pear shape
            messages['hips'] = { message: 'محيط الأرداف أكبر من الصدر، هذا يلائم شكل الجسم الكمثري.', type: 'info' };
        } else if (ratio < 0.95) { // Bust significantly larger than hips -> Inverted triangle
            messages['hips'] = { message: 'محيط الأرداف أصغر من الصدر، هذا يلائم شكل المثلث المقلوب.', type: 'info' };
        } else if (m.bust > 80 && m.hips > 80) { // Check for hourglass only if measurements are reasonable
             const waistRatio = m.waist / ((m.bust + m.hips) / 2);
             if (waistRatio < 0.8 && !messages['waist']) {
                messages['waist'] = { message: 'الخصر محدد بشكل واضح مقارنة بالصدر والأرداف، هذا يلائم شكل الساعة الرملية.', type: 'info' };
             }
        }
    }

    return messages;
  });

  private womanStandardSizes: StandardSize[] = [
    { name: 'XS', numericSize: '34', measurements: { bust: 82, waist: 64, hips: 90, shoulderWidth: 38, pieceLength: 58, sleeveLength: 57, armCircumference: 26, inlegLength: 77, waistToFloor: 104, shoulderToCrotch: 73, sleevePuffRatio: 1.5, neckCircumference: 35 }},
    { name: 'S', numericSize: '36', measurements: { bust: 86, waist: 68, hips: 94, shoulderWidth: 39, pieceLength: 59, sleeveLength: 58, armCircumference: 28, inlegLength: 78, waistToFloor: 105, shoulderToCrotch: 75, sleevePuffRatio: 1.5, neckCircumference: 36 }},
    { name: 'M', numericSize: '38', measurements: { bust: 90, waist: 72, hips: 98, shoulderWidth: 40, pieceLength: 60, sleeveLength: 59, armCircumference: 30, inlegLength: 78, waistToFloor: 106, shoulderToCrotch: 76, sleevePuffRatio: 1.5, neckCircumference: 37 }},
    { name: 'L', numericSize: '40', measurements: { bust: 94, waist: 76, hips: 102, shoulderWidth: 41, pieceLength: 61, sleeveLength: 60, armCircumference: 32, inlegLength: 79, waistToFloor: 107, shoulderToCrotch: 78, sleevePuffRatio: 1.5, neckCircumference: 38 }},
    { name: 'XL', numericSize: '42', measurements: { bust: 100, waist: 82, hips: 108, shoulderWidth: 42, pieceLength: 62, sleeveLength: 60, armCircumference: 34, inlegLength: 79, waistToFloor: 108, shoulderToCrotch: 80, sleevePuffRatio: 1.5, neckCircumference: 39 }},
    { name: 'XXL', numericSize: '44', measurements: { bust: 106, waist: 88, hips: 114, shoulderWidth: 43, pieceLength: 63, sleeveLength: 61, armCircumference: 36, inlegLength: 80, waistToFloor: 109, shoulderToCrotch: 82, sleevePuffRatio: 1.5, neckCircumference: 40 }},
    { name: '3XL', numericSize: '46', measurements: { bust: 112, waist: 94, hips: 120, shoulderWidth: 44, pieceLength: 64, sleeveLength: 61, armCircumference: 38, inlegLength: 80, waistToFloor: 110, shoulderToCrotch: 83, sleevePuffRatio: 1.5, neckCircumference: 41 }},
  ];

  private manStandardSizes: StandardSize[] = [
    { name: 'S', numericSize: '46', measurements: { bust: 92, waist: 80, hips: 96, shoulderWidth: 44, pieceLength: 70, sleeveLength: 63, armCircumference: 32, inlegLength: 81, waistToFloor: 108, shoulderToCrotch: 82, sleevePuffRatio: 1.5, neckCircumference: 39 }},
    { name: 'M', numericSize: '48', measurements: { bust: 96, waist: 84, hips: 100, shoulderWidth: 45, pieceLength: 72, sleeveLength: 64, armCircumference: 34, inlegLength: 82, waistToFloor: 109, shoulderToCrotch: 84, sleevePuffRatio: 1.5, neckCircumference: 40 }},
    { name: 'L', numericSize: '50', measurements: { bust: 100, waist: 88, hips: 104, shoulderWidth: 46, pieceLength: 74, sleeveLength: 65, armCircumference: 36, inlegLength: 83, waistToFloor: 110, shoulderToCrotch: 86, sleevePuffRatio: 1.5, neckCircumference: 41 }},
    { name: 'XL', numericSize: '52', measurements: { bust: 104, waist: 92, hips: 108, shoulderWidth: 47, pieceLength: 76, sleeveLength: 66, armCircumference: 38, inlegLength: 84, waistToFloor: 111, shoulderToCrotch: 88, sleevePuffRatio: 1.5, neckCircumference: 42 }},
    { name: 'XXL', numericSize: '54', measurements: { bust: 108, waist: 96, hips: 112, shoulderWidth: 48, pieceLength: 78, sleeveLength: 67, armCircumference: 40, inlegLength: 85, waistToFloor: 112, shoulderToCrotch: 90, sleevePuffRatio: 1.5, neckCircumference: 43 }},
    { name: '3XL', numericSize: '56', measurements: { bust: 112, waist: 100, hips: 116, shoulderWidth: 49, pieceLength: 80, sleeveLength: 68, armCircumference: 42, inlegLength: 86, waistToFloor: 113, shoulderToCrotch: 91, sleevePuffRatio: 1.5, neckCircumference: 44 }},
  ];

  private childStandardSizes: StandardSize[] = [
    { name: 'سنة', numericSize: '1', measurements: { bust: 50, waist: 49, hips: 52, shoulderWidth: 22, pieceLength: 36, sleeveLength: 28, armCircumference: 17, inlegLength: 30, waistToFloor: 48, shoulderToCrotch: 42, sleevePuffRatio: 1.5, neckCircumference: 25 }},
    { name: 'سنتان', numericSize: '2', measurements: { bust: 52, waist: 50, hips: 54, shoulderWidth: 23, pieceLength: 40, sleeveLength: 32, armCircumference: 18, inlegLength: 34, waistToFloor: 53, shoulderToCrotch: 44, sleevePuffRatio: 1.5, neckCircumference: 26 }},
    { name: '4 سنوات', numericSize: '4', measurements: { bust: 56, waist: 53, hips: 58, shoulderWidth: 25, pieceLength: 46, sleeveLength: 38, armCircumference: 19, inlegLength: 43, waistToFloor: 63, shoulderToCrotch: 48, sleevePuffRatio: 1.5, neckCircumference: 27 }},
    { name: '6 سنوات', numericSize: '6', measurements: { bust: 60, waist: 56, hips: 63, shoulderWidth: 27, pieceLength: 52, sleeveLength: 43, armCircumference: 20, inlegLength: 52, waistToFloor: 73, shoulderToCrotch: 52, sleevePuffRatio: 1.5, neckCircumference: 28 }},
    { name: '8 سنوات', numericSize: '8', measurements: { bust: 66, waist: 59, hips: 68, shoulderWidth: 29, pieceLength: 58, sleeveLength: 48, armCircumference: 22, inlegLength: 60, waistToFloor: 83, shoulderToCrotch: 56, sleevePuffRatio: 1.5, neckCircumference: 30 }},
    { name: '10 سنوات', numericSize: '10', measurements: { bust: 72, waist: 62, hips: 74, shoulderWidth: 31, pieceLength: 64, sleeveLength: 52, armCircumference: 24, inlegLength: 67, waistToFloor: 91, shoulderToCrotch: 60, sleevePuffRatio: 1.5, neckCircumference: 32 }},
    { name: '12 سنة', numericSize: '12', measurements: { bust: 78, waist: 65, hips: 80, shoulderWidth: 33, pieceLength: 70, sleeveLength: 56, armCircumference: 26, inlegLength: 73, waistToFloor: 98, shoulderToCrotch: 64, sleevePuffRatio: 1.5, neckCircumference: 33 }},
    { name: '14 سنة', numericSize: '14', measurements: { bust: 84, waist: 68, hips: 86, shoulderWidth: 35, pieceLength: 76, sleeveLength: 59, armCircumference: 28, inlegLength: 78, waistToFloor: 104, shoulderToCrotch: 68, sleevePuffRatio: 1.5, neckCircumference: 34 }},
  ];

  standardSizes = computed<StandardSize[]>(() => {
    switch(this.category()) {
      case 'child': return this.childStandardSizes;
      case 'man': return this.manStandardSizes;
      case 'woman': return this.womanStandardSizes;
      default: return this.womanStandardSizes;
    }
  });

  setTab(tab: 'standard' | 'custom'): void {
    this.activeTab.set(tab);
  }

  setUnit(unit: Unit): void {
    this.unit.set(unit);
  }

  getDisplayValue(key: keyof Measurements): number {
    const valueInCm = (this.measurements() as any)[key] || 0;
    if (key === 'sleevePuffRatio') return valueInCm; // Ratio is unitless
    const displayValue = this.unit() === 'in' ? valueInCm / 2.54 : valueInCm;
    // Return with 2 decimal places for inches, 1 for cm
    return parseFloat(displayValue.toFixed(this.unit() === 'in' ? 2 : 1));
  }
  
  getStandardDisplayValue(size: StandardSize, key: keyof Measurements): string {
     const valueInCm = (size.measurements as any)[key] || 0;
     if (key === 'sleevePuffRatio') return valueInCm.toFixed(1);
     const displayValue = this.unit() === 'in' ? valueInCm / 2.54 : valueInCm;
     return displayValue.toFixed(this.unit() === 'in' ? 2 : 1);
  }

  selectStandardSize(size: StandardSize): void {
    this.measurements.update(m => ({...m, ...size.measurements}));
    this.selectedStandardSize.set(size);
    this.setTab('custom');
  }

  updateMeasurement(field: keyof Measurements, value: string): void {
    const numericValue = parseFloat(value) || 0;
    const valueInCm = this.unit() === 'in' && field !== 'sleevePuffRatio' ? numericValue * 2.54 : numericValue;

    this.measurements.update(m => ({ ...m, [field]: valueInCm }));
    this.selectedStandardSize.set(null); // Invalidate standard size on custom edit
  }
  
  isRequired(measurementKey: keyof Measurements): boolean {
    return this.requiredMeasurementsKeys().includes(measurementKey);
  }

  submitMeasurements(): void {
    this.measurementsReady.emit(this.measurements());
  }

  submitSearch(): void {
    const model = this.model();
    const modelName = model.name;
    const lastSelectedSize = this.selectedStandardSize();

    let fullQuery: string;

    // Special case for children with a standard size selected
    if (model.category === 'child' && lastSelectedSize) {
      const childAge = lastSelectedSize.name; // e.g., "سنة", "5 سنوات"
      const keywords = 'باترون مفصل';
      fullQuery = `${modelName} ${childAge} ${keywords}`;
    } else {
      // Default logic for all other cases (men, women, or children with custom measurements)
      const categoryName = {
        'woman': 'نسائي',
        'man': 'رجالي',
        'child': 'أطفال'
      }[model.category];

      let sizeQueryPart = '';
      if (lastSelectedSize) {
        // This part will only run for men/women now
        sizeQueryPart = `مقاس ${lastSelectedSize.name} (${lastSelectedSize.numericSize})`;
      } else {
        // This part will run for custom measurements for all categories
        const measurements = this.measurements();
        const requiredMeasurements = model.requiredMeasurements;
        sizeQueryPart = requiredMeasurements
          .slice(0, 3) // Take the first 3 most important measurements for a cleaner query
          .map(key => {
            const label = this.measurementLabels[key];
            const value = measurements[key];
            if (value !== undefined) {
              return `${label} ${value}سم`;
            }
            return '';
          })
          .filter(Boolean)
          .join(' ');
      }

      const keywords = 'باترون جاهز';
      fullQuery = `${modelName} ${categoryName} ${sizeQueryPart} ${keywords}`;
    }

    const encodedQuery = encodeURIComponent(fullQuery);
    const googleSearchUrl = `https://www.google.com/search?q=${encodedQuery}`;
    window.open(googleSearchUrl, '_blank');
  }
}