import { Injectable } from '@angular/core';
import { Measurements, PatternData, PatternModel, SvgPath, Category, Unit } from '../models/pattern.model';

interface PatternPiece {
  paths: SvgPath[];
  width: number;
  height: number;
}

interface BodiceResult {
  piece: PatternPiece;
  armholeCurveLength: number;
}


/**
 * A utility class to programmatically build SVG path data strings.
 * This provides a cleaner and more maintainable way to create complex shapes
 * compared to manual string concatenation.
 */
class PathBuilder {
  private d: string[] = [];

  moveTo(x: number, y: number): this {
    this.d.push(`M ${x} ${y}`);
    return this;
  }

  lineTo(x: number, y: number): this {
    this.d.push(`L ${x} ${y}`);
    return this;
  }

  arcTo(rx: number, ry: number, xAxisRotation: number, largeArcFlag: number, sweepFlag: number, x: number, y: number): this {
    this.d.push(`A ${rx} ${ry} ${xAxisRotation} ${largeArcFlag} ${sweepFlag} ${x} ${y}`);
    return this;
  }

  cubicCurveTo(x1: number, y1: number, x2: number, y2: number, x: number, y: number): this {
    this.d.push(`C ${x1} ${y1}, ${x2} ${y2}, ${x} ${y}`);
    return this;
  }

  quadraticCurveTo(x1: number, y1: number, x: number, y: number): this {
    this.d.push(`Q ${x1} ${y1}, ${x} ${y}`);
    return this;
  }

  closePath(): this {
    this.d.push('Z');
    return this;
  }

  build(): string {
    return this.d.join(' ');
  }
}


@Injectable({
  providedIn: 'root',
})
export class PatternService {
  private scale = 10; // Increased scale for higher precision
  
  generatePattern(model: PatternModel, measurements: Measurements, options?: { showMeasurements?: boolean; unit?: Unit }): PatternData {
    const allPaths: SvgPath[] = [];
    let currentX = 0;
    let maxHeight = 0;
    const padding = 10 * this.scale;
    
    let totalArmholeLength = 0;
    const bodiceOptions = { showMeasurements: options?.showMeasurements, isDarted: model.id.includes('darted'), unit: options?.unit };

    // --- Generator for specific, image-based patterns ---
    const imageBasedPatterns: { [id: string]: () => PatternPiece[] } = {
        'w-zip-polo-image': () => this._generateZipPoloFromImage(),
        'm-hoodie-unisex-image': () => this._generateUnisexHoodieFromImage(),
        'w-lab-coat-image': () => this._generateLabCoatFromImage(),
        'm-tshirt-adult-image': () => this._generateTshirtFromImage(),
        'm-social-pants-image': () => this._generateMensSocialPantsFromImage(),
    };

    if (imageBasedPatterns[model.id]) {
        const pieces = imageBasedPatterns[model.id]();
        for (const piece of pieces) {
            this._offsetPaths(piece.paths, currentX, 0);
            allPaths.push(...piece.paths);
            currentX += piece.width + padding;
            maxHeight = Math.max(maxHeight, piece.height);
        }
        return { paths: allPaths, width: currentX - padding, height: maxHeight + padding };
    }

    // --- COMPLEX SYSTEM GENERATORS (override standard flow) ---
    if (model.sleeveType === 'kimono') {
        const kimonoPieces = this._generateKimono(measurements);
        for(const piece of kimonoPieces) {
          this._offsetPaths(piece.paths, currentX, 0);
          allPaths.push(...piece.paths);
          currentX += piece.width + padding;
          maxHeight = Math.max(maxHeight, piece.height);
        }
        return { paths: allPaths, width: currentX, height: maxHeight + padding };
    } 
    if (model.sleeveType === 'raglan') {
        const raglanPieces = this._generateRaglanPieces(measurements, model.category, options);
        for (const piece of raglanPieces) {
             this._offsetPaths(piece.paths, currentX, 0);
             allPaths.push(...piece.paths);
             currentX += piece.width + padding;
             maxHeight = Math.max(maxHeight, piece.height);
        }
        return { paths: allPaths, width: currentX, height: maxHeight + padding };
    }
    
    // --- STANDARD FACTORY FLOW (Body -> Sleeve -> Collar) ---
    
    // 1. Generate Main Body Pieces
    if (model.id.includes('bodice') || model.id.includes('dress') || model.id.includes('shirt') || model.id.includes('jacket') || model.id.includes('blouse') || model.id.includes('jumpsuit') || model.id.includes('abaya') || model.id.includes('cardigan') || model.id.includes('polo') || model.id.includes('hoodie') || model.id.includes('thobe') || model.id.includes('pajamas') || model.id.includes('coat') || model.id.includes('robe')) {
        const frontResult = this._generateBodice(measurements, true, model.category, bodiceOptions);
        this._offsetPaths(frontResult.piece.paths, currentX, 0);
        allPaths.push(...frontResult.piece.paths);
        currentX += frontResult.piece.width + padding;
        maxHeight = Math.max(maxHeight, frontResult.piece.height);
        totalArmholeLength += frontResult.armholeCurveLength;

        const backResult = this._generateBodice(measurements, false, model.category, bodiceOptions);
        this._offsetPaths(backResult.piece.paths, currentX, 0);
        allPaths.push(...backResult.piece.paths);
        currentX += backResult.piece.width + padding;
        maxHeight = Math.max(maxHeight, backResult.piece.height);
        totalArmholeLength += backResult.armholeCurveLength;
    } else if (model.id.includes('skirt')) {
        let skirtPiece: PatternPiece;
        if (model.id.includes('circle')) {
            const type = model.id.includes('double') ? 'double' : 'full';
            skirtPiece = this._generateCircleSkirt(measurements, type, options);
        } else if (model.id.includes('pleated')) {
            skirtPiece = this._generatePleatedSkirt(measurements);
        } else {
            skirtPiece = this._generateSkirt(measurements, model.category, bodiceOptions);
        }
        this._offsetPaths(skirtPiece.paths, currentX, 0);
        allPaths.push(...skirtPiece.paths);
        currentX += skirtPiece.width + padding;
        maxHeight = Math.max(maxHeight, skirtPiece.height);
    }
    
    if (model.id.includes('pants') || model.id.includes('jumpsuit') || model.id.includes('shorts') || model.id.includes('pajamas') || model.id.includes('overalls') || model.id.includes('sweatpants')) {
        const frontPants = this._generatePants(measurements, true, model.category, options);
        this._offsetPaths(frontPants.paths, currentX, 0);
        allPaths.push(...frontPants.paths);
        currentX += frontPants.width + padding;
        maxHeight = Math.max(maxHeight, frontPants.height);

        const backPants = this._generatePants(measurements, false, model.category, options);
        this._offsetPaths(backPants.paths, currentX, 0);
        allPaths.push(...backPants.paths);
        currentX += backPants.width + padding;
        maxHeight = Math.max(maxHeight, backPants.height);
    }


    // 2. Generate Sleeve Piece (if requested and applicable)
    if (model.sleeveType && totalArmholeLength > 0) {
        let sleevePiece: PatternPiece | null = null;
        switch(model.sleeveType) {
            case 'basic':
            case 'puff':
            case 'darted':
                sleevePiece = this._generateSleeve(measurements, totalArmholeLength, model.sleeveType, options);
                break;
            case 'twopiece':
                const sleevePieces = this._generateTwoPieceSleeve(measurements, totalArmholeLength, options);
                this._offsetPaths(sleevePieces[0].paths, currentX, 0);
                allPaths.push(...sleevePieces[0].paths);
                currentX += sleevePieces[0].width + padding;
                maxHeight = Math.max(maxHeight, sleevePieces[0].height);
                
                this._offsetPaths(sleevePieces[1].paths, currentX, 0);
                allPaths.push(...sleevePieces[1].paths);
                currentX += sleevePieces[1].width + padding;
                maxHeight = Math.max(maxHeight, sleevePieces[1].height);
                break;
        }

        if(sleevePiece) {
            this._offsetPaths(sleevePiece.paths, currentX, 0);
            allPaths.push(...sleevePiece.paths);
            currentX += sleevePiece.width + padding;
            maxHeight = Math.max(maxHeight, sleevePiece.height);
        }
    }
    
    // 3. Generate Collar Piece (if requested)
    if (model.collarType && measurements.neckCircumference) {
        const collarPiece = this._generateCollar(model.collarType, measurements);
        if (collarPiece) {
            this._offsetPaths(collarPiece.paths, currentX, 0);
            allPaths.push(...collarPiece.paths);
            currentX += collarPiece.width + padding;
            maxHeight = Math.max(maxHeight, collarPiece.height);
        }
    }

    return {
      paths: allPaths,
      width: currentX,
      height: maxHeight + padding,
    };
  }
  
  private _offsetPaths(paths: SvgPath[], offsetX: number, offsetY: number): void {
      for(const path of paths) {
          if (path.d) {
             path.d = path.d.replace(/([MmLlCcQqAa])([^MmLlCcQqAa]+)/g, (match, command, coords) => {
                const points = coords.trim().split(/[\s,]+/).map(parseFloat);
                let transformed = '';
                if (command.toUpperCase() === 'A') {
                    // For Arc command, only the last two coordinates (x, y) are translated
                    for (let i = 0; i < points.length - 2; i++) {
                        transformed += `${points[i]} `;
                    }
                    transformed += `${points[points.length - 2] + offsetX} ${points[points.length - 1] + offsetY} `;
                } else {
                    for (let i = 0; i < points.length; i += 2) {
                       const newX = points[i] + offsetX;
                       const newY = points[i+1] + offsetY;
                       transformed += `${newX} ${newY} `;
                    }
                }
                return `${command} ${transformed.trim()}`;
             });
          }
          if (path.x !== undefined) path.x += offsetX;
          if (path.y !== undefined) path.y += offsetY;
      }
  }

  private _generateBodice(measurements: Measurements, isFront: boolean, category: Category, options?: { showMeasurements?: boolean; isDarted?: boolean; unit?: Unit }): BodiceResult {
    const { bust, waist, hips, shoulderWidth, pieceLength } = measurements;
    const scale = this.scale;
    const paths: SvgPath[] = [];

    // Calculations based on quarter measurements with ease
    const bustEase = category === 'man' ? 2.5 : 2;
    const waistEase = 2.5;
    const hipsEase = category === 'man' ? 2 : 1.5;

    const finalQuarterBust = (bust / 4) + bustEase;
    const finalQuarterWaist = (waist / 4) + waistEase;
    const finalQuarterHips = (hips / 4) + hipsEase;
    const waistReduction = finalQuarterBust - finalQuarterWaist;

    // Vertical key points
    const backNeckDrop = 2;
    const frontNeckDrop = isFront ? (bust / 12) + 1 : backNeckDrop;
    const armholeDepth = (bust / 10) + (category === 'woman' ? 10.5 : 12);
    const waistline = category === 'child' ? 35 : 42; // Standard back-waist length
    const hipLine = waistline + (category === 'child' ? 15 : 20); // Standard hip depth

    // Horizontal key points
    const neckWidth = (bust / 20) + 2;
    const shoulderSlope = category === 'child' ? 3 : 4.5;

    // --- NEW: Professional Back/Chest Width Calculations ---
    const backWidth = (bust / 8) + 5.5; // Standard formula for back width
    const chestWidth = (bust / 4) - 4; // Standard formula for front chest width
    
    // Define all points for the pattern piece
    const p = {
      neckTop: { x: neckWidth, y: 0 },
      shoulderTip: { x: shoulderWidth / 2, y: shoulderSlope },
      neckDrop: { x: 0, y: isFront ? frontNeckDrop : backNeckDrop },
      bustSide: { x: finalQuarterBust, y: armholeDepth },
      waistCenter: { x: 0, y: waistline },
      waistSide: { x: finalQuarterWaist, y: waistline },
      hipCenter: { x: 0, y: hipLine},
      hipSide: { x: finalQuarterHips, y: hipLine},
      hemCenter: { x: 0, y: pieceLength },
      hemSide: { x: finalQuarterHips, y: pieceLength },
      armholeLandmark: { x: isFront ? chestWidth : backWidth, y: armholeDepth }
    };

    // --- REFINED NECKLINE CURVE CONTROL POINTS ---
    const neckCurveC1 = { x: p.neckDrop.x + (p.neckTop.x * 0.55), y: p.neckDrop.y };
    const neckCurveC2 = { x: p.neckTop.x * 0.9, y: p.neckTop.y + (p.neckDrop.y * 0.55) };

    // --- RE-ENGINEERED ARMHOLE CURVE CONTROL POINTS ---
    const armholeHeight = p.bustSide.y - p.shoulderTip.y;
    // C1 controls the top part of the curve, near the shoulder.
    const armholeC1 = {
        x: p.shoulderTip.x - (isFront ? 2.5 : 0.75), // Deeper curve start for front
        y: p.shoulderTip.y + armholeHeight * 0.35 // Position C1 lower to flatten the top of the curve
    };
    // C2 controls the bottom part, creating the "scoop". This creates the major front/back difference.
    const armholeC2 = {
        x: isFront 
           ? p.armholeLandmark.x + (p.bustSide.x - p.armholeLandmark.x) * 0.2 // A bit more room than 0.1
           : p.armholeLandmark.x + (p.bustSide.x - p.armholeLandmark.x) * 0.7, // A bit shallower than 0.8
        y: p.bustSide.y - armholeHeight * 0.30 // Position C2 higher to tighten the bottom scoop
    };

    // --- More robust side seam curve calculation using two chained bezier curves ---
    const waistHeight = p.waistSide.y - p.bustSide.y;
    const hipHeight = p.hipSide.y - p.waistSide.y;
    
    // Control points for the curve from bust to waist
    const bustToWaistC1 = { x: p.bustSide.x, y: p.bustSide.y + waistHeight * 0.4 };
    const bustToWaistC2 = { x: p.waistSide.x, y: p.waistSide.y - waistHeight * 0.6 };

    // Control points for the curve from waist to hip
    const waistToHipC1 = { x: p.waistSide.x, y: p.waistSide.y + hipHeight * 0.6 };
    const waistToHipC2 = { x: p.hipSide.x, y: p.hipSide.y - hipHeight * 0.4 };
    
    const mainPath = new PathBuilder()
        .moveTo(p.hemCenter.x * scale, p.hemCenter.y * scale)
        .lineTo(p.waistCenter.x * scale, p.waistCenter.y * scale)
        .lineTo(p.neckDrop.x * scale, p.neckDrop.y * scale)
        .cubicCurveTo(neckCurveC1.x * scale, neckCurveC1.y * scale, neckCurveC2.x * scale, neckCurveC2.y * scale, p.neckTop.x * scale, p.neckTop.y * scale)
        .lineTo(p.shoulderTip.x * scale, p.shoulderTip.y * scale)
        .cubicCurveTo(armholeC1.x * scale, armholeC1.y * scale, armholeC2.x * scale, armholeC2.y * scale, p.bustSide.x * scale, p.bustSide.y * scale)
        .cubicCurveTo(bustToWaistC1.x * scale, bustToWaistC1.y * scale, bustToWaistC2.x * scale, bustToWaistC2.y * scale, p.waistSide.x * scale, p.waistSide.y * scale)
        .cubicCurveTo(waistToHipC1.x * scale, waistToHipC1.y * scale, waistToHipC2.x * scale, waistToHipC2.y * scale, p.hipSide.x * scale, p.hipSide.y * scale)
        .lineTo(p.hemSide.x * scale, p.hemSide.y * scale)
        .closePath()
        .build();
        
    paths.push({ d: mainPath, class: 'stroke-red-600 fill-red-500/10 stroke-2' });
    
    // --- Calculate precise armhole length using Bezier.js ---
    let armholeCurveLength: number;
    const BezierConstructor = (window as any).Bezier;

    if (typeof BezierConstructor === 'function') {
      try {
        const armholeCurve = new BezierConstructor(
          p.shoulderTip.x, p.shoulderTip.y,
          armholeC1.x, armholeC1.y,
          armholeC2.x, armholeC2.y,
          p.bustSide.x, p.bustSide.y
        );
        armholeCurveLength = armholeCurve.length();

        // --- ADD ARMHOLE NOTCHES ---
        const notchPath = (point: {x:number, y:number}, normal: {x:number, y:number}, length = 0.5 * scale) => {
            const p1 = { x: (point.x * scale) - (normal.x * length), y: (point.y * scale) - (normal.y * length) };
            const p2 = { x: (point.x * scale) + (normal.x * length), y: (point.y * scale) + (normal.y * length) };
            return `M ${p1.x} ${p1.y} L ${p2.x} ${p2.y}`;
        };
        const notchClass = 'stroke-red-800 stroke-2';

        if (isFront) {
            const t = 0.65; // Position for front notch
            const notchPoint = armholeCurve.get(t);
            const normal = armholeCurve.normal(t);
            paths.push({ d: notchPath(notchPoint, normal), class: notchClass });
        } else { // Back
            const t1 = 0.60;
            const t2 = 0.65;
            const notchPoint1 = armholeCurve.get(t1);
            const normal1 = armholeCurve.normal(t1);
            paths.push({ d: notchPath(notchPoint1, normal1), class: notchClass });
            
            const notchPoint2 = armholeCurve.get(t2);
            const normal2 = armholeCurve.normal(t2);
            paths.push({ d: notchPath(notchPoint2, normal2), class: notchClass });
        }

      } catch (e) {
        console.error("Error instantiating Bezier.js, falling back to approximation.", e);
        armholeCurveLength = this._approximateBezierLength(p.shoulderTip, armholeC1, armholeC2, p.bustSide);
      }
    } else {
      console.warn('Bezier.js library not found. Falling back to armhole length approximation.');
      armholeCurveLength = this._approximateBezierLength(p.shoulderTip, armholeC1, armholeC2, p.bustSide);
    }

    if (options?.showMeasurements) {
        const guidlineClass = 'stroke-slate-400 stroke-1 stroke-dasharray';
        const labelClass = 'fill-slate-600 text-xs';
        const offsetX = finalQuarterBust * scale + 1 * scale; // Position for vertical labels

        // --- Horizontal Guide Lines ---
        const bustLinePath = new PathBuilder().moveTo(0, p.bustSide.y * scale).lineTo(p.bustSide.x * scale, p.bustSide.y * scale).build();
        paths.push({ d: bustLinePath, class: guidlineClass });
        paths.push({ d: '', label: `خط الصدر (${this._formatDim(armholeDepth, options.unit)})`, class: labelClass, x: offsetX, y: p.bustSide.y * scale });

        const waistLinePath = new PathBuilder().moveTo(0, p.waistSide.y * scale).lineTo(p.waistSide.x * scale, p.waistSide.y * scale).build();
        paths.push({ d: waistLinePath, class: guidlineClass });
        paths.push({ d: '', label: `خط الخصر (${this._formatDim(waistline, options.unit)})`, class: labelClass, x: offsetX, y: p.waistSide.y * scale });

        const hipLinePath = new PathBuilder().moveTo(0, p.hipSide.y * scale).lineTo(p.hipSide.x * scale, p.hipSide.y * scale).build();
        paths.push({ d: hipLinePath, class: guidlineClass });
        paths.push({ d: '', label: `خط الأرداف (${this._formatDim(hipLine, options.unit)})`, class: labelClass, x: offsetX, y: p.hipSide.y * scale });

        // --- Vertical Guide Lines ---
        const widthGuideLabel = isFront ? `عرض الصدر (${this._formatDim(chestWidth, options.unit)})` : `عرض الظهر (${this._formatDim(backWidth, options.unit)})`;
        const widthGuidePath = new PathBuilder().moveTo(p.armholeLandmark.x * scale, p.shoulderTip.y * scale).lineTo(p.armholeLandmark.x * scale, p.armholeLandmark.y * scale).build();
        paths.push({ d: widthGuidePath, class: guidlineClass });
        paths.push({ d: '', label: widthGuideLabel, class: labelClass, x: p.armholeLandmark.x * scale - (isFront ? 15 : 12), y: p.shoulderTip.y * scale + 15 });

        // Add Center Front/Back line for clarity
        const centerLinePath = new PathBuilder().moveTo(0, 0).lineTo(0, pieceLength * scale).build();
        paths.push({ d: centerLinePath, class: 'stroke-slate-500 stroke-1' });

        // --- Dimensions ---
        // Horizontal
        paths.push(...this._createDimension(0, p.bustSide.y, p.bustSide.x, p.bustSide.y, 6, finalQuarterBust, options.unit));
        paths.push(...this._createDimension(0, p.waistSide.y, p.waistSide.x, p.waistSide.y, 7, finalQuarterWaist, options.unit));
        paths.push(...this._createDimension(0, p.hipSide.y, p.hipSide.x, p.hipSide.y, 8, finalQuarterHips, options.unit));
        paths.push(...this._createDimension(0, p.neckTop.y, p.neckTop.x, p.neckTop.y, -2.5, neckWidth, options.unit));
        paths.push(...this._createDimension(p.neckTop.x, 0, p.shoulderTip.x, p.shoulderTip.y, -4, shoulderWidth/2, options.unit));
        
        // Vertical
        paths.push(...this._createDimension(0, 0, 0, p.hemCenter.y, -6, pieceLength, options.unit));
        const neckDropDimX = isFront ? -2.5 : p.neckTop.x + 2;
        paths.push(...this._createDimension(0, 0, 0, p.neckDrop.y, neckDropDimX, frontNeckDrop, options.unit));
        paths.push(...this._createDimension(p.shoulderTip.x, 0, p.shoulderTip.x, p.shoulderTip.y, 2, shoulderSlope, options.unit));
    }

    // --- DART IMPLEMENTATION ---
    if (category === 'woman' && options?.isDarted) {
        const dartIntake = Math.max(0, waistReduction - 1.5);
        if (dartIntake > 0) {
            const dartApexX = bust / 10;
            const topDartTipY = armholeDepth + 3;
            const bottomDartTipY = waistline + 12;
            const dartLeg1X = dartApexX - dartIntake / 2;
            const dartLeg2X = dartApexX + dartIntake / 2;
            
            const waistDartPath = new PathBuilder()
                .moveTo(dartApexX * scale, topDartTipY * scale)
                .lineTo(dartLeg1X * scale, waistline * scale)
                .lineTo(dartApexX * scale, bottomDartTipY * scale)
                .lineTo(dartLeg2X * scale, waistline * scale)
                .closePath().build();
            paths.push({ d: waistDartPath, class: 'stroke-red-600 stroke-1' });
        }

        if (isFront) { // Side bust dart for front
            const sideDartIntake = 3;
            const sideDartY = p.bustSide.y - 5;
            const bustApex = { x: bust / 10, y: armholeDepth + 3 };
            const sideDartPath = new PathBuilder()
                .moveTo(p.bustSide.x * scale, (sideDartY - sideDartIntake / 2) * scale)
                .lineTo(bustApex.x * scale, bustApex.y * scale)
                .lineTo(p.bustSide.x * scale, (sideDartY + sideDartIntake / 2) * scale).build();
            paths.push({ d: sideDartPath, class: 'stroke-red-600 stroke-1' });
        } else { // Shoulder dart for back
            const shoulderMidX = (p.neckTop.x + p.shoulderTip.x) / 2;
            const shoulderDartTipY = p.shoulderTip.y + 8;
            const shoulderDartWidth = 1.5;
            const p1x = shoulderMidX - shoulderDartWidth / 2;
            const p2x = shoulderMidX + shoulderDartWidth / 2;
            const p1y = p.neckTop.y + (shoulderSlope * (p1x - p.neckTop.x) / (p.shoulderTip.x - p.neckTop.x));
            const p2y = p.neckTop.y + (shoulderSlope * (p2x - p.neckTop.x) / (p.shoulderTip.x - p.neckTop.x));
            
            const shoulderDartPath = new PathBuilder()
                .moveTo(p1x * scale, p1y * scale)
                .lineTo(shoulderMidX * scale, shoulderDartTipY * scale)
                .lineTo(p2x * scale, p2y * scale).build();
            paths.push({ d: shoulderDartPath, class: 'stroke-red-600 stroke-1' });
        }
    }

    const grainlineX = (finalQuarterBust / 2) * scale;
    const grainlineY1 = 10 * scale;
    const grainlineY2 = (pieceLength - 10) * scale;
    paths.push({ d: `M ${grainlineX},${grainlineY1 - 10} L ${grainlineX},${grainlineY2 + 10} M ${grainlineX-5},${grainlineY1} L ${grainlineX},${grainlineY1-10} L ${grainlineX+5},${grainlineY1} M ${grainlineX-5},${grainlineY2} L ${grainlineX},${grainlineY2+10} L ${grainlineX+5},${grainlineY2}`, class: 'stroke-black stroke-1'});
    
    const labelText = isFront ? 'الأمام' : 'الخلف';
    paths.push({ d: '', class: 'fill-gray-700 text-lg font-bold', label: labelText, x: 3 * scale, y: 5 * scale });
    paths.push({ d: '', class: 'fill-gray-700 text-sm', label: 'على ثنية القماش', x: p.neckDrop.x * scale + 1.5 * scale, y: p.neckDrop.y * scale + 6 * scale });

    const piece = { paths, width: finalQuarterBust * scale + 10 * scale, height: pieceLength * scale };

    return { piece, armholeCurveLength };
  }
  
  private _generateSleeve(measurements: Measurements, armholeLengthCm: number, type: 'basic' | 'puff' | 'darted', options?: { showMeasurements?: boolean; unit?: Unit }): PatternPiece {
    const { sleeveLength, armCircumference, sleevePuffRatio } = measurements;
    const scale = this.scale;

    const baseSleeveCapHeight = armholeLengthCm / 3;
    const bicepWidth = armCircumference + 6;
    const isPuffed = type === 'puff';
    const puffRatio = isPuffed && sleevePuffRatio && sleevePuffRatio > 1 ? sleevePuffRatio : 1;
    const puffedBicep = bicepWidth * puffRatio;
    const halfPuffedBicep = puffedBicep / 2;
    const finalSleeveCapHeight = baseSleeveCapHeight * (isPuffed ? (1 + (puffRatio - 1) * 0.5) : 1);
    
    const wristWidth = armCircumference * 0.8 + 4;
    
    const p = {
      capTop: { x: halfPuffedBicep, y: 0 },
      bicepLeft: { x: 0, y: finalSleeveCapHeight },
      bicepRight: { x: puffedBicep, y: finalSleeveCapHeight },
      hemLeft: { x: (halfPuffedBicep - (wristWidth / 2)), y: sleeveLength },
      hemRight: { x: (halfPuffedBicep + (wristWidth / 2)), y: sleeveLength },
    };

    const cap = {
      back_c1: { x: p.bicepLeft.x + halfPuffedBicep * 0.3, y: p.bicepLeft.y - finalSleeveCapHeight * 1.1 },
      back_c2: { x: p.capTop.x - halfPuffedBicep * 0.6, y: p.capTop.y },
      front_c1: { x: p.capTop.x + halfPuffedBicep * 0.7, y: p.capTop.y },
      front_c2: { x: p.bicepRight.x - halfPuffedBicep * 0.15, y: p.bicepRight.y - finalSleeveCapHeight * 0.9 }
    };

    const sleevePathBuilder = new PathBuilder();

    if (type === 'darted') {
        const elbowBend = 2;
        const elbowY = sleeveLength * 0.6;
        sleevePathBuilder.moveTo(p.hemLeft.x * scale, p.hemLeft.y * scale)
                         .quadraticCurveTo((p.bicepLeft.x - elbowBend) * scale, elbowY * scale, p.bicepLeft.x * scale, p.bicepLeft.y * scale);
    } else {
        sleevePathBuilder.moveTo(p.hemLeft.x * scale, p.hemLeft.y * scale)
                         .lineTo(p.bicepLeft.x * scale, p.bicepLeft.y * scale);
    }

    sleevePathBuilder
      .cubicCurveTo(cap.back_c1.x * scale, cap.back_c1.y * scale, cap.back_c2.x * scale, cap.back_c2.y * scale, p.capTop.x * scale, p.capTop.y * scale)
      .cubicCurveTo(cap.front_c1.x * scale, cap.front_c1.y * scale, cap.front_c2.x * scale, cap.front_c2.y * scale, p.bicepRight.x * scale, p.bicepRight.y * scale)
      .lineTo(p.hemRight.x * scale, p.hemRight.y * scale)
      .closePath();

    const sleevePathD = sleevePathBuilder.build();
    const paths: SvgPath[] = [{ d: sleevePathD, class: 'stroke-purple-600 fill-purple-500/10 stroke-2' }];
    
    const BezierConstructor = (window as any).Bezier;
    const notchClass = 'stroke-purple-800 stroke-2';

    if (typeof BezierConstructor === 'function') {
        const backCurve = new BezierConstructor(p.bicepLeft, cap.back_c1, cap.back_c2, p.capTop);
        const frontCurve = new BezierConstructor(p.capTop, cap.front_c1, cap.front_c2, p.bicepRight);

        const notchOnCurve = (curve: any, t: number, length = 0.5 * scale) => {
            const point = curve.get(t);
            const normal = curve.normal(t);
            const p1 = { x: (point.x * scale) - (normal.x * length), y: (point.y * scale) - (normal.y * length) };
            const p2 = { x: (point.x * scale) + (normal.x * length), y: (point.y * scale) + (normal.y * length) };
            return `M ${p1.x} ${p1.y} L ${p2.x} ${p2.y}`;
        };
        
        // Shoulder notch
        paths.push({ d: notchOnCurve(frontCurve, 0, 0.7 * scale), class: notchClass });

        // Front notch (matches bodice t=0.65 from top)
        paths.push({ d: notchOnCurve(frontCurve, 0.65), class: notchClass });

        // Back notches (matches bodice t=0.60 and t=0.65 from top)
        // backCurve is bottom-to-top, so t must be inverted: 1 - t_bodice
        paths.push({ d: notchOnCurve(backCurve, 1 - 0.60), class: notchClass });
        paths.push({ d: notchOnCurve(backCurve, 1 - 0.65), class: notchClass });
    }

    paths.push({ d: '', label: 'الأمام', class: 'fill-slate-600 text-xs', x: (p.bicepRight.x - 5) * scale, y: (p.bicepRight.y + 3) * scale });
    paths.push({ d: '', label: 'الخلف', class: 'fill-slate-600 text-xs', x: (p.bicepLeft.x + 5) * scale, y: (p.bicepLeft.y + 3) * scale });

    if (type === 'darted') {
        const elbowY = sleeveLength * 0.6;
        const elbowBend = 2;
        const dartIntake = 2.5;
        const dartLength = 12;
        
        const dartSeamCenterX = p.bicepLeft.x - elbowBend;
        const dartSeamCenterY = elbowY;

        const dartTip = { x: dartSeamCenterX + dartLength, y: dartSeamCenterY };
        const dartLeg1 = { x: dartSeamCenterX, y: dartSeamCenterY - dartIntake / 2 };
        const dartLeg2 = { x: dartSeamCenterX, y: dartSeamCenterY + dartIntake / 2 };

        const dartPath = new PathBuilder()
            .moveTo(dartLeg1.x * scale, dartLeg1.y * scale)
            .lineTo(dartTip.x * scale, dartTip.y * scale)
            .lineTo(dartLeg2.x * scale, dartLeg2.y * scale)
            .build();
        paths.push({d: dartPath, class: 'stroke-purple-600 stroke-1'});
    }
    
    if(options?.showMeasurements) {
        const guidlineClass = 'stroke-slate-400 stroke-1 stroke-dasharray';
        const labelClass = 'fill-slate-600 text-xs';

        // Bicep Line
        const bicepLinePath = new PathBuilder().moveTo(p.bicepLeft.x * scale, p.bicepLeft.y * scale).lineTo(p.bicepRight.x * scale, p.bicepRight.y * scale).build();
        paths.push({ d: bicepLinePath, class: guidlineClass });
        paths.push({ d: '', label: 'خط أعلى الذراع', class: labelClass, x: p.bicepRight.x * scale + 5, y: p.bicepRight.y * scale });

        // Hem Line
        const hemLinePath = new PathBuilder().moveTo(p.hemLeft.x * scale, p.hemLeft.y * scale).lineTo(p.hemRight.x * scale, p.hemRight.y * scale).build();
        paths.push({d: hemLinePath, class: guidlineClass });

        // Dimensions
        paths.push(...this._createDimension(p.bicepLeft.x, p.bicepLeft.y, p.bicepRight.x, p.bicepRight.y, 4, puffedBicep, options.unit));
        paths.push(...this._createDimension(p.hemLeft.x, p.hemLeft.y, p.hemRight.x, p.hemLeft.y, 6, wristWidth, options.unit));
        paths.push(...this._createDimension(halfPuffedBicep, 0, halfPuffedBicep, sleeveLength, puffedBicep / 2 + 4, sleeveLength, options.unit));
        paths.push(...this._createDimension(0, 0, 0, finalSleeveCapHeight, -4, finalSleeveCapHeight, options.unit));
    }

    const grainlineX = halfPuffedBicep * scale;
    paths.push({ d: `M ${grainlineX},${10 * scale} L ${grainlineX},${(sleeveLength - 10) * scale}`, class: 'stroke-black stroke-1'});
    paths.push({ d: `M ${grainlineX - 5},${10 * scale} L ${grainlineX},${5 * scale} L ${grainlineX + 5},${10 * scale}`, class: 'stroke-black stroke-1'});
    
    paths.push({ d: '', class: 'fill-gray-700 text-lg font-bold', label: isPuffed ? 'كم منفوخ' : (type === 'darted' ? 'كم تايلور' : 'الكم'), x: (halfPuffedBicep * scale) - 30, y: (finalSleeveCapHeight + 5) * scale });
    
    return { paths, width: puffedBicep * scale + 10 * scale, height: sleeveLength * scale };
  }
  
  private _generateSkirt(measurements: Measurements, category: Category, options?: { showMeasurements?: boolean; isDarted?: boolean; unit?: Unit }): PatternPiece {
      const { waist, hips, pieceLength } = measurements;
      const quarterWaist = waist / 4;
      const quarterHips = hips / 4;
      const waistEase = 1;
      const hipsEase = 1.5;
      const finalQuarterWaist = quarterWaist + waistEase;
      const finalQuarterHips = quarterHips + hipsEase;
      const hipLineDepth = category === 'child' ? 15 : 20;

      const p = {
        waistCenter: { x: 0, y: 0 },
        waistSide: { x: finalQuarterWaist, y: 0 },
        hipSide: { x: finalQuarterHips, y: hipLineDepth },
        hemCenter: { x: 0, y: pieceLength },
        hemSide: { x: finalQuarterHips + 2, y: pieceLength },
      };

      const sideSeamControl1 = { x: p.waistSide.x, y: p.waistSide.y + hipLineDepth * 0.4 };
      const sideSeamControl2 = { x: p.hipSide.x, y: p.hipSide.y - hipLineDepth * 0.4 };

      const skirtPathD = new PathBuilder()
        .moveTo(p.hemCenter.x * this.scale, p.hemCenter.y * this.scale)
        .lineTo(p.waistCenter.x * this.scale, p.waistCenter.y * this.scale)
        .lineTo(p.waistSide.x * this.scale, p.waistSide.y * this.scale)
        .cubicCurveTo(sideSeamControl1.x*this.scale, sideSeamControl1.y*this.scale, sideSeamControl2.x * this.scale, sideSeamControl2.y * this.scale, p.hipSide.x * this.scale, p.hipSide.y * this.scale)
        .lineTo(p.hemSide.x * this.scale, p.hemSide.y * this.scale)
        .closePath()
        .build();
      
      const paths: SvgPath[] = [{ d: skirtPathD, class: 'stroke-green-600 fill-green-500/10 stroke-2' }];

      if (options?.isDarted) {
          const dartIntake = 2.5;
          const dartX = finalQuarterWaist / 2;
          const dartPath = new PathBuilder()
            .moveTo((dartX - dartIntake / 2) * this.scale, 0)
            .lineTo(dartX * this.scale, 12 * this.scale)
            .lineTo((dartX + dartIntake / 2) * this.scale, 0)
            .build();
          paths.push({d: dartPath, class: 'stroke-green-600 stroke-1'});
      }
      
      if(options?.showMeasurements) {
        const guidlineClass = 'stroke-slate-400 stroke-1 stroke-dasharray';
        const labelClass = 'fill-slate-600 text-xs';
        const offsetX = p.hemSide.x * this.scale + 1 * this.scale;

        // Hip Line
        const hipLinePath = new PathBuilder().moveTo(0, p.hipSide.y * this.scale).lineTo(p.hipSide.x * this.scale, p.hipSide.y * this.scale).build();
        paths.push({ d: hipLinePath, class: guidlineClass });
        paths.push({ d: '', label: `خط الأرداف (${this._formatDim(hipLineDepth, options.unit)})`, class: labelClass, x: offsetX, y: p.hipSide.y * this.scale });

        // Center Front/Back Line
        const centerLinePath = new PathBuilder().moveTo(0, 0).lineTo(0, pieceLength * this.scale).build();
        paths.push({ d: centerLinePath, class: 'stroke-slate-500 stroke-1' });

        // Dimensions
        paths.push(...this._createDimension(0, 0, p.waistSide.x, 0, -4, finalQuarterWaist, options.unit));
        paths.push(...this._createDimension(0, hipLineDepth, p.hipSide.x, hipLineDepth, 4, finalQuarterHips, options.unit));
        paths.push(...this._createDimension(0, pieceLength, p.hemSide.x, pieceLength, 6, p.hemSide.x, options.unit));
        paths.push(...this._createDimension(0, 0, 0, pieceLength, -6, pieceLength, options.unit));
      }

      paths.push({ d: '', class: 'fill-gray-700 text-lg font-bold', label: options?.isDarted ? 'تنورة مستقيمة' : 'التنورة', x: 20, y: 40 });
      paths.push({ d: '', class: 'fill-gray-700 text-xs', label: 'على ثنية القماش', x: p.waistCenter.x * this.scale + 5, y: p.waistCenter.y * this.scale + 50 });

      return { paths, width: p.hemSide.x * this.scale + 10 * this.scale, height: pieceLength * this.scale };
  }

  private _generatePants(measurements: Measurements, isFront: boolean, category: Category, options?: { showMeasurements?: boolean; unit?: Unit }): PatternPiece {
    const { waist, hips, waistToFloor, inlegLength } = measurements;
    const scale = this.scale;
    const quarterWaist = waist / 4;
    const quarterHips = hips / 4;
    const crotchDepth = waistToFloor - inlegLength;
    const waistEase = 0.5;
    const hipEase = isFront ? 0.5 : 1.5;
    const crotchExtension = isFront ? (hips / 20) : (hips / 10);
    const centerShift = isFront ? 0 : 1;
    const sideShift = isFront ? 0 : 2;
    const centerWaistRaise = isFront ? 0 : 2.5;
    const crotchDrop = isFront ? 0 : 1;
    const blockWidth = quarterHips + hipEase;

    const p = {
      waistSide: { x: 0, y: centerWaistRaise },
      waistCenter: { x: blockWidth + centerShift, y: isFront ? 0.5 : 0 },
      hipSide: { x: 0, y: crotchDepth * 0.3 + centerWaistRaise },
      hipCenter: { x: blockWidth + centerShift, y: crotchDepth * 0.3 },
      crotchSide: { x: sideShift, y: crotchDepth + centerWaistRaise },
      crotchPoint: { x: blockWidth + centerShift + crotchExtension, y: crotchDepth + crotchDrop },
      hemSide: { x: sideShift + 4, y: waistToFloor },
      hemCenter: { x: blockWidth + centerShift - 4, y: waistToFloor }
    };

    const paths: SvgPath[] = [];
    const crotchCurveC1 = { x: p.crotchPoint.x - crotchExtension * 0.8, y: p.crotchPoint.y };
    const crotchCurveC2 = { x: p.waistCenter.x, y: p.crotchPoint.y - crotchDepth * 0.5 };
    const inseamCurve = { x: (p.crotchPoint.x + p.hemCenter.x) / 2.2, y: p.crotchPoint.y + (p.hemCenter.y - p.crotchPoint.y) * 0.3 };
    const finalQuarterWaist = quarterWaist + waistEase + (isFront || category === 'child' ? 0 : 2.5);
    p.waistCenter.x = p.waistSide.x + finalQuarterWaist;
    
    const pathBuilder = new PathBuilder()
      .moveTo(p.waistSide.x * scale, p.waistSide.y * scale)
      .lineTo(p.hemSide.x * scale, p.hemSide.y * scale)
      .lineTo(p.hemCenter.x * scale, p.hemCenter.y * scale)
      .quadraticCurveTo(inseamCurve.x * scale, inseamCurve.y * scale, p.crotchPoint.x * scale, p.crotchPoint.y * scale)
      .cubicCurveTo(crotchCurveC1.x*scale, crotchCurveC1.y*scale, crotchCurveC2.x*scale, crotchCurveC2.y*scale, p.waistCenter.x*scale, p.waistCenter.y*scale);

    if (!isFront && category !== 'child') {
      const dartWidth = 2.5;
      const dartPos = p.waistSide.x + finalQuarterWaist / 2;
      const dart = {
        leg2: { x: dartPos + dartWidth / 2, y: p.waistSide.y },
        tip: { x: dartPos, y: p.waistSide.y + 12 },
        leg1: { x: dartPos - dartWidth / 2, y: p.waistSide.y },
      };
      pathBuilder.lineTo(dart.leg2.x * scale, dart.leg2.y * scale)
                 .lineTo(dart.tip.x * scale, dart.tip.y * scale)
                 .lineTo(dart.leg1.x * scale, dart.leg1.y * scale);
    }
    
    pathBuilder.lineTo(p.waistSide.x * scale, p.waistSide.y * scale).closePath();
    paths.push({ d: pathBuilder.build(), class: 'stroke-blue-600 fill-blue-500/10 stroke-2' });

    if(options?.showMeasurements) {
        const guidlineClass = 'stroke-slate-400 stroke-1 stroke-dasharray';
        const labelClass = 'fill-slate-600 text-xs';
        const offsetX = p.crotchPoint.x * scale + 1 * scale;

        // Horizontal Guide Lines
        const hipLinePath = new PathBuilder().moveTo(p.hipSide.x * scale, p.hipSide.y * scale).lineTo(p.hipCenter.x * scale, p.hipCenter.y * scale).build();
        paths.push({ d: hipLinePath, class: guidlineClass });
        paths.push({ d: '', label: 'خط الأرداف', class: labelClass, x: offsetX, y: p.hipSide.y * scale });

        const crotchLinePath = new PathBuilder().moveTo(p.crotchSide.x * scale, p.crotchPoint.y * scale).lineTo(p.crotchPoint.x * scale, p.crotchPoint.y * scale).build();
        paths.push({ d: crotchLinePath, class: guidlineClass });
        paths.push({ d: '', label: `خط الحجر (${this._formatDim(crotchDepth, options.unit)})`, class: labelClass, x: offsetX, y: p.crotchPoint.y * scale });

        // Knee Line
        const kneeY = crotchDepth + inlegLength / 2;
        const kneeLinePath = new PathBuilder().moveTo(p.hemSide.x*scale, kneeY*scale).lineTo(p.hemCenter.x*scale, kneeY*scale).build();
        paths.push({d: kneeLinePath, class: guidlineClass});
        paths.push({d: '', label: 'خط الركبة', class: labelClass, x: offsetX, y: kneeY * scale});

        // Dimensions
        paths.push(...this._createDimension(p.waistSide.x, p.waistSide.y, p.waistCenter.x, p.waistCenter.y, -4, finalQuarterWaist, options.unit));
        paths.push(...this._createDimension(p.waistSide.x, p.waistSide.y, p.waistSide.x, p.hemSide.y, -6, waistToFloor, options.unit));
        paths.push(...this._createDimension(p.crotchPoint.x, p.crotchPoint.y, p.crotchPoint.x, p.hemCenter.y, 6, inlegLength, options.unit));
        paths.push(...this._createDimension(p.crotchSide.x, p.crotchPoint.y, p.crotchPoint.x, p.crotchPoint.y, 8, (blockWidth + crotchExtension + sideShift), options.unit));
        paths.push(...this._createDimension(p.hemSide.x, p.hemSide.y, p.hemCenter.x, p.hemSide.y, 10, (p.hemCenter.x - p.hemSide.x), options.unit));
    }

    const grainlineX = (p.hemSide.x + p.hemCenter.x) / 2 * scale;
    paths.push({ d: `M ${grainlineX},${10 * scale} L ${grainlineX},${(waistToFloor - 10) * scale}`, class: 'stroke-black stroke-1'});
    paths.push({ d: '', class: 'fill-gray-700 text-lg font-bold', label: isFront ? 'الأمام' : 'الخلف', x: 20, y: 40 });
    
    return { paths, width: (p.crotchPoint.x + 10) * scale, height: waistToFloor * scale };
  }
  
  // --- COLLAR GENERATORS ---
  private _generateCollar(type: NonNullable<PatternModel['collarType']>, measurements: Measurements): PatternPiece | null {
      switch (type) {
          case 'stand':
              return this._generateStandCollar(measurements);
          case 'mandarin':
              return this._generateMandarinCollar(measurements);
          case 'shawl':
              return this._generateShawlCollar(measurements);
          case 'notch':
              return this._generateNotchCollar(measurements);
          default:
              return null;
      }
  }

  private _generateStandCollar(measurements: Measurements): PatternPiece {
      const { neckCircumference = 40 } = measurements;
      const halfNeck = (neckCircumference / 2) + 0.5; // Ease
      const standHeight = 3.5;
      const collarHeight = 4.5;
      const buttonStand = 2.5;

      const p = {
          cbNeck: { x: 0, y: 0.7 },
          cfNeck: { x: halfNeck, y: 0 },
          cfStandTop: { x: halfNeck + buttonStand, y: standHeight },
          cbStandTop: { x: 0, y: standHeight },
          cbCollarTop: { x: 0, y: standHeight + collarHeight },
          cfCollarTip: { x: halfNeck + buttonStand + 1, y: standHeight + collarHeight - 1 }
      };

      const path = new PathBuilder()
          .moveTo(p.cbNeck.x * this.scale, p.cbNeck.y * this.scale)
          .quadraticCurveTo(halfNeck / 2 * this.scale, 0, p.cfNeck.x * this.scale, p.cfNeck.y * this.scale)
          .lineTo(p.cfStandTop.x * this.scale, p.cfStandTop.y * this.scale)
          .lineTo(p.cfCollarTip.x * this.scale, p.cfCollarTip.y * this.scale)
          .lineTo(p.cbCollarTop.x * this.scale, p.cbCollarTop.y * this.scale)
          .closePath()
          .build();
      
      const standLine = new PathBuilder().moveTo(p.cbStandTop.x * this.scale, p.cbStandTop.y * this.scale).lineTo(p.cfStandTop.x * this.scale, p.cfStandTop.y * this.scale).build();
      
      const paths: SvgPath[] = [
          { d: path, class: 'stroke-orange-600 fill-orange-500/10 stroke-2' },
          { d: standLine, class: 'stroke-orange-600 stroke-1 stroke-dasharray' },
          { d: '', class: 'fill-gray-700 text-lg font-bold', label: 'ياقة قميص', x: 20, y: 40 },
          { d: '', class: 'fill-gray-700 text-xs', label: 'على ثنية القماش', x: p.cbNeck.x * this.scale + 5, y: p.cbNeck.y * this.scale + 40 },
      ];
      
      return { paths, width: (halfNeck + buttonStand + 2) * this.scale, height: (standHeight + collarHeight + 1) * this.scale };
  }

  private _generateMandarinCollar(measurements: Measurements): PatternPiece {
      const { neckCircumference = 40 } = measurements;
      const halfNeck = neckCircumference / 2;
      const height = 3.5;
      const curveRadius = 2;

      const p = {
          cbBottom: { x: 0, y: 0.5 },
          cfBottom: { x: halfNeck, y: 0 },
          cfTop: { x: halfNeck, y: height },
          cbTop: { x: 0, y: height }
      };

      const path = new PathBuilder()
          .moveTo(p.cbBottom.x * this.scale, p.cbBottom.y * this.scale)
          .quadraticCurveTo(halfNeck/2 * this.scale, 0, p.cfBottom.x * this.scale, p.cfBottom.y * this.scale)
          .lineTo((p.cfTop.x - curveRadius) * this.scale, p.cfTop.y * this.scale)
          .arcTo(curveRadius * this.scale, curveRadius * this.scale, 0, 0, 1, p.cfTop.x * this.scale, (p.cfTop.y - curveRadius) * this.scale)
          .lineTo(p.cbTop.x * this.scale, p.cbTop.y * this.scale)
          .closePath()
          .build();
      
      const paths: SvgPath[] = [
          { d: path, class: 'stroke-orange-600 fill-orange-500/10 stroke-2' },
          { d: '', class: 'fill-gray-700 text-lg font-bold', label: 'ياقة ماندرين', x: 20, y: 25 },
          { d: '', class: 'fill-gray-700 text-xs', label: 'على ثنية القماش', x: p.cbBottom.x * this.scale + 5, y: p.cbBottom.y * this.scale + 20 },
      ];
      return { paths, width: (halfNeck + 2) * this.scale, height: (height + 2) * this.scale };
  }

  private _generateShawlCollar(measurements: Measurements): PatternPiece {
    const { neckCircumference = 40, bust = 92 } = measurements;
    const backNeck = (neckCircumference / 2) + 0.5;
    const collarWidthBack = 8;
    const frontDrop = bust / 4; // Approximation

    const p = {
        cbNeck: {x: collarWidthBack, y:0},
        shoulderNeck: {x: 0, y: backNeck},
        frontEnd: {x: collarWidthBack + 2, y: backNeck + frontDrop},
        cbOuter: {x: 0, y:0},
    };
    
    const path = new PathBuilder()
        .moveTo(p.cbNeck.x * this.scale, p.cbNeck.y * this.scale)
        .quadraticCurveTo(p.cbNeck.x*0.8*this.scale, backNeck/2*this.scale, p.shoulderNeck.x*this.scale, p.shoulderNeck.y*this.scale)
        .quadraticCurveTo((p.shoulderNeck.x+p.frontEnd.x)/2*this.scale, (p.shoulderNeck.y+p.frontEnd.y)*0.8*this.scale, p.frontEnd.x*this.scale, p.frontEnd.y*this.scale)
        .lineTo(p.frontEnd.x*this.scale, p.frontEnd.y*this.scale)
        .quadraticCurveTo((p.cbOuter.x + p.frontEnd.x)*0.8*this.scale, backNeck*this.scale, p.cbOuter.x*this.scale, p.cbOuter.y*this.scale)
        .closePath()
        .build();

     const paths: SvgPath[] = [
          { d: path, class: 'stroke-orange-600 fill-orange-500/10 stroke-2' },
          { d: '', class: 'fill-gray-700 text-lg font-bold', label: 'ياقة شال', x: 40, y: 60 },
          { d: '', class: 'fill-gray-700 text-xs', label: 'على ثنية القماش', x: p.cbOuter.x * this.scale + 5, y: p.cbOuter.y * this.scale + 40 },
      ];

      return { paths, width: (collarWidthBack + 4) * this.scale, height: (backNeck + frontDrop + 2) * this.scale };
  }
  
  private _generateNotchCollar(measurements: Measurements): PatternPiece {
    const { neckCircumference = 40 } = measurements;
    const backNeck = (neckCircumference / 2) + 0.5;
    const collarHeight = 8;
    const standHeight = 3;
    const notchAngleOffset = 2;

    const p = {
        cb: { x: 0, y: 0 },
        shoulder: { x: backNeck, y: 0 },
        gorge: { x: backNeck, y: standHeight },
        tip: { x: backNeck + notchAngleOffset, y: collarHeight },
        cbOuter: { x: 0, y: collarHeight },
    };
    
    const path = new PathBuilder()
        .moveTo(p.cb.x * this.scale, p.cb.y * this.scale)
        .lineTo(p.shoulder.x * this.scale, p.shoulder.y * this.scale)
        .lineTo(p.gorge.x * this.scale, p.gorge.y * this.scale)
        .lineTo(p.tip.x * this.scale, p.tip.y * this.scale)
        .lineTo(p.cbOuter.x * this.scale, p.cbOuter.y * this.scale)
        .closePath()
        .build();

    const standLine = `M ${p.cb.x*this.scale},${standHeight*this.scale} L ${p.gorge.x*this.scale},${p.gorge.y*this.scale}`;

    const paths: SvgPath[] = [
          { d: path, class: 'stroke-orange-600 fill-orange-500/10 stroke-2' },
          { d: standLine, class: 'stroke-orange-600 stroke-1 stroke-dasharray' },
          { d: '', class: 'fill-gray-700 text-lg font-bold', label: 'ياقة سفلية', x: 30, y: 45 },
          { d: '', class: 'fill-gray-700 text-xs', label: 'على ثنية القماش', x: p.cb.x * this.scale + 5, y: p.cb.y * this.scale + 40 },
      ];

    return { paths, width: (backNeck + notchAngleOffset + 2) * this.scale, height: (collarHeight + 2) * this.scale };
  }


  // --- NEW ADVANCED GENERATORS ---

  private _generateCircleSkirt(measurements: Measurements, type: 'full' | 'double', options?: { showMeasurements?: boolean; unit?: Unit }): PatternPiece {
    const { waist, pieceLength } = measurements;
    const scale = this.scale;
    const waistCircumference = waist + 2; // Ease
    const radius = type === 'full' ? waistCircumference / (2 * Math.PI) : waistCircumference / (4 * Math.PI);
    const outerRadius = radius + pieceLength;

    const p = {
      waistInner: { x: 0, y: radius },
      waistOuter: { x: radius, y: 0 },
      hemInner: { x: 0, y: outerRadius },
      hemOuter: { x: outerRadius, y: 0 }
    };

    const skirtPathD = new PathBuilder()
        .moveTo(p.waistInner.x * scale, p.waistInner.y * scale)
        .arcTo(radius * scale, radius * scale, 0, 0, 1, p.waistOuter.x * scale, p.waistOuter.y * scale)
        .lineTo(p.hemOuter.x * scale, p.hemOuter.y * scale)
        .arcTo(outerRadius * scale, outerRadius * scale, 0, 0, 0, p.hemInner.x * scale, p.hemInner.y * scale)
        .closePath()
        .build();
    
    const label = type === 'full' ? 'تنورة كلوش' : 'تنورة دوبل كلوش';
    const paths: SvgPath[] = [
      { d: skirtPathD, class: 'stroke-pink-600 fill-pink-500/10 stroke-2' },
      { d: '', class: 'fill-gray-700 text-lg font-bold', label, x: 20, y: 40 },
      { d: '', class: 'fill-gray-700 text-xs', label: 'قص قطعتين على قماش مثني', x: 20, y: 70 }
    ];
    
    if (options?.showMeasurements) {
        const radiusLine = new PathBuilder().moveTo(0,0).lineTo(p.waistOuter.x * scale, p.waistOuter.y * scale).build();
        paths.push({d: radiusLine, class: 'stroke-slate-400 stroke-1 stroke-dasharray'});
        const radiusLabelPath: SvgPath = {
          d: '',
          label: `R=${this._formatDim(radius, options.unit)}`,
          class: 'fill-slate-600 text-xs',
          x: radius * scale * 0.4,
          y: radius * scale * 0.4
        };
        paths.push(radiusLabelPath);
        paths.push(...this._createDimension(radius, 0, outerRadius, 0, -3, pieceLength, options.unit));
    }

    return { paths, width: outerRadius * scale, height: outerRadius * scale };
  }

  private _generatePleatedSkirt(measurements: Measurements): PatternPiece {
    const { waist, pieceLength } = measurements;
    const fabricWidth = waist * 3; // Standard 3x fullness for pleats
    const mainPath = new PathBuilder()
        .moveTo(0, 0).lineTo(fabricWidth * this.scale, 0)
        .lineTo(fabricWidth * this.scale, pieceLength * this.scale)
        .lineTo(0, pieceLength * this.scale).closePath().build();
    const paths: SvgPath[] = [{ d: mainPath, class: 'stroke-green-600 fill-green-500/10 stroke-2' }];
    for (let x = 8; x < fabricWidth; x += 8) { // Add pleat markings every 8cm
        paths.push({ d: `M ${x * this.scale},0 V ${pieceLength * this.scale}`, class: 'stroke-green-800 stroke-1 stroke-dasharray' });
    }
    paths.push({ d: '', class: 'fill-gray-700 text-lg font-bold', label: 'تنورة بكسرات', x: 20, y: 40 });
    return { paths, width: fabricWidth * this.scale, height: pieceLength * this.scale };
  }

  private _generateKimono(measurements: Measurements): PatternPiece[] {
      const { bust, pieceLength, sleeveLength } = measurements;
      const bodyWidth = bust / 2 + 10;
      const sleeveWidth = 35;
      const bodyMainWidth = bodyWidth + 20;

      const bodyPath = new PathBuilder().moveTo(0, 0).lineTo(bodyMainWidth * this.scale, 0).lineTo(bodyMainWidth * this.scale, pieceLength * this.scale).lineTo(0, pieceLength * this.scale).closePath().build();
      const bodyPaths: SvgPath[] = [
        { d: bodyPath, class: 'stroke-cyan-600 fill-cyan-500/10 stroke-2' },
        { d: `M ${(bodyMainWidth / 2) * this.scale},0 L ${(bodyMainWidth / 2) * this.scale},${8 * this.scale}`, class: 'stroke-cyan-800 stroke-1 stroke-dasharray' },
        { d: `M ${(bodyWidth/2) * this.scale},0 L ${(bodyWidth/2) * this.scale},${pieceLength * this.scale}`, class: 'stroke-cyan-800 stroke-1' },
        {d:'', class: 'fill-gray-700 text-sm', label: 'قطعة الجسم الرئيسية', x: 15, y:40}
      ];
      const bodyPiece = { paths: bodyPaths, width: bodyMainWidth * this.scale, height: pieceLength * this.scale};
      
      const sleevePath = new PathBuilder().moveTo(0, 0).lineTo(sleeveWidth * this.scale, 0).lineTo(sleeveWidth * this.scale, sleeveLength * this.scale).lineTo(0, sleeveLength * this.scale).closePath().build();
      const sleevePaths: SvgPath[] = [
        { d: sleevePath, class: 'stroke-cyan-600 fill-cyan-500/10 stroke-2' },
        {d:'', class: 'fill-gray-700 text-sm', label: 'كم (قص 2)', x: 15, y:40}
      ];
      const sleevePiece = { paths: sleevePaths, width: sleeveWidth * this.scale, height: sleeveLength * this.scale};

      return [bodyPiece, sleevePiece];
  }

  private _generateTwoPieceSleeve(measurements: Measurements, armholeLengthCm: number, options?: { showMeasurements?: boolean; unit?: Unit }): PatternPiece[] {
    const { sleeveLength, armCircumference } = measurements;
    const sleeveCapHeight = armholeLengthCm / 3.2; // Slightly shorter for jacket, based on precise length
    const bicep = armholeLengthCm + 6; // Bicep related to precise armhole length
    const wrist = armCircumference * 0.8;
    const overSleeveWidth = bicep * 0.6;
    const underSleeveWidth = bicep * 0.4;
    
    // Upper Sleeve
    const pUpper = { capTop: { x: overSleeveWidth / 2, y: 0 }, capBack: { x: 0, y: sleeveCapHeight }, capFront: { x: overSleeveWidth, y: sleeveCapHeight }, elbowBack: { x: -2, y: sleeveLength / 2 + 3 }, wristBack: { x: 0, y: sleeveLength }, wristFront: { x: overSleeveWidth, y: sleeveLength } };
    const wristTaperUpper = (overSleeveWidth - (wrist * 0.6)) / 2;
    pUpper.wristBack.x += wristTaperUpper; pUpper.wristFront.x -= wristTaperUpper;
    const upperSleevePath = new PathBuilder().moveTo(pUpper.wristBack.x * this.scale, pUpper.wristBack.y * this.scale).lineTo(pUpper.elbowBack.x * this.scale, pUpper.elbowBack.y * this.scale).lineTo(pUpper.capBack.x * this.scale, pUpper.capBack.y * this.scale).quadraticCurveTo(pUpper.capTop.x*this.scale, pUpper.capTop.y*this.scale, pUpper.capFront.x*this.scale, pUpper.capFront.y*this.scale).lineTo(pUpper.wristFront.x * this.scale, pUpper.wristFront.y * this.scale).closePath().build();
    const upperSleevePiece = { paths: [{ d: upperSleevePath, class: 'stroke-indigo-600 fill-indigo-500/10 stroke-2' }, {d:'', class: 'fill-gray-700 text-sm', label: 'كم علوي', x: 15, y:40}], width: overSleeveWidth * this.scale, height: sleeveLength * this.scale};

    // Under Sleeve
    const pUnder = { capBack: { x: 0, y: sleeveCapHeight }, capFront: { x: underSleeveWidth, y: sleeveCapHeight }, wristBack: { x: 0, y: sleeveLength }, wristFront: { x: underSleeveWidth, y: sleeveLength } };
    const wristTaperUnder = (underSleeveWidth - wrist * 0.4) / 2;
    pUnder.wristBack.x += wristTaperUnder; pUnder.wristFront.x -= wristTaperUnder;
    const underSleevePath = new PathBuilder().moveTo(pUnder.wristBack.x * this.scale, pUnder.wristBack.y * this.scale).lineTo(pUnder.capBack.x * this.scale, pUnder.capBack.y * this.scale).quadraticCurveTo(underSleeveWidth/2 * this.scale, (sleeveCapHeight + 2) * this.scale, pUnder.capFront.x * this.scale, pUnder.capFront.y*this.scale).lineTo(pUnder.wristFront.x * this.scale, pUnder.wristFront.y * this.scale).closePath().build();
    const underSleevePiece = { paths: [{ d: underSleevePath, class: 'stroke-indigo-600 fill-indigo-500/10 stroke-2' }, {d:'', class: 'fill-gray-700 text-sm', label: 'كم سفلي', x: 15, y:40}], width: underSleeveWidth * this.scale, height: sleeveLength * this.scale};

    return [upperSleevePiece, underSleevePiece];
  }

  private _generateRaglanPieces(measurements: Measurements, category: Category, options?: { showMeasurements?: boolean; unit?: Unit }): PatternPiece[] {
    const { bust, shoulderWidth, sleeveLength, armCircumference } = measurements;
    const neckWidth = (bust / 20) + 2;
    const armholeDepth = (bust / 10) + (category === 'woman' ? 10.5 : 12);
    const raglanNeckPoint = { x: neckWidth / 2, y: 0 };
    const raglanArmholePoint = { x: (shoulderWidth/2) * 0.8, y: armholeDepth };
    
    // Front Bodice (Modified)
    const frontBodiceResult = this._generateBodice(measurements, true, category, options);
    const frontBodicePiece = frontBodiceResult.piece;
    frontBodicePiece.paths.push({d: `M ${raglanNeckPoint.x*this.scale} ${raglanNeckPoint.y*this.scale} L ${raglanArmholePoint.x*this.scale} ${raglanArmholePoint.y*this.scale}`, class: 'stroke-red-600 stroke-1 stroke-dasharray'});
    frontBodicePiece.paths.push({d:'', class: 'fill-gray-700 text-sm', label: 'كورساج أمامي (معدل)', x: 15, y:40});
    
    // Back Bodice (Modified)
    const backBodiceResult = this._generateBodice(measurements, false, category, options);
    const backBodicePiece = backBodiceResult.piece;
    backBodicePiece.paths.push({d: `M ${raglanNeckPoint.x*this.scale} ${raglanNeckPoint.y*this.scale} L ${raglanArmholePoint.x*this.scale} ${raglanArmholePoint.y*this.scale}`, class: 'stroke-red-600 stroke-1 stroke-dasharray'});
    backBodicePiece.paths.push({d:'', class: 'fill-gray-700 text-sm', label: 'كورساج خلفي (معدل)', x: 15, y:40});
    
    // Raglan Sleeve Piece
    const bicep = armCircumference + 5;
    const sleevePath = new PathBuilder().moveTo((bicep/2 - armCircumference/2)*this.scale, sleeveLength*this.scale).lineTo(0, armholeDepth*this.scale).lineTo((bicep/2 - (neckWidth - raglanNeckPoint.x))*this.scale, 0).lineTo((bicep/2 + (neckWidth - raglanNeckPoint.x))*this.scale, 0).lineTo(bicep*this.scale, armholeDepth*this.scale).lineTo((bicep/2 + armCircumference/2)*this.scale, sleeveLength*this.scale).closePath().build();
    const sleevePiece = { paths: [{d: sleevePath, class: 'stroke-teal-600 fill-teal-500/10 stroke-2'}, {d:'', class: 'fill-gray-700 text-sm', label: 'كم رجلان', x: 15, y:40}], width: bicep * this.scale, height: sleeveLength * this.scale };

    return [frontBodicePiece, backBodicePiece, sleevePiece];
  }
  
  private _formatDim(value: number, unit: Unit = 'cm'): string {
    if (unit === 'in') {
        return `${(value / 2.54).toFixed(2)} in`;
    }
    return `${value.toFixed(1)} سم`;
  }

  private _createDimension(
    x1: number, y1: number, // Point 1 on pattern
    x2: number, y2: number, // Point 2 on pattern
    offset: number,         // Distance of dimension line from pattern edge
    value: number,
    unit: Unit = 'cm'
  ): SvgPath[] {
    const scale = this.scale;
    const isHorizontal = Math.abs(y1 - y2) < 0.1;
    const paths: SvgPath[] = [];
    const label = this._formatDim(value, unit);

    // Scale all inputs before calculations
    x1 *= scale; y1 *= scale;
    x2 *= scale; y2 *= scale;
    offset *= scale;

    let p1Ext, p2Ext, textPos;
    const terminatorSize = 0.4 * scale;

    if (isHorizontal) {
      const y = y1 + offset;
      p1Ext = { x: x1, y };
      p2Ext = { x: x2, y };
      textPos = { x: (x1 + x2) / 2, y: y + (offset > 0 ? (0.8 * scale) : (-0.5 * scale)) };
    } else { // Vertical
      const x = x1 + offset;
      p1Ext = { x, y: y1 };
      p2Ext = { x, y: y2 };
      textPos = { x: x + (offset > 0 ? (0.5 * scale) : (-0.5 * scale)), y: (y1 + y2) / 2 };
    }

    const dimensionLine = new PathBuilder().moveTo(p1Ext.x, p1Ext.y).lineTo(p2Ext.x, p2Ext.y).build();
    const extensionLine1 = new PathBuilder().moveTo(x1, y1).lineTo(p1Ext.x, p1Ext.y).build();
    const extensionLine2 = new PathBuilder().moveTo(x2, y2).lineTo(p2Ext.x, p2Ext.y).build();
    
    const term1Path = isHorizontal 
      ? `M ${p1Ext.x},${p1Ext.y - terminatorSize} V ${p1Ext.y + terminatorSize}`
      : `M ${p1Ext.x - terminatorSize},${p1Ext.y} H ${p1Ext.x + terminatorSize}`;
      
    const term2Path = isHorizontal
      ? `M ${p2Ext.x},${p2Ext.y - terminatorSize} V ${p2Ext.y + terminatorSize}`
      : `M ${p2Ext.x - terminatorSize},${p2Ext.y} H ${p2Ext.x + terminatorSize}`;

    const dimClass = 'stroke-slate-500 stroke-1 fill-none';
    paths.push({ d: dimensionLine, class: dimClass });
    paths.push({ d: extensionLine1, class: 'stroke-slate-400 stroke-1' });
    paths.push({ d: extensionLine2, class: 'stroke-slate-400 stroke-1' });
    paths.push({ d: term1Path, class: dimClass });
    paths.push({ d: term2Path, class: dimClass });
    paths.push({ d: '', label: label, class: 'fill-slate-600 text-xs', x: textPos.x, y: textPos.y });

    return paths;
  }
  
  private _approximateBezierLength = (p0: {x:number, y:number}, p1: {x:number, y:number}, p2: {x:number, y:number}, p3: {x:number, y:number}): number => {
    const dist = (a: {x:number, y:number}, b: {x:number, y:number}) => Math.sqrt(Math.pow(a.x - b.x, 2) + Math.pow(a.y - b.y, 2));
    const chordLength = dist(p0, p3);
    const polylineLength = dist(p0, p1) + dist(p1, p2) + dist(p2, p3);
    return (chordLength + polylineLength) / 2;
  }
  
  // --- START: Specific generators for patterns from images ---
  private _generateZipPoloFromImage(): PatternPiece[] {
    const front = this._generateZipPoloFront();
    const back = this._generateZipPoloBack();
    const sleeve = this._generateZipPoloSleeve();
    const collar = this._generateZipPoloCollar();
    return [front, back, sleeve, collar];
  }

  private _generateZipPoloFront(): PatternPiece {
    const paths: SvgPath[] = [];
    const p = {
      cfHem: { x: 0, y: 54 },
      cfNeck: { x: 0, y: 8 },
      sideNeck: { x: 8.5, y: 0 },
      shoulderTip: { x: 14, y: 4 },
      armpit: { x: 25, y: 24 },
      sideHem: { x: 24.5, y: 54 },
    };

    const mainPath = new PathBuilder()
      .moveTo(p.cfHem.x * this.scale, p.cfHem.y * this.scale)
      .lineTo(p.cfNeck.x * this.scale, p.cfNeck.y * this.scale)
      .cubicCurveTo(4 * this.scale, 8 * this.scale, 8 * this.scale, 4 * this.scale, p.sideNeck.x * this.scale, p.sideNeck.y * this.scale)
      .lineTo(p.shoulderTip.x * this.scale, p.shoulderTip.y * this.scale)
      .cubicCurveTo(14.5 * this.scale, 14 * this.scale, 18 * this.scale, 24 * this.scale, p.armpit.x * this.scale, p.armpit.y * this.scale)
      .lineTo(p.sideHem.x * this.scale, p.sideHem.y * this.scale)
      .closePath()
      .build();

    paths.push({ d: mainPath, class: 'stroke-red-600 fill-red-500/10 stroke-2' });
    paths.push({ d: '', label: 'الأمام (x1)', class: 'fill-gray-700 text-lg font-bold', x: 12.5 * this.scale, y: 35 * this.scale });
    
    // Dimensions
    paths.push(...this._createDimension(0, 0, 0, 54, -2, 54));
    paths.push(...this._createDimension(0, 24, 25, 24, 15, 24));
    paths.push(...this._createDimension(0, 44, 0, 54, 3, 10));
    paths.push(...this._createDimension(0, 8, 0, 20, 3, 12));
    paths.push(...this._createDimension(0, 0, 8.5, 0, -2, 8.5));
    paths.push(...this._createDimension(8.5, 0, 14, 4, -2, 14));
    paths.push(...this._createDimension(0, 0, 25, 0, -4, 25));
    paths.push(...this._createDimension(0, 54, 24.5, 54, 2, 24.5));
    paths.push(...this._createDimension(0, 0, 0, 8, 2, 8));
    paths.push(...this._createDimension(14, 0, 14, 4, 3, 4));

    return { paths, width: 30 * this.scale, height: 60 * this.scale };
  }

  private _generateZipPoloBack(): PatternPiece {
    const paths: SvgPath[] = [];
    const p = {
      cbHem: { x: 0, y: 54 },
      cbNeck: { x: 0, y: 2 },
      sideNeck: { x: 8.5, y: 0 },
      shoulderTip: { x: 14, y: 4 },
      armpit: { x: 25, y: 24 },
      sideHem: { x: 25, y: 54 },
    };

    const mainPath = new PathBuilder()
      .moveTo(p.cbHem.x * this.scale, p.cbHem.y * this.scale)
      .lineTo(p.cbNeck.x * this.scale, p.cbNeck.y * this.scale)
      .quadraticCurveTo(4 * this.scale, 0, p.sideNeck.x * this.scale, p.sideNeck.y * this.scale)
      .lineTo(p.shoulderTip.x * this.scale, p.shoulderTip.y * this.scale)
      .cubicCurveTo(15 * this.scale, 12 * this.scale, 19 * this.scale, 24 * this.scale, p.armpit.x * this.scale, p.armpit.y * this.scale)
      .lineTo(p.sideHem.x * this.scale, p.sideHem.y * this.scale)
      .closePath()
      .build();

    paths.push({ d: mainPath, class: 'stroke-blue-600 fill-blue-500/10 stroke-2' });
    paths.push({ d: '', label: 'الخلف (x1 على ثنية)', class: 'fill-gray-700 text-lg font-bold', x: 12.5 * this.scale, y: 35 * this.scale });

    // Dimensions
    paths.push(...this._createDimension(0, 0, 0, 54, -2, 54));
    paths.push(...this._createDimension(0, 24, 25, 24, 15, 24));
    paths.push(...this._createDimension(0, 44, 0, 54, 3, 10));
    paths.push(...this._createDimension(0, 0, 8.5, 0, -3, 8.5));
    paths.push(...this._createDimension(8.5, 0, 14, 4, -2, 14));
    paths.push(...this._createDimension(0, 0, 25, 0, -5, 25));
    paths.push(...this._createDimension(0, 0, 0, 2, 2, 2));
    paths.push(...this._createDimension(14, 0, 14, 4, 3, 4));

    return { paths, width: 30 * this.scale, height: 60 * this.scale };
  }

  private _generateZipPoloSleeve(): PatternPiece {
    const paths: SvgPath[] = [];
    const p = {
      capTop: { x: 19, y: 0 },
      bicepLeft: { x: 0, y: 4 },
      bicepRight: { x: 38, y: 4 },
      hemLeft: { x: 6, y: 55 },
      hemRight: { x: 32, y: 55 },
    };

    const mainPath = new PathBuilder()
      .moveTo(p.hemLeft.x * this.scale, p.hemLeft.y * this.scale)
      .lineTo(p.bicepLeft.x * this.scale, p.bicepLeft.y * this.scale)
      .cubicCurveTo(5 * this.scale, -2 * this.scale, 12 * this.scale, 0, p.capTop.x * this.scale, p.capTop.y * this.scale) // Back Curve
      .cubicCurveTo(26 * this.scale, 0, 33 * this.scale, -1 * this.scale, p.bicepRight.x * this.scale, p.bicepRight.y * this.scale) // Front Curve
      .lineTo(p.hemRight.x * this.scale, p.hemRight.y * this.scale)
      .closePath()
      .build();

    paths.push({ d: mainPath, class: 'stroke-purple-600 fill-purple-500/10 stroke-2' });
    paths.push({ d: '', label: 'الكم (x2)', class: 'fill-gray-700 text-lg font-bold', x: 19 * this.scale, y: 30 * this.scale });
    paths.push({ d: '', label: 'الأمام', class: 'fill-gray-700 text-sm', x: 28 * this.scale, y: 15 * this.scale });
    paths.push({ d: '', label: 'الخلف', class: 'fill-gray-700 text-sm', x: 10 * this.scale, y: 15 * this.scale });

    // Dimensions
    paths.push(...this._createDimension(19, 0, 19, 55, 21, 55));
    paths.push(...this._createDimension(0, 4, 38, 4, -4, 38));
    paths.push(...this._createDimension(19, 0, 19, 4, -10, 4));
    paths.push(...this._createDimension(0, 55, 6, 55, 2, 6));
    paths.push(...this._createDimension(32, 55, 38, 55, 2, 6));
    
    // Curve guides
    const guideClass = 'stroke-slate-400 stroke-1 stroke-dasharray';
    paths.push({ d: new PathBuilder().moveTo(0, 4*this.scale).lineTo(19*this.scale, 4*this.scale).lineTo(19*this.scale, 0).build(), class: guideClass });
    paths.push({ d: new PathBuilder().moveTo(19*this.scale, 0).lineTo(19*this.scale, 4*this.scale).lineTo(38*this.scale, 4*this.scale).build(), class: guideClass });
    paths.push(...this._createDimension(19, 4, (19+7.5), 4, 3, 7.5));
    paths.push(...this._createDimension(p.bicepRight.x - 7.5, p.bicepRight.y, p.bicepRight.x, p.bicepRight.y, 3, 7.5));
    
    const frontCurveGuideY = p.bicepRight.y - 1.5;
    paths.push(...this._createDimension(p.bicepRight.x - 7.5, p.bicepRight.y, p.bicepRight.x - 7.5, frontCurveGuideY, 8, 1.5));

    const backCurveGuideY = p.bicepLeft.y - 2;
    paths.push(...this._createDimension(7.5, p.bicepLeft.y, 7.5, backCurveGuideY, -8, 2));

    return { paths, width: 42 * this.scale, height: 60 * this.scale };
  }

  private _generateZipPoloCollar(): PatternPiece {
    const paths: SvgPath[] = [];
    const p = {
      topFold: { x: 0, y: 0 },
      bottomFold: { x: 0, y: 7.5 },
      topPointStart: { x: 18, y: 0 }, // 21.5 - 3.5
      tip: { x: 21.5, y: 2 },
      bottomRight: { x: 21.5, y: 7.5 },
    };
    
    const mainPath = new PathBuilder()
      .moveTo(p.bottomFold.x * this.scale, p.bottomFold.y * this.scale)
      .lineTo(p.bottomRight.x * this.scale, p.bottomRight.y * this.scale)
      .lineTo(p.tip.x * this.scale, p.tip.y * this.scale)
      .lineTo(p.topPointStart.x * this.scale, p.topPointStart.y * this.scale)
      .lineTo(p.topFold.x * this.scale, p.topFold.y * this.scale)
      .closePath()
      .build();

    paths.push({ d: mainPath, class: 'stroke-green-600 fill-green-500/10 stroke-2' });
    paths.push({ d: '', label: 'الياقة (x2 على ثنية)', class: 'fill-gray-700 text-lg font-bold', x: 10 * this.scale, y: 4 * this.scale });

    // Dimensions
    paths.push(...this._createDimension(0, 0, 0, 7.5, -2, 7.5));
    paths.push(...this._createDimension(0, 7.5, 21.5, 7.5, 2, 21.5));
    paths.push(...this._createDimension(18, 0, 21.5, 0, -2, 3.5));
    paths.push(...this._createDimension(21.5, 0, 21.5, 2, 2, 2));

    return { paths, width: 25 * this.scale, height: 12 * this.scale };
  }
  
  private _generateUnisexHoodieFromImage(): PatternPiece[] {
    const mainClass = 'stroke-cyan-600 fill-cyan-500/10 stroke-2';
    const paths: SvgPath[] = [];

    // Front Piece
    const front = (() => {
        const p = { hemCF: {x:0, y:68}, neckCF: {x:0, y:9.5}, neckSide: {x:9, y:0}, shoulder: {x:20.5, y:2.5}, armpit: {x:27, y:26.5}, hemSide: {x:27, y:68} };
        const frontPath = new PathBuilder().moveTo(p.hemCF.x*this.scale, p.hemCF.y*this.scale).lineTo(p.neckCF.x*this.scale, p.neckCF.y*this.scale).quadraticCurveTo(p.neckSide.x/2*this.scale, p.neckSide.y/2*this.scale, p.neckSide.x*this.scale, p.neckSide.y*this.scale).lineTo(p.shoulder.x*this.scale, p.shoulder.y*this.scale).quadraticCurveTo(23*this.scale, 15*this.scale, p.armpit.x*this.scale, p.armpit.y*this.scale).lineTo(p.hemSide.x*this.scale, p.hemSide.y*this.scale).closePath().build();
        const frontPaths: SvgPath[] = [{ d: frontPath, class: mainClass }, {d:'', label: 'الأمام (x1)', class:'fill-gray-700 text-lg font-bold', x:15*this.scale, y:45*this.scale}];
        // Pocket
        const pocket = {p1:{x:21,y:49}, p2:{x:27-10.5, y:49}, p3:{x:27, y:49+19}, p4:{x:21, y:49+19}};
        const pocketPath = new PathBuilder().moveTo(pocket.p1.x*this.scale, pocket.p1.y*this.scale).lineTo(pocket.p2.x*this.scale, pocket.p2.y*this.scale).lineTo(pocket.p3.x*this.scale, pocket.p3.y*this.scale).lineTo(pocket.p4.x*this.scale, pocket.p4.y*this.scale).build();
        frontPaths.push({d: pocketPath, class:'stroke-cyan-800 stroke-1 stroke-dasharray'});
        // Dimensions
        frontPaths.push(...this._createDimension(0,0,27,0,-4,27)); frontPaths.push(...this._createDimension(0,0,0,68,-4,68)); frontPaths.push(...this._createDimension(0,0,9,0,-2,9)); frontPaths.push(...this._createDimension(0,0,0,9.5,2,9.5)); frontPaths.push(...this._createDimension(20.5,0,20.5,2.5,4,2.5));
        return { paths: frontPaths, width: 32*this.scale, height: 72*this.scale };
    })();

    // Back Piece
    const back = (() => {
        const p = { hemCB: {x:0, y:68}, neckCB: {x:0, y:2}, neckSide: {x:9, y:0}, shoulder: {x:20.5, y:2.5}, armpit: {x:27, y:26.5}, hemSide: {x:27, y:68} };
        const backPath = new PathBuilder().moveTo(p.hemCB.x*this.scale, p.hemCB.y*this.scale).lineTo(p.neckCB.x*this.scale, p.neckCB.y*this.scale).quadraticCurveTo(p.neckSide.x/2*this.scale, 0, p.neckSide.x*this.scale, p.neckSide.y*this.scale).lineTo(p.shoulder.x*this.scale, p.shoulder.y*this.scale).quadraticCurveTo(24*this.scale, 15*this.scale, p.armpit.x*this.scale, p.armpit.y*this.scale).lineTo(p.hemSide.x*this.scale, p.hemSide.y*this.scale).closePath().build();
        const backPaths: SvgPath[] = [{ d: backPath, class: mainClass }, {d:'', label: 'الخلف (x1 على ثنية)', class:'fill-gray-700 text-lg font-bold', x:12*this.scale, y:45*this.scale}];
        backPaths.push(...this._createDimension(0,0,27,0,-4,27)); backPaths.push(...this._createDimension(0,0,0,68,-4,68)); backPaths.push(...this._createDimension(0,0,9,0,-2,9)); backPaths.push(...this._createDimension(0,0,0,2,2,2));
        return { paths: backPaths, width: 32*this.scale, height: 72*this.scale };
    })();
    
    // Sleeve
    const sleeve = (() => {
        const sleevePath = new PathBuilder().moveTo(0, 56).lineTo(0, 7.5).quadraticCurveTo(9.5/2, 7.5 - 9.7, 9.5, 7.5).quadraticCurveTo(23, -5, 46, 7.5).lineTo(46, 56).closePath().build();
        const scaledPath = sleevePath.split(' ').map(s => isNaN(parseFloat(s)) ? s : parseFloat(s)*this.scale).join(' ');
        const sleevePaths: SvgPath[] = [{ d: scaledPath, class: mainClass }, {d:'', label: 'الكم (x2)', class:'fill-gray-700 text-lg font-bold', x:23*this.scale, y:30*this.scale}];
        sleevePaths.push(...this._createDimension(0,0,46,0,-2,46)); sleevePaths.push(...this._createDimension(0,0,0,56,-4,56));
        return { paths: sleevePaths, width: 50*this.scale, height: 60*this.scale };
    })();
    
    // Hood
    const hood = (() => {
        const hoodPath = new PathBuilder().moveTo(5.5, 33).lineTo(0, 33).lineTo(0,10).quadraticCurveTo(10,0, 29, 10).lineTo(29, 33-7.5).quadraticCurveTo(29-10, 33, 5.5, 33).closePath().build();
        const scaledPath = hoodPath.split(' ').map(s => isNaN(parseFloat(s)) ? s : parseFloat(s)*this.scale).join(' ');
        const hoodPaths: SvgPath[] = [{ d: scaledPath, class: mainClass }, {d:'', label: 'الكابيشون (x2)', class:'fill-gray-700 text-lg font-bold', x:15*this.scale, y:20*this.scale}];
        hoodPaths.push(...this._createDimension(0,10,29,10,-2,29)); hoodPaths.push(...this._createDimension(0,0,0,33,-2,33));
        return { paths: hoodPaths, width: 33*this.scale, height: 37*this.scale };
    })();

    return [front, back, sleeve, hood];
  }

  private _generateLabCoatFromImage(): PatternPiece[] {
      const mainClass = 'stroke-indigo-600 fill-indigo-500/10 stroke-2';
      // Front
      const front = (() => {
          const p = { hemCF:{x:0, y:92}, neckCF:{x:0,y:7.5}, neckSide:{x:7,y:0}, shoulder:{x:14,y:4}, armpit:{x:22.5,y:21}, hemSide:{x:22.5+2,y:92} };
          const path = new PathBuilder().moveTo(p.hemCF.x*this.scale,p.hemCF.y*this.scale).lineTo(p.neckCF.x*this.scale, p.neckCF.y*this.scale).quadraticCurveTo(3*this.scale, 3*this.scale, p.neckSide.x*this.scale, p.neckSide.y*this.scale).lineTo(p.shoulder.x*this.scale,p.shoulder.y*this.scale).quadraticCurveTo(18*this.scale, 15*this.scale, p.armpit.x*this.scale, p.armpit.y*this.scale).lineTo(p.hemSide.x*this.scale, p.hemSide.y*this.scale).closePath().build();
          const paths: SvgPath[] = [{d:path, class: mainClass}, {d:'', label:'الأمام (x2)', class:'fill-gray-700 text-lg font-bold', x:12*this.scale, y:50*this.scale}];
          paths.push(...this._createDimension(0,0,22.5,0,-4, 22.5)); paths.push(...this._createDimension(0,0,0,92,-4, 92));
          // Pockets
          const chestPocket = new PathBuilder().moveTo(4*this.scale, (21+4)*this.scale).lineTo(15*this.scale, (21+4)*this.scale).lineTo(15*this.scale,(21+4+13)*this.scale).lineTo(4*this.scale,(21+4+13)*this.scale).closePath().build();
          const hipPocket = new PathBuilder().moveTo(2*this.scale, (92-2-20)*this.scale).lineTo((2+20)*this.scale, (92-2-20)*this.scale).lineTo((2+20)*this.scale, (92-2)*this.scale).lineTo(2*this.scale, (92-2)*this.scale).closePath().build();
          paths.push({d:chestPocket, class: 'stroke-indigo-800 stroke-1 stroke-dasharray'}); paths.push({d:hipPocket, class: 'stroke-indigo-800 stroke-1 stroke-dasharray'});
          return { paths, width: 30*this.scale, height: 96*this.scale };
      })();
      // Back
      const back = (() => {
          const p = { hemCB:{x:0, y:92}, neckCB:{x:0,y:2}, neckSide:{x:7,y:0}, shoulder:{x:14,y:4}, armpit:{x:22.5,y:21}, hemSide:{x:22.5+2,y:92} };
          const path = new PathBuilder().moveTo(p.hemCB.x*this.scale,p.hemCB.y*this.scale).lineTo(p.neckCB.x*this.scale, p.neckCB.y*this.scale).quadraticCurveTo(3*this.scale, 0, p.neckSide.x*this.scale, p.neckSide.y*this.scale).lineTo(p.shoulder.x*this.scale,p.shoulder.y*this.scale).quadraticCurveTo(18*this.scale, 15*this.scale, p.armpit.x*this.scale, p.armpit.y*this.scale).lineTo(p.hemSide.x*this.scale, p.hemSide.y*this.scale).closePath().build();
          const paths: SvgPath[] = [{d:path, class: mainClass}, {d:'', label:'الخلف (x1 على ثنية)', class:'fill-gray-700 text-lg font-bold', x:12*this.scale, y:50*this.scale}];
          paths.push(...this._createDimension(0,0,22.5,0,-4, 22.5)); paths.push(...this._createDimension(0,0,0,92,-4, 92));
          return { paths, width: 30*this.scale, height: 96*this.scale };
      })();
      // Sleeve, Collar
      const sleeve = {paths:[], width: 40*this.scale, height: 56*this.scale};
      const collar = {paths:[], width: 24*this.scale, height: 8*this.scale};
      return [front, back, sleeve, collar];
  }
  
  private _generateTshirtFromImage(): PatternPiece[] {
    const mainClass = 'stroke-teal-600 fill-teal-500/10 stroke-2';
    // Body
    const body = (() => {
      const p = { hem:{x:0, y:68}, neckDrop: {x:0, y:9}, neckSide:{x:9, y:0}, shoulder:{x:15, y:4}, armpit:{x:26, y:29}, sideHem:{x:26, y:68}};
      const path = new PathBuilder().moveTo(p.hem.x*this.scale, p.hem.y*this.scale).lineTo(p.neckDrop.x*this.scale, p.neckDrop.y*this.scale).quadraticCurveTo(4*this.scale,4*this.scale, p.neckSide.x*this.scale,p.neckSide.y*this.scale).lineTo(p.shoulder.x*this.scale,p.shoulder.y*this.scale).quadraticCurveTo(20*this.scale, 20*this.scale, p.armpit.x*this.scale,p.armpit.y*this.scale).lineTo(p.sideHem.x*this.scale,p.sideHem.y*this.scale).closePath().build();
      const paths: SvgPath[] = [{d:path, class:mainClass}, {d:'', label:'الجسم (x2 على ثنية)', class:'fill-gray-700 text-lg font-bold', x:13*this.scale, y:45*this.scale}];
      paths.push(...this._createDimension(0,0,26,0,-4,26)); paths.push(...this._createDimension(0,0,0,68,-4,68));
      return {paths, width:30*this.scale, height:72*this.scale};
    })();
    // Sleeve
    const sleeve = (() => {
      const p = { top:{x:21, y:0}, bL:{x:0, y:7}, bR:{x:42, y:7}, hL:{x:1, y:22}, hR:{x:41, y:22} };
      const path = new PathBuilder().moveTo(p.hL.x*this.scale, p.hL.y*this.scale).lineTo(p.bL.x*this.scale, p.bL.y*this.scale).quadraticCurveTo(p.top.x*this.scale, -4.5*this.scale, p.bR.x*this.scale, p.bR.y*this.scale).lineTo(p.hR.x*this.scale, p.hR.y*this.scale).closePath().build();
      const paths: SvgPath[] = [{d:path, class: mainClass}, {d:'', label:'الكم (x2)', class:'fill-gray-700 text-lg font-bold', x:21*this.scale, y:15*this.scale}];
      paths.push(...this._createDimension(0,7,42,7,-4,42)); paths.push(...this._createDimension(21,0,21,22,23,22));
      return {paths, width:46*this.scale, height:26*this.scale};
    })();

    return [body, sleeve];
  }

  private _generateMensSocialPantsFromImage(): PatternPiece[] {
    const mainClass = 'stroke-blue-600 fill-blue-500/10 stroke-2';
    // Front
    const front = (() => {
      const p = {wS:{x:0,y:4}, wC:{x:20,y:0}, cP:{x:24.5,y:22.5}, hS:{x:0,y:96}, hC:{x:21,y:96}};
      const path = new PathBuilder().moveTo(p.hS.x*this.scale,p.hS.y*this.scale).lineTo(p.wS.x*this.scale,p.wS.y*this.scale).lineTo(p.wC.x*this.scale,p.wC.y*this.scale).lineTo(p.cP.x*this.scale, p.cP.y*this.scale).quadraticCurveTo(23*this.scale, 50*this.scale, p.hC.x*this.scale,p.hC.y*this.scale).closePath().build();
      const paths: SvgPath[] = [{d:path, class: mainClass}, {d:'', label:'الأمام (x2)', class:'fill-gray-700 text-lg font-bold', x:12*this.scale, y:60*this.scale}];
      paths.push(...this._createDimension(0,0,0,96,-4,96)); paths.push(...this._createDimension(4.5,0,24.5,0,-4,24.5));
      return {paths, width:30*this.scale, height:100*this.scale};
    })();
    // Back
    const back = (() => {
      const p = {wS:{x:0,y:0}, wC:{x:23,y:0}, cP:{x:24.5+3,y:22.5}, hS:{x:0,y:96}, hC:{x:24,y:96}};
      const dart = {l1:{x:12,y:0}, tip:{x:12, y:12}, l2:{x:14, y:0}};
      const path = new PathBuilder().moveTo(p.hS.x*this.scale,p.hS.y*this.scale).lineTo(p.wS.x*this.scale,p.wS.y*this.scale).lineTo(dart.l1.x*this.scale, dart.l1.y*this.scale).lineTo(dart.tip.x*this.scale, dart.tip.y*this.scale).lineTo(dart.l2.x*this.scale, dart.l2.y*this.scale).lineTo(p.wC.x*this.scale,p.wC.y*this.scale).quadraticCurveTo(28*this.scale, 10*this.scale, p.cP.x*this.scale, p.cP.y*this.scale).quadraticCurveTo(26*this.scale, 50*this.scale, p.hC.x*this.scale,p.hC.y*this.scale).closePath().build();
      const paths: SvgPath[] = [{d:path, class: mainClass}, {d:'', label:'الخلف (x2)', class:'fill-gray-700 text-lg font-bold', x:12*this.scale, y:60*this.scale}];
      paths.push(...this._createDimension(0,0,0,96,-4,96)); paths.push(...this._createDimension(0,0,24.5,0,-4,24.5));
      return {paths, width:32*this.scale, height:100*this.scale};
    })();

    return [front, back];
  }
  // --- END: Specific generators ---
}