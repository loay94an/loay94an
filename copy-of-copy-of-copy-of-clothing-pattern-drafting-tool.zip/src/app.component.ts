
import { Component, ChangeDetectionStrategy, signal, computed } from '@angular/core';
import { trigger, transition, style, animate } from '@angular/animations';
import { CommonModule } from '@angular/common';

import { Category, Measurements, PatternModel } from './models/pattern.model';

import { CategorySelectorComponent } from './components/category-selector/category-selector.component';
import { ModelSelectorComponent } from './components/model-selector/model-selector.component';
import { MeasurementsComponent } from './components/measurements/measurements.component';
import { PatternViewerComponent } from './components/pattern-viewer/pattern-viewer.component';
import { CustomDesignComponent } from './components/custom-design/custom-design.component';
import { AiDesignComponent } from './components/ai-design/ai-design.component';
import { ChildGenderSelectorComponent } from './components/child-gender-selector/child-gender-selector.component';
import { OnlineSearchComponent } from './components/online-search/online-search.component';
import { BodyShapeSelectorComponent } from './components/body-shape-selector/body-shape-selector.component';
import { PatternDraftingComponent } from './components/pattern-drafting/pattern-drafting.component';

type WizardStep = 'intro' | 'category' | 'child-gender' | 'model' | 'customDesign' | 'aiDesign' | 'onlineSiteChoice' | 'measurements' | 'pattern' | 'drafting';

const slideTransition = trigger('slide', [
  transition(':enter', [
    style({ opacity: 0, transform: 'translateX(20px)' }),
    animate('0.4s cubic-bezier(0.25, 0.8, 0.25, 1)', style({ opacity: 1, transform: 'translateX(0)' }))
  ])
]);

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    CategorySelectorComponent,
    ModelSelectorComponent,
    MeasurementsComponent,
    PatternViewerComponent,
    CustomDesignComponent,
    AiDesignComponent,
    ChildGenderSelectorComponent,
    OnlineSearchComponent,
    BodyShapeSelectorComponent,
    PatternDraftingComponent,
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
  animations: [
    slideTransition
  ]
})
export class AppComponent {
  currentStep = signal<WizardStep>('intro');
  
  selectedCategory = signal<Category | null>(null);
  selectedChildGender = signal<'boy' | 'girl' | null>(null);
  selectedModel = signal<PatternModel | null>(null);
  finalMeasurements = signal<Measurements | null>(null);
  
  startWizard(): void {
    this.currentStep.set('category');
  }

  startImageDesign(): void {
    this.currentStep.set('customDesign');
  }
  
  startAiDesign(): void {
    this.currentStep.set('aiDesign');
  }

  startOnlineSearch(): void {
    this.currentStep.set('onlineSiteChoice');
  }

  startDrafting(): void {
    this.currentStep.set('drafting');
  }

  onCategorySelected(category: Category): void {
    this.selectedCategory.set(category);
    if (category === 'child') {
      this.currentStep.set('child-gender');
    } else {
      this.currentStep.set('model');
    }
  }

  onChildGenderSelected(gender: 'boy' | 'girl'): void {
    this.selectedChildGender.set(gender);
    this.currentStep.set('model');
  }

  onModelSelected(model: PatternModel): void {
    this.selectedModel.set(model);
    if (model.requiredMeasurements.length === 0) {
      // This is a ready-made pattern, skip measurements step.
      this.finalMeasurements.set({
        bust: 90, waist: 72, hips: 98, shoulderWidth: 40, pieceLength: 60, // Using M size as a base for display
        sleeveLength: 59, armCircumference: 30, inlegLength: 78, waistToFloor: 106, 
        shoulderToCrotch: 76, sleevePuffRatio: 1.5, neckCircumference: 37
      });
      this.currentStep.set('pattern');
    } else {
      // This is a dynamic pattern, go to measurements step.
      this.currentStep.set('measurements');
    }
  }
  
  onAnalysisComplete(model: PatternModel): void {
    this.selectedCategory.set(model.category); // Set category from AI analysis
    this.selectedModel.set(model);
    this.currentStep.set('measurements');
  }

  onMeasurementsReady(measurements: Measurements): void {
    this.finalMeasurements.set(measurements);
    this.currentStep.set('pattern');
  }

  goBack(): void {
    const current = this.currentStep();
    switch (current) {
      case 'pattern':
        const model = this.selectedModel();
        if (model?.requiredMeasurements.length === 0) {
            this.currentStep.set('model');
        } else {
            this.currentStep.set('measurements');
        }
        break;
      case 'measurements':
        const selectedModel = this.selectedModel();
        if (selectedModel?.id.startsWith('custom-') || selectedModel?.id.startsWith('ai-') || selectedModel?.id.startsWith('online-')) {
          this.reset(); // On AI flows, back from measurements is a reset.
        } else {
          this.currentStep.set('model');
        }
        break;
      case 'model':
        this.currentStep.set(this.selectedCategory() === 'child' ? 'child-gender' : 'category');
        break;
      case 'child-gender':
        this.currentStep.set('category');
        break;
      case 'category':
      case 'customDesign':
      case 'aiDesign':
      case 'onlineSiteChoice':
      case 'drafting':
        this.reset();
        break;
    }
  }

  reset(): void {
    this.currentStep.set('intro');
    this.selectedCategory.set(null);
    this.selectedChildGender.set(null);
    this.selectedModel.set(null);
    this.finalMeasurements.set(null);
  }
}