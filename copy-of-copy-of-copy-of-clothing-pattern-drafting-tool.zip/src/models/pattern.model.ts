
export type Category = 'woman' | 'man' | 'child';
export type Unit = 'cm' | 'in';

export interface PatternModel {
  id: string;
  name: string;
  category: Category;
  gender?: 'boy' | 'girl';
  imageUrl: string;
  difficulty: 'سهل' | 'متوسط' | 'صعب' | 'احترافي';
  requiredMeasurements: (keyof Measurements)[];
  // FIX: Added 'darted' to sleeveType to support darted sleeves in the pattern service.
  sleeveType?: 'basic' | 'puff' | 'twopiece' | 'raglan' | 'kimono' | 'darted' | null;
  collarType?: 'stand' | 'mandarin' | 'shawl' | 'notch' | null;
  // FIX: Added 'darted' to availableSleeveTypes to allow models to specify it as an option.
  availableSleeveTypes?: ('basic' | 'puff' | 'twopiece' | 'darted')[];
}

export interface Measurements {
  bust: number;
  waist: number;
  hips: number;
  shoulderWidth: number;
  pieceLength: number;
  sleeveLength: number;
  armCircumference: number;
  inlegLength: number;
  waistToFloor: number;
  shoulderToCrotch: number;
  sleevePuffRatio?: number;
  neckCircumference?: number;
}

export interface StandardSize {
  name: string;
  numericSize: string;
  measurements: Measurements;
}

export interface SvgPath {
  d: string;
  class: string;
  label?: string;
  x?: number;
  y?: number;
}

export interface PatternData {
  paths: SvgPath[];
  width: number;
  height: number;
}