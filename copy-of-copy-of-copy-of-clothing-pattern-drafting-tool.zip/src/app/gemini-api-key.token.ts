
import { InjectionToken } from '@angular/core';

export const GEMINI_API_KEY = new InjectionToken<string>('GEMINI_API_KEY');
